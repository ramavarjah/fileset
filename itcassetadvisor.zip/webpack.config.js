const webpack = require("webpack");
const path = require("path");
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");

const extractCSS = new ExtractTextPlugin("[name].fonts.css");
const extractSCSS = new ExtractTextPlugin("[name].styles.css");
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer")
    .BundleAnalyzerPlugin;
// const ShakePlugin = require('webpack-common-shake').Plugin;
const ReplaceCSSUrlPlugin = require("webpack-plugin-replace-css-url");
const DotenvWP = require("dotenv-webpack");
const dotenv = require("dotenv").config();

if (dotenv.error) {
    throw dotenv.error;
}

const { PROXY_TARGET } = dotenv.parsed;

const BUILD_DIR = path.resolve(__dirname, "build");
const SRC_DIR = path.resolve(__dirname, "src");

//console.log('BUILD_DIR', BUILD_DIR);
//console.log('SRC_DIR', SRC_DIR);

function relayRequestHeaders(proxyReq, req) {
    console.log("💥💥💥 request 💥💥💥");
    Object.keys(req.headers).forEach(key => {
        console.log(`--->${key}: ${req.headers[key]}`);
        proxyReq.setHeader(key, req.headers[key]);
    });
}

function relayResponseHeaders(proxyRes, req, res) {
    console.log("💥💥💥 response 💥💥💥");
    Object.keys(proxyRes.headers).forEach(key => {
    // console.log(`${key}: ${proxyRes.headers[key]}`);
        res.append(key, proxyRes.headers[key]);
    });
}

module.exports = (env = {}) => {
    let module = {
        entry: {
            app: ["babel-polyfill", "react-hot-loader/patch", SRC_DIR + "/index.js"]
        },
        output: {
            path: BUILD_DIR,
            filename: "[name].bundle.js",
            publicPath: '/'
        },
        resolve: {
            alias: {
                src: path.resolve(__dirname, "src")
            }
        },
        // watch: true,
        devtool: env.prod ? "" : "cheap-module-eval-source-map",
        // devtool: env.prod ? 'source-map' : 'cheap-module-eval-source-map',
        devServer: {
            contentBase: BUILD_DIR,
            //   port: 9001,
            compress: true,
            hot: true,
            // open: true,
            historyApiFallback: true,
            proxy: {
                "/Thingworx": {
                    target: PROXY_TARGET,
                    secure: false,
                    logLevel: "debug",
                    onProxyReq: relayRequestHeaders,
                    onProxyRes: relayResponseHeaders
                },
                "/secureAccess": {
                    target: PROXY_TARGET,
                    secure: false,
                    logLevel: "debug",
                    onProxyReq: relayRequestHeaders,
                    onProxyRes: relayResponseHeaders
                },
                "/Keysight": {
                    target: PROXY_TARGET,
                    secure: false,
                    logLevel: "debug",
                    onProxyReq: relayRequestHeaders,
                    onProxyRes: relayResponseHeaders
                }
            }
        },
        module: {
            rules: [
                { enforce: "pre", test: /\.js$/, loader: "eslint-loader", exclude: /node_modules/, options: { failOnError: false, failOnWarning: false } },
                {
                    test: /\.(js|jsx)$/,
                    exclude: /node_modules/,
                    use: {
                        loader: "babel-loader",
                        options: {
                            cacheDirectory: true,
                            plugins: [
                                "transform-decorators-legacy",
                                "transform-object-rest-spread"
                            ],
                            presets: [["es2015", { modules: false }], "react", "stage-1"]
                        }
                    }
                },
                {
                    test: /\.html$/,
                    loader: "html-loader"
                },
                {
                    test: /\.(scss)$/,
                    use: ["css-hot-loader"].concat(
                        extractSCSS.extract({
                            fallback: "style-loader",
                            use: [
                                {
                                    loader: "css-loader",
                                    options: { alias: { "../img": "../public/img" } }
                                },
                                {
                                    loader: "sass-loader"
                                }
                            ]
                        })
                    )
                },
                {
                    test: /\.css$/,
                    use: extractCSS.extract({
                        fallback: "style-loader",
                        use: "css-loader"
                    })
                },
                {
                    test: /\.(png|jpg|jpeg|gif|ico)$/,
                    use: [
                        {
                            // loader: 'url-loader'
                            loader: "file-loader",
                            options: {
                                name: "./img/[name].[hash].[ext]"
                            }
                        }
                    ]
                },
                {
                    test: /\.(pdf)$/,
                    use: [
                        {
                            // loader: 'url-loader'
                            loader: "file-loader",
                            options: {
                                name: "./files/[name].[hash].[ext]"
                            }
                        }
                    ]
                },
                {
                    test: /\.(woff(2)?|ttf|eot|svg)(\?v=\d+\.\d+\.\d+)?$/,
                    loader: "file-loader",
                    options: {
                        name: "./fonts/[name].[hash].[ext]"
                    }
                }
            ]
        },
        plugins: [
            new webpack.HotModuleReplacementPlugin(),
            new webpack.NamedModulesPlugin(),
            extractCSS,
            extractSCSS,
            // new ShakePlugin(),
            new ReplaceCSSUrlPlugin({
                replace: (url, file) => {
                    var prefix = "../".repeat(file.split("/").length - 1) || "./";
                    var match = /(?:https?:)\/\/at.alicdn.com\/t\/\w+.([^.]+)/.exec(url);
                    console.log("***********csssss", file, url);
                    return match ? prefix + "antd/t" + match[1] : url;
                }
            }),
            new HtmlWebpackPlugin({
                inject: true,
                template: "./public/index.html"
            }),
            new CopyWebpackPlugin(
                [
                    { from: "./public/img", to: "img" },
                    { from: "./public/antd", to: "antd" },
                    { from: "./public/amcharts", to: "amcharts" },
                    { from: "./public/locales", to: "locales" },
                    { from: "./public/WEB-INF", to: "WEB-INF" },
                    { from: "./public/files", to: "files" }
                ],
                { copyUnmodified: false }
            ),
            new DotenvWP()
        ]
    };

    if (env.prod) {
        module.plugins.push(
            new webpack.optimize.UglifyJsPlugin({
                sourceMap: false,
                parallel: true,
                compress: {
                    drop_console: true
                }
            })
        );
        module.plugins.push(
            new webpack.DefinePlugin({
                "process.env": { NODE_ENV: `"production"` }
            })
        );
    }

    env.analyzer ? module.plugins.push(new BundleAnalyzerPlugin()) : "";
    return module;
};
