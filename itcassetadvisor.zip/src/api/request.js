import axios from "axios";
import URL from "./Urls";
import userStore from "../stores/userStore";
import addAssetsStore from "../stores/addAssetsStore";
import permissionStore from "../stores/permissionStore";
import tabModelStore from "../stores/tabModelStore";
import UIFunctions from "../helpers/UIFunctions";

let timeout = 60 * 60 * 1000 - 10;

/**
 * Create an Axios Client with defaults
 */
var client = axios.create({
    baseURL: URL.hostUrl
});

export const isSessionValid = () => {
    var lastLogin = localStorage.getItem("lastLogggedAt");
    var d = new Date();
    var n = d.getTime();
    var diff = n - lastLogin;

    // check userid is valid and lastlogin within 60 minutes
    if (localStorage.getItem("user") && diff > timeout) {
        userStore.setMe(null); //todo change to token¸
        userStore.setLogout(); //todo change to token
        tabModelStore.clearStore();
        permissionStore.clearPermissions();
        addAssetsStore.clearStore();
        UIFunctions.Toast(
            "Session Expired \n Please re-login to renew your session.",
            "error"
        );
        // console.log("session expired");
        return false;
    } else return true;
};

/**
 * Request Wrapper with default success/error actions
 */
const request = function(options) {
    const onSuccess = function(response) {
    //signOut();
    //console.debug('Request Successful!', response);
        return response;
    };

    const onError = function(error) {
    // console.error("Request Failed:", error.config);

        if (error.response) {
            // Request was made but server responded with something
            // other than 2xx
            /* console.error('Status:', error.response.status);
       console.error('Data:', error.response.data);
       console.error('Headers:', error.response.headers);*/
        } else {
            // Something else happened while setting up the request
            // triggered the error
            // console.error("Error Message:", error.message);
        }
        //signOut();
        return Promise.reject(error.response || error.message);
    };

    var lastLogin = localStorage.getItem("lastLogggedAt");
    var d = new Date();
    var n = d.getTime();
    var diff = n - lastLogin;

    // console.log(localStorage.getItem("user"), diff, localStorage.getItem("user") && diff > 20000);

    // check userid is valid and lastlogin within 60 minutes
    if (localStorage.getItem("user") && diff > timeout) {
        let p1 = new Promise(resolve => {
            resolve("success");
        });
        return p1.then(() => {
            userStore.setMe(null); //todo change to token¸
            userStore.setLogout(); //todo change to token
            tabModelStore.clearStore();
            permissionStore.clearPermissions();
            addAssetsStore.clearStore();
            return UIFunctions.Toast(
                "Session Expired \n Please re-login to renew your session.",
                "error"
            );
        });
    } else {
        localStorage.setItem("lastLogggedAt", n);
        return client(options)
            .then(onSuccess)
            .catch(onError);
    }
};

export default request;
