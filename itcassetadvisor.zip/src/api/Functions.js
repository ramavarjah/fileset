import request from "./request";
import URL from "./Urls";
import UIFunctions from "./../helpers/UIFunctions";

const onSuccess = function(response) {
  //console.debug('Request Successful!', response);
  return response;
};

const onError = function(error) {
  if (error.response) {
    // Request was made but server responded with something
    // other than 2xx
    // console.error("Status:", error.response.status);
    // console.error("Data:", error.response.data);
    UIFunctions.Toast(error.response.message, "error");
    // console.error("Headers:", error.response.headers);
  } else {
    // Something else happened while setting up the request
    // triggered the error
    // console.error("Error Message:", error.message);
    UIFunctions.Toast(error.message, "error");
  }

  return Promise.reject(error.response || error.message);
};
/**
 * Request Wrapper with default success/error actions
 */
export const GetUserTab = function() {
  const options = {
    method: "post",
    url: URL.userTabs
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetGridDataModel = function(tabId) {
  const options = {
    method: "post",
    url: URL.assetGridColumns,
    data: {
      TabId: tabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetGridData = function(TabId, limit, page, start) {
  const options = {
    method: "post",
    url: URL.assetDetails,
    data: {
      TabId: TabId,
      limit: limit,
      page: page,
      start: start
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const spotfireSignout = function() {
  const options = {
    method: "get",
    url: URL.spotfireSignout
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const spotfireAuth = function(userName) {
  const options = {
    method: "post",
    url: URL.spotfireAuth,
    data: { params: window.btoa(userName) }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetCompleteGridData = function(TabId) {
  const options = {
    method: "post",
    url: URL.assetDetailsComplete,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const SetActiveTab = function(value) {
  const options = {
    method: "post",
    url: URL.setActiveTab,
    data: {
      TabId: value
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const SetDisplayDensity = function(DisplayDensity, TabId) {
  const options = {
    method: "post",
    url: URL.SetDisplayDensity,
    data: {
      DisplayDensity: DisplayDensity,
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const SetPagination = function(CurrentLimit, TabId) {
  const options = {
    method: "post",
    url: URL.SetPagination,
    data: {
      Pagination: CurrentLimit,
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetPageWiseDropDownValue = function(pageName = "CreateAsset") {
  const options = {
    method: "post",
    url: URL.assetDropdownValues,
    data: {
      PageName: pageName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetOrgs = function() {
  const options = {
    method: "post",
    url: URL.organizationDetails
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetOotCaseNumberSequence = function() {
  const options = {
    method: "post",
    url: URL.ootCaseSequence
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetEquipmentNumberSequence = function() {
  const options = {
    method: "post",
    url: URL.equipmentNumberSequence
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetOrganizationTree = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.userOrganizationDetails,
    data: {
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetLocationTree = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.locationDetails,
    data: {
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
// customerAssets
export const GetCustomerAssets = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.customerAssets,
    data: {
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
// customerAssets
export const CreateAsset = function(json) {
  const options = {
    method: "post",
    url: URL.createAsset,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
// ValidateEquipmentNumber
export const ValidateEquipmentNumber = function(EquipmentNumber) {
  const options = {
    method: "post",
    url: URL.validateEquipmentNumber,
    data: {
      EquipmentNumber: EquipmentNumber
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const ValidateOotCaseNumber = function(CaseNumber) {
  const options = {
    method: "post",
    url: URL.validateOotCaseNumber,
    data: {
      CaseNumber: CaseNumber
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
// GetTemplates
export const GetTemplates = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.templateDetails,
    data: {
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// Create New Tab
// payload : TabName (as string)
// sample response {"success":true,"message":"Tab Test1 created successfully","TabId":"10a59a51-b676-44fd-a6a4-9859d9743d7e"}
export const CreateUserTab = function(TabName) {
  const options = {
    method: "post",
    url: URL.createNewTab,
    data: {
      TabName: TabName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : Name ,TabId (as string)DeleteTab
// sample response {"success":true}
export const RenameTab = function(Name, TabId) {
  const options = {
    method: "post",
    url: URL.renameTab,
    data: {
      TabId: TabId,
      Name: Name
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : TabId (as string)
// sample response {"success":true}
export const DeleteTab = function(TabId) {
  const options = {
    method: "post",
    url: URL.deleteTab,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : null
// sample response {"success":true,"tabs":[{"baseQuery":{},"TabOrder":1,"Active":false,"SortedColumns":[],"TabName":"Tab-1","TabId":"84b7d1e9-f8a1-4e13-a3f7-e44afdf7c8c5"},{"baseQuery":{},"TabOrder":2,"Active":true,"SortedColumns":[],"TabName":"test3","TabId":"885fcd30-22c6-4cda-919a-e3120f9d4096"}]}
export const GetUserTabs = function() {
  const options = {
    method: "post",
    url: URL.userTabs
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

/*Asset Details*/
// payload : ThingName (as string)
// sample response {"data":{"ParentSystemName":"","UniqueID":"11_10000011","UtilizationCategory":"","LastUpdate":"1970-01-01T00:00:00.000Z","AssetNo":"32121","BorrowereReturnDate":"2017-10-09T10:21:21.016Z","OrderNumber":"","LifeCycleStage":"","UseProviderCalibrationType":false,"History":"[{\"Description\":\"Asset number changed from ' ' to 32121\",\"Timestamp\":\"2017-10-09T10:21:20.980Z\",\"Property\":\"AssetNo\",\"EditedBy\":\"11-Admin\"},{\"Description\":\"Barcode/RFID changed from ' ' to Ba3sd\",\"Timestamp\":\"2017-10-09T10:21:20.994Z\",\"Property\":\"Barcode\",\"EditedBy\":\"11-Admin\"}]","UseProviderCalibrationSchedule":false,"EquipmentType":"","RepairProvider":"","ServiceAgreement":"","ReplacedBy":"","CalibrationProvider":"","Currency":"","ServiceInterval":0,"Manufacturer":"Agilent Technologies Inc","BorrowerStartDate":"2017-10-09T10:21:21.016Z","InvoiceNumber":"","PlannedDisposalDate":"1970-01-01T00:00:00.000Z","AltManufacturerName":"","Status":"","InventoryDate":"1970-01-01T00:00:00.000Z","SerialNo":"35145","ServiceEndDate":"1970-01-01T00:00:00.000Z","HealthStatus":"","SoftwareRevision":"","homeMashup":"","WorkFlowState":"","HardwareVersion":"","LastReportedCondition":"","tags":[{"vocabulary":"ITC-DEV","vocabularyTerm":"BatchImport"},{"vocabulary":"ITC-DEV","vocabularyTerm":"KeysightData"},{"vocabulary":"Keysight-Customer","vocabularyTerm":"11"}],"Depreciation":0.0,"ReceivedDate":"1970-01-01T00:00:00.000Z","Barcode":"Ba3sd","OrganizationUnit":"","name":"11_10000011","ProductCategory":"","OwnershipStatus":"","Options":"","LoanpoolStatus":"Available","Description":"","Organization":"ITC test customer org > IDES","User":"","SystemParent":false,"BookValueDate":"1970-01-01T00:00:00.000Z","description":"","ReplacementDate":"1970-01-01T00:00:00.000Z","PurchasePrice":0.0,"PartOfSystemCalibration":false,"Information":{"OS":[],"SCPI":[]},"CalibrationDate":"1970-01-01T00:00:00.000Z","isSystemObject":false,"Accessories":"","AssetLocation":{"latitude":0.0,"longitude":0.0,"elevation":0.0,"defaultValue":true},"SystemChild":false,"RemoteThing":"11_10000011-EMS","ServiceStartDate":"1970-01-01T00:00:00.000Z","SystemComponents":"","SystemName":"","DepreciationRateInNoOfYear":0.0,"EquipmentNo":"10000011","Borrowable":false,"IsUtilization":false,"OwningCompany":"","ServiceDueDate":"1970-01-01T00:00:00.000Z","Borrower":"","ServiceLogistics":"","Request":"","thingName":"11_10000011","avatar":"/Thingworx/Things/11_10000011/Avatar","Coordinator":"muzahidh.m@gmail.com","RequestorEmail":"","OrderDate":"1970-01-01T00:00:00.000Z","IsIndexed":true,"ModelNo":"34401A","UseDefaultProvider":false,"BookValue":0.0,"LoanDailyCost":0.0,"ServiceCost":0,"CalibrationType":"","FirmwareRevision":"","IsConnected":false,"Location":"ITC test customer org > San Jose","StickyNotes":""},"success":true}
export const AssetDetails = function(ThingName) {
  const options = {
    method: "post",
    url: URL.getAssetDetailsUrl,
    data: {
      ThingName: ThingName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

/*Bulk Edit*/
// payload : Asset (as string)
// sample response
export const BulkEdit = function(Asset, Data) {
  const options = {
    method: "post",
    url: URL.bulkEdit,
    data: {
      Asset: Asset,
      Data: Data
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : none
// sample response
export const GetBulkEditableFields = function() {
  const options = {
    method: "post",
    url: URL.bulkEditableFields
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

/*Edit Asset*/
// payload : None
// sample response
export const GetPermissionBasedColumns = function() {
  const options = {
    method: "post",
    url: URL.permissionBasedColumns
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : None
// sample response
export const GetEditableFields = function() {
  const options = {
    method: "post",
    url: URL.getEditableFields
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : None
// sample response
export const GetUserOrg = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.getEditableFields,
    data: {
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : CustomerId (as string)
// sample response
export const GetLoc = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.getLoc,
    data: {
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : None
// sample response
export const GetAllUsersForCustomer = function(OrgUnit, ThingName) {
  const options = {
    method: "post",
    url: URL.usersForCustomers,
    data: {
      OrgUnit: OrgUnit,
      ThingName: ThingName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload sample json : {CustomerId,Owner,SrvInterval,LastUpdate,AssetNo,OrderNumber,ServiceYearlyCurrency,Checkbox,Currency,PurchasePriceCurrency,Manufacturer,CalibDate,InvoiceNumber,PlannedDisposalDate,AltManufacturerName,Status,SerialNo,UseProviderCalSchedule,BookValuePrice,RequestId,ServiceEndDate,HealthStatus,SoftwareRevision,HardwareVersion,ReceivedDate,Price,Barcode,IsSystem,RepairProviderId,Category,Description,Organization,BookValueDate,ReplacementDate,System,Accessories,ServiceStartDate,SrvYearlyCost,InventoryCountedDate,ReplacedAsset,Condition,Borrowable,EquipType,OwningCompany,UseProviderCalType,SrvLogistics,OrderDate,Provider,ModelNo,AssetType,PartOfSystemCal,LoanDailyCost,SrvDueDate,FirmwareRevision,BookValueCurrency,Location} (as string)
// sample response
export const EditAsset = function(json) {
  const options = {
    method: "post",
    url: URL.editAssetDetails,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

/*filters and saved Search*/
//payload sample {"baseQuery":{},"filterQuery":{},"TabId":""}
// sample response
export const SetFilters = function(json) {
  const options = {
    method: "post",
    url: URL.setFilters,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetFilters = function(TabId) {
  const options = {
    method: "post",
    url: URL.getFilters,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const ClearFilters = function(TabId) {
  const options = {
    method: "post",
    url: URL.clearFilters,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"baseQuery":{},"filterQuery":{},"TabId":"","SearchName":""}
// sample response
export const CreateSavedSearch = function(json) {
  const options = {
    method: "post",
    url: URL.createSavedSearch,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetSavedSearch = function(TabId) {
  const options = {
    method: "post",
    url: URL.getSavedSearch,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":"","SearchId":""}
// sample response
export const SetSavedSearch = function(TabId, SearchId) {
  const options = {
    method: "post",
    url: URL.setSavedSearch,
    data: {
      TabId: TabId,
      SearchId: SearchId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"baseQuery":{},"filterQuery":{},"SearchId":""}
// sample response
export const EditSavedSearch = function(json) {
  const options = {
    method: "post",
    url: URL.editSavedSearch,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"SearchId":""}
// sample response
export const DeleteSavedSearch = function(SearchId) {
  const options = {
    method: "post",
    url: URL.deleteSavedSearch,
    data: {
      SearchId: SearchId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : None
// sample response
export const GetFilterValues = function() {
  const options = {
    method: "post",
    url: URL.getFilterValues
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

/*Ordering Services*/
// payload : None
// sample response
export const GetUserDetails = function() {
  const options = {
    method: "post",
    url: URL.UserDetailsUrl
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

/*Views*/
//payload sample {"TabId":""}
// sample response
export const GetAssetHealthLocWise = function(TabId, propertyName) {
  const options = {
    method: "post",
    url: URL.getAssetHealthLocWise,
    data: {
      TabId: TabId,
      propertyName: propertyName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetAssetHealthModelWise = function(TabId, propertyName) {
  const options = {
    method: "post",
    url: URL.getAssetHealthModelWise,
    data: {
      TabId: TabId,
      propertyName: propertyName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetAssetHealthOrgWise = function(TabId, propertyName) {
  const options = {
    method: "post",
    url: URL.getAssetHealthOrgWise,
    data: {
      TabId: TabId,
      propertyName: propertyName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetAssetHealthSerialWise = function(TabId, propertyName) {
  const options = {
    method: "post",
    url: URL.getAssetHealthSerialWise,
    data: {
      TabId: TabId,
      propertyName: propertyName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetUtilizationViewData = function(
  TabId,
  propertyName,
  bucketType
) {
  const options = {
    method: "post",
    url: URL.getUtilizationViewData,
    data: {
      TabId: TabId,
      propertyName: propertyName,
      bucketType: bucketType
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"TabId":""}
// sample response
export const getUtilizationViewDataLoc = function(TabId) {
  const options = {
    method: "post",
    url: URL.getUtilizationViewDataLoc,
    data: {
      TabId: TabId,
      clientOffset: -330
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"TabId":""}
// sample response
export const getUtilizationViewDataModel = function(TabId) {
  const options = {
    method: "post",
    url: URL.getUtilizationViewDataModel,
    data: {
      TabId: TabId,
      clientOffset: -330
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"TabId":""}
// sample response
export const getUtilizationViewDataOrg = function(TabId) {
  const options = {
    method: "post",
    url: URL.getUtilizationViewDataOrg,
    data: {
      TabId: TabId,
      clientOffset: -330
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"TabId":""}
// sample response
export const getUtilizationViewDataSerial = function(TabId) {
  const options = {
    method: "post",
    url: URL.getUtilizationViewDataSerial,
    data: {
      TabId: TabId,
      clientOffset: -330
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetAssetCountByLocation = function(TabId) {
  const options = {
    method: "post",
    url: URL.assetCountByLocation,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetAssetCountByOrganization = function(TabId) {
  const options = {
    method: "post",
    url: URL.getAssetCountByOrganization,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetAssetCountByManufacturer = function(TabId) {
  const options = {
    method: "post",
    url: URL.getAssetCountByManufacturer,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetAssetCountByModelNo = function(TabId) {
  const options = {
    method: "post",
    url: URL.getAssetCountByModelNo,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetServiceDueDateData = function(TabId) {
  const options = {
    method: "post",
    url: URL.serviceDueDate,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//payload sample {"TabId":""}
// sample response
export const GetViewNames = function(TabId) {
  const options = {
    method: "post",
    url: URL.getViewNamesUrl,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"CategoryId":"","TabId":""}
// sample response
export const GetSubViewOptions = function(TabId, CategoryId) {
  const options = {
    method: "post",
    url: URL.getSubViewOptionsUrl,
    data: {
      TabId: TabId,
      CategoryId: CategoryId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"CategoryId":"","TabId":""}
// sample response
export const SetCategoryId = function(TabId, CategoryId) {
  const options = {
    method: "post",
    url: URL.setCategoryId,
    data: {
      TabId: TabId,
      CategoryId: CategoryId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"ChartId":"","TabId":""}
// sample response
export const SetChartId = function(TabId, ChartId) {
  const options = {
    method: "post",
    url: URL.setChartId,
    data: {
      TabId: TabId,
      ChartId: ChartId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"ViewStartDate":,"TabId":""}
// sample response
export const SetStartDate = function(TabId, ViewStartDate) {
  const options = {
    method: "post",
    url: URL.assetChartStartDate,
    data: {
      TabId: TabId,
      ViewStartDate: ViewStartDate
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"ViewEndDate":,"TabId":""}
// sample response
export const SetEndDate = function(TabId, ViewEndDate) {
  const options = {
    method: "post",
    url: URL.assetChartEndDate,
    data: {
      TabId: TabId,
      ViewEndDate: ViewEndDate
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {"WorkingHours":,"TabId":""}
// sample response
export const SetWorkingHours = function(TabId, WorkingHours) {
  const options = {
    method: "post",
    url: URL.setWorkingHours,
    data: {
      TabId: TabId,
      WorkingHours: WorkingHours
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//payload sample {deviceName:,startDate:,endDate:,AssetName}
// sample response
export const GetHealthTrendData = function(
  deviceName,
  startDate,
  endDate,
  AssetName,
  metricName,
  Units,
  bucketType,
  roundOffDigits
) {
  const options = {
    method: "post",
    url: URL.assetHealthTrend,
    data: {
      deviceName: deviceName,
      startDate: startDate,
      endDate: endDate,
      AssetName: AssetName,
      metricName: metricName,
      Units: Units,
      bucketType: bucketType,
      roundOffDigits: roundOffDigits
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
/*Global Search*/
// payload : None
// sample response
export const GetSolrSearchDetails = function() {
  const options = {
    method: "post",
    url: URL.getSolrSearchDetails
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
/*Submit Issue*/
// payload : None
// sample response
export const GetUserIssueLog = function() {
  const options = {
    method: "post",
    url: URL.needURL
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
// payload : {"Title":"","Description":"","Implication":"","UserName":"","Organization":"","CustomerId":""}
// sample response
export const SetIssueAPI = function(
  Title,
  Description,
  Implication,
  UserName,
  Organization,
  CustomerId
) {
  const options = {
    method: "post",
    url: URL.needURL,
    data: {
      Title: Title,
      Description: Description,
      Implication: Implication,
      UserName: UserName,
      Organization: Organization,
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
// payload : "{"Title":"","Description":"","Implication":"","UserName":"","Organization":"","CustomerId":"","IssueId":""}
// sample response
export const UpdateIssueAPI = function(
  Title,
  Description,
  Implication,
  UserName,
  Organization,
  CustomerId,
  IssueId
) {
  const options = {
    method: "post",
    url: URL.needURL,
    data: {
      Title: Title,
      Description: Description,
      Implication: Implication,
      UserName: UserName,
      Organization: Organization,
      CustomerId: CustomerId,
      IssueId: IssueId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//sample payload {"IssueId":""}
// sample response
export const GetSelectedIssue = function(IssueId) {
  const options = {
    method: "post",
    url: URL.needURL,
    data: {
      IssueId: IssueId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
/*Loan Pool New*/
//sample payload {"CustomerId":""}
//response
export const GetLoanableAssetsForCustomer = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.serviceLoanPool,
    data: {
      CustomerId: CustomerId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//sample payload {"CustomerId":""}
//response
export const GetLoanableAssetsForCustomerLoanpoolGrid = function(
  page,
  start,
  limit
) {
  const options = {
    method: "post",
    url: URL.loanPoolAssetGrid,
    data: { page, start, limit }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
/*Edit User Profile*/
//sample payload none
//sample response
export const GetUserProfile = function() {
  const options = {
    method: "post",
    url: URL.getUserProfile
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const serviceRequest = function(req, method) {
  const options = {
    method: "post",
    url: URL.serviceRequestUrl,
    data: {
      requestJson: {
        jsonrpc: "2.0",
        id: "1234",
        method: method ? method : "SRValidateRequest",
        params: req
      }
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//sample payload {"firstName": "","lastName": "","phoneNo": "","Base64Image": "","PostalCode": "","Prefix": "","City": "","JobTitle": "","mobilePhone": "","AddressLine1": "","AddressLine2": "","AddressLine3": "","State": "","Country": "","Fax": "","Department": ""}
//response
export const SetUserProfile = function(json) {
  const options = {
    method: "post",
    url: URL.setUserProfile,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//sample payload {}
//response
export const SetInfolineCredentials = function(json) {
  const options = {
    method: "post",
    url: URL.setInfolineCredentialsURL,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//sample payload none
//sample response
export const GetUserAvatar = function() {
  const options = {
    method: "post",
    url: URL.getUserAvatar
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//sample payload {"oldPassword":"","newPassword":"","confirmNewPassword":""}
//response
export const ChangePassword = function(
  oldPassword,
  newPassword,
  confirmNewPassword
) {
  const options = {
    method: "post",
    url: URL.changePassword,
    data: {
      oldPassword: oldPassword,
      newPassword: newPassword,
      confirmNewPassword: confirmNewPassword
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
/*Dashboard*/
//sample payload none
//sample response
export const getDashboardData = function() {
  const options = {
    method: "post",
    url: URL.dashboard
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
/*Grid and Tabs*/
//sample payload
//sample response
export const SetColumnOrder = function(json) {
  const options = {
    method: "post",
    url: URL.assetGridColumnOrder,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const SetColumnWidth = function(json) {
  const options = {
    method: "post",
    url: URL.setColumnWidth,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const SetPinnedColumn = function(json) {
  const options = {
    method: "post",
    url: URL.setPinnedColumn,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
//sample payload {"TabId":""}
//sample response
export const ClearSorters = function(TabId) {
  const options = {
    method: "post",
    url: URL.assetGridClearSort,
    data: {
      TabId: TabId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//sample payload
//sample response
export const ReorderTabs = function(json) {
  const options = {
    method: "post",
    url: URL.tabReOrder,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//sample payload
//sample response
export const SetColumnSort = function(json) {
  const options = {
    method: "post",
    url: URL.assetGridColumnsSortURL,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// payload : Asset (as string)
// sample response
export const GetHealthData = function(Asset) {
  const options = {
    method: "post",
    url: URL.healthPopup,
    data: {
      Asset: Asset
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetHealthDataGrouped = function(Asset) {
  const options = {
    method: "post",
    url: URL.getHealthDataGrouped,
    data: {
      Asset: Asset
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const CloneTab = function(TabId, TabName) {
  const options = {
    method: "post",
    url: URL.createCloneTab,
    data: {
      TabId: TabId,
      TabName: TabName
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GenerateIssueName = function() {
  const options = {
    method: "post",
    url: URL.IssueName
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const SearchAssetDetails = function(ModelNo, SerialNo) {
  const appKey = "7352f8ec-6c4d-4fc7-bd99-ecff6cdc0cb6";
  const options = {
    method: "post",
    url: URL.searchAsset + appKey,
    data: { ModelNo, SerialNo }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetIssuesAssignedToMe = function() {
  const options = {
    method: "post",
    url: URL.GetUserAssignedIssueLog
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetIssuesSubmittedByMe = function() {
  const options = {
    method: "post",
    url: URL.GetUserSubmittedIssueLog
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const CreateIssue = function(json) {
  const options = {
    method: "post",
    url: URL.CreateIssue,
    data: json
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const ClearSessionForSubmit = function() {
  const options = {
    method: "post",
    url: URL.clearSubmitSession
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetLoanPoolDataModel = function() {
  const options = {
    method: "post",
    url: URL.assetGridColumns,
    data: {
      TabId: 0
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetLoanPoolFilter = function() {
  const options = {
    method: "post",
    url: URL.getLoanPoolFilter,
    data: {
      TabId: 0
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const UpdateSubmittedIssue = function(
  Description,
  Implication,
  IssueSummary,
  IssueId
) {
  const options = {
    method: "post",
    url: URL.UpdateSubmittedIssue,
    data: {
      Description,
      Implication,
      IssueSummary,
      IssueId
    }
  };

  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const UpdateAssignedIssue = function(
  IssueSummary,
  Description,
  Implication,
  Status,
  Severity,
  Category,
  AssignedTo,
  IssueId
) {
  const options = {
    method: "post",
    url: URL.UpdateAssignedIssue,
    data: {
      IssueSummary,
      Description,
      Implication,
      Status,
      Severity,
      Category,
      AssignedTo,
      IssueId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const UploadIssueFile = function(
  ServerURL,
  Issue,
  FileList,
  DeleteFileList
) {
  const options = {
    method: "post",
    url: URL.UploadFileAPI,
    data: {
      ServerURL,
      Issue,
      FileList,
      DeleteFileList
    }
  };

  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const mailConformation = function(emailid) {
  const options = {
    method: "post",
    url: URL.forgotPassword,
    data: {
      EmailId: emailid
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetSolrSearchResult = function(QueryString, Context) {
  const options = {
    method: "post",
    url: URL.getSolrSearchURL,
    data: {
      QueryString: QueryString,
      Context: Context
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const InitializeApplication = function() {
  const options = {
    method: "post",
    url: URL.initializeApplication,
    data: {}
  };

  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const UpdateUserPreference = function(preferences) {
  const options = {
    method: "post",
    url: URL.updateUserPreference,
    data: preferences
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetAttachments = function(reqID) {
  const options = {
    method: "post",
    url: URL.getAttachedFiles,
    data: {
      Issue: reqID
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const ClearUpdateSession = function() {
  const options = {
    method: "post",
    url: URL.clearUpdateSession
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const ValidateLoanPoolRequest = function(
  inputStartDate,
  inputEndDate,
  CustomerID,
  AssetName
) {
  const options = {
    method: "post",
    url: URL.validateLoanPoolRequest,
    data: { inputStartDate, inputEndDate, CustomerID, AssetName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const CreateNewLoanPoolRequest = function(
  StartDate,
  EndDate,
  CustomerID,
  Justification,
  Location,
  ChargeBack,
  Phone,
  Assets
) {
  const options = {
    method: "post",
    url: URL.createNewLoanPoolRequest,
    data: {
      StartDate,
      EndDate,
      CustomerID,
      Justification,
      Location,
      ChargeBack,
      Phone,
      Assets
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetLoanableAssetsData = function(
  endDate,
  startDate,
  limit,
  start,
  page
) {
  const options = {
    method: "post",
    url: URL.getLoanableAssetsData,
    data: { endDate, startDate, limit, start, page }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const AddExternalAssetRequest = function(
  EndDate,
  StartDate,
  Notes,
  Location,
  Justification,
  Description,
  ModelNo,
  Manufacturer,
  MobileNo
) {
  const options = {
    method: "post",
    url: URL.addExternalAssetRequest,
    data: {
      EndDate,
      StartDate,
      Notes,
      Location,
      Justification,
      Description,
      ModelNo,
      Manufacturer,
      MobileNo
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const IsExistingTemplate = function(CustomerId, TemplateName) {
  const options = {
    method: "post",
    url: URL.isExistingTemplate,
    data: { CustomerId, TemplateName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const CreateTemplateURL = function(json) {
  const options = {
    method: "post",
    url: URL.createTemplate,
    data: { Input: json }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetAllLoanPoolRequests = function() {
  const options = {
    method: "post",
    url: URL.GetAllLoanPoolRequests
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

// export const CreateScheduledTask = function (input) {
//     const options = {
//         method: "post",
//         url: URL.createScheduledTask,
//         data: input
//     };
//     return request(options).then(onSuccess).catch(onError);
// };

export const DeleteScheduledTask = function(input) {
  var data = {};
  data.Id = input;
  const options = {
    method: "post",
    url: URL.deleteScheduledTask,
    data: data
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetScheduledTasks = function(input) {
  var data = {};
  data.ThingName = input;
  const options = {
    method: "post",
    url: URL.getScheduledTasks,
    data: data
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetManufactureList = function() {
  const options = {
    method: "post",
    url: URL.getManufactureList
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetSystemComponent = function(thingName) {
  const options = {
    method: "post",
    url: URL.getSystemComponents,
    data: { ThingName: thingName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetAssetFiles = function(AssetEq) {
  const options = {
    method: "post",
    url: URL.getAssetFiles,
    data: { AssetEq: AssetEq }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetParentSystemName = function(CustomerId) {
  const options = {
    method: "post",
    url: URL.getparentSystemName,
    data: { CustomerId: CustomerId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetModelNoList = Manufacturer => {
  const options = {
    method: "post",
    url: URL.getModelNoList,
    data: { Manufacturer: Manufacturer }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const AddManufacturer = Value => {
  const options = {
    method: "post",
    url: URL.addManufacturer,
    data: { Value }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const AddModelNo = (Manufacturer, Value) => {
  const options = {
    method: "post",
    url: URL.addModelNumber,
    data: { Manufacturer, Value }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const CreateScheduledTask = function(input) {
  const options = {
    method: "post",
    url: URL.createScheduledTask,
    data: input
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const CreateOrDeleteTasks = function(input) {
  const options = {
    method: "post",
    url: URL.createOrDeleteTasks,
    data: input
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

//   export const DeleteScheduledTask = function(input) {
//        var data = {};
//        data.Id = input;
//    const options = {
//       method: "post",
//       url: URL.deleteScheduledTask,
//       data: data
//    };
//    return request(options).then(onSuccess).catch(onError);
//   };

//   export const GetScheduledTasks = function(input) {
//        var data = {};
//        data.ThingName = input;
//    const options = {
//       method: "post",
//       url: URL.getScheduledTasks,
//       data: data
//    };
//    return request(options).then(onSuccess).catch(onError);
//   };

export const GetAssetHealthDrillDown = function(
  TabId,
  propertyName,
  propertyValue,
  bucketType
) {
  const options = {
    method: "post",
    url: URL.assetHealthDrillDown,
    data: { TabId, propertyName, propertyValue, bucketType }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetAssetCountBySubLocation = function(
  CustomerId,
  breadcrumb,
  TabId
) {
  const options = {
    method: "post",
    url: URL.assetCountBySubLocation,
    data: { CustomerId, breadcrumb, TabId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetAssetCountBySubOrganization = function(
  CustomerId,
  breadcrumb,
  TabId
) {
  const options = {
    method: "post",
    url: URL.getAssetCountBySubOrganization,
    data: { CustomerId, breadcrumb, TabId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const SetDatesInTab = function(TabId, ViewStartDate, ViewEndDate) {
  const options = {
    method: "post",
    url: URL.setTabDates,
    data: { TabId, ViewStartDate, ViewEndDate }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const SetApprovalOnLoanPoolRequest = function(
  approval,
  workflowInstanceId
) {
  const options = {
    method: "post",
    url: URL.setApprovalOnLoanPoolRequest,
    data: { approval, workflowInstanceId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const MarkLoanedAssetAsReturned = function(instanceId) {
  const options = {
    method: "post",
    url: URL.markLoanedAssetAsReturned,
    data: { instanceId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const SetEquipmentRequestApproval = function(ApprovalStatus, StreamId) {
  const options = {
    method: "post",
    url: URL.setEquipmentRequestApproval,
    data: { ApprovalStatus, StreamId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetAssetInfo = function(EquipmentNo) {
  const options = {
    method: "post",
    url: URL.getAssetInfo,
    data: { EquipmentNo }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const CreateNewCase = function(
  CaseId,
  Investigator,
  Status,
  Impact,
  Action,
  Description,
  Notes,
  ThingName,
  Manufacturer,
  ModelNo,
  SerialNo
) {
  const options = {
    method: "post",
    url: URL.createNewCase,
    data: {
      CaseId,
      Investigator,
      Status,
      Impact,
      Action,
      Description,
      Notes,
      ThingName,
      Manufacturer,
      ModelNo,
      SerialNo
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const SetDatePreset = function(TabId, Preset) {
  const options = {
    method: "post",
    url: URL.setDatePreset,
    data: { TabId, Preset }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetEquipmentNumbersForOOT = function() {
  const options = {
    method: "post",
    url: URL.getEquipmentNumbersForOOT,
    data: {}
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetAllCases = function() {
  const options = {
    method: "post",
    url: URL.getAllCases,
    data: {}
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetAllEntries = function(CaseId) {
  const options = {
    method: "post",
    url: URL.getAllEntries,
    data: { CaseId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const CreateNewEntry = function(
  CaseId,
  Notes,
  Impact,
  Status,
  Action,
  Investigator,
  ThingName,
  StreamId,
  QuickTag,
  EntryId
) {
  const options = {
    method: "post",
    url: URL.createNewEntry,
    data: {
      CaseId,
      Notes,
      Impact,
      Status,
      Action,
      Investigator,
      ThingName,
      StreamId,
      QuickTag,
      EntryId
    }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const UploadFileForEntry = function(CaseId, EntryId, Data, FileName) {
  const options = {
    method: "post",
    url: URL.uploadFileForEntry,
    data: { CaseId, EntryId, Data, FileName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const ValidateLoanPoolApproval = function(
  ThingName,
  WorkflowId,
  StartDate,
  EndDate
) {
  const options = {
    method: "post",
    url: URL.validateLoanPoolApproval,
    data: { ThingName, WorkflowId, StartDate, EndDate }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const UploadFileForAsset = function(AssetEqNum, FileName, File) {
  const options = {
    method: "post",
    url: URL.fileupload,
    data: { AssetEqNum, FileName, File }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const DeleteUploadedFiles = function(AssetEqNum, input) {
  const options = {
    method: "post",
    url: URL.deleteUploadedfiles,
    data: { AssetEqNum, input }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetLicenseInfo = function(ThingName) {
  const options = {
    method: "post",
    url: URL.getAssetLicenseInfo,
    data: { ThingName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetSystemChild = function(SystemName) {
  const options = {
    method: "post",
    url: URL.getSystemChild,
    data: { SystemName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetSystemComponents = function(SystemName, ParentSystemName) {
  const options = {
    method: "post",
    url: URL.getSystemComponent,
    data: { SystemName, ParentSystemName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

/*export const UploadFileForAsset = function (AssetEqNum, FileName, File) {
    const options = {
        method: 'post',
        url: URL.fileupload,
        data: { AssetEqNum, FileName, File }
    }
    return request(options)
        .then(onSuccess)
        .catch(onError);
};

export const GetLicenseInfo = function (ThingName) {
    const options = {
        method: 'post',
        url: URL.getAssetLicenseInfo,
        data: { ThingName }
    }
    return request(options)
        .then(onSuccess)
        .catch(onError);
};
export const GetSystemChild = function (SystemName) {
    const options = {
        method: 'post',
        url: URL.getSystemChild,
        data: { SystemName }
    }
    return request(options)
        .then(onSuccess)
        .catch(onError);
};
export const GetSystemComponents = function (ThingName) {
    const options = {
        method: 'post',
        url: URL.getSystemComponent,
        data: { ThingName }
    }
    return request(options)
        .then(onSuccess)
        .catch(onError);
};*/

export const ValidateParentSystemNameForBulkEdit = function(
  SystemName,
  Assets
) {
  const options = {
    method: "post",
    url: URL.validateParentSystemNameForBulkEdit,
    data: { SystemName, Assets }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const ValidateSystemName = function(SystemName) {
  const options = {
    method: "post",
    url: URL.validateSystemName,
    data: { SystemName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const ValidateSystemParentUncheck = function(ThingName) {
  const options = {
    method: "post",
    url: URL.validateSystemParentUncheck,
    data: { ThingName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const AssetGridColumnHide = function(HiddenColumn, TabId) {
  const options = {
    method: "post",
    url: URL.assetGridColumnHide,
    data: { HiddenColumn, TabId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const AssetGridColumnShow = function(Column, TabId) {
  const options = {
    method: "post",
    url: URL.assetGridColumnShow,
    data: { Column, TabId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetUserPreference = function() {
  const options = {
    method: "post",
    url: URL.getUserPreference,
    data: {}
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetErrors = function(ThingName) {
  const options = {
    method: "post",
    url: URL.getErrorList,
    data: ThingName
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetWarnings = function(ThingName) {
  const options = {
    method: "post",
    url: URL.getWarningsList,
    data: ThingName
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const fetchAssetDetailsValues = function(UniqueId) {
  const options = {
    method: "post",
    url: URL.fetchAssetDetailsValues,
    data: { UniqueId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetAllApiResult = function(CustomerId, PageName) {
  const options = {
    method: "post",
    url: URL.getAllApiResult,
    data: { CustomerId, PageName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetDropDownData = function() {
  const options = {
    method: "post",
    url: URL.getDropDownData
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetServiceHistory = function(ThingName) {
  const options = {
    method: "post",
    url: URL.getServiceHistory,
    data: { ThingName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const GetCustomerServiceRequests = function() {
  const options = {
    method: "post",
    url: URL.getCustomerServiceRequests
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const ResetHealthParamMinMax = function(streamId, ThingName) {
  const options = {
    method: "post",
    url: URL.resetHealthParameter,
    data: { streamId, ThingName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const ResetAllHealthParamsMinMax = function(ThingName) {
  const options = {
    method: "post",
    url: URL.resetAllHealthParameters,
    data: { ThingName }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
export const GetNotificationCount = function(Module) {
  const options = {
    method: "post",
    url: URL.getNotificationCount,
    data: { Module }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const MarkNotificationAsRead = function(Module, NotificationId) {
  const options = {
    method: "post",
    url: URL.markNotificationAsRead,
    data: { Module, NotificationId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const resetErrorOrWarning = function(ThingName, streamId) {
  const options = {
    method: "post",
    url: URL.clearErrorsOrWarnings,
    data: { ThingName, streamId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};

export const renameTab = function(Name, TabId) {
  const options = {
    method: "post",
    url: URL.renameTab,
    data: { Name, TabId }
  };
  return request(options)
    .then(onSuccess)
    .catch(onError);
};
const Functions = {
  SetActiveTab: SetActiveTab,
  SetDisplayDensity: SetDisplayDensity,
  SetPagination: SetPagination,
  GetUserTab: GetUserTab,
  GetGridDataModel: GetGridDataModel,
  GetGridData: GetGridData,
  GetCompleteGridData: GetCompleteGridData,
  GetPageWiseDropDownValue: GetPageWiseDropDownValue,
  GetOrgs: GetOrgs,
  GetEquipmentNumberSequence: GetEquipmentNumberSequence,
  GetOotCaseNumberSequence: GetOotCaseNumberSequence,
  GetOrganizationTree: GetOrganizationTree,
  GetLocationTree: GetLocationTree,
  GetCustomerAssets: GetCustomerAssets,
  GetTemplates: GetTemplates,
  CreateUserTab: CreateUserTab,
  RenameTab: RenameTab,
  DeleteTab: DeleteTab,
  GetUserTabs: GetUserTabs,
  AssetDetails: AssetDetails,
  BulkEdit: BulkEdit,
  GetBulkEditableFields: GetBulkEditableFields,
  GetPermissionBasedColumns: GetPermissionBasedColumns,
  GetEditableFields: GetEditableFields,
  GetUserOrg: GetUserOrg,
  GetLoc: GetLoc,
  GetAllUsersForCustomer: GetAllUsersForCustomer,
  EditAsset: EditAsset,
  SetFilters: SetFilters,
  GetFilters: GetFilters,
  ClearFilters: ClearFilters,
  CreateSavedSearch: CreateSavedSearch,
  GetSavedSearch: GetSavedSearch,
  SetSavedSearch: SetSavedSearch,
  EditSavedSearch: EditSavedSearch,
  DeleteSavedSearch: DeleteSavedSearch,
  GetFilterValues: GetFilterValues,
  GetUserDetails: GetUserDetails,
  GetAssetHealthLocWise: GetAssetHealthLocWise,
  GetAssetHealthModelWise: GetAssetHealthModelWise,
  GetAssetHealthOrgWise: GetAssetHealthOrgWise,
  GetAssetHealthSerialWise: GetAssetHealthSerialWise,
  GetUtilizationViewData: GetUtilizationViewData,
  getUtilizationViewDataLoc: getUtilizationViewDataLoc,
  getUtilizationViewDataModel: getUtilizationViewDataModel,
  getUtilizationViewDataOrg: getUtilizationViewDataOrg,
  getUtilizationViewDataSerial: getUtilizationViewDataSerial,
  GetAssetCountByLocation: GetAssetCountByLocation,
  GetAssetCountByOrganization: GetAssetCountByOrganization,
  GetAssetCountByManufacturer: GetAssetCountByManufacturer,
  GetAssetCountByModelNo: GetAssetCountByModelNo,
  GetServiceDueDateData: GetServiceDueDateData,
  GetViewNames: GetViewNames,
  GetSubViewOptions: GetSubViewOptions,
  SetCategoryId: SetCategoryId,
  SetChartId: SetChartId,
  SetStartDate: SetStartDate,
  SetEndDate: SetEndDate,
  SetWorkingHours: SetWorkingHours,
  GetHealthTrendData: GetHealthTrendData,
  GetSolrSearchDetails: GetSolrSearchDetails,
  GetUserIssueLog: GetUserIssueLog,
  SetIssueAPI: SetIssueAPI,
  UpdateIssueAPI: UpdateIssueAPI,
  GetSelectedIssue: GetSelectedIssue,
  GetLoanableAssetsForCustomer: GetLoanableAssetsForCustomer,
  GetLoanableAssetsForCustomerLoanpoolGrid: GetLoanableAssetsForCustomerLoanpoolGrid,
  GetUserProfile: GetUserProfile,
  serviceRequest: serviceRequest,
  SetUserProfile: SetUserProfile,
  SetInfolineCredentials: SetInfolineCredentials,
  GetUserAvatar: GetUserAvatar,
  ChangePassword: ChangePassword,
  getDashboardData: getDashboardData,
  SetColumnOrder: SetColumnOrder,
  SetPinnedColumn: SetPinnedColumn,
  ClearSorters: ClearSorters,
  ReorderTabs: ReorderTabs,
  SetColumnSort: SetColumnSort,
  GetHealthData: GetHealthData,
  GetHealthDataGrouped: GetHealthDataGrouped,
  CreateAsset: CreateAsset,
  ValidateEquipmentNumber: ValidateEquipmentNumber,
  ValidateOotCaseNumber: ValidateOotCaseNumber,
  CloneTab: CloneTab,
  GenerateIssueName: GenerateIssueName,
  SearchAssetDetails: SearchAssetDetails,
  GetIssuesAssignedToMe: GetIssuesAssignedToMe,
  GetIssuesSubmittedByMe: GetIssuesSubmittedByMe,
  CreateIssue: CreateIssue,
  ClearSessionForSubmit: ClearSessionForSubmit,
  GetLoanPoolDataModel: GetLoanPoolDataModel,
  GetLoanPoolFilter: GetLoanPoolFilter,
  InitializeApplication: InitializeApplication,
  UpdateUserPreference: UpdateUserPreference,
  UploadIssueFile: UploadIssueFile,
  UpdateSubmittedIssue: UpdateSubmittedIssue,
  UpdateAssignedIssue: UpdateAssignedIssue,
  GetSolrSearchResult: GetSolrSearchResult,
  mailConformation: mailConformation,
  CreateNewLoanPoolRequest: CreateNewLoanPoolRequest,
  GetAttachments: GetAttachments,
  ClearUpdateSession: ClearUpdateSession,
  ValidateLoanPoolRequest: ValidateLoanPoolRequest,
  GetLoanableAssetsData: GetLoanableAssetsData,
  AddExternalAssetRequest: AddExternalAssetRequest,
  IsExistingTemplate: IsExistingTemplate,
  CreateTemplateURL: CreateTemplateURL,
  GetAllLoanPoolRequests: GetAllLoanPoolRequests,
  CreateScheduledTask: CreateScheduledTask,
  CreateOrDeleteTasks: CreateOrDeleteTasks,
  GetScheduledTasks: GetScheduledTasks,
  DeleteScheduledTask: DeleteScheduledTask,
  GetManufactureList: GetManufactureList,
  GetSystemComponent: GetSystemComponent,
  GetAssetFiles: GetAssetFiles,
  GetParentSystemName: GetParentSystemName,
  GetModelNoList: GetModelNoList,
  AddManufacturer: AddManufacturer,
  AddModelNo: AddModelNo,
  GetAssetHealthDrillDown: GetAssetHealthDrillDown,
  GetAssetCountBySubLocation: GetAssetCountBySubLocation,
  GetAssetCountBySubOrganization: GetAssetCountBySubOrganization,
  SetDatesInTab: SetDatesInTab,
  SetApprovalOnLoanPoolRequest: SetApprovalOnLoanPoolRequest,
  MarkLoanedAssetAsReturned: MarkLoanedAssetAsReturned,
  SetEquipmentRequestApproval: SetEquipmentRequestApproval,
  SetDatePreset: SetDatePreset,
  CreateNewCase: CreateNewCase,
  GetAssetInfo: GetAssetInfo,
  GetEquipmentNumbersForOOT: GetEquipmentNumbersForOOT,
  GetAllCases: GetAllCases,
  GetAllEntries: GetAllEntries,
  CreateNewEntry: CreateNewEntry,
  UploadFileForEntry: UploadFileForEntry,
  ValidateLoanPoolApproval: ValidateLoanPoolApproval,
  UploadFileForAsset: UploadFileForAsset,
  DeleteUploadedFiles: DeleteUploadedFiles,
  GetLicenseInfo: GetLicenseInfo,
  GetSystemComponents: GetSystemComponents,
  GetSystemChild: GetSystemChild,
  ValidateSystemName: ValidateSystemName,
  ValidateParentSystemNameForBulkEdit: ValidateParentSystemNameForBulkEdit,
  ValidateSystemParentUncheck: ValidateSystemParentUncheck,
  AssetGridColumnHide: AssetGridColumnHide,
  AssetGridColumnShow: AssetGridColumnShow,
  GetUserPreference: GetUserPreference,
  SetColumnWidth: SetColumnWidth,
  GetErrors: GetErrors,
  GetWarnings: GetWarnings,
  GetAllApiResult: GetAllApiResult,
  GetDropDownData: GetDropDownData,
  fetchAssetDetailsValues: fetchAssetDetailsValues,
  GetServiceHistory: GetServiceHistory,
  GetCustomerServiceRequests: GetCustomerServiceRequests,
  ResetHealthParamMinMax: ResetHealthParamMinMax,
  ResetAllHealthParamsMinMax: ResetAllHealthParamsMinMax,
  GetNotificationCount: GetNotificationCount,
  MarkNotificationAsRead: MarkNotificationAsRead,
  resetErrorOrWarning: resetErrorOrWarning,
  renameTab: renameTab,
  spotfireSignout: spotfireSignout,
  spotfireAuth: spotfireAuth
};

export default Functions;
