/* eslint-disable  */
import React, { Component } from "react";
// import Iframe from "react-iframe";
import tabModelStore from "../../stores/tabModelStore";
import userStore from "../../stores/userStore";
import UIFunctions from "src/helpers/UIFunctions";
import PropTypes from "prop-types";
// import { Switch, Route } from "react-router-dom";
// import UIFunctions from "../../helpers/UIFunctions";
//  var c_analysisPath = "https://ec2-18-144-10-152.us-west-1.compute.amazonaws.com/spotfire/wp/render/m9hJJeY346c25BMwlA/analysis?file=/Development/Health%20and%20Utilization%20Data%20offenders%20with%20Postgres%20-%202018_05_10_embedded2";
//  var c_analysisPath1 = "https://ec2-18-144-10-152.us-west-1.compute.amazonaws.com/spotfire/wp/render/m9hJJeY346c25BMwlA/analysis?file=/Customers/Leonardo/Leonardo%20TEMS%20SVA%20Data%2020180524%20-%20SVA%20data";
//  var c_analysisPath2 = "https://ec2-18-144-10-152.us-west-1.compute.amazonaws.com/spotfire/wp/render/m9hJJeY346c25BMwlA/analysis?file=/Customers/Leonardo/2018%20KPI%20Report%20-%20Leonardo%20MW%20Ltd%2020180524";
//  var c_analysisPath3 = "https://ec2-18-144-10-152.us-west-1.compute.amazonaws.com/spotfire/wp/render/m9hJJeY346c25BMwlA/analysis?file=/Customers/Leonardo/LeonardoOverdueAssetsMod";

// for demo purpose
{
  /* <Iframe url="https://ec2-18-144-10-152.us-west-1.compute.amazonaws.com/spotfire/wp/"
width="100%"
height="100%"
id="myId"
className="myClassname"
display="initial"
position="relative"
allowFullScreen/> */
}

// const default_path = `${spotfireServer}/spotfire/wp/OpenAnalysis?file=/Customers/${customerDisplayName}/${filename}`;

// var c_analysisPath1 =
//   "/Development/Health and Utilization Data offenders with Postgres - 2018_05_10_embedded2";
// var c_analysisPath2 =
//   "/Customers/Leonardo/Leonardo TEMS SVA Data 20180524 - SVA data";
// var c_analysisPath3 =
//   "/Customers/Leonardo/2018 KPI Report - Leonardo MW Ltd 20180524";
// var c_analysisPath4 = "/Customers/Leonardo/LeonardoOverdueAssetsMod";

class Spotfire extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bottomFooterHeight: 38
      // 88.5,
    };
  }
  UNSAFE_componentWillMount() {
    tabModelStore.setIsAssetListView(false);
    tabModelStore.setIsChartView(false);
    tabModelStore.setIsVisible(true);
    tabModelStore.setShowToolTip(true);
    tabModelStore.setHideHeader(true);
  }
  componentDidMount = () => {
    tabModelStore.setIsAssetListView(false);
    tabModelStore.setIsChartView(false);
    tabModelStore.setIsVisible(true);
    tabModelStore.setShowToolTip(true);
    tabModelStore.setHideHeader(true);
    let dashboardUserName = userStore.userDetails.CustomerName;
    if (dashboardUserName == "") {
      UIFunctions.Toast("Oops ! Something went wrong !", "error");
      this.props.history.push("/");
    }
  };
  handleSpotfire(url, c_analysisPath1, title) {
    var c_serverUrl = url;
    //   "https://ec2-18-144-10-152.us-west-1.compute.amazonaws.com/spotfire/wp/";
    // "https://aa-w-spotfire.ssgaa.usw2.amzn.keysight.com/spotfire/wp/";
    // var c_analysisPathh = url;
    var c_analysisPath = c_analysisPath1;
    // "/Development/Health and Utilization Data offenders with Postgres - 2018_05_10_embedded2";
    var c_parameters = ""; //Option configuration block

    try {
      setTimeout(() => {
        var customization = new spotfire.webPlayer.Customization();
        var app;

        var c_reloadAnalysisInstance = false; // if true for debug, cached version refreshed everytime load html
        app = new spotfire.webPlayer.Application(
          c_serverUrl,
          customization,
          c_analysisPath,
          c_parameters,
          c_reloadAnalysisInstance
        );
        //Hide UI elements
        customization.showDodPanel = false;
        customization.showStatusbar = true;
        customization.showToolBar = false;
        customization.showPageNavigation = true;
        customization.showClose = false;
        customization.showAnalysisInfo = false;
        customization.showExportFile = false;
        customization.showExportVisualization = false;
        customization.showUndoRedo = false;
        customization.showFilterPanel = false;
        customization.showBookmark = false;

        var viewOne = app.openDocument("myId", title, customization);
        // Register an error handler to catch errors.
        app.onError(errorCallback);
      }, 2000);
    } catch (err) {
      console.error(err);
    }

    function errorCallback(errorCode, description) {
      // Displays an error message if something goes wrong in the Web Player.
      var divElement = document.createElement("DIV");
      divElement.style.cssText =
        "width:100vw;height:100vh;background-color:#9b9b9b";
      var h2Element = document.createElement("H2");
      h2Element.style.cssText =
        'position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);font-family:"Open Sans";font-weight:600; letter-spacing:1.2px; line-height:32px;font-size:18px ';
      h2Element.textContent =
        "Access to this feature is restricted. Please Contact Administrator";
      divElement.appendChild(h2Element);

      document.getElementById("myId").appendChild(divElement);
    }
  }

  // handleSpotfireFeatures = (spotfireServer, customerDisplayName, filename) =>
  //   `${spotfireServer}/spotfire/wp/OpenAnalysis?file=/Customers/${customerDisplayName}/${filename}`;

  onWinResize() {
    var gridElem = document.getElementById("ksgridContainer");
    if (gridElem) {
      var footerElem = document.getElementById("footer");
      var mainFooter = document.getElementById("mainFooter");
      var appHeader = document.getElementById("app-header");
      // console.log("heights", footerElem.clientHeight, mainFooter.clientHeight, appHeader.clientHeight);
      var footerPlusBottomElemHeight =
        footerElem.clientHeight +
        mainFooter.clientHeight +
        appHeader.clientHeight -
        7;
      this.setState({ bottomFooterHeight: footerPlusBottomElemHeight });
    }
  }

  render() {
    window.addEventListener("resize", this.onWinResize);
    const spotfireServer =   userStore.userDetails.dashboardUrl+"/spotfire/wp/";
    const customerDisplayName = userStore.userDetails.CustomerName
      ? userStore.userDetails.CustomerName
      : "";
    const filename = "Dashboard";
    const c_analysisPath1 = `/Customers/${customerDisplayName}/${filename}`;
    // const DashboardDemo = () => (
    //   <div id="myId" style={{ width: "100%", height: "100%" }}>
    //     {this.handleSpotfire(c_analysisPath1, "Dashboard")}
    //   </div>
    // );
    // const SVA = () => (
    //   <div id="myId" style={{ width: "100%", height: "100%" }}>
    //     {this.handleSpotfire(c_analysisPath2, "Total Spend by Contract Year")}
    //   </div>
    // );
    // const KPI = () => (
    //   <div id="myId" style={{ width: "100%", height: "100%" }}>
    //     {this.handleSpotfire(c_analysisPath3, "Performance KPIs")}
    //   </div>
    // );
    // const ServiceDue = () => (
    //   <div id="myId" style={{ width: "100%", height: "100%" }}>
    //     {this.handleSpotfire(c_analysisPath4, "Cal Due Status")}
    //   </div>
    // );
    return (
      //top:50
      <div
        id="subMenuContainer"
        style={{
          position: "absolute",
          left: 59,
          top: 0,
          // height: window.innerHeight - this.state.bottomFooterHeight,
          // width: window.innerWidth - 59.5,
          width: "calc(100vw - 59px)",
          backgroundColor: "white",
          bottom: 38
        }}
      >
        {/* <Switch>
          <Route
            path="/spotfire/dashboarddemo"
            name="Dashboard"
            component={DashboardDemo}
          />
          <Route path="/spotfire/sva" name="sva" component={SVA} />
          <Route path="/spotfire/kpi" name="kpi" component={KPI} />
          <Route
            path="/spotfire/servicedue"
            name="servicedue"
            component={ServiceDue}
          />
        </Switch> */}

        {/* <Iframe
          url={this.handleSpotfireFeatures(
            spotfireServer,
            customerDisplayName,
            filename
          )}
          width="100%"
          height="100%"
          id="myId"
          className="myClassname"
          display="initial"
          position="relative"
          allowFullScreen
        /> */}
        <div id="myId" style={{ width: "100%", height: "100%" }}>
          {this.handleSpotfire(spotfireServer, c_analysisPath1, filename)}
        </div>
      </div>
    );
  }
}

export default Spotfire;
Spotfire.propTypes = {
  history: PropTypes.object
};
