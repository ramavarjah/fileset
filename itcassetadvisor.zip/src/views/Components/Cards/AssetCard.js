import React from "react";
import Functions from "src/api/Functions";
import { Spin } from "antd";
import noDataImage from "../../../../public/img/no-data-placeholder_standard.png";
import _ from "lodash";
class AssetCard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      url: null
    };
  }
  componentDidMount() {
    const { modelNo, dummyUrl } = this.props;
    let models = [];
    models.push(modelNo);

    //to get the URL's of the images from the catalg server
    Functions.GetModelDetails({
      InputParams: { models }
    })
      .then(resp => {
        resp.data.length == 0 || resp.data.data[0].url == ""
          ? this.setState({ loading: true, url: dummyUrl })
          : this.setState({ loading: true, url: resp.data.data[0].url });
      })
      .catch(() => this.setState({ loading: true, url: dummyUrl }));
  }
  componentDidUpdate(prevProps) {
    if (!_.isEqual(prevProps.modelNo, this.props.modelNo)) {
      const { modelNo, dummyUrl } = this.props;
      let models = [];
      models.push(modelNo);
      Functions.GetModelDetails({
        InputParams: { models }
      })
        .then(resp => {
          resp.data.length == 0 || resp.data.data[0].url == ""
            ? this.setState({ loading: true, url: dummyUrl })
            : this.setState({ loading: true, url: resp.data.data[0].url });
        })
        .catch(() => this.setState({ loading: true, url: dummyUrl }));
    }
  }
  render() {
    const { width, hasExternalRequest, size , height} = this.props;
    const { url, loading } = this.state;
    return loading ? (
      <img
        src={hasExternalRequest ? "/img/externalReqest.jpg" : url}
        width={"auto"}
        height={"auto"}
        alt="keysightAssetImage"
        style={{
          marginLeft: hasExternalRequest && size ? "-28px" : "",
          marginTop: hasExternalRequest && size ? "-22px" : "",
          maxWidth: width,
          minHeight: height,
          minWidth: "10vw",
          maxHeight: "auto"
        }}
      />
    ) : (
      <Spin loading={!loading}>
        <img
          src={noDataImage}
          width={"auto"}
          height={"auto"}
          style={{
            marginLeft: "24px",
            maxWidth: width,
            minHeight: "auto",
            minWidth: "10vw"
            }}
        />
      </Spin>
    );
  }
}
export default AssetCard;
