import React from "react";
import moment from "moment";
import PropTypes from "prop-types";
import styled from "styled-components";
import _ from "lodash";
const Div = styled.div`
  .check-availability-calendar-month {
    width: 230px;
    .check-availability-month-day {
      color: rgb(151, 151, 151);
      width: 37px;
      display: inline-block;
      cursor: pointer;
      font-family: "Open Sans";
      font-size: 13.6px;
      letter-spacing: 0.56px;
      line-height: 27px;
      text-align: center;
      margin: 4px -4px;
      border-radius: 5px;
    }
    .month--wrapper {
      display: inline-block;
      border-radius: 1px;
      &:hover {
        background: #cccccc;
      }
    }
    .LOANED {
      background: rgb(255, 189, 205);
      color: #fff;
    }
    .SERVICED {
      background: rgb(210, 213, 223);
      color: #fff;
    }
    .REQUESTED {
      background: rgb(255, 216, 147);
      color: #fff;
    }
    .blue {
      background: lightblue;
      color: #fff;
    }
    .disabledDaysWrapper{
      cursor: not-allowed !important;
       display: inline-block;    
    }
    .disabledDays{
      pointer-events: none !important;
    }
  }
`;

export default class Month extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      availability: {
        "05": "REQUESTED",
        "06": "LOANED",
        "07": "SERVICED",
        "11": "LOANED"
      }
    };
  }

  getDays = (lMonth, lYear, lSelectedDates, lOnDataLoaded, lOnDayClick,availability,PlannedDisposalDate) => {
   // const { availability } = this.state;
    //get the start date of the month
    const startDate = moment([lYear, lMonth - 1, 1]).format("YYYY-MM-DD");
    // get the number of days for this month
    const daysInMonth = moment(startDate).daysInMonth();

    //to get which day i have to start the month
    const startDayOfTheCurrentMonth = moment(startDate).format("d");
    let days = [];
    let labels = [];
    //make an empty dates
    for (let i = 0; i < startDayOfTheCurrentMonth; i++) {
      labels.push(
        <span
        key={i + lMonth + lYear + "_"}
        className={`month--wrapper`}
      >
        <span
         
          className={`check-availability-month-day`}
          />
          </span>
      );
    }
    //create dates
    
    for (let i = 1; i <= daysInMonth; i++) {
      const beforeCurrentDay = moment(
        `${i}/${lMonth}/${lYear}`,
        "DD/MM/YYYY"
      );
      const selctedColor = lSelectedDates[
        `${String(i).length == 1 ? "0" + i : i}`
      ]
        ? "blue"
        : "";
      let backgroundColor = availability[
        `${String(i).length == 1 ? "0" + i : i}`
      ]
        ? availability[`${String(i).length == 1 ? "0" + i : i}`]
        : "";
      if( PlannedDisposalDate != "1970-01-01T00:00:00.000Z" && beforeCurrentDay > moment(PlannedDisposalDate)) 
      {
        backgroundColor = "LOANED"
      } 
      let day;
      day = (
        <span
          key={i + lMonth + lYear + "__"}
       //   className={`month--wrapper  ${selctedColor}`}
          className={`${
            beforeCurrentDay &&
            beforeCurrentDay <=
              moment()
                .endOf("day")
                .subtract(1, "day")
              ? "disabledDaysWrapper"
              : `month--wrapper  ${selctedColor}`
          }`}
        >
          <span
          //  className={`check-availability-month-day  ${backgroundColor}`}
             className={`check-availability-month-day ${
              beforeCurrentDay &&
              beforeCurrentDay <=
                moment()
                  .endOf("day")
                  .subtract(1, "day")
                ? "disabledDays"
                : backgroundColor
            }`}
            onClick={e => lOnDayClick(e)}
          >
            {i}
          </span>
        </span>
      );
      days.push(day);
    }

    return [...labels, ...days];
  };
  shouldComponentUpdate(nextProps) {
    const {
      props: { selectedDates }
    } = this;
    if (!_.isEqual(selectedDates, nextProps.selectedDates)) {
      return true;
    }
    if(!_.isEqual(this.props.availabilityData,nextProps.availabilityData)){
      return true;
    }
    return false;
  }

  render() {
    const { month, year, selectedDates, onDataLoaded, onDayClick, availabilityData,PlannedDisposalDate } = this.props;
  
    return (
      <Div>
        <div className="check-availability-calendar-month">
          {this.getDays(month, year, selectedDates, onDataLoaded, onDayClick,availabilityData,PlannedDisposalDate)}
        </div>
      </Div>
    );
  }
}

Month.propTypes = {
  year: PropTypes.string,
  month: PropTypes.string,
  selectedDates: PropTypes.object,
  onDayClick: PropTypes.func,
  onDataLoaded: PropTypes.func,
  availabilityData: PropTypes.object
};
