import React from "react";
import Month from "./Month";
import MonthHeader from './MonthHeader'
import PropTypes from "prop-types";
import styled from "styled-components";

const Wrapper = styled.div`
padding-top: 0;
padding-bottom: 0;
margin: 16px;
`;
const CACalendarNew = ({
    year,
    month,
    selectedDates,
    onDayClick,
    PlannedDisposalDate,
    availabilityData
}) => {
    return (
        <Wrapper>
            <MonthHeader title={month} year={year} />
            <Month
                key={month + year}
                month={month}
                year={year}
                selectedDates={selectedDates}
                onDayClick={onDayClick}
                PlannedDisposalDate={PlannedDisposalDate}
                availabilityData={availabilityData}
            />
        </Wrapper>
    );
};
export default CACalendarNew;
CACalendarNew.propTypes = {
    year: PropTypes.string,
    month: PropTypes.string,
    selectedDates: PropTypes.array,
    onDayClick: PropTypes.func,
    availabilityData: PropTypes.object,
    PlannedDisposalDate: PropTypes.string
};
