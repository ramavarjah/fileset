import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

const Div = styled.div`
  .check-availability-calendar-nav h1 {
    user-select: none;
    color: #5d646a;
    font-family: "Open Sans";
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.47px;
    line-height: 18px;
    margin-left: 8px;
  }
`;
const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];

const getMonthName = i => {
  let returnElement;

  months.map((e, index, arr) => {
    returnElement = arr[i - 1];
  });

  return returnElement;
};
const MonthHeader = ({ title, year }) => (
  <Div>
    <nav className="check-availability-calendar-nav">
      <h1>
        {getMonthName(title)} {year}
      </h1>
    </nav>
  </Div>
);

export default MonthHeader;
MonthHeader.propTypes = {
  year: PropTypes.string,
  title: PropTypes.string
};
