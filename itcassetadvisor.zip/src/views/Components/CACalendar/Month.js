import React from "react";
import moment from "moment";
import PropTypes from "prop-types";

const getBackgroundColor = (datess, item, rNewMarkerss) => {
  if (datess.length == 2) {
    const dates = datess.sort((a, b) => a - b); //to sort the dates in correct order
    const itemm = typeof item == "string" ? moment(item) : item;

    return moment(itemm) >= dates[0] && moment(itemm) <= dates[1]
      ? "#94B9ED"
      : "";
  }
  const itemmm = moment(item).format("MM-DD-YYYY");
  return rNewMarkerss.indexOf(itemmm) != -1 ? "#94B9ED" : "";
};

const getDays = (
  year,
  month,
  rMarkers,
  rOnSelectionChange,
  rOnHoverChange,
  rSelectedDates,
  rNewMarkers,
  rPlannedDisposalDate,
  rItem
) => {
  const props = {
    year,
    month,
    rMarkers,
    rOnSelectionChange,
    rOnHoverChange,
    rSelectedDates,
    rNewMarkers,
    rPlannedDisposalDate,
    rItem
  };
  //get the start date of the month
  const lStartDate = moment([year, month - 1, 1]).format("YYYY-MM-DD");

  // get the number of days for this month
  const daysInMonth = moment(lStartDate).daysInMonth();

  //to get which day i have to start the month
  const lStartDayOfTheCurrentMonth = moment(lStartDate).format("d");

  let days = [];
  let labels = [];

  let dateObj = {};

  //make an empty dates
  for (let i = 0; i < lStartDayOfTheCurrentMonth; i++) {
    labels.push(
      <span key={i + "_"} className="check-availability-month-days" />
    );
  }

  let rNewMarkerss;
  if (rNewMarkers.length == 2) {
    rNewMarkerss =
      rNewMarkers[1]["lightblue"] &&
      rNewMarkers[1]["lightblue"].map(e => e.format("MM-DD-YYYY"));
  }

  //put markers on the dates
  rMarkers.map(item => {
    let backgroundColor = Object.keys(item);
    item[backgroundColor].map(itemm => {
      let i = moment(itemm).format("D");
      const beforeCurrentDay = moment(itemm);
      dateObj[moment(itemm).format("DD/MM/YYYY")] = (
        <span
          className={`${
            beforeCurrentDay &&
            beforeCurrentDay <=
              moment()
                .endOf("day")
                .subtract(1, "day")
              ? "disabledDaysWrapper"
              : ""
          }`}
          style={{
            display: "inline-block",
            backgroundColor:
              rSelectedDates.length == 2 || rNewMarkerss
                ? getBackgroundColor(rSelectedDates, itemm, rNewMarkerss)
                : ""
          }}
        >
          <span
            key={i + "__"}
            style={{
              background:
                rPlannedDisposalDate != "1970-01-01T00:00:00.000Z" &&
                beforeCurrentDay > moment(rPlannedDisposalDate)
                  ? "#FFBDCD"
                  : backgroundColor == "blue"
                  ? "#3385FF"
                  : backgroundColor,
              color: `white`
            }}
            className={`check-availability-month-days ${
              beforeCurrentDay &&
              beforeCurrentDay <=
                moment()
                  .endOf("day")
                  .subtract(1, "day")
                ? "disabledDays"
                : ""
            }`}
            onClick={e => rOnSelectionChange(e, props)}
            onMouseOver={e => rOnHoverChange(e, props)}
          >
            {i}
          </span>
        </span>
      );
    });
  });

  //create dates
  for (let i = 1; i <= daysInMonth; i++) {
    let day;
    const beforeCurrentDay = moment(
      `${i}/${props.month}/${props.year}`,
      "DD/MM/YYYY"
    );
    let date = moment(`${i}/${props.month}/${props.year}`, "DD/MM/YYYY").format(
      "DD/MM/YYYY"
    );
    if (dateObj[date]) day = dateObj[date];
    else
      day = (
        <span
          className={`${
            beforeCurrentDay &&
            beforeCurrentDay <=
              moment()
                .endOf("day")
                .subtract(1, "day")
              ? "disabledDaysWrapper"
              : ""
          }`}
        >
          <span
            key={i + "__"}
            style={{
              background:
                rPlannedDisposalDate != "1970-01-01T00:00:00.000Z" &&
                beforeCurrentDay > moment(rPlannedDisposalDate)
                  ? "#FFBDCD"
                  : "#0000",
              color:
                rPlannedDisposalDate != "1970-01-01T00:00:00.000Z" &&
                beforeCurrentDay > moment(rPlannedDisposalDate)
                  ? "white"
                  : `#979797`
            }}
            className={`check-availability-month-days ${
              beforeCurrentDay &&
              beforeCurrentDay <=
                moment()
                  .endOf("day")
                  .subtract(1, "day")
                ? "disabledDays"
                : ""
            }`}
            onClick={e => rOnSelectionChange(e, props)}
            onMouseOver={e => rOnHoverChange(e, props)}
          >
            {i}
          </span>
        </span>
      );

    days.push(day);
  }
  return [...labels, ...days];
};

const Month = ({
  year,
  month,
  markers,
  onSelectionChange,
  onHoverChange,
  selectedDates,
  newMarkers,
  plannedDisposalDate,
  item
}) => {
  return (
    <div>
      {getDays(
        year,
        month,
        markers,
        onSelectionChange,
        onHoverChange,
        selectedDates,
        newMarkers,
        plannedDisposalDate,
        item
      )}
    </div>
  );
};
export default Month;
Month.propTypes = {
  year: PropTypes.string,
  month: PropTypes.string,
  markers: PropTypes.array,
  newMarkers: PropTypes.array,
  selectedDates: PropTypes.array,
  onSelectionChange: PropTypes.func,
  onHoverChange: PropTypes.func,
  plannedDisposalDate: PropTypes.string,
  item: PropTypes.object
};
