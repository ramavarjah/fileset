import React from "react";
import Month from "./Month";
import CAHeader from "./CAHeader";
import "./CA.scss";
import PropTypes from "prop-types";

const CACalendar = ({
  year,
  month,
  markers,
  onSelectionChange,
  onHoverChange,
  selectedDates,
  newMarkers,
  plannedDisposalDate,
  item
}) => {
  return (
    <div className="check-availability-calendar">
      <div className="check-availability-calendar-months">
        <CAHeader title={month} year={year} />
        <Month
          year={year}
          month={month}
          markers={markers}
          onSelectionChange={onSelectionChange}
          onHoverChange={onHoverChange}
          selectedDates={selectedDates}
          newMarkers={newMarkers}
          plannedDisposalDate={plannedDisposalDate}
          item={item}
        />
      </div>
    </div>
  );
};
export default CACalendar;
CACalendar.propTypes = {
  year: PropTypes.string,
  month: PropTypes.string,
  markers: PropTypes.array,
  newMarkers: PropTypes.array,
  selectedDates: PropTypes.array,
  onSelectionChange: PropTypes.func,
  onHoverChange: PropTypes.func,
  plannedDisposalDate: PropTypes.string,
  item: PropTypes.object
};
