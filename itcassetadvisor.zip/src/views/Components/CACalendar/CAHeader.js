import React from "react";
const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];
import PropTypes from "prop-types";
const getMonthName = i => {
  let returnElement;

  months.map((e, index, arr) => {
    returnElement = arr[i - 1];
  });

  return returnElement;
};
const CAHeader = ({ title, year }) => (
  <nav className="check-availability-calendar-nav">
    <h1>
      {getMonthName(title)} {year}
    </h1>
  </nav>
);

export default CAHeader;
CAHeader.propTypes = {
  year: PropTypes.string,
  title: PropTypes.string
};
