import React from "react";
import { observer } from "mobx-react";
import mobx from "mobx";
import { createBrowserHistory } from "history";
import { AgGridReact } from "ag-grid-react";
import serviceRequestStore from "../../stores/serviceRequestStore";
import PropTypes from "prop-types";

import { Form, Spin, Button, Icon } from "antd";
const FormItem = Form.Item;
const history = createBrowserHistory();

@observer
class RequestPage4 extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            columns: [
                { field: "manufacturer", headerName: "Manufacturer" },
                { field: "modelno", headerName: "Model Number" },
                { field: "serialno", headerName: "Serial Number" },
                { field: "assestno", headerName: "Asset No" },
                { field: "requestedservice", headerName: "Service Requested" },
                { field: "date", headerName: "Preferred Date" },
                { field: "coverage", headerName: "Coverage" }
            ],
            rows: [],
            rowSelection: "single",
            pickupAddress: "",
            reqContact: "",
            reqPhone: "",
            reqAddress: "",
            pickupcontact: "",
            pickupcompanyname: ""
        };
    }
    componentDidMount() {
        serviceRequestStore.conformBudgetaryQuote();
    }

    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridApi.sizeColumnsToFit();
    }

    handleCancel(e) {
        e.preventDefault();
        history.go(-1);
    }

    handleContinue() {
        this.props.form.validateFields();
    }
    handleClose() {
        this.props.history.push("/request");
    }

    handleExit() {
        serviceRequestStore.serviceRequestNewAddCheck([]);
        this.props.history.push("/");
    }

    render() {
        var griddata = [];
        const rowGridVal = mobx.toJS(serviceRequestStore.response_confirmation);
        var sritems = rowGridVal.result
            ? rowGridVal.result.sritems
                ? rowGridVal.result.sritems
                : []
            : [];
        sritems.map(item => {
            var griditems = {};
            griditems.manufacturer = item.manufacturer;
            griditems.modelno = item.modelno;
            griditems.serialno = item.serialno;
            griditems.requestedservice = item.requestedservice;
            griditems.coverage = item.quoteditems[0].coverage;
            griditems.assestno = item.custassetno;
            griditems.date = "";
            griddata.push(griditems);
        });

        return (
            <div id="wizard" className="serviceRequestWrapper">
                <div className="wizardHeader serviceRequestHeader">
                    <div className="pull-left">
                        <div
                            className="wizardTitle"
                            style={{ color: "rgb(255,255,255)", textTransform: "uppercase" }}
                        >
              Service Request
                        </div>
                    </div>
                    <div className="pull-right fr">
                        <Icon
                            type="close-circle-o"
                            style={{
                                color: "rgb(255,255,255)",
                                fontWeight: "100",
                                fontSize: "21px",
                                lineHeight: "normal",
                                paddingRight: "20px",
                                cursor: "pointer"
                            }}
                            onClick={this.handleClose.bind(this)}
                        />
                    </div>
                </div>
                <div className="stepsWrapper serviceRequestSteps">
                    <div className="steps active" id="step1">
            1. Service Selected
                    </div>
                    <div className="serviceStepsIcon">
                        <Icon type="arrow-right" />
                    </div>
                    <div className="steps active" id="step2">
            2. Contact & Shipping
                    </div>
                    <div className="serviceStepsIcon">
                        <Icon type="arrow-right" />
                    </div>
                    <div className="steps active" id="step3">
            3. Budgetary Quote
                    </div>
                    <div className="serviceStepsIcon">
                        <Icon type="arrow-right" />
                    </div>
                    <div className="steps active" id="step4">
            4. Confirmation
                    </div>
                </div>
                <Spin spinning={serviceRequestStore.servicerequestsLoading}>
                    <div className="col-lg-12">
                        {!serviceRequestStore.servicerequestsLoading ? (
                            <div className="selectedAssetsRowGridHeader">
                                <div className="col-md-1 pull-left">
                                    <Icon
                                        type="check-circle-o"
                                        style={{ fontSize: "65px", color: "#3ad1a4" }}
                                    />
                                </div>
                                <div className="col-md-11 pull-left">
                                    <p style={{ marginBottom: "0px" }}>
                    You have{" "}
                                        <span style={{ color: "#3ad1a4" }}> successfully </span>{" "}
                    placed your request and have now been sent a confirmation
                    email with your Service Request /RMA. Please note you may
                    reference the Service Request Number on your PO and shipping
                    documents. Please feel free to ship your equipment
                    referemcing this number. This number will be referenced on
                    all your Keysight correspondences for this request. This
                    will be followed up with a Service Order acknowledgement
                    shortly.
                                    </p>
                                </div>
                            </div>
                        ) : (
                            <div className="selectedAssetsRowGridHeader">
                                <div className="col-md-1 pull-left" />
                                <div className="col-md-11 pull-left" />
                            </div>
                        )}
                        <div style={{ clear: "both" }} />
                        <h3 style={{ marginTop: "15px" }}>Request Summary </h3>

                        <div
                            style={{
                                height: window.innerHeight - 501,
                                color: "#666",
                                overflow: "auto",
                                marginBottom: "15px"
                            }}
                            className="ag-fresh selectedAssetsRowGrid"
                        >
                            <AgGridReact
                                rowData={griddata}
                                columnDefs={this.state.columns}
                                suppressCellSelection={true}
                                rowHeight="35"
                                headerHeight="35"
                                enableSorting={true}
                                onGridReady={this.onGridReady.bind(this)}
                                rowSelection={this.state.rowSelection}
                            />
                        </div>
                        <div className="selectedAssetsRowShippingInstructions">
                            <h5>Shipping Instructions </h5>
                            <div className="shippingInstructionsTokeysight">
                                <h6>To Keysight: </h6>
                                <i> We will notify you shortly with RMA and ship to address </i>
                            </div>
                            <div className="shippingInstructionsFromKeysight">
                                <h6>From Keysight: </h6>
                                <i> No Return delivery. Customer pickup request </i>
                            </div>
                        </div>
                    </div>
                </Spin>
                <div className="wizardFooter" style={{ padding: "10px 5px 25px" }}>
                    <div className="serviceRequestFooter serviceRequestBudgetaryQuoteFooter">
                        <Form layout="inline" className="pull-right">
                            <FormItem>
                                <Button
                                    className="addThisItemButton"
                                    onClick={this.handleExit.bind(this)}
                                >
                  Close
                                </Button>
                            </FormItem>
                        </Form>
                    </div>
                </div>
            </div>
        );
    }
}
RequestPage4.propTypes = {
    router: PropTypes.func,
    form: PropTypes.object,
    history: PropTypes.object
};
const RequestConfirmationComponent = Form.create()(RequestPage4);
export default RequestConfirmationComponent;
