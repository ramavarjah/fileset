import React from "react";
import { observer } from "mobx-react";
import moment from "moment";
import { Form, Row, Button } from "antd";
import addAssetsStore from "../../stores/addAssetsStore";
const FormItem = Form.Item;

@observer
class RequestInfoCard extends React.Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            isEditing: false
        };
    }

    componentDidMount() {}

    render() {
        const heightDelta = this.state.isEditing ? 60 : 0;
        var infoStyles = {
            clearBoth: {
                clear: "both"
            },
            colRight: {
                height: window.innerHeight - 221 - heightDelta,
                backgroundColor: "#fff",
                padding: "20px",
                overflow: "scroll"
            },
            textStyle: {
                color: "#6a7682",
                fontSize: "1.1rem",
                marginBottom: "15px"
            },
            requestMarginBottom: {
                fontSize: "15px",
                marginBottom: "20px"
            },
            requestLeftTextStyle: {
                color: "#707c88",
                fontWeight: "500"
            },
            information: {
                height: window.innerHeight - 220,
                backgroundColor: "#e5e5e5",
                textAlign: "center"
            },
            informationText: {
                fontSize: "20px",
                color: "#3ad1a4",
                fontStyle: "italic",
                padding: "52% 20%",
                margin: "0px"
            }
        };
        return (
            <div className="serviceRequestInfo">
                <div className="pull-left" style={infoStyles.textStyle}>
          Request Info
                </div>

                {addAssetsStore.requestRowSelected ? (
                    <div>
                        <div
                            className={
                                this.state.isEditing
                                    ? "editissuebutton pull-right"
                                    : "editissuebuttondisabled pull-right"
                            }
                            onClick={() =>
                                this.setState({ isEditing: !this.state.isEditing })
                            }
                        >
                            {" "}
                            {/* Edit <Icon type="edit" style={{ fontWeight: 100 }} /> */}
                        </div>
                        <div style={infoStyles.clearBoth} />
                        <div style={infoStyles.colRight}>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Request ID:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.ServiceRequestID}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Order ID:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.serviceOrderId}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Type:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.serviceType}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Status:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.serviceStatus}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Event Status:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.eventStatus}
                            </Row>
                            <Row>
                                <hr />
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Equipment number:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.equipmentNo}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Manufacturer:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.manufacturer}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Model number:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.modelNo}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Serial number:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.serialNo}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Description:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.description}
                            </Row>
                            <Row>
                                <hr />
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Calibration Type:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.CalibrationType}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>Ship date :</span>{" "}
                                {new Date(addAssetsStore.requestRowSelected.shipDate) <
                new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(addAssetsStore.requestRowSelected.shipDate).format(
                                        "YYYY-MM-DD"
                                    )}
                                {/* {addAssetsStore.requestRowSelected.shipDate} */}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Order Update:
                                </span>{" "}
                                {new Date(
                                    addAssetsStore.requestRowSelected.serviceOrderUpdate
                                ) < new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(
                                        addAssetsStore.requestRowSelected.serviceOrderUpdate
                                    ).format("YYYY-MM-DD")}
                                {/* {addAssetsStore.requestRowSelected.serviceOrderUpdate} */}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>Comments :</span>{" "}
                                {addAssetsStore.requestRowSelected.comments}
                            </Row>
                            <Row>
                                <hr />
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Quote Amount:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.quoteAmount}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Quote Return Date:
                                </span>{" "}
                                {new Date(addAssetsStore.requestRowSelected.quoteDate) <
                new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(addAssetsStore.requestRowSelected.quoteDate).format(
                                        "YYYY-MM-DD"
                                    )}
                                {/* {addAssetsStore.requestRowSelected.quoteDate} */}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Pickup Date:
                                </span>{" "}
                                {new Date(addAssetsStore.requestRowSelected.pickUpDate) <
                new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(addAssetsStore.requestRowSelected.pickUpDate).format(
                                        "YYYY-MM-DD"
                                    )}
                                {/* {addAssetsStore.requestRowSelected.pickUpDate} */}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Received Date:
                                </span>{" "}
                                {new Date(addAssetsStore.requestRowSelected.receivedDate) <
                new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(
                                        addAssetsStore.requestRowSelected.receivedDate
                                    ).format("YYYY-MM-DD")}
                                {/* {addAssetsStore.requestRowSelected.receivedDate} */}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Received Condition:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.receivedCondition}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Date:
                                </span>{" "}
                                {new Date(addAssetsStore.requestRowSelected.serviceDate) <
                new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(
                                        addAssetsStore.requestRowSelected.serviceDate
                                    ).format("YYYY-MM-DD")}
                                {/* {addAssetsStore.requestRowSelected.serviceDate} */}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Service Performed:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.servicePerformed}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Returned Condition:
                                </span>{" "}
                                {addAssetsStore.requestRowSelected.returnedCondition}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Delivery Date:
                                </span>{" "}
                                {new Date(addAssetsStore.requestRowSelected.deliveryDate) <
                new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(
                                        addAssetsStore.requestRowSelected.deliveryDate
                                    ).format("YYYY-MM-DD")}
                                {/* {addAssetsStore.requestRowSelected.deliveryDate} */}
                            </Row>
                            <Row style={infoStyles.requestMarginBottom}>
                                <span style={infoStyles.requestLeftTextStyle}>
                  Closed Date:
                                </span>{" "}
                                {new Date(addAssetsStore.requestRowSelected.closedDate) <
                new Date("1970-01-02T00:00:00.00Z")
                                    ? ""
                                    : moment(addAssetsStore.requestRowSelected.closedDate).format(
                                        "YYYY-MM-DD"
                                    )}
                                {/* {addAssetsStore.requestRowSelected.closedDate} */}
                            </Row>
                        </div>
                        <div className="clear" />

                        {this.state.isEditing ? (
                            <div className="serviceRequestInfoButton">
                                <div className="userSettingsButton">
                                    <FormItem>
                                        <Button
                                            className="cancelButton"
                                            style={{ marginLeft: 8 }}
                                            onClick={() =>
                                                this.setState({ isEditing: !this.state.isEditing })
                                            }
                                        >
                      Cancel
                                        </Button>
                                        <Button
                                            className="submitButton"
                                            type="primary"
                                            style={{ marginLeft: 8 }}
                                            onClick={this.handleSubmit}
                                        >
                      Submit
                                        </Button>
                                    </FormItem>
                                </div>
                            </div>
                        ) : null}
                    </div>
                ) : (
                    <div>
                        <div style={infoStyles.clearBoth} />{" "}
                        <div style={infoStyles.information}>
                            <h1 style={infoStyles.informationText}>
                Click on an item to view more information
                            </h1>
                        </div>
                    </div>
                )}
            </div>
        );
    }
}
export default RequestInfoCard;
