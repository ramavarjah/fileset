import React from "react";
import { observer } from "mobx-react";
import mobx from "mobx";
import { createBrowserHistory } from "history";
import UIFunctions from "../../helpers/UIFunctions";
import { AgGridReact } from "ag-grid-react";
import serviceRequestStore from "../../stores/serviceRequestStore";
import PropTypes from "prop-types";
var griddata = [];
import {
  Form,
  Select,
  Input,
  Spin,
  Button,
  Upload,
  Icon,
  DatePicker
} from "antd";
const FormItem = Form.Item;
const { TextArea } = Input;
const history = createBrowserHistory();
@observer
class RequestPage3 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      ManufacturerList: [],
      columns: [
        { field: "manufacturer", headerName: "Manufacturer" },
        { field: "modelno", headerName: "Model Number" },
        { field: "serialno", headerName: "Serial Number" },
        { field: "requestedservice", headerName: "Service Requested" },
        { field: "coverage", headerName: "Coverage" },
        { field: "price", headerName: "Price*" },
        {
          field: "edit",
          headerName: "",
          cellRenderer: function() {
            return '<div> <i class="anticon anticon-edit" style="font-size:15px; cursor:pointer;"></i> <span style="font-size:15px; padding-left = "5px" cursor:pointer;"> Edit </span></div>';
          },
          width: 150,
          cellStyle: { "text-align": "center" }
        },
        {
          field: "",
          headerName: "",
          cellRenderer: this.actionCellRendererDelete,
          width: 50,
          cellStyle: { "text-align": "center" }
        }
      ],
      rowGrid: serviceRequestStore.rowSelectedAssetsData,
      rowSelection: "single",
      windowHeight: 0
    };
    this.setMode = this.setMode.bind(this);
  }

  actionCellRendererDelete = e => {
    const del = document.createElement("div");
    del.innerHTML =
      '<span><i class="anticon anticon-close-circle-o" style="color: rgb(216, 104, 104); font-size:15px; cursor:pointer;"/></span>';
    del.addEventListener("click", function() {
      const data = e.data;
      serviceRequestStore.removeFromSRItems(data);
    });
    return del;
  };

  actionCellRendererEdit = () => {
    const del = document.createElement("div");
    del.innerHTML =
      '<div> <i class="anticon anticon-edit" style="font-size:15px; cursor:pointer;"></i> <span style="font-size:15px; padding-left = "5px" cursor:pointer;"> Edit </span></div>';
    del.addEventListener("click", function() {});
    return del;
  };

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  handleSubmit() {
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        serviceRequestStore.updateSritems(values);
        serviceRequestStore.setEditFlag(true);
        serviceRequestStore.refreshBudgetaryQuote();
      }
    });
  }
  componentDidMount() {}

  handleCancel(e) {
    e.preventDefault();
    history.go(-1);
  }
  onCellClicked(event) {
    serviceRequestStore.setEditFlag(true);
    var self = this;
    if (event.column.colId == "edit") {
      serviceRequestStore.setEditFlag(false);
    }
    var selectedRows = this.gridApi.getSelectedRows();
    var formData;
    serviceRequestStore.rowSelectedAssetsData.map(item => {
      if (
        selectedRows[0].modelno === item.ModelNo &&
        selectedRows[0].serialno === item.SerialNo
      ) {
        formData = item;
      }
    });
    this.setState(
      {
        visible: true,
        mode: "edit"
      },
      () => {
        self.props.form.resetFields();
        self.props.form.setFieldsValue(formData);
      }
    );
  }
  handleContinue() {
    if (griddata.length > 0) {
      this.props.history.push("/request/RequestConfirmationComponent");
    } else {
      return UIFunctions.Toast(
        "There are no Asset to create a Request.Please add atleast one!",
        "warn"
      );
    }
  }
  setMode(mode) {
    this.setState({ mode });
  }
  handleClose() {
    this.props.history.push("/request");
  }
  render() {
    griddata = [];
    const rowGridVal = mobx.toJS(serviceRequestStore.responseData);
    var sritems = rowGridVal.result
      ? rowGridVal.result.sritems
        ? rowGridVal.result.sritems
        : []
      : [];
    sritems.map(item => {
      var griditems = {};
      griditems.manufacturer = item.manufacturer;
      griditems.modelno = item.modelno;
      griditems.serialno = item.serialno;
      griditems.requestedservice = item.requestedservice;
      griditems.coverage = item.quoteditems[0].coverage;
      griditems.price = item.quoteditems[0].price;
      griddata.push(griditems);
    });
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 12 }
    };
    const formItemLayoutTextarea = {
      labelCol: { span: 24 },
      wrapperCol: { span: 20 }
    };
    return (
      <div id="wizard" className="serviceRequestWrapper">
        <Form>
          <div className="wizardHeader serviceRequestHeader">
            <div className="pull-left">
              <div
                className="wizardTitle"
                style={{
                  color: "rgb(255,255,255)",
                  textTransform: "uppercase"
                }}
              >
                Service Request
              </div>
            </div>
            <div className="pull-right fr">
              <Icon
                type="close-circle-o"
                style={{
                  color: "rgb(255,255,255)",
                  fontWeight: "100",
                  fontSize: "21px",
                  lineHeight: "normal",
                  paddingRight: "20px",
                  cursor: "pointer"
                }}
                onClick={this.handleClose.bind(this)}
              />
            </div>
          </div>
          <div className="stepsWrapper serviceRequestSteps">
            <div className="steps active" id="step1">
              1. Service Selected
            </div>
            <div className="serviceStepsIcon">
              <Icon type="arrow-right" />
            </div>
            <div className="steps active" id="step2">
              2. Contact & Shipping
            </div>
            <div className="serviceStepsIcon">
              <Icon type="arrow-right" />
            </div>
            <div className="steps active" id="step3">
              3. Budgetary Quote
            </div>
            <div className="serviceStepsIcon">
              <Icon type="arrow-right" />
            </div>
            <div className="steps" id="step4">
              4. Confirmation
            </div>
          </div>
          <div>
            <div className="col-lg-12">
              <div className="selectedAssetsRowGridHeader">
                <p>
                  The below table shows the coverage found for the requested
                  services. For any service not covered by warranty or a service
                  agreement, the standard price is shown
                </p>
                <h3>Budgetary Quote- United States </h3>
              </div>
              <Spin spinning={serviceRequestStore.servicerequestsLoading}>
                <div
                  style={{
                    height: window.innerHeight - 473,
                    color: "#666",
                    marginBottom: "15px"
                  }}
                  className="ag-fresh selectedAssetsRowGrid"
                >
                  <AgGridReact
                    rowData={griddata}
                    columnDefs={this.state.columns}
                    suppressCellSelection={true}
                    rowHeight="35"
                    headerHeight="35"
                    enableSorting={true}
                    onGridReady={this.onGridReady.bind(this)}
                    rowSelection={this.state.rowSelection}
                    onCellClicked={this.onCellClicked.bind(this)}
                  />
                </div>
              </Spin>
              {this.state.visible && serviceRequestStore.editRowData ? (
                <div
                  className="ag-fresh srSelectedAssetsEditData srBudgedatoryQuoteEditData"
                  style={{
                    height: "155px",
                    color: "#666",
                    overflowY: "scroll"
                  }}
                >
                  <div className="col-md-6 pull-left borderRight">
                    <FormItem
                      {...formItemLayout}
                      label="Manufacturer:"
                      hasFeedback
                    >
                      {getFieldDecorator("Manufacturer", {
                        rules: [
                          { required: true, message: "Please give an input!" }
                        ]
                      })(<Input type="text" disabled />)}
                    </FormItem>
                    <FormItem
                      {...formItemLayout}
                      label="Serial Number:"
                      hasFeedback
                    >
                      {getFieldDecorator("SerialNo", {
                        rules: [
                          { required: true, message: "Please give an input!" }
                        ]
                      })(<Input type="text" disabled />)}
                    </FormItem>
                    <FormItem
                      {...formItemLayout}
                      label="Model Number:"
                      hasFeedback
                    >
                      {getFieldDecorator("ModelNo", {
                        rules: [
                          { required: true, message: "Please give an input!" }
                        ]
                      })(<Input type="text" disabled />)}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Calibration Interval:">
                      {getFieldDecorator("CalibrationInterval", {
                        rules: [
                          {
                            required: false,
                            message: "Please give an input!",
                            pattern: new RegExp("^[0-9]+(.[0-9]{1,2})?$")
                          }
                        ]
                      })(
                        <Input
                          type="text"
                          className="calibrationCycleInput"
                          disabled
                        />
                      )}
                      <span className="calibrationCycleText">Months</span>
                    </FormItem>
                    <FormItem {...formItemLayout} label="Service Agreement:">
                      {getFieldDecorator("serviceAgreement", {
                        rules: [
                          { required: false, message: "Please give an input!" }
                        ]
                      })(
                        <Input
                          type="text"
                          disabled={serviceRequestStore.editFlag}
                        />
                      )}
                    </FormItem>
                    <FormItem
                      {...formItemLayout}
                      label="Attach Fault Report/Cal Spec:"
                      hasFeedback
                    >
                      {getFieldDecorator("CalSpec", {
                        rules: [
                          { required: false, message: "Please give an input!" }
                        ]
                      })(
                        <Upload>
                          <Button disabled>
                            <Icon type="upload" /> Choose File
                          </Button>
                        </Upload>
                      )}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Asset Number:">
                      {getFieldDecorator("AssetNo", {
                        rules: [
                          { required: false, message: "Please give an input!" }
                        ]
                      })(
                        <Input
                          type="text"
                          disabled={serviceRequestStore.editFlag}
                        />
                      )}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Payment Method:">
                      {getFieldDecorator("paymentmethod", {
                        rules: [
                          { required: false, message: "Please give an input!" }
                        ]
                      })(
                        <Select
                          className="reqServiceSelectBx"
                          style={{ width: "95%" }}
                          disabled={serviceRequestStore.editFlag}
                          showSearch={true}
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.props.children
                              .toLowerCase()
                              .indexOf(input.toLowerCase()) >= 0
                          }
                          allowClear
                        >
                          {serviceRequestStore.formDropDownData.paymentmethods.map(
                            dropdown => (
                              <option key={dropdown.id}>
                                {dropdown.description}
                              </option>
                            )
                          )}
                        </Select>
                      )}
                    </FormItem>
                    <FormItem
                      {...formItemLayout}
                      label="Purchase Order Number:"
                    >
                      {getFieldDecorator("purchaseorderno", {
                        rules: [
                          { required: false, message: "Please give an input!" }
                        ]
                      })(
                        <Input
                          type="text"
                          disabled={serviceRequestStore.editFlag}
                        />
                      )}
                    </FormItem>
                    <FormItem
                      {...formItemLayout}
                      label="Attach Purchase Order:"
                      hasFeedback
                    >
                      <Upload>
                        <Button disabled>
                          <Icon type="upload" /> Choose File
                        </Button>
                      </Upload>
                    </FormItem>
                  </div>
                  <div className="col-md-6 pull-left">
                    <FormItem
                      {...formItemLayout}
                      label="Requested Service:"
                      hasFeedback
                    >
                      {getFieldDecorator("requestedservice", {
                        rules: [
                          { required: true, message: "Please give an input!" }
                        ]
                      })(
                        <Select
                          type="requestedService"
                          id="tabSelect"
                          style={{ width: "100%" }}
                          disabled={serviceRequestStore.editFlag}
                          showSearch={true}
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.props.children
                              .toLowerCase()
                              .indexOf(input.toLowerCase()) >= 0
                          }
                          allowClear
                        >
                          {serviceRequestStore.formDropDownData.services.map(
                            dropdown => (
                              <option key={dropdown.id}>
                                {dropdown.description}
                              </option>
                            )
                          )}
                        </Select>
                      )}
                    </FormItem>
                    <FormItem
                      {...formItemLayout}
                      label="Preferred date:"
                      hasFeedback
                    >
                      {getFieldDecorator("preferreddate", {})(
                        <DatePicker
                          format="YYYY-MM-DD"
                          disabled={serviceRequestStore.editFlag}
                        />
                      )}
                    </FormItem>
                    <FormItem
                      {...formItemLayoutTextarea}
                      label="Fault Description Comments:"
                      hasFeedback
                    >
                      {getFieldDecorator("fault", {
                        rules: [{}]
                      })(
                        <TextArea
                          style={{ width: "97%" }}
                          rows={4}
                          disabled={serviceRequestStore.editFlag}
                        />
                      )}
                    </FormItem>
                    <Form layout="inline">
                      {!serviceRequestStore.editFlag && (
                        <FormItem>
                          <Button type="default" className="cancelButton">
                            Cancel
                          </Button>
                        </FormItem>
                      )}
                      {!serviceRequestStore.editFlag && (
                        <FormItem>
                          <Button
                            type="Button"
                            className="aaSmallBtn btn btn-primary btn-sm"
                            id="submitBtn"
                            onClick={this.handleSubmit.bind(this)}
                            style={{ marginRight: "10px", float: "right" }}
                          >
                            Update
                          </Button>
                        </FormItem>
                      )}
                    </Form>
                    <div className="clearboth" />
                  </div>
                </div>
              ) : (
                <div
                  className="ag-fresh"
                  style={{ height: "155px", color: "#666" }}
                />
              )}
            </div>
          </div>
          <div className="wizardFooter" style={{ padding: "33px 12px 15px" }}>
            <div className="serviceRequestFooter serviceRequestBudgetaryQuoteFooter">
              <Form layout="inline">
                <FormItem>
                  <Button
                    type="default"
                    onClick={this.handleCancel.bind(this)}
                    style={{ paddingLeft: "30px", paddingRight: "0px" }}
                  >
                    <Icon type="left" />
                    Back
                  </Button>
                </FormItem>

                <FormItem>
                  <Button
                    type="default"
                    onClick={this.handleContinue.bind(this)}
                    loading={this.state.loading}
                  >
                    Continue
                    <Icon type="right" />
                  </Button>
                </FormItem>
              </Form>
            </div>
          </div>
        </Form>
      </div>
    );
  }
}
const RequestBudgatoryComponent = Form.create()(RequestPage3);
export default RequestBudgatoryComponent;

RequestPage3.propTypes = {
  router: PropTypes.func
};
