import React, { Component } from "react";
import { observer } from "mobx-react";
import { createBrowserHistory } from "history";
import Functions from "../../api/Functions";
import { AgGridReact } from "ag-grid-react";
import addAssetsStore from "../../stores/addAssetsStore";
import serviceRequestStore from "../../stores/serviceRequestStore";
import "ag-grid-enterprise";
import { Spin } from "antd";
import tabModelStore from "../../stores/tabModelStore";
import { Icon } from "antd";
import "./style.css";
import PropTypes from "prop-types";
import RequestInfoCard from "./RequestInfoCard";
import userStore from "../../stores/userStore";
import moment from "moment";

const history = createBrowserHistory();
@observer
class RequestComponent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			pickupoptions: [],
			services: [],
			returnoptions: [],
			paymentmethods: [],
			visible: false,
			mode: "",
			Manufacturer: "",
			ManufacturerList: [],
			ModelNoList: [],
			addNewItemShow: true,
			addRequest: false,

			table_expandicons: {
				groupExpanded: '<i class="fa fa-chevron-down" style="color: #40444d"/>',
				groupContracted: '<i class="fa fa-chevron-up" style="color: #40444d"/>'
			},

			_columns: [
				{
					field: "Action",
					headerName: "",
					width: 25,
					cellRenderer: "agGroupCellRenderer",
					valueGetter: this.emptyValueGetter
				},
				{ field: "ServiceRequestID", headerName: "Service Request ID" },
				{ field: "serviceOrderId", headerName: "Service Order ID" },
				{ field: "serviceType", headerName: "Service Type " },
				{ field: "serviceEventStatus", headerName: "Status " },
				{ field: "equipmentNo", headerName: "Equipment number " },
				{ field: "manufacturer", headerName: "Manufacturer" },
				{ field: "modelNo", headerName: "Model number" },
				{ field: "serialNo", headerName: "Serial number" },
				{ field: "description", headerName: "Description  " },
				{ field: "CalibrationType", headerName: "Calibration Type " },
				{
					field: "shipDate",
					headerName: "Ship Date",
					valueFormatter: this.dateFormatter
				},
				{
					field: "DocumentURL",
					headerName: "Document",
					cellRenderer: params =>
						params.value ? "<a href=" + params.value + ">Download</a>" : ""
				}
			],
			rowGrid: addAssetsStore.rowArrayData,
			rowSelection: "single",
			getRowNodeId: function(data) {
				return data.serviceOrderId;
			},
			rowClassRules: {
				"normal-row": function(params) {
					return params.node.data.read;
				},
				"bold-row": function(params) {
					return !params.node.data.read;
				}
			},
			windowHeight: 0
		};
		this.onSelectionChanged = this.onSelectionChanged.bind(this);
		this.updateDimensions();
	}
	emptyValueGetter = () => "";
	updateDimensions = () => {
		var w = window,
			d = document,
			documentElement = d.documentElement,
			body = d.getElementsByTagName("body")[0],
			height =
				w.innerHeight || documentElement.clientHeight || body.clientHeight;
		this.setState({ windowHeight: height });
	};

	dateFormatter = params => {
		if (new Date(params.value) < new Date("1970-01-02T00:00:00.00Z")) {
			return "";
		} else {
			return moment(params.value).format("YYYY-MM-DD");
		}
	};

	componentWillUnmount = function() {
		window.removeEventListener("resize", this.updateDimensions);
	};

	onSelectionChanged = () => {
		var selection = this.gridApi.getSelectedRows();
		this.gridApi.forEachDetailGridInfo(detailGridInfo =>
			detailGridInfo.api.deselectAll()
		  );
		
		var row = null;
		if (selection.length > 0) {
			row = selection[0];
		}
		addAssetsStore.setRequestRowSelected(row);
		if (row.assets) return; 

		if(row.read == false) {
			
			serviceRequestStore.markAsRead(row);
			this.gridApi.redrawRows();
			
		}
		    Functions.MarkNotificationAsRead("ServiceRequest", row.NotificationId);
		    var rowNode = this.gridApi.getRowNode(row.serviceOrderId);
		    row.read = true;
			rowNode.setData(row);
	};

	handleCancelModal = () => {
		this.setState({
			visible: false,
			mode: "edit"
		});
	};

	handleCancel(e) {
		e.preventDefault();
		history.go(-1);
	}

	handleClose() {
		serviceRequestStore.serviceRequestNewAddCheck([]);
		this.props.history.push("/");
		Functions.GetNotificationCount().then(response => {
			Functions.GetGridDataModel(tabModelStore.activeTab.TabId).then(resp => {
				tabModelStore.setCurrentTabColoumns(resp);
			});
			tabModelStore.ServiceRequestNotificationCount =
				response.data.ServiceRequestNotificationCount;
		});
	}

	handleAddReq() {
		if (this.state.addRequest) {
			this.setState({ addRequest: false });
		} else {
			this.setState({ addRequest: true });
		}
	}
	componentDidMount() {
		addAssetsStore.setRequestRowSelected(null);
		window.addEventListener("resize", this.updateDimensions);

		serviceRequestStore.initializeData().then(() => {
			this.setState({ ManufacturerList: [] });
		});
		userStore.userDetails ? "" : userStore.initializeApplication();
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
	}

	render() {
		var issueStyles = {
			clearBoth: {
				clear: "both"
			},
			colLeft: {
				height: window.innerHeight - 220,
				color: "#666"
			}
		};

		const rowGridVal = JSON.parse(
			JSON.stringify(serviceRequestStore.serviceRequestHistory)
		);

		return (
			<div id="wizard" className="serviceRequestWrapper">
				<div className="serviceRequestHeader">
					<div className="pull-left">
						<div
							className="wizardTitle"
							style={{ color: "rgb(255,255,255)", textTransform: "uppercase" }}
						>
							Service Request
						</div>
					</div>
					<div className="pull-right fr">
						<Icon
							type="close-circle-o"
							style={{
								color: "rgb(255,255,255)",
								fontWeight: "100",
								fontSize: "21px",
								lineHeight: "normal",
								paddingRight: "20px",
								cursor: "pointer"
							}}
							onClick={this.handleClose.bind(this)}
						/>
					</div>
					<div style={issueStyles.clearBoth} />
				</div>

				<div style={{ paddingTop: "35px" }} />

				<div className="reqComponentWrapper">
					<div className="col-lg-8 pull-left">
						<div className="selectedAssetsText">Open Requests</div>
						<Spin
							spinning={serviceRequestStore.servicerequestsLoading}
							delay={500}
						>
							<div
								style={issueStyles.colLeft}
								className="selectedAssetsOpenRowGrid ag-fresh"
							>
								<AgGridReact
									rowData={rowGridVal.map(e => e)}
									icons={this.state.table_expandicons}
									detailRowHeight="150"
									suppressCellSelection={true}
									rowSelection={this.state.rowSelection}
									columnDefs={this.state._columns}
									onSelectionChanged={this.onSelectionChanged}
									getRowNodeId={this.state.getRowNodeId}
									// masterDetail={true}
									// detailCellRendererParams={this.state.detailCellRendererParams}
									rowHeight="35"
									headerHeight="35"
									enableSorting={true}
									enableColResize={true}
									onGridReady={this.onGridReady.bind(this)}
									rowClassRules={this.state.rowClassRules}
								/>
							</div>
						</Spin>
					</div>

					<div className="col-lg-4 pull-left">
						<RequestInfoCard />
					</div>

					<div
						className="wizardFooter"
						style={{
							justifyContent: "center",
							fontSize: "18px",
							fontWeight: 600
						}}
					>
						<div>
							<div
								style={{
									color: "rgb(106, 118, 130)"
								}}
								onClick={() =>
									this.context.router.history.push("/request/RequestNew")
								}
							>
								New Request{" "}
								<Icon type="plus-circle-o" style={{ fontWeight: 100 }} />
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export default RequestComponent;

RequestComponent.contextTypes = {
	router: PropTypes.object.isRequired
};
RequestComponent.propTypes = {
	history: PropTypes.func
};
