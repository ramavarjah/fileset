import React from "react";
import { observer } from "mobx-react";
import mobx from "mobx";
import { createBrowserHistory } from "history";
import { AgGridReact } from "ag-grid-react";
import serviceRequestStore from "../../stores/serviceRequestStore";
import addAssetsStore from "../../stores/addAssetsStore";
import EquipmentRequest from "./EquipmentRequest";
import UIFunctions from "../../helpers/UIFunctions";
import PropTypes from "prop-types";
import moment from "moment";
import {
  Form,
  Select,
  Button,
  Icon,
  Input,
  Tooltip,
  DatePicker,
  Upload
} from "antd";

const FormItem = Form.Item;
const { TextArea } = Input;

const history = createBrowserHistory();

@observer
class RequestPage1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pickupoptions: [],
      services: [],
      returnoptions: [],
      paymentmethods: [],
      visible: false,
      mode: "details",
      Manufacturer: "",
      ManufacturerList: [],
      ModelNoList: [],
      addNewItemShow: false,
      addRequest: false,
      _columns: [
        {
          field: "updatedFlag",
          headerName: "",
          cellRenderer: function(params) {
            if (params.value)
              return '<span><i class="anticon anticon-check" style="color: #3ad1a4; font-size:20px;"/></span>';
            else
              return '<span><i class="anticon anticon-exclamation-circle-o" style="color: #f6b73c; font-size:20px;"/></span>';
          },
          width: 40,
          cellStyle: { "text-align": "center" }
        },
        { field: "EquipmentNo", headerName: "Equipment Number" },
        { field: "Manufacturer", headerName: "Manufacturer" },
        { field: "ModelNo", headerName: "Model Number" },
        { field: "SerialNo", headerName: "Serial Number" },
        { field: "CalibrationType", headerName: "Calibration Type" },
        {
          field: "requestedservice",
          headerName: "Requested Service ",
          cellRenderer: this.RequestedServiceValue
        },
        { field: "Price", headerName: "Price" },
        {
          field: "edit",
          headerName: "",
          cellRenderer: function() {
            return '<div> <i class="anticon anticon-edit" style="font-size:15px; cursor:pointer;"></i> <span style="font-size:15px; padding-left :5px ;cursor:pointer;"> Edit </span></div>';
          },
          width: 150,
          cellStyle: { "text-align": "center" }
        },
        {
          field: "",
          headerName: "",
          cellRenderer: this.actionCellRendererDelete,
          width: 50,
          cellStyle: { "text-align": "center" }
        }
      ],

      rowGrid: serviceRequestStore.rowSelectedAssetsData,
      rowSelection: "single",
      windowHeight: 0
    };
    this.setMode = this.setMode.bind(this);
    this.updateDimensions();
    addAssetsStore.setIsDashboardSelected(false);
    addAssetsStore.setIsServiceChartDashboardSelected(false);
  }
  actionCellRendererDelete = e => {
    const del = document.createElement("div");
    del.innerHTML =
      '<span><i class="anticon anticon-close-circle-o" style="color: rgb(216, 104, 104); font-size:15px; cursor:pointer;"/></span>';
    del.addEventListener("click", function() {
      const uid = e.data.EquipmentNo;
      const filteredRowData = serviceRequestStore.rowSelectedAssetsData.filter(
        r => r.EquipmentNo != uid
      );
      serviceRequestStore.serviceRequestNewAddCheck(filteredRowData);
    });
    return del;
  };

  RequestedServiceValue = params => {
    const del = document.createElement("div");
    del.innerHTML = "";
    if (params.value != "" && params.value != undefined) {
      serviceRequestStore.formDropDownData.services.map(dropdown => {
        if (dropdown.id === params.value) del.innerHTML = dropdown.description;
      });
    }
    return del;
  };

  //@Height test
  updateDimensions = () => {
    var w = window,
      d = document,
      documentElement = d.documentElement,
      body = d.getElementsByTagName("body")[0],
      height =
        w.innerHeight || documentElement.clientHeight || body.clientHeight;

    this.setState({ windowHeight: height });
  };

  componentWillUnmount = function() {
    window.removeEventListener("resize", this.updateDimensions);
    addAssetsStore.setIsDashboardSelected(false);
    addAssetsStore.setIsServiceChartDashboardSelected(false);
  };

  actionCellRenderer = e => {
    const del = document.createElement("div");
    del.innerHTML =
      '<span><i className="anticon anticon-close-circle" style="color: rgb(216, 104, 104); font-size:20px; cursor:pointer;"/></span>';
    del.addEventListener("click", () => {
      const uid = e.data.EquipmentNo;
      const filteredRowData = serviceRequestStore.rowSelectedAssetsData.filter(
        item => item.EquipmentNo != uid
      );
      serviceRequestStore.serviceRequestNewAddCheck(filteredRowData);
      this.setState({
        visible: false,
        mode: "edit"
      });
    });
    return del;
  };

  onCellClicked(event) {
    serviceRequestStore.setEditFlag(true);
    var self = this;
    if (event.column.colId == "0") {
      return this.setState({
        mode: "edit"
      });
    } //if it is a delection will not proceed further
    if (event.column.colId == "edit") {
      serviceRequestStore.setEditFlag(false);
    }
    var selectedRows = this.gridApi.getSelectedRows();
    this.setState(
      {
        visible: true,
        mode: "edit"
      },
      () => {
        self.props.form.resetFields();
        self.props.form.setFieldsValue(selectedRows[0]);
      }
    );
  }

  handleUpdate() {}
  handleContinue = () => {
    var allrequestServiceSet = true;
    serviceRequestStore.rowSelectedAssetsData.map(item => {
      if (!item.requestedservice) allrequestServiceSet = false;
    });
    if (allrequestServiceSet)
      return this.props.history.push("/request/RequestContactComponent");
    else
      UIFunctions.Toast(
        "Please add requested service type for all selected assets.",
        "error"
      );
  };
  handleSubmit() {
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        serviceRequestStore.updateSritems(values);
        serviceRequestStore.setEditFlag(true);
      }
    });
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  handleCancelModal = () => {
    this.setState({
      visible: false,
      mode: "edit"
    });
  };

  handleCancel(e) {
    e.preventDefault();
    history.go(-1);
  }
  handleCancelEdit(e) {
    e.preventDefault();
    this.setState({ mode: "details", visible: false }, () => {
      serviceRequestStore.clearEditRowData();
      this.gridApi.deselectAll();
    });
  }
  setMode(mode) {
    this.setState({ mode });
  }
  handleClose() {
    this.props.history.push("/request");
  }

  handleAddReq() {
    if (this.state.addRequest) {
      this.setState({ addRequest: false });
    } else {
      this.setState({ addRequest: true });
    }
  }
  componentDidMount() {
    window.addEventListener("resize", this.updateDimensions);
    serviceRequestStore.getFormDropDownData().then(resp => {
      this.setState({ pickupoptions: resp.data.details.result.pickupoptions });
      this.setState({ services: resp.data.details.result.services });
      this.setState({ returnoptions: resp.data.details.result.returnoptions });
      this.setState({
        paymentmethods: resp.data.details.result.paymentmethods
      });
    });
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 9 },
      wrapperCol: { span: 14 }
    };
    const reqComponentWrapperStyle = {
      height: window.innerHeight - 65
    };
    var issueStyles = {
      clearBoth: {
        clear: "both"
      }
    };

    var rowGridVal = mobx.toJS(serviceRequestStore.rowSelectedAssetsData);
    return (
      <div id="wizard" className="serviceRequestWrapper">
        <div className="serviceRequestHeader">
          <div className="pull-left">
            <div
              className="wizardTitle"
              style={{ color: "rgb(255,255,255)", textTransform: "uppercase" }}
            >
              Service Request
            </div>
          </div>
          <div className="pull-right fr">
            <Icon
              type="close-circle-o"
              style={{
                color: "rgb(255,255,255)",
                fontWeight: "100",
                fontSize: "21px",
                lineHeight: "normal",
                paddingRight: "20px",
                cursor: "pointer"
              }}
              onClick={this.handleClose.bind(this)}
            />
          </div>
          <div style={issueStyles.clearBoth} />
        </div>

        <div className="reqComponentWrapper" style={reqComponentWrapperStyle}>
          <div className="col-lg-12 column1">
            <div className="stepsWrapper serviceRequestSteps">
              <div className="steps active" id="step1">
                1. Service Selected
              </div>
              <div className="serviceStepsIcon">
                <Icon type="arrow-right" />
              </div>
              <div className="steps" id="step2">
                2. Contact & Shipping
              </div>
              <div className="serviceStepsIcon">
                <Icon type="arrow-right" />
              </div>
              <div className="steps" id="step3">
                3. Budgetary Quote
              </div>
              <div className="serviceStepsIcon">
                <Icon type="arrow-right" />
              </div>
              <div className="steps" id="step4">
                4. Confirmation
              </div>
            </div>
            <div className="selectedAssetsText">Selected Assets</div>
            <div className="gridwrapper-selected-component">
              <div
                className="selectedAssetsRowGrid ag-fresh"
                style={{
                  backgroundColor: "#e5e5e5",
                  color: "#666",
                  marginBottom: "25px"
                }}
              >
                <AgGridReact
                  rowData={rowGridVal}
                  rowSelection={this.state.rowSelection}
                  columnDefs={this.state._columns}
                  rowHeight="35"
                  headerHeight="35"
                  suppressCellSelection={true}
                  onGridReady={this.onGridReady.bind(this)}
                  onCellClicked={this.onCellClicked.bind(this)}
                />
              </div>

              {this.state.visible && serviceRequestStore.editRowData ? (
                <div
                  className="ag-fresh srSelectedAssetsEditData"
                  style={{
                    color: "#666",
                    overflowY: "scroll"
                  }}
                >
                  <Form
                    onSubmit={this.handleSubmit.bind(this)}
                    autoComplete="off"
                  >
                    <div className="col-lg-4 pull-left borderRight">
                      <FormItem
                        {...formItemLayout}
                        label="Manufacturer:"
                        hasFeedback
                      >
                        {getFieldDecorator("Manufacturer", {
                          rules: [
                            { required: true, message: "Please give an input!" }
                          ]
                        })(<Input type="text" disabled />)}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Serial Number:"
                        hasFeedback
                      >
                        {getFieldDecorator("SerialNo", {
                          rules: [
                            { required: true, message: "Please give an input!" }
                          ]
                        })(<Input type="text" disabled />)}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Model number"
                        hasFeedback
                      >
                        {getFieldDecorator("ModelNo", {
                          rules: [
                            {
                              required: addAssetsStore.mode === "CREATE",
                              message: "Please input Model number"
                            }
                          ]
                        })(<Input type="text" disabled />)}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Asset Number"
                        hasFeedback
                      >
                        {getFieldDecorator("AssetNo", {
                          rules: [
                            {
                              required: false,
                              message: "Please give an input!"
                            }
                          ]
                        })(<Input type="text" disabled />)}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Attach Fault Report/Cal Spec"
                        hasFeedback
                      >
                        <Upload>
                          <Button disabled>
                            <Icon type="upload" /> Upload File
                          </Button>
                        </Upload>
                      </FormItem>
                      <div className="clearboth" />
                    </div>
                    <div className="col-lg-4 pull-left borderRight">
                      <FormItem
                        {...formItemLayout}
                        label={
                          <span>
                            Requested Service &nbsp;
                            <Tooltip title="What is the requested service?">
                              <Icon type="question-circle-o" />
                            </Tooltip>
                          </span>
                        }
                        hasFeedback
                      >
                        {getFieldDecorator("requestedservice", {
                          rules: [
                            { required: true, message: "Please give an input!" }
                          ]
                        })(
                          <Select
                            type="requestedService"
                            id="tabSelect"
                            style={{ width: "100%" }}
                            disabled={serviceRequestStore.editFlag}
                            showSearch={true}
                            optionFilterProp="children"
                            filterOption={(input, option) =>
                              option.props.children
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                            allowClear
                          >
                            {this.state.services.map(dropdown => (
                              <option key={dropdown.id}>
                                {dropdown.description}
                              </option>
                            ))}
                          </Select>
                        )}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Preferred date"
                        hasFeedback
                      >
                        {getFieldDecorator("preferreddate", {
                          initialValue: moment().add(1, "days")
                        })(
                          <DatePicker
                            format="YYYY-MM-DD"
                            disabled={serviceRequestStore.editFlag}
                          />
                        )}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Fault description/Comments"
                        hasFeedback
                      >
                        {getFieldDecorator("fault", {
                          rules: [
                            {
                              required: false,
                              message: "Please give an input!"
                            }
                          ]
                        })(
                          <TextArea
                            rows={4}
                            disabled={serviceRequestStore.editFlag}
                          />
                        )}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Calibration Interval:"
                        hasFeedback
                      >
                        {getFieldDecorator("CalibrationInterval", {
                          rules: [
                            {
                              required: false,
                              message: "Please give an input!",
                              pattern: new RegExp("^[0-9]+(.[0-9]{1,2})?$")
                            }
                          ]
                        })(<Input type="text" disabled />)}
                      </FormItem>
                      <div className="clearboth" />
                    </div>
                    <div className="col-lg-4 pull-left">
                      <FormItem
                        {...formItemLayout}
                        label="Service Agreement:"
                        hasFeedback
                      >
                        {getFieldDecorator("serviceAgreement", {
                          rules: [
                            {
                              required: false,
                              message: "Please give an input!"
                            }
                          ]
                        })(
                          <Input
                            type="text"
                            disabled={serviceRequestStore.editFlag}
                          />
                        )}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Payment Method:"
                        hasFeedback
                      >
                        {getFieldDecorator("paymentmethod", {
                          rules: [
                            {
                              required: false,
                              message: "Please give an input!"
                            }
                          ]
                        })(
                          <Select
                            id="tabSelect"
                            style={{ width: "100%" }}
                            disabled={serviceRequestStore.editFlag}
                            showSearch={true}
                            optionFilterProp="children"
                            filterOption={(input, option) =>
                              option.props.children
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                            allowClear
                          >
                            {this.state.paymentmethods.map(dropdown => (
                              <option key={dropdown.id}>
                                {dropdown.description}
                              </option>
                            ))}
                          </Select>
                        )}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Purchase Order Number:"
                        hasFeedback
                      >
                        {getFieldDecorator("purchaseorderno", {
                          rules: [
                            {
                              required: false,
                              message: "Please give an input!"
                            }
                          ]
                          //initialValue: this.state.OrderNumber
                        })(
                          <Input
                            type="text"
                            disabled={serviceRequestStore.editFlag}
                          />
                        )}
                      </FormItem>
                      <FormItem
                        {...formItemLayout}
                        label="Attach Purchase Order"
                        hasFeedback
                      >
                        <Upload>
                          <Button disabled>
                            <Icon
                              type="upload"
                              disabled={serviceRequestStore.editFlag}
                            />{" "}
                            Upload File
                          </Button>
                        </Upload>
                      </FormItem>
                      <Form layout="inline">
                        {!serviceRequestStore.editFlag && (
                          <FormItem>
                            <Button
                              type="default"
                              className="cancelButton"
                              onClick={this.handleCancelEdit.bind(this)}
                            >
                              Cancel
                            </Button>
                          </FormItem>
                        )}
                        {!serviceRequestStore.editFlag && (
                          <FormItem>
                            <Button
                              className="aaSmallBtn btn btn-primary btn-sm"
                              onClick={this.handleUpdate.bind(this)}
                              id="submitBtn"
                              type="primary"
                              htmlType="submit"
                              style={{ marginRight: "10px", float: "right" }}
                            >
                              Update
                            </Button>
                          </FormItem>
                        )}
                      </Form>
                      <div className="clearboth" />
                    </div>
                  </Form>
                </div>
              ) : (
                <div
                  className="ag-fresh"
                  style={{ height: "50px", color: "#666" }}
                />
              )}
            </div>
            <div className="wizardFooter">
              <div className="serviceRequestFooter">
                <Form layout="inline">
                  <FormItem>
                    <Button
                      type="default"
                      onClick={this.handleCancel.bind(this)}
                      style={{ paddingLeft: "125px", paddingRight: "0px" }}
                    >
                      <Icon type="left" />
                      Cancel
                    </Button>
                  </FormItem>
                  <FormItem>
                    <Button
                      onClick={this.handleContinue.bind(this)}
                      disabled={
                        serviceRequestStore.rowSelectedAssetsData.length
                          ? false
                          : true
                      }
                      type="default"
                    >
                      Continue
                      <Icon type="right" />
                    </Button>
                  </FormItem>
                  {/* </Link> */}
                </Form>
              </div>
              <Button
                className="addThisItemButton"
                onClick={() => this.setState({ addNewItemShow: true })}
              >
                Add New Item
              </Button>
              {this.state.addNewItemShow ? (
                <EquipmentRequest
                  onCancel={() => this.setState({ addNewItemShow: false })}
                />
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const RequestSelectedComponent = Form.create()(RequestPage1);
export default RequestSelectedComponent;

RequestSelectedComponent.propTypes = {
  router: PropTypes.func
};
