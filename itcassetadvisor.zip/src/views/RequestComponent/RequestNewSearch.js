import React, { Component } from "react";
import { observer } from "mobx-react";
import { Input, Icon, Col } from "antd";
import PropTypes from "prop-types";
@observer
class RequestNewSearch extends Component {
    constructor(props) {
        super(props);
        this.state = null;
    }
    componentDidMount() {}

    render() {
        return (
            <div className="lp-search-wrapper">
                <Col span={3}>
                    <span style={{ cursor: "pointer" }}>
                        <Icon type="search" />
                    </span>
                </Col>
                <Col span={21}>
                    <Input placeholder="Search of an Asset..." />
                </Col>
            </div>
        );
    }
}

export default RequestNewSearch;

RequestNewSearch.contextTypes = {
    router: PropTypes.object.isRequired
};
