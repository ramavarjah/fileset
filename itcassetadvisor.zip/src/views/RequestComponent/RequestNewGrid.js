import React, { Component } from "react";
import { observer } from "mobx-react";
import { AgGridReact } from "ag-grid-react";
import { Spin } from "antd";
import serviceRequestStore from "../../stores/serviceRequestStore";
import HealthCellRenderer from "../Dashboard/ag/HealthCellRenderer";
import PropTypes from "prop-types";
@observer
class RequestNewGrid extends Component {
  constructor(props) {
    super(props);
    this.state = {
      columnDefs: [
        {
          field: "",
          headerName: "",
          width: 50,
          checkboxSelection: true,
          headerCheckboxSelection: true,
          pinned: true,
          menuTabs: []
        },
        {
          field: "HealthStatus",
          headerName: "Health",
          width: 170,
          formatter: "ImageFormatter",
          cellRendererFramework: HealthCellRenderer
        },
        { field: "IsConnected", headerName: "Is Connected", width: 220 },
        {
          field: "AssetNo",
          headerName: "Asset Number",
          width: 170
        },
        { field: "Barcode", headerName: "Barcode / RFID", width: 170 },
        {
          field: "EquipmentNo",
          headerName: "Equipment Number",
          width: 170
        },
        { field: "Manufacturer", headerName: "Manufacturer", width: 278 },
        {
          field: "AltManufacturerName",
          headerName: "Alt Manufacturer",
          width: 170
        },
        { field: "ModelNo", headerName: "ModelNumber", width: 220 },
        { field: "SerialNo", headerName: "Serial Number", width: 170 },
        { field: "Description", headerName: "Description", width: 220 }
      ],
      rowSelection: "multiple",
      lastPageFound: false,
      currentLimit: 25,
      totalPages: 0,
      startItem: 1,
      lastItem: 25,
      isDensityApplied: "false",
      currentDensityState: "default",
      currentPage: 1
    };

    this.currentRowHeight = "35";
    this.rowGetData = this.rowGetData.bind(this);

    this.onRowSelected = this.onRowSelected.bind(this);
  }

  setGridItemsSelection() {
    this.api.removeEventListener("selectionChanged", this.onRowSelected);

    this.api.forEachNode(function(node) {
      //hmmmpf need to check if modelnumber is unique or if there is any other unique fields -- @premith
      if (
        serviceRequestStore.rowSelectedAssetsData.find(
          item => item.EquipmentNo === node.data.EquipmentNo
        )
      ) {
        node.setSelected(true);
      }
    });

    this.api.addEventListener("selectionChanged", this.onRowSelected);
  }
  rowGetData = () => {
    var rtn = serviceRequestStore.ServiceRequestAssetsData;
    return JSON.parse(JSON.stringify(rtn));
  };
  onRowSelected = event => {
    let rows = event.api.getSelectedRows();
    serviceRequestStore.serviceRequestNewAddCheck(
      JSON.parse(JSON.stringify(rows))
    );
  };
  componentDidUpdate() {
    serviceRequestStore.servicerequestsLoading
      ? ""
      : this.setGridItemsSelection();
  }

  onGridReady = params => {
    this.api = params.api;
    this.columnApi = params.columnApi;
    this.setState({ totalPages: this.api.paginationGetTotalPages() });
    this.setGridItemsSelection();
  };

  onBtFirst = () => {
    this.api.paginationGoToFirstPage();
  };

  onBtLast = () => {
    this.api.paginationGoToLastPage();
  };

  onBtNext = () => {
    this.api.paginationGoToNextPage();
  };

  onBtPrevious = () => {
    this.api.paginationGoToPreviousPage();
  };

  getTotalPages = () => {
    return this.api.paginationGetTotalPages();
  };

  paginationGoToPage = e => {
    if (e.target.value > 0) {
      this.api.paginationGoToPage(parseInt(e.target.value) - 1);
    }
  };

  handleDensityDefault() {
    this.setState({
      isDensityApplied: "false",
      currentDensityState: "default"
    });
    this.currentRowHeight = "35";
    this.api.resetRowHeights();
    this.api.onRowHeightChanged();
  }

  handleDensityMedium() {
    this.setState({
      isDensityApplied: "true",
      currentDensityState: "medium"
    });
    this.currentRowHeight = "43";

    this.api.resetRowHeights();
    this.api.onRowHeightChanged();
  }

  handleDensityLarge() {
    this.setState({
      isDensityApplied: "true",
      currentDensityState: "large"
    });
    this.currentRowHeight = "50";

    this.api.resetRowHeights();
    this.api.redrawRows();
    this.api.onRowHeightChanged();
  }

  handlePageSize(e) {
    var currentLimit = e.target.value;
    this.api.paginationSetPageSize(currentLimit);
  }

  onPaginationChanged() {
    if (this.api) {
      var currentPage = this.api.paginationGetCurrentPage();
      var currentPageSize = this.api.paginationGetPageSize();
      var startItem = currentPage * currentPageSize + 1;

      var lastItem = +parseInt(startItem) + parseInt(currentPageSize) - 1;
      if (lastItem > serviceRequestStore.ServiceRequestAssetsData.length)
        lastItem = serviceRequestStore.ServiceRequestAssetsData.length;
      const totalPages = this.api.paginationGetTotalPages();
      this.setState({
        totalPages,
        startItem,
        lastItem,
        currentPage: this.api.paginationGetCurrentPage() + 1
      });
    }
  }

  handleRefresh() {
    serviceRequestStore.initializeDataNewRequest();
  }
  getRowHeight = () => {
    return parseInt(this.currentRowHeight);
  };

  render() {
    let gridStyles = {
      clearBoth: {
        clear: "both"
      },
      windowHeight: {
        color: "#666",
        border: "1px solid #afb5c3"
      }
    };
    return (
      <div className="srnew-grid-wrapper">
        <Spin spinning={serviceRequestStore.servicerequestsLoading} delay={500}>
          <div
            className="selectedAssetsOpenRowGrid ag-fresh"
            style={gridStyles.windowHeight}
          >
            <AgGridReact
              rowData={
                serviceRequestStore.ServiceRequestAssetsData
                  ? serviceRequestStore.ServiceRequestAssetsData.map(e => e)
                  : []
              }
              columnDefs={serviceRequestStore.SelectAssetsGridColumn.map(
                e => e
              )}
              rowSelection={this.state.rowSelection}
              suppressRowClickSelection={true}
              suppressCellSelection={true}
              suppressPaginationPanel={true}
              headerHeight="50"
              getRowHeight={this.getRowHeight}
              enableSorting={true}
              enableColResize={true}
              pagination={true}
              paginationPageSize="25"
              onGridReady={this.onGridReady}
              onPaginationChanged={this.onPaginationChanged.bind(this)}
            />
          </div>
        </Spin>
        <div id="">
          <div>
            <nav className="navbar navbar-dark bg-dark paginationBar">
              <div className="col-sm-3 paginationButtons">
                <ul>
                  <li className="pageControls ">
                    <i
                      className="fa fa-angle-double-left clickable "
                      onClick={this.onBtFirst.bind(this)}
                    />
                  </li>
                  <li className="pageControls">
                    <i
                      className="fa fa-angle-left clickable"
                      onClick={this.onBtPrevious.bind(this)}
                    />
                  </li>
                  <li>
                    <span className="page">Page</span>
                  </li>
                  <li>
                    <input
                      className="pageNumberInput"
                      type="number"
                      min="1"
                      onChange={this.paginationGoToPage.bind(this)}
                      value={this.state.currentPage}
                    />
                  </li>
                  <li>
                    <span className="of38">of {this.state.totalPages}</span>
                  </li>
                  <li className="pageControls">
                    <i
                      className="fa fa-angle-right clickable"
                      onClick={this.onBtNext.bind(this)}
                    />
                  </li>
                  <li className="pageControls">
                    <i
                      className="fa fa-angle-double-right clickable"
                      onClick={this.onBtLast.bind(this)}
                    />
                  </li>
                  <li className="pageControls">
                    <i
                      className="icon-refresh clickable refresh-hover"
                      onClick={this.handleRefresh.bind(this)}
                    />
                  </li>
                </ul>
              </div>

              {/*============== 'Display Density Group' ==============*/}
              <div className="col-sm-2 displayDensity">
                <ul>
                  <li className="densityButtons">
                    <span className="displayDensityLabel">Display Density</span>
                  </li>
                  <li
                    className="densityButtons"
                    onClick={this.handleDensityDefault.bind(this)}
                  >
                    <a href="#">
                      <i
                        className={
                          "icon-menu " +
                          (this.state.currentDensityState == "default"
                            ? "selected"
                            : "")
                        }
                        style={{ fontSize: "0.8em", paddingRight: 15 }}
                      />
                    </a>
                  </li>
                  <li
                    className="densityButtons"
                    onClick={this.handleDensityMedium.bind(this)}
                    style={{ marginTop: 2 }}
                  >
                    <a href="#">
                      <i
                        className={
                          "icon-menu " +
                          (this.state.currentDensityState == "medium"
                            ? "selected"
                            : "")
                        }
                        style={{ fontSize: "1.2em", paddingRight: 15 }}
                      />
                    </a>
                  </li>
                  <li
                    className="densityButtons"
                    onClick={this.handleDensityLarge.bind(this)}
                    style={{ marginTop: -1 }}
                  >
                    <a href="#">
                      <i
                        className={
                          "icon-menu " +
                          (this.state.currentDensityState == "large"
                            ? "selected"
                            : "")
                        }
                        style={{ fontSize: "1.5em", paddingRight: 15 }}
                      />
                    </a>
                  </li>
                </ul>
              </div>

              <span
                className="page"
                style={{
                  paddingLeft: "20px",
                  paddingRight: "5px",
                  color: "#fff"
                }}
              >
                Page Size
              </span>
              <div className="col-sm-1 pageSize">
                <select
                  id="tabSelect"
                  className="dashfooterSelect"
                  onChange={this.handlePageSize.bind(this)}
                >
                  <option key={25}>25</option>
                  <option key={50}>50</option>
                  <option key={75}>75</option>
                  <option key={100}>100</option>
                  <option key={150}>150</option>
                  <option key={200}>200</option>
                  <option key={250}>250</option>
                </select>
              </div>

              <span className="grid-page-label">
                Displaying {this.state.startItem}-{this.state.lastItem} of{" "}
                {serviceRequestStore.ServiceRequestAssetsData.length}
              </span>
              {/*</div>*/}
            </nav>
          </div>
        </div>
      </div>
    );
  }
}

export default RequestNewGrid;

RequestNewGrid.propTypes = {
  router: PropTypes.object.isRequired
};
