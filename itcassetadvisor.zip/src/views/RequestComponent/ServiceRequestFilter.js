/* eslint react/no-string-refs: 0 */ // --> OFF
import React, { Component } from "react";
import { Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import moment from "moment";
import PropTypes from "prop-types";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";
import "./style.css";
import tabModelStore from "../../stores/tabModelStore";
import serviceRequestStore from "../../stores/serviceRequestStore";
// eslint-disable-next-line
import JQueryBuilder from "src/libs/jQuery-QueryBuilder-chosen/query-builder";
// eslint-disable-next-line
import chosen from "src/libs/jQuery-QueryBuilder-chosen/chosen-js-patched";
// eslint-disable-next-line
import datepicker from "bootstrap-datepicker";

var $ = require("jquery");

const emptyRule = {
	rules: [
		{
			empty: true
		}
	]
};

class ServiceRequestFilter extends Component {
	constructor(props) {
		super(props);

		this.handleSaveFilterClick = this.handleSaveFilterClick.bind(this);
		this.handleDeleteFilterClick = this.handleDeleteFilterClick.bind(this);

		this.state = {
			modal: true,
			modalNew: !this.props.clicked,
			rules: {},
			savedFilters: null,
			searchInput: "",
			filterSaving: false,
			savedSearchID: "",
			savedSearchSelected: false,
			saveFilterEnabled: false
		};
	}

	initializeQueryBuilder(element, newRules, filters) {
		try {
			if (Object.getOwnPropertyNames(newRules).length === 0) {
				newRules = null;
			}

			const plugins = {
				"chosen-selectpicker": null,
				"unique-filter": null,
				"bt-checkbox": { color: "primary" }
			};

			var operators = [
				{ type: "equal", optgroup: "basic" },
				{ type: "not_equal", optgroup: "basic" },
				{ type: "in", optgroup: "basic" },
				{ type: "not_in", optgroup: "basic" },
				{ type: "less", optgroup: "numbers" },
				{ type: "less_or_equal", optgroup: "numbers" },
				{ type: "greater", optgroup: "numbers" },
				{ type: "greater_or_equal", optgroup: "numbers" },
				{ type: "between", optgroup: "numbers" },
				{ type: "not_between", optgroup: "numbers" },
				{ type: "begins_with", optgroup: "text" },
				{ type: "not_begins_with", optgroup: "text" },
				{ type: "contains", optgroup: "text" },
				{ type: "not_contains", optgroup: "text" },
				{ type: "ends_with", optgroup: "text" },
				{ type: "not_ends_with", optgroup: "text" },
				{ type: "is_empty", optgroup: "empty/null" },
				{ type: "is_not_empty", optgroup: "empty/null" },
				{ type: "is_null", optgroup: "empty/null" },
				{ type: "is_not_null", optgroup: "empty/null" }
			];

			var optgroups = {
				Dates: { en: "Dates" },
				Booleans: { en: "Yes/No" },
				Lists: { en: "Lists" },
				Strings: { en: "Text Input" },
				Spinner: { en: "numeric spinner input" },
				Doubles: { en: "Prices" },
				Integers: { en: "Numbers" }
			};

			const rules = newRules ? newRules : null;
			$(element).queryBuilder({
				plugins: plugins,
				operators: operators,
				filters: filters,
				rules: rules,
				optgroups: optgroups,
				conditions: ["AND", "OR"],
				allow_groups: 3
			});

			this.setState({ rules: newRules });

			//added code to enable save filter
			var thisRef = this;
			$(element).on(
				"afterUpdateRuleValue.queryBuilder afterUpdateGroupCondition.queryBuilder afterUpdateRuleOperator.queryBuilder afterAddRule.queryBuilder afterDeleteRule.queryBuilder afterDeleteGroup.queryBuilder",
				function() {
					if (thisRef.state.savedSearchSelected) {
						thisRef.setState({ saveFilterEnabled: true });
					}
				}
			);
		} catch (error) {
			UIFunctions.Toast("Something went wrong..!", "error");
		}
	}

	toggleNew() {
		if (serviceRequestStore.serviceRequestfilterModalOpen) {
			serviceRequestStore.setServiceRequestFilterModalopen(false);
		} else {
			serviceRequestStore.setServiceRequestFilterModalopen(true);
		}
	}
	// get data from jQuery Query Builder and pass to the react component
	handleGetRulesClick() {
		const rules = $(this.refs.queryBuilder).queryBuilder("getRules");
		this.setState({ rules: rules });
		this.forceUpdate();
	}
	// reinitialize jQuery Query Builder based on react state
	handleSetRulesClick(rule) {
		const newRules = rule;
		if (Object.getOwnPropertyNames(rule).length === 0) {
			const newRule = { ...emptyRule };
			$(this.refs.queryBuilder).queryBuilder("setRules", newRule);
		} else {
			$(this.refs.queryBuilder).queryBuilder("setRules", rule);
			this.setState({ rules: newRules });
		}
	}
	SetDateISOString(baseQuery) {
		var noOfRules = baseQuery.rules.length;
		if (noOfRules == 1) {
			if (baseQuery.rules[0].type == "date") {
				if (
					baseQuery.rules[0].operator == "between" ||
					baseQuery.rules[0].operator == "not_between"
				) {
					baseQuery.rules[0].value[0] = new Date(
						baseQuery.rules[0].value[0]
					).toISOString();
					baseQuery.rules[0].value[1] = new Date(
						baseQuery.rules[0].value[1]
					).toISOString();
				} else {
					baseQuery.rules[0].value = new Date(
						baseQuery.rules[0].value
					).toISOString();
				}
			}
		} else {
			for (var i = 0; i < noOfRules; i++) {
				if (baseQuery.rules[i].rules == undefined) {
					if (baseQuery.rules[i].type == "date") {
						if (
							baseQuery.rules[i].operator == "between" ||
							baseQuery.rules[i].operator == "not_between"
						) {
							baseQuery.rules[i].value[0] = new Date(
								baseQuery.rules[i].value[0]
							).toISOString();
							baseQuery.rules[i].value[1] = new Date(
								baseQuery.rules[i].value[1]
							).toISOString();
						} else {
							baseQuery.rules[i].value = new Date(
								baseQuery.rules[i].value
							).toISOString();
						}
					}
				} else {
					baseQuery.rules[i] = this.SetDateISOString(baseQuery.rules[i]);
				}
			}
		}
		return baseQuery;
	}

	formatfilterDate(baseQuery) {
		baseQuery = JSON.parse(JSON.stringify(baseQuery));
		var noOfRules = baseQuery.rules ? baseQuery.rules.length : 0;
		if (noOfRules == 1) {
			if (baseQuery.rules[0].type == "date") {
				if (
					baseQuery.rules[0].operator == "between" ||
					baseQuery.rules[0].operator == "not_between"
				) {
					baseQuery.rules[0].value[0] = moment(
						baseQuery.rules[0].value[0]
					).format("YYYY/MM/DD");
					baseQuery.rules[0].value[1] = moment(
						baseQuery.rules[0].value[1]
					).format("YYYY/MM/DD");
				} else {
					baseQuery.rules[0].value = moment(baseQuery.rules[0].value).format(
						"YYYY/MM/DD"
					);
				}
			}
		} else {
			for (var i = 0; i < noOfRules; i++) {
				if (baseQuery.rules[i].rules == undefined) {
					if (baseQuery.rules[i].type == "date") {
						if (
							baseQuery.rules[i].operator == "between" ||
							baseQuery.rules[i].operator == "not_between"
						) {
							baseQuery.rules[i].value[0] = moment(
								baseQuery.rules[i].value[0]
							).format("YYYY/MM/DD");
							baseQuery.rules[i].value[1] = moment(
								baseQuery.rules[i].value[1]
							).format("YYYY/MM/DD");
						} else {
							baseQuery.rules[i].value = moment(
								baseQuery.rules[i].value
							).format("YYYY/MM/DD");
						}
					}
				} else {
					baseQuery.rules[i] = this.formatfilterDate(baseQuery.rules[i]);
				}
			}
		}
		return baseQuery;
	}

	handleApplyFilterClick() {
		const appliedRule = $(this.refs.queryBuilder).queryBuilder("getRules");
		var FilterData = {};
		FilterData.TabId = "1";
		FilterData.baseQuery = appliedRule;
		FilterData.filterQuery = {};
		if (!FilterData.baseQuery)
			return UIFunctions.ShowError({
				zIndex: 2000,
				title: "Invalid filter query!"
			});
		FilterData.baseQuery = this.SetDateISOString(appliedRule);
		tabModelStore.setDataLoaded(false);
		Functions.SetFilters(FilterData)
			.then(() => {
				this.toggleNew();
				serviceRequestStore.initializeDataNewRequest();
			})
			.catch(() => {});
	}

	handleChange(value) {
		this.setState({
			searchInput: value
		});
	}

	handleSaveAsFilterClick() {
		const appliedRule = $(this.refs.queryBuilder).queryBuilder("getRules");
		var FilterData = {};
		FilterData.TabId = tabModelStore.activeTab.TabId;
		FilterData.baseQuery = appliedRule;
		FilterData.SearchName = this.state.searchInput;
		FilterData.filterQuery = {};
		if (!FilterData.baseQuery)
			return UIFunctions.ShowError({
				zIndex: 2000,
				title: "Invalid filter query!"
			});
		if (!this.state.searchInput)
			return UIFunctions.ShowError({
				zIndex: 2000,
				title: "Invalid filter name!"
			});
		var existingFilter = this.state.savedFilters;
		function existingFilterCheck(filterName) {
			return filterName.key === FilterData.SearchName;
		}
		if (existingFilter.find(existingFilterCheck) != undefined) {
			UIFunctions.ShowError({
				zIndex: 2000,
				title:
					"Filter name: " +
					this.state.searchInput +
					" already exist! Please use different name"
			});
		} else {
			this.setState({
				filterSaving: true
			});
			Functions.CreateSavedSearch(FilterData)
				.then(resp => {
					Functions.GetSavedSearch(tabModelStore.activeTab.TabId)
						.then(respFiData => {
							var arrTen = [];
							var result = respFiData.data.data;
							for (var k = 0; k < result.length; k++) {
								var item = result[k];
								arrTen.push(
									<option
										key={item.SearchName}
										baseQuery={item.baseQuery}
										selected={item.selected}
										value={item.SearchId}
									>
										{" "}
										{item.SearchName}{" "}
									</option>
								);
							}

							this.setState({
								savedFilters: arrTen,
								filterSaving: false
							});
						})
						.catch(() => {
							this.setState({
								filterSaving: false
							});
						});
					if (resp.data.success === true) {
						UIFunctions.ShowSuccess({
							zIndex: 2000,
							title:
								"Filter Name: " +
								this.state.searchInput +
								" Filter Created Successfully! "
						});
						this.setState({
							filterSaving: false
						});
					}
				})
				.catch(() => {
					this.setState({
						filterSaving: false
					});
				});
		}
	}

	handleSaveFilterClick() {
		this.setState({
			filterSaving: true,
			saveFilterEnabled: false
		});
		const appliedRule = $(this.refs.queryBuilder).queryBuilder("getRules");
		var FilterData = {};
		FilterData.baseQuery = appliedRule;
		FilterData.SearchId = this.state.savedSearchID;
		FilterData.filterQuery = {};
		if (!FilterData.baseQuery)
			return UIFunctions.ShowError({
				zIndex: 2000,
				title: "Invalid filter query!"
			});
		Functions.EditSavedSearch(FilterData)
			.then(resp => {
				if (resp.data.success === true) {
					UIFunctions.ShowSuccess({
						zIndex: 2000,
						title:
							"Filter : " + this.state.searchInput + " Updated Successfully "
					});
				}
			})
			.catch(() => {});

		this.setState({
			filterSaving: false
		});
	}

	onFilterChange(val) {
		this.setState({ saveFilterEnabled: false });
		this.setState({ savedSearchSelected: true });
		var allFilters = this.state.savedFilters;
		function getFilter(filterName) {
			return filterName.props.value === val;
		}
		var selectedFilter = allFilters.find(getFilter);
		$(this.refs.queryBuilder).queryBuilder(
			"setRules",
			selectedFilter.props.baseQuery
		);
		this.setState({
			savedSearchID: val
		});
		this.forceUpdate();
	}

	handleDeleteFilterClick() {
		this.setState({ saveFilterEnabled: false, savedSearchSelected: false });
		var searchID = this.state.savedSearchID;
		Functions.DeleteSavedSearch(searchID)
			.then(() => {
				Functions.GetSavedSearch(tabModelStore.activeTab.TabId)
					.then(respFiData => {
						var arrTen = [];
						var result = respFiData.data.data;
						for (var k = 0; k < result.length; k++) {
							var item = result[k];
							arrTen.push(
								<option
									key={item.SearchName}
									baseQuery={item.baseQuery}
									selected={item.selected}
									value={item.SearchId}
								>
									{" "}
									{item.SearchName}{" "}
								</option>
							);
						}

						this.setState({
							savedFilters: arrTen
						});
					})
					.catch(() => {});
			})
			.catch(() => {});
	}

	componentDidMount() {
		const element = this.refs.queryBuilder;
		$(".datepicker").datepicker();
		Functions.GetFilterValues().then(resp => {
			Functions.GetFilters("1").then(respFiData => {
				respFiData.data.baseQuery = this.formatfilterDate(
					respFiData.data.baseQuery
				);
				var Fields = serviceRequestStore.SelectAssetsGridColumn.map(
					item => item.field
				);
				const FilterFields = JSON.parse(
					JSON.stringify(
						resp.data.filters.filter(item => {
							return Fields.indexOf(item.id) >= 0;
						})
					)
				);

				this.initializeQueryBuilder(
					element,
					respFiData.data.baseQuery,
					FilterFields
				);
				Functions.GetSavedSearch().then(respFiData => {
					var arrTen = [];
					var result = respFiData.data.data;
					for (var k = 0; k < result.length; k++) {
						var item = result[k];
						if (item.selected == true) {
							this.setState({
								savedSearchID: item.SearchId
							});
						}
						arrTen.push(
							<option
								key={item.SearchName}
								baseQuery={item.baseQuery}
								selected={item.selected}
								value={item.SearchId}
								className="savedFilterSelectBoxOption"
							>
								{" "}
								{item.SearchName}{" "}
							</option>
						);
					}

					this.setState({
						savedFilters: arrTen
					});
				});
			});
		});
	}
	clearFilter() {
		serviceRequestStore.clearServiceRequestFilter();
		this.toggleNew();
	}
	render() {
		return (
			<Modal
				isOpen={true}
				className="modal-dialog modal-lg editFiltersModal"
				id="createAssetModal"
				style={{ maxWidth: 900 }}
			>
				<ModalHeader className="row modalHeader editFiltersModalHeader">
					<span className="createAssetLabel">EDIT FILTERS</span>
					<span
						onClick={this.toggleNew.bind(this)}
						style={{ cursor: "pointer" }}
					>
						<i className="icon-close" />
					</span>
				</ModalHeader>
				<ModalBody style={{ padding: 0 }}>
					<div
						className="filterBody"
						style={{ height: window.innerHeight - 230 }}
					>
						<div id="query-builder" ref="queryBuilder" />
					</div>
				</ModalBody>
				<ModalFooter>
					{/* 'Create Asset Fixed Footer' */}
					<nav className="modalFooter navbar">
						<div
							className="btn-group"
							id="queryBuilderButtons"
							role="group"
							aria-label="Basic example"
						>
							<button
								type="button"
								className="aaSmallBtn btn"
								onClick={this.clearFilter.bind(this)}
							>
								Clear Filters
							</button>
							<button
								type="button"
								className="aaSmallBtn btn"
								onClick={this.handleApplyFilterClick.bind(this)}
								id="applyBtn"
							>
								Apply Filters
							</button>
						</div>
					</nav>
				</ModalFooter>
			</Modal>
		);
	}
}
export default ServiceRequestFilter;
ServiceRequestFilter.propTypes = {
	clicked: PropTypes.String
};
