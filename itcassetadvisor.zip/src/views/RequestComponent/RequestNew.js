import React, { Component } from "react";
import { observer } from "mobx-react";
import mobx from "mobx";
import PropTypes from "prop-types";

import { Icon, Row, Col } from "antd";
import { AgGridReact } from "ag-grid-react";
import moment from "moment";

import Functions from "../../api/Functions";
import loanPoolStore from "../../stores/loanPoolStore";
import serviceRequestStore from "../../stores/serviceRequestStore";
import _ from "lodash";
import dateArray from "moment-array-dates";

import Autosuggest from "react-autosuggest";
import RequestNewGrid from "./RequestNewGrid";
import EquipmentRequest from "./EquipmentRequest";
import ServiceRequestFilter from "./ServiceRequestFilter";

const getSuggestionValue = suggestion =>
  suggestion.colName != undefined ? suggestion.searchStr : "";
const renderSuggestion = suggestion => (
  <div
    style={{
      color: "white",
      zIndex: 10000000,
      backgroundColor: "grey",
      marginBottom: 1,
      borderBottomColor: "black",
      cursor: suggestion.colName != undefined ? "pointer" : "cursor"
    }}
  >
    {suggestion.searchStr}
  </div>
);
@observer
class RequestNew extends Component {
  constructor(props) {
    super(props);
    this.createRows();
    this._columns = [{ key: "AssetNo", name: "Equipment Number" }];

    this.state = {
      addNewItemShow: true,
      addRequest: false,
      tabActive: "selectAsset",
      currentStep: "step1",
      AvalibalityColumns: [],
      suggestions: [],
      value: "",
      columns: [{ key: "EquipmentNo", name: "Equipment Number" }],
      columnLength: 0,

      columnDefs: [
        {
          field: "Asset Number",
          headerName: "Asset Number",
          width: 170
        },
        { field: "Barcode / RFID", headerName: "Barcode / RFID", width: 170 },
        {
          field: "EquipmentNumber",
          headerName: "Equipment Number",
          width: 170
        },
        { field: "Manufacturer", headerName: "Manufacturer", width: 278 },
        {
          field: "AltManufacturer",
          headerName: "Alt Manufacturer",
          width: 170
        },
        { field: "ModelNumber", headerName: "ModelNumber", width: 220 },
        { field: "SerialNumber", headerName: "Serial Number", width: 170 },
        { field: "Description", headerName: "Description", width: 220 }
      ],
      rowSelection: "single",
      showExternalRequest: false
    };

    this.filterClick = this.filterClick.bind(this);
    this.search = _.debounce(this.search.bind(this), 1000);
  }
  operatorLib = {
    equal: { type: "EQ", value: "value", category: "comparison", symbol: "=" },
    not_equal: {
      type: "NE",
      value: "value",
      category: "comparison",
      symbol: "!="
    },
    in: { type: "IN", value: "value", category: "list", symbol: "in" },
    less: { type: "LT", value: "value", category: "comparison", symbol: "<" },
    less_or_equal: {
      type: "LE",
      value: "value",
      category: "comparison",
      symbol: "<="
    },
    greater: {
      type: "GT",
      value: "value",
      category: "comparison",
      symbol: ">"
    },
    greater_or_equal: {
      type: "GE",
      value: "value",
      category: "comparison",
      symbol: ">="
    },
    between: {
      type: "Between",
      value: "value",
      category: "range",
      symbol: "Between"
    },
    not_between: {
      type: "NotBetween",
      value: "value",
      category: "range",
      symbol: "Not Between"
    },
    begins_with: {
      type: "LIKE",
      value: "value*",
      category: "comparison",
      symbol: "Begins with"
    },
    not_begins_with: {
      type: "NOTLIKE",
      value: "value*",
      category: "comparison",
      symbol: "Not Begins with"
    },
    contains: {
      type: "LIKE",
      value: "*value*",
      category: "comparison",
      symbol: "Contains"
    },
    not_contains: {
      type: "NOTLIKE",
      value: "*value*",
      category: "comparison",
      symbol: "Not Contains"
    },
    ends_with: {
      type: "LIKE",
      value: "*value",
      category: "comparison",
      symbol: "Ends with"
    },
    not_ends_with: {
      type: "NOTLIKE",
      value: "*value",
      category: "comparison",
      symbol: "Not Ends With"
    },
    is_empty: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsEmpty"
    },
    is_not_empty: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNotEmpty"
    },
    is_null: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNull"
    },
    is_not_null: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNotNull"
    }
  };
  componentDidMount() {
    serviceRequestStore.initializeDataNewRequest();
  }
  generateOneMonthColumns = () => {
    var columns = [];
    columns.push({ key: "EquipmentNo", name: "Equipment Number" });
    var dates = dateArray.range(
      loanPoolStore.startDate,
      loanPoolStore.endDate,
      "MM-DD-YYYY",
      true
    );
    for (var dateItem of dates) {
      var item = {};
      item.key = dateItem;
      item.name = dateItem;
      item.width = 200;
      columns.push(item);
    }
    this.setState({
      columns: columns,
      columnLength: columns.length
    });
  };

  static defaultProps = { rowKey: "id" };
  createRows = () => {
    let rows = [];
    for (let i = 1; i < 100; i++) {
      rows.push({
        id: i,
        title: "company " + i,
        manufacturer: "manufacturer " + i,
        serial: i,
        count: i * 100
      });
    }

    this._rows = rows;
  };

  rowGetter = i => {
    var rtn = loanPoolStore.loanableAssetsForCustomerLoanpoolGrid;
    return rtn[i];
  };
  availabilityRowGetter = i => {
    var rtn = loanPoolStore.loanableAssetsForCustomer;
    rtn = JSON.parse(JSON.stringify(rtn[i]));
    return rtn;
  };

  handleClose(e) {
    e.preventDefault();
    serviceRequestStore.serviceRequestNewAddCheck([]);
    /*eslint "react/prop-types":0 */
    this.props.history.push("/request");
  }

  handleAddReq() {
    if (this.state.addRequest) {
      this.setState({ addRequest: false });
    } else {
      this.setState({ addRequest: true });
    }
  }

  handleLPbutton(e) {
    this.setState({ tabActive: e.target.id });
  }

  addNewRequest() {
    this.setState({ currentStep: "step2" });
    loanPoolStore.setCurrentStep("step2");
  }
  addExternalRequest = () => {
    this.setState({ showExternalRequest: true });
  };

  handleExternalRequestCancel = () => {
    this.setState({ showExternalRequest: false });
  };

  onChange = (event, { newValue }) => {
    this.setState({
      value: newValue
    });
  };

  onSuggestionSelected = (event, { suggestion }) => {
    if (suggestion.colName == undefined) return;
    var FilterData = {};
    FilterData.TabId = "1";
    FilterData.baseQuery = {
      condition: "AND",
      rules: [
        {
          field: suggestion.colName,
          id: suggestion.colName,
          input: "text",
          operator: "equal",
          type: "string",
          value: suggestion.searchValue
        }
      ],
      valid: true
    };
    FilterData.filterQuery = {};
    Functions.SetFilters(FilterData).then(() => {
      serviceRequestStore.initializeDataNewRequest();
    });
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  concatFilterTags(result, i) {
    var filter = result.rules[i],
      retStr = "";
    if (this.operatorLib.hasOwnProperty(filter.operator)) {
      var operatorObj = this.operatorLib[filter.operator];

      if (operatorObj.category == "comparison") {
        retStr =
          filter.field +
          " " +
          operatorObj.symbol +
          " " +
          (filter.value != undefined || filter.value != null
            ? filter.value != "1970/01/01"
              ? JSON.stringify(filter.value + "")
              : ""
            : "");
      } else if (operatorObj.category == "list") {
        var str = JSON.stringify(filter.value);
        retStr = filter.field + " " + operatorObj.symbol + " " + str;
      } else if (operatorObj.category == "range") {
        retStr =
          filter.field +
          " " +
          operatorObj.symbol +
          " ( " +
          filter.value[0] +
          " AND " +
          filter.value[0] +
          " ) ";
      }
    }
    return retStr;
  }

  filterClick() {
    if (serviceRequestStore.serviceRequestfilterModalOpen) {
      serviceRequestStore.setServiceRequestFilterModalopen(false);
    } else {
      serviceRequestStore.setServiceRequestFilterModalopen(true);
    }
  }

  handleEmptyRulesClick() {
    serviceRequestStore.clearServiceRequestFilter();
  }
  formatfilterDate(baseQueryy) {
    var baseQuery = JSON.parse(JSON.stringify(baseQueryy));
    var noOfRules = baseQuery.rules ? baseQuery.rules.length : 0;

    if (noOfRules == 1) {
      if (baseQuery.rules[0].type == "date") {
        if (
          baseQuery.rules[0].operator == "between" ||
          baseQuery.rules[0].operator == "not_between"
        ) {
          baseQuery.rules[0].value[0] = moment(
            baseQuery.rules[0].value[0]
          ).format("YYYY/MM/DD");
          baseQuery.rules[0].value[1] = moment(
            baseQuery.rules[0].value[1]
          ).format("YYYY/MM/DD");
        } else {
          baseQuery.rules[0].value = moment(baseQuery.rules[0].value).format(
            "YYYY/MM/DD"
          );
        }
      }
    } else {
      for (var i = 0; i < noOfRules; i++) {
        if (baseQuery.rules[i].rules == undefined) {
          if (baseQuery.rules[i].type == "date") {
            if (
              baseQuery.rules[i].operator == "between" ||
              baseQuery.rules[i].operator == "not_between"
            ) {
              baseQuery.rules[i].value[0] = moment(
                baseQuery.rules[i].value[0]
              ).format("YYYY/MM/DD");
              baseQuery.rules[i].value[1] = moment(
                baseQuery.rules[i].value[1]
              ).format("YYYY/MM/DD");
            } else {
              baseQuery.rules[i].value = moment(
                baseQuery.rules[i].value
              ).format("YYYY/MM/DD");
            }
          }
        } else {
          baseQuery.rules[i] = this.formatfilterDate(baseQuery.rules[i]);
        }
      }
    }
    return baseQuery;
  }
  formatFilterTags(resultt) {
    var result = this.formatfilterDate(resultt);
    var filterTagObj = new Object();
    if (typeof result === "string") result = JSON.parse(result);
    var filterTag = "";
    if (Object.keys(result).length !== 0) {
      for (var i = 0; i < result.rules.length; i++) {
        if (result.rules[i].hasOwnProperty("condition")) {
          for (var ii = 0; ii < result.rules[i].rules.length; ii++) {
            if (result.rules[i].rules[ii].hasOwnProperty("condition")) {
              for (
                var iii = 0;
                iii < result.rules[i].rules[ii].rules.length;
                iii++
              ) {
                if (
                  result.rules[i].rules[ii].rules[iii].hasOwnProperty(
                    "condition"
                  )
                ) {
                  for (
                    var iiii = 0;
                    iiii < result.rules[i].rules[ii].rules[iii].rules.length;
                    iiii++
                  ) {
                    filterTag =
                      filterTag.replace("))", "") +
                      " ( " +
                      this.concatFilterTags(
                        result.rules[i].rules[ii].rules[iii],
                        iiii
                      ) +
                      ") ) )";
                  }
                } else {
                  filterTag =
                    filterTag.replace(")", "") +
                    " ( " +
                    this.concatFilterTags(result.rules[i].rules[ii], iii) +
                    " ) ) " +
                    (iii == result.rules[i].rules[ii].rules.length - 1
                      ? ""
                      : result.rules[i].rules[ii].condition);
                }
              }
            } else {
              filterTag =
                filterTag +
                " ( " +
                this.concatFilterTags(result.rules[i], ii) +
                " ) " +
                (ii == result.rules[i].rules.length - 1
                  ? ""
                  : result.rules[i].condition);
            }
          }
        } else {
          filterTag =
            filterTag +
            " " +
            this.concatFilterTags(result, i) +
            " " +
            (i == result.rules.length - 1 ? "" : result.condition);
        }
      }
    }
    var filterLength = this.state.width / 10 - 70;
    filterTagObj.filterTagAlt = filterTag;
    filterTagObj.filterTag =
      filterTag.length > filterLength
        ? filterTag.substring(0, filterLength) + " ..."
        : filterTag;

    return filterTagObj;
  }
  search(value) {
    if (value.value.length >= 2) {
      Functions.GetSolrSearchResult(value.value, "Global").then(resp => {
        var srcStr = value.value;
        var response = resp.data.response;
        var data = [];
        if (response && response.numFound > 0) {
          var docs = response.docs;
          var len = docs.length;
          var exist;
          var test = {};
          var displayNames = JSON.parse(
            JSON.stringify(serviceRequestStore.gridDataModel)
          );

          for (var j = 0; j < displayNames.length; j++) {
            test[displayNames[j].key] = displayNames[j].name;
          }

          for (var i = 0; i < len; i++) {
            for (var key in docs[i]) {
              if (typeof docs[i][key] != "string") {
                docs[i][key] = "" + docs[i][key];
              }
              if (
                typeof docs[i][key] === "string" &&
                docs[i][key].toLowerCase().indexOf(srcStr.toLowerCase()) >= 0
              ) {
                exist = false;

                for (var index = 0; index < data.length; index++) {
                  var item = data[index];

                  if (
                    item.colName === key &&
                    item.searchValue === docs[i][key]
                  ) {
                    exist = true;
                  }
                }

                if (!exist) {
                  /*eslint-disable*/
                  console.log("Docs added",docs[i][key])
                  data.push({
                    colName: key,
                    searchValue: docs[i][key],
                    searchStr: docs[i][key] + " in " + test[key]
                  });
                }
              }
            }
          }
        } else {
          if (data.length == 0) {
            data.push({
              colName: undefined,
              searchValue: undefined,
              searchStr: "No results found "
            });
          }
        }
        this.setState({ suggestions: data });
      });
    }
  }
  render() {
    const { value, suggestions } = this.state;
    var requestNewStyles = {
      clearBoth: {
        clear: "both"
      },
      colLeft: {
        height: window.innerHeight - 330,
        color: "#666"
      },
      windowHeight: {
        height: 222,
        color: "#666",
        border: "1px solid #afb5c3"
      }
    };
    const inputProps = {
      placeholder: "Search For Asset...",
      value,
      onChange: this.onChange
    };
    const gridStyle = {
      height: window.innerHeight - 92
    };
    //Not sure about leaking mobx to components though easier on the eye than cyclic json stuff - @premith
    const gridRowSelAssetsData = mobx.toJS(
      serviceRequestStore.rowSelectedAssetsData
    );

    const nextActiveClass = serviceRequestStore.rowSelectedAssetsData.length
      ? "active"
      : "";

    return (
      <div id="wizard" className="serviceRequestWrapper">
        {/* Header */}
        <div className="serviceRequestHeader">
          <div className="pull-left">
            <div
              className="wizardTitle"
              style={{ color: "rgb(255,255,255)", textTransform: "uppercase" }}
            >
              Service Request
            </div>
          </div>
          <div className="pull-right fr">
            <Icon
              type="close-circle-o"
              style={{
                color: "rgb(255,255,255)",
                fontWeight: "100",
                fontSize: "21px",
                lineHeight: "normal",
                paddingRight: "20px",
                cursor: "pointer"
              }}
              onClick={this.handleClose.bind(this)}
            />
          </div>
          <div style={requestNewStyles.clearBoth} />
        </div>
        {/* /Header ends */}

        <div className="sr-new-body">
          <section className="section-box">
            <Row>
              <Col span={4}>
                <div className="row lp-search-wrapper">
                  <Col span={3}>
                    <span style={{ cursor: "pointer" }}>
                      <Icon type="search" />
                    </span>
                  </Col>
                  <Col span={21}>
                    <Autosuggest
                      suggestions={suggestions}
                      onSuggestionsFetchRequested={this.search.bind(this)}
                      onSuggestionsClearRequested={
                        this.onSuggestionsClearRequested
                      }
                      getSuggestionValue={getSuggestionValue}
                      renderSuggestion={renderSuggestion}
                      inputProps={inputProps}
                      onSuggestionSelected={this.onSuggestionSelected}
                    />
                  </Col>
                </div>
              </Col>
              <Col className="col-sm-4 pull-left">
                <div className="lp-filter-wrapper pull-left">
                  <Col className="pull-left filterButton">
                    <span
                      onClick={this.filterClick}
                      style={{ cursor: "pointer" }}
                    >
                      <Icon
                        type="filter"
                        data-toggle="modal"
                        data-target=".filtersModal"
                      />
                    </span>
                  </Col>
                </div>
                {serviceRequestStore.serviceRequestFilter &&
                this.formatFilterTags(serviceRequestStore.serviceRequestFilter)
                  .filterTag.length > 0 ? (
                  <li className="filterTags" style={{ cursor: "pointer" }}>
                    <span
                      className="badge badge-pill badge-primary"
                      data-tip={
                        this.formatFilterTags(
                          serviceRequestStore.serviceRequestFilter
                        ).filterTagAlt
                      }
                    >
                      <a onClick={this.filterClick}>
                        {
                          this.formatFilterTags(
                            serviceRequestStore.serviceRequestFilter
                          ).filterTag
                        }
                      </a>
                      <i
                        className="icon-close"
                        style={{ margin: 5 }}
                        onClick={this.handleEmptyRulesClick.bind(this)}
                      />
                    </span>
                  </li>
                ) : (
                  ""
                )}
              </Col>
            </Row>
          </section>
          {/* /Search_Filter ends*/}

          {/* Grid */}
          <section className="grid-Wrapping" style={gridStyle}>
            <section className="section-box serviceRequestGrid">
              <Row>
                <Col span={24}>
                  <RequestNewGrid />
                </Col>
              </Row>
            </section>
            {/* /Grid ends*/}

            {/* Selected Assets */}
            <section className="section-box serviceRequestSelectedAssets">
              <Row>
                <Col span={2}>
                  <div
                    className="srNextButton active"
                    onClick={this.handleClose.bind(this)}
                  >
                    <Icon type="left" style={{ fontWeight: 100 }} /> Back
                  </div>
                </Col>
                <Col span={20}>
                  <div className="selectedAssetsTitle"> Selected Assets </div>

                  <div className="srnew-sel-grid-wrapper">
                    <div
                      className="selectedAssetsOpenRowGrid ag-fresh"
                      style={requestNewStyles.windowHeight}
                    >
                      <AgGridReact
                        //onRowSelected={this.onRowSelected}
                        rowData={gridRowSelAssetsData}
                        //columnDefs={this.state.columnDefs}
                        columnDefs={serviceRequestStore.SelectedAssetsGridColumn.map(
                          e => e
                        )}
                        rowSelection={this.state.rowSelection}
                        suppressRowClickSelection={true}
                        rowHeight="35"
                        headerHeight="35"
                        enableSorting={true}
                        enableColResize={true}
                      />
                    </div>
                  </div>
                </Col>
                <Col span={2}>
                  <div
                    className={"srNextButton " + nextActiveClass}
                    style={{ textAlign: "right" }}
                    onClick={() => {
                      if (serviceRequestStore.rowSelectedAssetsData.length) {
                        this.context.router.history.push(
                          "/request/RequestSelectedComponent"
                        );
                      }
                    }}
                  >
                    Next <Icon type="right" style={{ fontWeight: 100 }} />
                  </div>
                </Col>
              </Row>
              {this.state.showExternalRequest ? (
                <EquipmentRequest onCancel={this.handleExternalRequestCancel} />
              ) : (
                ""
              )}
            </section>
          </section>
        </div>
        {serviceRequestStore.serviceRequestfilterModalOpen ? (
          <ServiceRequestFilter />
        ) : (
          ""
        )}
      </div>
    );
  }
}

export default RequestNew;

RequestNew.contextTypes = {
  history: PropTypes.func,
  router: PropTypes.func
};
