import React, { Component } from "react";

import { Route, Switch } from "react-router-dom";

// Views
import RequestComponent from "./RequestComponent";
import RequestNew from "./RequestNew";
import RequestSelectedComponent from "./RequestSelectedComponent";
import RequestContactComponent from "./RequestContactComponent";
import RequestBudgatoryComponent from "./RequestBudgatoryComponent";
import RequestConfirmationComponent from "./RequestConfirmationComponent";

class Request extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <Switch>
          <Route path="/request" exact component={RequestComponent} />
          <Route path="/request/RequestNew" exact component={RequestNew} />
          <Route
            path="/request/RequestSelectedComponent"
            exact
            component={RequestSelectedComponent}
          />
          <Route
            path="/request/RequestContactComponent"
            exact
            component={RequestContactComponent}
          />
          <Route
            path="/request/RequestBudgatoryComponent"
            exact
            component={RequestBudgatoryComponent}
          />
          <Route
            path="/request/RequestConfirmationComponent"
            exact
            component={RequestConfirmationComponent}
          />
        </Switch>
      </div>
    );
  }
}

export default Request;
