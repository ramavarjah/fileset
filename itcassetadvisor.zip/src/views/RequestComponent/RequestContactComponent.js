import React from "react";
import { observer } from "mobx-react";
import { createBrowserHistory } from "history";
import mobx from "mobx";
import UIFunctions from "../../helpers/UIFunctions";
import userStore from "../../stores/userStore";
import { Form, Input, Radio, Button, Icon } from "antd";
import serviceRequestStore from "../../stores/serviceRequestStore";
import PropTypes from "prop-types";

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const history = createBrowserHistory();

@observer
class RequestPage2 extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      permissionkey: "hydraxtest",
      reqprefix: "",
      reqlastname: userStore.userDetails.lastName,
      reqfirstname: userStore.userDetails.firstName,
      reqemail: userStore.userDetails.emailAddress,
      reqphone: userStore.userDetails.phoneNo,
      reqfax: userStore.userDetails.phoneNo,
      reqline1: userStore.userDetails.addressLine1,
      reqline2: userStore.userDetails.addressLine2,
      reqline3: userStore.userDetails.addressLine3,
      reqline4: "",
      reqcompanyname: userStore.userDetails.Organization,
      reqcity: userStore.userDetails.city,
      reqpostalcode: "11253", //contactAddress[2],
      reqstate: userStore.userDetails.state,
      reqcountry: "US", //contactAddress[5]
      biladdresscontact:
        userStore.userDetails.lastName + userStore.userDetails.firstName,
      biladdressphone: userStore.userDetails.phoneNo,
      biladdresscompanyname: userStore.userDetails.Organization,
      biladdressline1: userStore.userDetails.addressLine1,
      biladdressline2: userStore.userDetails.addressLine2,
      biladdressline3: userStore.userDetails.addressLine3,
      biladdressline4: userStore.userDetails.addressLine3,
      biladdresscity: userStore.userDetails.city,
      biladdresspostalcode: "11253", //contactAddress[2],
      biladdressstate: "",
      biladdresscountry: "US", //contactAddress[5],
      biladdressvatid: "",

      pickupoption: serviceRequestStore.NewReq_basepayload.pickupoption,
      pickupcontact: serviceRequestStore.NewReq_basepayload.pickupcontact,
      pickupphone: serviceRequestStore.NewReq_basepayload.pickupphone,
      toKeySightFax: serviceRequestStore.NewReq_basepayload.toKeySightFax,
      toKeySightMobile: serviceRequestStore.NewReq_basepayload.toKeySightMobile,
      pickupcompanyname:
        serviceRequestStore.NewReq_basepayload.pickupcompanyname,
      pickupline1: serviceRequestStore.NewReq_basepayload.pickupline1,
      pickupline2: serviceRequestStore.NewReq_basepayload.pickupline2,
      pickupline3: serviceRequestStore.NewReq_basepayload.pickupline3,
      pickupline4: serviceRequestStore.NewReq_basepayload.pickupline4,
      pickupcity: serviceRequestStore.NewReq_basepayload.pickupcity,
      pickuppostalcode: serviceRequestStore.NewReq_basepayload.pickuppostalcode,
      pickupprovince: serviceRequestStore.NewReq_basepayload.pickupprovince,
      pickupstate: serviceRequestStore.NewReq_basepayload.pickupstate,
      pickupcountry: serviceRequestStore.NewReq_basepayload.pickupcountry,
      returnoption: serviceRequestStore.NewReq_basepayload.returnoption,
      returncontact: serviceRequestStore.NewReq_basepayload.returncontact,
      returnphone: serviceRequestStore.NewReq_basepayload.returnphone,
      fromKeySightFax: serviceRequestStore.NewReq_basepayload.fromKeySightFax,
      fromKeySightMobile:
        serviceRequestStore.NewReq_basepayload.fromKeySightMobile,
      returncompanyname:
        serviceRequestStore.NewReq_basepayload.returncompanyname,
      returnline1: serviceRequestStore.NewReq_basepayload.returnline1,
      returnline2: serviceRequestStore.NewReq_basepayload.reqline2,
      returnline3: serviceRequestStore.NewReq_basepayload.returnline3,
      returnline4: serviceRequestStore.NewReq_basepayload.returnline4,
      returncity: serviceRequestStore.NewReq_basepayload.returncity,
      returnpostalcode: serviceRequestStore.NewReq_basepayload.returnpostalcode,
      returnprovince: serviceRequestStore.NewReq_basepayload.returnprovince,
      returnstate: serviceRequestStore.NewReq_basepayload.returnstate,
      returncountry: serviceRequestStore.NewReq_basepayload.returncountry,

      sritems: [
        {
          manufacturer: "",
          modelno: "",
          serialno: "",
          custassetno: "",
          calcycle: "",
          agreementno: "",
          purchaseorderno: "",
          paymentmethod: "",
          attachpurchaseorderfilename: "",
          attachpurchaseorderfile: "",
          attachfaultreportfilename: "",
          attachfaultreportfile: "",
          requestedservice: "",
          preferreddate: "",
          fault: ""
        }
      ]
    };
  }

  handleCancel() {
    return this.props.form.validateFieldsAndScroll((err, values) => {
      var basepayload = mobx.toJS(serviceRequestStore.NewReq_basepayload);
      var payload = Object.assign(
        basepayload,
        values,
        this.getRequiredUserDetails()
      );

      serviceRequestStore.NewReq_basepayload = payload;
      return history.go(-1);
    });
  }
  getRequiredUserDetails() {
    var details = {
      reqlastname: userStore.userDetails.lastName,
      reqfirstname: userStore.userDetails.firstName,
      reqemail: userStore.userDetails.infolineUserName,
      reqphone: userStore.userDetails.phoneNo,
      reqfax: userStore.userDetails.phoneNo,
      reqline1: userStore.userDetails.AddressLine1,
      reqline2: userStore.userDetails.AddressLine2,
      reqline3: userStore.userDetails.AddressLine3,
      reqline4: "",
      reqcompanyname: userStore.userDetails.Organization,
      reqcity: userStore.userDetails.City,
      reqpostalcode: "11253", //contactAddress[2],
      reqstate: userStore.userDetails.State,
      reqcountry: "US", //contactAddress[5],   userStore.userDetails.country,

      biladdresscontact:
        userStore.userDetails.lastName + userStore.userDetails.firstName,
      biladdressphone: userStore.userDetails.phoneNo,
      biladdresscompanyname: userStore.userDetails.Organization,
      biladdressline1: userStore.userDetails.AddressLine1,
      biladdressline2: userStore.userDetails.AddressLine2,
      biladdressline3: userStore.userDetails.AddressLine3,

      biladdresscity: userStore.userDetails.City,
      biladdresspostalcode: "11253", //contactAddress[2],
      biladdressstate: "",
      biladdresscountry: "US", //contactAddress[5],
      biladdressvatid: ""
    };

    return details;
  }
  radioOptionChanged(value, e) {
    var basepayload = mobx.toJS(serviceRequestStore.NewReq_basepayload);
    var fieldvalues = this.props.form.getFieldsValue();
    fieldvalues[value] = e.target.value;
    var payload = Object.assign(
      basepayload,
      fieldvalues,
      this.getRequiredUserDetails()
    );
    serviceRequestStore.NewReq_basepayload = payload;
    var self = this;
    setTimeout(() => {
      self.props.form.setFieldsValue(payload);
    }, 100);
  }
  handleContinue() {
    return this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        userStore.setWaitForRequest(true);
        //expecting the value from form
        //populate with the userstore details
        //make sure the payload is ready other than sritems array
        if (userStore.userDetails.infolineUserName) {
          var basepayload = mobx.toJS(serviceRequestStore.NewReq_basepayload);
          var payload = Object.assign(
            basepayload,
            values,
            this.getRequiredUserDetails()
          );
          serviceRequestStore.NewReq_basepayload = payload;
          serviceRequestStore.getBudgetaryQuote(payload).then(result => {
            if (result.result) {
              this.props.history.push("/request/RequestBudgatoryComponent");
              userStore.setWaitForRequest(false);
              return;
            } else
              UIFunctions.Toast(
                "Service Request creation Failed. Please contact Administrator",
                "error"
              );
            userStore.setWaitForRequest(false);
            return;
          });
        } else {
          UIFunctions.Toast(
            "Please update myKeysight Account details in User Setting to continue Service Request",
            "warn"
          );
          userStore.setWaitForRequest(false);
          return;
        }
      }
    });
  }
  handleClose() {
    this.props.history.push("/request");
  }

  componentDidMount() {
    serviceRequestStore.rowSelectedAssetsData.length,
      serviceRequestStore.rowSelectedAssetsData,
      "Did Mount Contact";

    if (serviceRequestStore.rowSelectedAssetsData.length < 1) {
      UIFunctions.Toast("Please Select Assets ", "warn");
      this.props.history.push("/request/RequestNew");
    } else {
      var allrequestedService = false;
      serviceRequestStore.rowSelectedAssetsData.map(item => {
        if (!item.requestedservice || item.requestedservice == "") {
          allrequestedService = true;
        }
      });
      if (allrequestedService) {
        UIFunctions.Toast(
          "Please select required service for selected assets ",
          "warn"
        );
        this.props.history.push("/request/RequestSelectedComponent");
      }
    }
    this.props.form.setFieldsValue(serviceRequestStore.NewReq_basepayload);
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 12 }
    };
    const radioItemLayout = {
      wrapperCol: { span: 24 },
      labelCol: { span: 4 }
    };
    const radioStyle = {
      display: "block",
      height: "30px",
      lineHeight: "30px"
    };
    var issueStyles = {
      clearBoth: {
        clear: "both"
      }
    };
    return (
      <div id="wizard" className="serviceRequestWrapper">
        <Form>
          <div
            style={{
              backgroundColor: "#3ad1a4",
              paddingTop: "10px",
              paddingBottom: "10px"
            }}
          >
            <div className="pull-left ">
              <div
                className="wizardTitle"
                style={{
                  color: "rgb(255,255,255)",
                  textTransform: "uppercase"
                }}
              >
                Service Request
              </div>
            </div>
            <div className="pull-right">
              <Icon
                type="close-circle-o"
                style={{
                  color: "rgb(255,255,255)",
                  fontWeight: "100",
                  fontSize: "21px",
                  lineHeight: "normal",
                  paddingRight: "20px",
                  cursor: "pointer"
                }}
                onClick={this.handleClose.bind(this)}
              />
            </div>
            <div style={issueStyles.clearBoth} />
          </div>
          <div className="stepsWrapper serviceRequestSteps">
            <div className="steps active" id="step1">
              1. Service Selected
            </div>
            <div className="serviceStepsIcon">
              <Icon type="arrow-right" />
            </div>
            <div className="steps active" id="step2">
              2. Contact & Shipping
            </div>
            <div className="serviceStepsIcon">
              <Icon type="arrow-right" />
            </div>
            <div className="steps" id="step3">
              3. Budgetary Quote
            </div>
            <div className="serviceStepsIcon">
              <Icon type="arrow-right" />
            </div>
            <div className="steps" id="step4">
              4. Confirmation
            </div>
          </div>
          <div className="serviceRequestText">
            <p>
              To enhance your contact information, please go to my profile. *
            </p>
          </div>
          <div
            className="reqPageWrapper serviceRequestInformationWrapper"
            style={{ height: window.innerHeight - 255 }}
          >
            <div className="column1">
              <div className="row" style={{ padding: 0, margin: 0 }}>
                <div className="col-lg-12">
                  <h5>Contact Information</h5>
                </div>
                <div className="row col-lg-12">
                  <div className="col-lg-4">
                    <FormItem {...formItemLayout} label="Last (family) Name:">
                      {userStore.userDetails.lastName}
                    </FormItem>
                    <FormItem {...formItemLayout} label="First (given) Name:">
                      {userStore.userDetails.firstName}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Company Name:">
                      {userStore.userDetails.Organization}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Mailing Address:">
                      {userStore.userDetails.AddressLine1
                        ? userStore.userDetails.AddressLine1 + ", "
                        : ""}
                      {userStore.userDetails.AddressLine2
                        ? userStore.userDetails.AddressLine2 + ", "
                        : ""}
                      {userStore.userDetails.AddressLine3
                        ? userStore.userDetails.AddressLine3 + ", "
                        : ""}
                      {userStore.userDetails.City
                        ? userStore.userDetails.City + ", "
                        : ""}
                      {userStore.userDetails.State
                        ? userStore.userDetails.State + ", "
                        : ""}
                      {userStore.userDetails.Country
                        ? userStore.userDetails.Country
                        : ""}
                    </FormItem>
                  </div>
                  <div className="col-lg-4">
                    <FormItem {...formItemLayout} label="Email Address:">
                      {userStore.userDetails.infolineUserName}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Phone Number:">
                      {userStore.userDetails.phoneNo}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Fax Number:">
                      {userStore.userDetails.Fax}
                    </FormItem>
                    <FormItem {...formItemLayout} label="Mobile Number:">
                      {userStore.userDetails.mobilePhone}
                    </FormItem>
                  </div>
                </div>
              </div>
              <div className="row" style={{ padding: 0, margin: 0 }}>
                <div className="col-lg-12">
                  <h5>Shipping Instructions</h5>
                </div>
                <div className="row col-lg-12">
                  <div className="col-lg-5">
                    <div className="shippingInstructionsTital">To Keysight</div>
                    <div className="shippingBorderRight">
                      <div className="row col-lg-12">
                        <FormItem
                          className="serviceInputStyle"
                          {...radioItemLayout}
                        >
                          {getFieldDecorator("pickupoption", {
                            rules: [
                              {
                                required: true,
                                message: "Please select an option"
                              }
                            ]
                          })(
                            <RadioGroup
                              name="pickupoption"
                              onChange={e =>
                                this.radioOptionChanged("pickupoption", e)
                              }
                            >
                              <Radio style={radioStyle} value={"0"}>
                                I will ship the instrument (s) to Keysight
                              </Radio>
                              <Radio style={radioStyle} value={"1"}>
                                Pickup the instrument (s) at the below address
                              </Radio>
                              <Radio style={radioStyle} value={"3"}>
                                Pickup the instrument (s) at the mailing address
                              </Radio>
                            </RadioGroup>
                          )}
                        </FormItem>
                      </div>
                      <div className="row col-lg-12">
                        Contact us for pickup service availability in your area
                      </div>
                      {serviceRequestStore.NewReq_basepayload.pickupoption ==
                      "1" ? (
                        <div>
                          <p> </p>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Contact Name:"
                          >
                            {getFieldDecorator("pickupcontact", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter contact name"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({
                                    pickupcontact: e.target.value
                                  })
                                }
                                style={issueStyles.inputStyle}
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Phone Number:"
                          >
                            {getFieldDecorator("pickupphone", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter phone number"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({ pickupphone: e.target.value })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Fax Number:"
                          >
                            {getFieldDecorator("toKeySightFax", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter fax number"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({
                                    toKeySightFax: e.target.value
                                  })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Mobile Number:"
                          >
                            {getFieldDecorator("toKeySightMobile", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter mobile number"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({
                                    toKeySightMobile: e.target.value
                                  })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Company:"
                          >
                            {getFieldDecorator("pickupcompanyname", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter company name"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({
                                    pickupcompanyname: e.target.value
                                  })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Address:"
                          >
                            {getFieldDecorator("pickupline1", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter address"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({ pickupline1: e.target.value })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Address (cont.)"
                          >
                            {getFieldDecorator("pickupline2")(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({ pickupline2: e.target.value })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Address (cont.)"
                          >
                            {getFieldDecorator("pickupline3")(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({ pickupline3: e.target.value })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="City:"
                          >
                            {getFieldDecorator("pickupcity", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter city"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({ pickupcity: e.target.value })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Postal Code:"
                          >
                            {getFieldDecorator("pickuppostalcode", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter postal code"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({
                                    pickuppostalcode: e.target.value
                                  })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="State:"
                          >
                            {getFieldDecorator("pickupstate", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter state"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({ pickupstate: e.target.value })
                                }
                              />
                            )}
                          </FormItem>
                          <FormItem
                            className="serviceInputStyle"
                            {...formItemLayout}
                            label="Country:"
                          >
                            {getFieldDecorator("pickupcountry", {
                              rules: [
                                {
                                  required: true,
                                  message: "Please enter country"
                                }
                              ]
                            })(
                              <Input
                                type="text"
                                onChange={e =>
                                  this.setState({
                                    pickupcountry: e.target.value
                                  })
                                }
                              />
                            )}
                          </FormItem>
                        </div>
                      ) : null}
                    </div>
                  </div>
                  <div className="col-lg-5">
                    <div className="shippingInstructionsTital">
                      From Keysight
                    </div>
                    <div className="row col-lg-12">
                      <FormItem
                        className="serviceInputStyle"
                        {...radioItemLayout}
                      >
                        {getFieldDecorator("returnoption", {
                          rules: [
                            {
                              required: true,
                              message: "Please select an option"
                            }
                          ]
                        })(
                          <RadioGroup
                            onChange={e =>
                              this.radioOptionChanged("returnoption", e)
                            }
                          >
                            <Radio style={radioStyle} value={"0"}>
                              I will Pickup the instrument (s) from Keysight
                            </Radio>
                            <Radio style={radioStyle} value={"1"}>
                              Return the instrument (s) to the below address
                            </Radio>
                            <Radio style={radioStyle} value={"3"}>
                              Return the instrument (s) to the mailing address
                            </Radio>
                          </RadioGroup>
                        )}
                      </FormItem>
                    </div>
                    <div className="row col-lg-12">&nbsp;</div>
                    {serviceRequestStore.NewReq_basepayload.returnoption ==
                    "1" ? (
                      <div>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Contact Name:"
                        >
                          {getFieldDecorator("returncontact", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter contact name"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returncontact: e.target.value })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Phone Number:"
                        >
                          {getFieldDecorator("returnphone", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter phone number"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returnphone: e.target.value })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Fax Number:"
                        >
                          {getFieldDecorator("fromKeySightFax", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter fax number"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({
                                  fromKeySightFax: e.target.value
                                })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Mobile Number:"
                        >
                          {getFieldDecorator("fromKeySightMobile", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter mobile number"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({
                                  fromKeySightMobile: e.target.value
                                })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Company:"
                        >
                          {getFieldDecorator("returncompanyname", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter company name"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({
                                  returncompanyname: e.target.value
                                })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Address:"
                        >
                          {getFieldDecorator("returnline1", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter address"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returnline1: e.target.value })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Address (cont.)"
                        >
                          {getFieldDecorator("returnline2")(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returnline2: e.target.value })
                              }
                            />
                          )}
                        </FormItem>

                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Address (cont.)"
                        >
                          {getFieldDecorator("returnline3")(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returnline3: e.target.value })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="City:"
                        >
                          {getFieldDecorator("returncity", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter city"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returncity: e.target.value })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Postal Code:"
                        >
                          {getFieldDecorator("returnpostalcode", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter postal code"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({
                                  returnpostalcode: e.target.value
                                })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="State:"
                        >
                          {getFieldDecorator("returnstate", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter state"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returnstate: e.target.value })
                              }
                            />
                          )}
                        </FormItem>
                        <FormItem
                          className="serviceInputStyle"
                          {...formItemLayout}
                          label="Country:"
                        >
                          {getFieldDecorator("returncountry", {
                            rules: [
                              {
                                required: true,
                                message: "Please enter country"
                              }
                            ]
                          })(
                            <Input
                              type="text"
                              onChange={e =>
                                this.setState({ returncountry: e.target.value })
                              }
                            />
                          )}
                        </FormItem>
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="wizardFooter">
            <div className="serviceRequestFooter">
              <FormItem>
                <Button type="default" onClick={this.handleCancel.bind(this)}>
                  <Icon type="left" />
                  Back
                </Button>
              </FormItem>

              <FormItem>
                <Button
                  type="default"
                  onClick={this.handleContinue.bind(this)}
                  disabled={userStore.waitForRequest}
                >
                  Continue
                  <Icon type="right" />
                </Button>
              </FormItem>
            </div>
          </div>
        </Form>
      </div>
    );
  }
}
const RequestContactComponent = Form.create()(RequestPage2);
export default RequestContactComponent;

RequestPage2.propTypes = {
  router: PropTypes.func.isRequired
};
