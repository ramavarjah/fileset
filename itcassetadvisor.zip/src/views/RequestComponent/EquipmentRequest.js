import React, { Component } from "react";
import { observer } from "mobx-react";
import userStore from "../../stores/userStore";
import { Col, Form, Input, DatePicker, Select, Upload } from "antd";
import { Button, Modal, ModalHeader, ModalBody } from "reactstrap";
import serviceRequestStore from "../../stores/serviceRequestStore";

const FormItem = Form.Item;
const { TextArea } = Input;

const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 10 }
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 13 }
    }
};

const formRightItemLayout = {
    labelCol: {
        xs: { span: 23 },
        sm: { span: 23 }
    },
    wrapperCol: {
        xs: { span: 23 },
        sm: { span: 23 }
    }
};

@observer
class EquipmentFormRequest extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "",
            emailAddress: "",
            mobileNumber: ""
        };
    }
    componentDidMount() {
    //for testing email field needs to be edited so making a state for that
        var firstName = userStore.userDetails.firstName;
        var lastName = userStore.userDetails.lastName;
        var emailAddress = userStore.userDetails.emailAddress;
        var mobile = userStore.userDetails.mobile;
        var name = "No Name";
        if (firstName && lastName) {
            name = firstName + " " + lastName;
        }
        if (!mobile) {
            mobile = "No Mobile Number";
        }
        if (!emailAddress) {
            emailAddress = "No emailAddress";
        }
        this.setState({
            name,
            emailAddress,
            mobile
        });
    }

  handleSubmit = e => {
      e.preventDefault();
      var self = this;
      return this.props.form.validateFieldsAndScroll((err, values) => {
          if (!err) {
              values.updatedFlag = true;
              serviceRequestStore.serviceRequestAddNewItem(values);
              self.props.onCancel();
          }
      });
  };

  render() {
      const { getFieldDecorator } = this.props.form;

      const formUpload = {
          onRemove: file => {
              this.setState(({ fileList }) => {
                  const index = fileList.indexOf(file);
                  const newFileList = fileList.slice();
                  newFileList.splice(index, 1);
                  return {
                      fileList: newFileList
                  };
              });
          },
          beforeUpload: file => {
              const fileName = file.name;
              this.setState(() => ({
                  fileList: [file]
              }));

              const reader = new FileReader();
              reader.onload = file => {
                  this.setState({
                      binaryFiles: {
                          data: file.target.result.split(",")[1],
                          fileName: fileName
                      },
                      isUploadFileSelected: true
                  });
              };
              reader.readAsDataURL(file);
              return false;
          },
          fileList: this.state.fileList
      };

      return (
          <Modal
              isOpen={true}
              className="modal-dialog modal-lg equipmentRequestModal"
              style={{ maxWidth: 900 }}
          >
              <ModalHeader
                  className="row modalHeader equipmentRequestModalHeader"
                  style={{ borderBottom: "1px solid #ccd0d8" }}
              >
                  <span className="equipmentRequestLabel">EQUIPMENT REQUEST</span>
                  <span onClick={this.props.onCancel} style={{ cursor: "pointer" }}>
                      <i className="icon-close" />
                  </span>
              </ModalHeader>

              <ModalBody className="sRequipmentRequest">
                  <div className="col-md-12 equipmentRequestFormContainer">
                      <Form style={{ width: "100%" }}>
                          <div
                              style={{
                                  height: window.innerHeight - 320,
                                  overflow: "auto",
                                  overflowX: "hidden"
                              }}
                          >
                              <Col span={12} className="col-md-6 pull-left borderRight">
                                  <FormItem {...formItemLayout} label="Manufacturer">
                                      {getFieldDecorator("Manufacturer", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter Manufacturer!"
                                              }
                                          ]
                                      })(<Input />)}
                                  </FormItem>

                                  <FormItem
                                      {...formItemLayout}
                                      label="Serial Number"
                                      required={true}
                                  >
                                      {getFieldDecorator("SerialNo", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter serial number!"
                                              }
                                          ]
                                      })(<Input />)}{" "}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Model Number">
                                      {getFieldDecorator("ModelNo", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter Model Number!"
                                              }
                                          ]
                                      })(<Input />)}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Asset Number">
                                      {getFieldDecorator("AssetNo", {
                                          rules: [
                                              {
                                                  message: "Please enter Asset Number!"
                                              }
                                          ]
                                      })(<Input />)}
                                  </FormItem>

                                  <FormItem
                                      {...formRightItemLayout}
                                      label="Attach Fault Report/Cal Spec"
                                  >
                                      {getFieldDecorator("location", {
                                          rules: [
                                              {
                                                  required: false
                                              }
                                          ]
                                      })(
                                          <div>
                                              <Input
                                                  style={{
                                                      width: "76%",
                                                      color: "rgba(0, 0, 0, 0.25",
                                                      backgroundColor: "#f7f7f7",
                                                      borderColor: "#d9d9d9"
                                                  }}
                                                  disabled={true}
                                              />
                                              <Upload {...formUpload} disabled={true}>
                                                  <Button
                                                      className="chooseButton"
                                                      style={{
                                                          padding: "7px",
                                                          marginLeft: "15px",
                                                          width: "85%",
                                                          cursor: "not-allowed",
                                                          color: "rgba(0, 0, 0, 0.25",
                                                          backgroundColor: "#f7f7f7",
                                                          borderColor: "#d9d9d9"
                                                      }}
                                                  >
                                                      {" "}
                            Upload{" "}
                                                  </Button>
                                              </Upload>
                                          </div>
                                      )}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Requested Service">
                                      {getFieldDecorator("requestedservice", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter Requested Service!"
                                              }
                                          ]
                                      })(
                                          <Select
                                              id="tabSelect"
                                              showSearch={true}
                                              optionFilterProp="children"
                                              filterOption={(input, option) =>
                                                  option.props.children
                                                      .toLowerCase()
                                                      .indexOf(input.toLowerCase()) >= 0
                                              }
                                              allowClear
                                          >
                                              {serviceRequestStore.formDropDownData.services.map(
                                                  dropdown => (
                                                      <option key={dropdown.id}>
                                                          {dropdown.description}
                                                      </option>
                                                  )
                                              )}
                                          </Select>
                                      )}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Preferred Date">
                                      {getFieldDecorator("preferreddate", {
                                          rules: [
                                              {
                                                  required: false,
                                                  message: "Please enter Preferred Date!"
                                              }
                                          ]
                                      })(
                                          <DatePicker
                                              style={{ width: "100%" }}
                                              format="YYYY-MM-DD"
                                          />
                                      )}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Fault Description">
                                      {getFieldDecorator("fault", {
                                          rules: [
                                              {
                                                  message: "Please enter Fault Description!"
                                              }
                                          ]
                                      })(<TextArea rows={6} />)}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Calibration Cycle">
                                      {getFieldDecorator("calcycle", {
                                          rules: [
                                              {
                                                  required: false,
                                                  message: "Please enter Calibration Cycle!",
                                                  pattern: new RegExp("^[0-9]+(.[0-9]{1,2})?$")
                                              }
                                          ]
                                      })(<Input />)}
                                  </FormItem>
                              </Col>

                              <Col span={12} className="col-md-6 pull-left">
                                  <FormItem {...formItemLayout} label="Service Agreement">
                                      {getFieldDecorator("serviceAgreement", {
                                          rules: [
                                              {
                                                  required: false,
                                                  message: "Please enter justification!"
                                              }
                                          ]
                                      })(<Input />)}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Payment Method">
                                      {getFieldDecorator("paymentmethod", {
                                          rules: [
                                              {
                                                  message: "Please select payment method!"
                                              }
                                          ]
                                      })(
                                          // (<Input />)
                                          <Select
                                              id="tabSelect"
                                              placeholder={""}
                                              style={{ width: "100%", backgroundColor: "#e5e5e5" }}
                                              showSearch={true}
                                              optionFilterProp="children"
                                              filterOption={(input, option) =>
                                                  option.props.children
                                                      .toLowerCase()
                                                      .indexOf(input.toLowerCase()) >= 0
                                              }
                                              allowClear
                                          >
                                              {serviceRequestStore.formDropDownData.paymentmethods.map(
                                                  dropdown => (
                                                      <option key={dropdown.id}>
                                                          {dropdown.description}
                                                      </option>
                                                  )
                                              )}
                                          </Select>
                                      )}
                                  </FormItem>

                                  <FormItem {...formItemLayout} label="Purchase Order No">
                                      {getFieldDecorator("purchaseorderno", {
                                          rules: [
                                              {
                                                  required: false,
                                                  message: "Please enter notes!"
                                              }
                                          ]
                                      })(<Input />)}
                                  </FormItem>

                                  <FormItem
                                      {...formRightItemLayout}
                                      label="Attach Purchase Order"
                                      hasFeedback
                                  >
                                      {getFieldDecorator("location", {
                                          rules: [
                                              {
                                                  required: false
                                              }
                                          ]
                                      })(
                                          <div>
                                              <Input
                                                  style={{
                                                      width: "76%",
                                                      color: "rgba(0, 0, 0, 0.25",
                                                      backgroundColor: "#f7f7f7",
                                                      borderColor: "#d9d9d9"
                                                  }}
                                                  disabled={true}
                                              />
                                              <Upload {...formUpload} disabled={true}>
                                                  <Button
                                                      className="chooseButton"
                                                      style={{
                                                          padding: "7px",
                                                          marginLeft: "15px",
                                                          width: "85%",
                                                          cursor: "not-allowed",
                                                          color: "rgba(0, 0, 0, 0.25",
                                                          backgroundColor: "#f7f7f7",
                                                          borderColor: "#d9d9d9"
                                                      }}
                                                  >
                                                      {" "}
                            Upload{" "}
                                                  </Button>
                                              </Upload>
                                          </div>
                                      )}
                                  </FormItem>
                              </Col>
                          </div>

                          <div className="clear" />

                          <div className="col-md-12 pull-left">
                              <div className="equipmentRequestButton">
                                  <FormItem>
                                      <Button
                                          className="cancelButton"
                                          type="primary"
                                          style={{ marginLeft: 8 }}
                                          onClick={this.props.onCancel}
                                      >
                      Cancel
                                      </Button>
                                      <Button
                                          className="submitButton"
                                          type="primary"
                                          style={{ marginLeft: 8 }}
                                          onClick={this.handleSubmit.bind(this)}
                                      >
                      Submit
                                      </Button>
                                  </FormItem>
                              </div>
                          </div>
                      </Form>
                  </div>
              </ModalBody>
          </Modal>
      );
  }
}

const EquipmentRequest = Form.create()(EquipmentFormRequest);
export default EquipmentRequest;
