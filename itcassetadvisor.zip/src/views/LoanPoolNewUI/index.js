import React, { Component } from "react";
import { Route, Switch } from "react-router-dom";
import { Layout } from "antd";
import "./css/Loanpool.css";
import "./css/LPNew.scss";
import "antd/dist/antd.css";
import "ag-grid/dist/styles/ag-grid.css";
import "../../../scss/aa_styles/_aa_new_loan_pool.scss";

// Views

import LoanPoolLandingPage from "./views/loanPoolLandingPageView/LoanPoolLandingPage";
import LoanPoolNewRequest from "./views/loanPoolNewRequestView/LoanPoolNewRequest";
import Footer from "../../components/Footer";
import Sidebar from "../../components/Sidebar/Sidebar";
import CheckAvailabiltyLandingPage from "./views/checkAvailabilityView/CheckAvailabiltyLandingPage";

import mobx from "mobx";
import loanPoolStoreV2 from "src/stores/loanPoolStoreV2";
class NewLoanPool extends Component {
  componentDidMount(){
    var path = mobx.toJS(loanPoolStoreV2.filteredItemsToShowCheckAvailability) ;
    if(path.length==0 & location.pathname == "/loan-pool-notifications/check-availability")
    { 
        this.props.history.push("/loan-pool-notifications")
    }
  }
  render() {
    return (
      <div>
        <Layout>
          <Sidebar />
        </Layout>
        <Switch>
          <Route
            path="/loan-pool-notifications"
            exact
            component={LoanPoolLandingPage}
          />
          <Route
            path="/loan-pool-notifications/loan-pool-new-request"
            exact
            component={LoanPoolNewRequest}
          />
          <Route
            path="/loan-pool-notifications/check-availability"
            exact
            component={CheckAvailabiltyLandingPage}
          />
        </Switch>
        <Footer />
      </div>
    );
  }
}

export default NewLoanPool;
