import React, { Component } from "react";
import LoanPoolHeader from "../../components/header/LoanPoolHeader";
import NewRequestGrid from "../../components/newrequest/NewRequestGrid";
import NewRequestForm from "../../components/newrequest/NewRequestForm";
import loanPoolStoreV2 from "../../components/../../../stores/loanPoolStoreV2";
import { observer } from "mobx-react";
import { Row, Col, Spin } from "antd";
import { Redirect } from "react-router-dom";

@observer
class LoanPoolNewRequest extends Component {
    componentDidMount() {
        loanPoolStoreV2.setIsBackArrowVisible(true);
        loanPoolStoreV2.setIsLoanPool(true);
        window.onbeforeunload = function () {
            return "Changes you made may not be saved.";
        }
    }
    componentWillUnmount(){
        window.onbeforeunload = null;
    }
    render() {
        const containerWrapper = {
            backgroundColor: "#f2f2f2",
            minHeight: "100%",
            marginLeft: 59,
            marginRight: 0
        };
        var duplicateItems = loanPoolStoreV2.getDataFromDuplicate
            ? loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets
            : [];    
        return loanPoolStoreV2.cartItems.length==0 & duplicateItems.length==0 ?
         (
            <Redirect to="/loan-pool-notifications" />
         ) :(
        // <Spin spinning={loanPoolStoreV2.isNewRequestLoading} delay={500}>
            <div>
                <LoanPoolHeader isVisible={false} />
                <div id="wizard" className="loanPoolWrapper newLoanPoolWrapper1">
                    <Spin spinning={loanPoolStoreV2.isNewRequestLoading} delay={500}>
                        <Row gutter={16} style={containerWrapper}>
                            <Col span={"1"} style={{ marginRight: -32 }} />
                            <Col span="24">
                                <div style={{ height: 577 }}>
                                    <NewRequestForm />
                                </div>
                                <div className="assetsGrid-newRequest">
                                    <NewRequestGrid />
                                </div>
                            </Col>
                        </Row>
                    </Spin>
                </div>
            </div>
        // </Spin>
        );
    }
}

export default LoanPoolNewRequest;
