import React, { Component } from "react";
import { observer } from "mobx-react";
import LoanPoolHeader from "../../components/header/LoanPoolHeader";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import LoanPoolNormalView from "./LoanPoolNormalView";
import LoanPoolReviewerView from "./LoanPoolReviewerView";
import tabModelStore from "../../../../stores/tabModelStore";
import PropTypes from "prop-types";

@observer
class LoanPoolLandingPage extends Component {
  componentDidMount = () => {
    tabModelStore.setIsAssetListView(false);
    tabModelStore.setIsChartView(false);
    loanPoolStoreV2.setIsLoanPool(true);
    loanPoolStoreV2.initializeLoanPool();
    if(loanPoolStoreV2.normalViewMode!="NORMAL")
    {
      loanPoolStoreV2.setNormalViewMode("ADVANCED");
      loanPoolStoreV2.dataLoaded=false;
    }
    else
    {
      loanPoolStoreV2.setNormalViewMode("NORMAL");
    }
    loanPoolStoreV2.setReviewerMode(false);
    return;
  };
  componentWillUnmount = () => {
    loanPoolStoreV2.setIsLoanPool(false);
    loanPoolStoreV2.doNotUpdate = false;
  };

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.location.state === "desiredState") {
     
      loanPoolStoreV2.initializeLoanPool();
      if(loanPoolStoreV2.normalViewMode!="NORMAL")
      {
        loanPoolStoreV2.setNormalViewMode("NORMAL");
      }
      return;
    }
  }

  // shouldComponentUpdate(nextProps){
  //   if (nextProps.location.state === "desiredState") {
  //     console.log("no chnage");
  //   }
  //   else{
  //     console.log("change");
  //   }
  // }

  render() {
    return (
      <div>
        <LoanPoolHeader isVisible={true} />
        <div id="wizard" className="loanPoolWrapper newLoanPoolWrapper">
          {loanPoolStoreV2.reviewerMode == false ? (
            <LoanPoolNormalView />
          ) : (
            <LoanPoolReviewerView />
          )}
        </div>
      </div>
    );
  }
}

export default LoanPoolLandingPage;
LoanPoolLandingPage.propTypes = {
  location: PropTypes.state
};
