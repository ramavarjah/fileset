import React, { Component } from "react";
import { observer } from "mobx-react";
import { Row, Form, Col } from "antd";
import "react-rangeslider/umd/rangeslider.css";
import LoanPoolAdvancedSearch from "../../components/header/LoanPoolAdvancedSearch";
import LoanPoolRequestDetails from "../../components/requestgrid/LoanPoolRequestDetails";
import LoanPoolBorrowableAssets from "../../components/borrowablegrid/LoanPoolBorrowableAssets";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import mobx from "mobx";
@observer
class LoanPoolNormalView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sliderValue: 25,
      reverseValue: 8
    };
  }
  render() {
    const containerWrapper = {
      backgroundColor: "#f2f2f2",
      minHeight: "100%",
      marginLeft: 59,
      marginRight: 0
    };

    const lpBody = {
      height: window.innerHeight - 106
    };
    let advancedSearchOn =
      loanPoolStoreV2.normalViewMode == "NORMAL" ||
      loanPoolStoreV2.normalViewMode == "REQUESTFULLSCREEN"
        ? false
        : true;
    return (
      <Row gutter={16} style={containerWrapper}>
        <Col span={advancedSearchOn ? "1" : "0"} style={{ marginRight: -32 }} />
        <Col span={advancedSearchOn ? "5" : "0"}>
          <LoanPoolAdvancedSearch
            lastSelectedSuggestion={mobx.toJS(
              loanPoolStoreV2.lastSelectedSuggestion
            )}
          />
        </Col>
        <div className="outerdiv" style={lpBody}>
          <Col style={lpBody} span={advancedSearchOn ? "18" : "24"}>
            {loanPoolStoreV2.normalViewMode == "REQUESTFULLSCREEN" ? (
              ""
            ) : (
              <div className="lpSectionBorrowableGrid">
                <section className="lp-section-box lpSelectAssets">
                  <Row>
                    <LoanPoolBorrowableAssets />
                  </Row>
                </section>
              </div>
            )}

            <div className="lpSectionRequestGrid">
              <section className="lp-section-box lpSelectAssets">
                <Row>
                  <LoanPoolRequestDetails
                    mode={loanPoolStoreV2.normalViewMode}
                  />
                </Row>
              </section>
            </div>
          </Col>
        </div>
      </Row>
    );
  }
}

export default Form.create()(LoanPoolNormalView);
