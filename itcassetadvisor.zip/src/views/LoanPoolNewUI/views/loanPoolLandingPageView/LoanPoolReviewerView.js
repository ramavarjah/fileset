import React, { Component } from "react";
import { observer } from "mobx-react";
import { Row, Form, Col } from "antd";
import "react-rangeslider/umd/rangeslider.css";
import LoanPoolAdvancedSearch from "../../components/header/LoanPoolAdvancedSearch";
import RequestsAwaitingApproval from "../../components/requestsawaitingapprovalgrid/RequestsAwaitingApproval";
import RequestApprovalLogGrid from "../../components/requestapprovalloggrid/RequestApprovalLogGrid";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import mobx from "mobx";
@observer
class LoanPoolReviewerView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sliderValue: 25,
            reverseValue: 8
        };
    }

    render() {
    //todo reviewer view
        const containerWrapper = {
            backgroundColor: "#f2f2f2",
            minHeight: "100%",
            marginLeft: 50,
            marginRight: 0
        };

        const lpBody = {
            height: window.innerHeight - 106
        };
        let advancedSearchOn =
      loanPoolStoreV2.reviewerViewMode == "NORMAL" ||
      loanPoolStoreV2.reviewerViewMode == "REQUESTFULLSCREEN"
          ? false
          : true;
        return (
            <Row gutter={16} style={containerWrapper}>
                <Col span={advancedSearchOn ? "1" : "0"} style={{ marginRight: -32 }} />
                <Col span={advancedSearchOn ? "5" : "0"}>
                    <LoanPoolAdvancedSearch
                        lastSelectedSuggestion={mobx.toJS(
                            loanPoolStoreV2.lastSelectedSuggestion
                        )}
                    />
                </Col>
                {/* <Col span="24">
                    <RequestsAwaitingApproval />
                    <br />
                    <br />

                    <RequestApprovalLogGrid />
                </Col> */}
                <div className="outerdiv" style={lpBody}>
                    <Col span={advancedSearchOn ? "18" : "24"} className="review-Wrapper">
                        {loanPoolStoreV2.reviewerViewMode == "REQUESTFULLSCREEN" ? (
                            ""
                        ) : (
                            <div className="lpSectionRequestAwaiting">
                                <section className="lp-section-box lpSelectAssets">
                                    <Row>
                                        <RequestsAwaitingApproval />
                                    </Row>
                                </section>
                            </div>
                        )}

                        <div className="lpSectionRequestApproval">
                            <section className="lp-section-box lpSelectAssets">
                                <Row>
                                    <RequestApprovalLogGrid
                                        mode={loanPoolStoreV2.reviewerViewMode}
                                    />
                                </Row>
                            </section>
                        </div>
                    </Col>
                </div>
            </Row>
        );
    }
}

export default Form.create()(LoanPoolReviewerView);
