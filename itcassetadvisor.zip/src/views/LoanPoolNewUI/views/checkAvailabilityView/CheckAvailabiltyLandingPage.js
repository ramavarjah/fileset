import React from "react";
import CANormalView from "../checkAvailabilityView/CANormalVIew";
import LoanPoolHeader from "../../components/header/LoanPoolHeader";
import loanPoolStoreV2 from "src/stores/loanPoolStoreV2";
export default class CheckAvailabiltyLandingPage extends React.Component {
  componentWillUnmount() {
    loanPoolStoreV2.itemsToShowCheckAvailability = [];
    loanPoolStoreV2.checkAvailabilityMode = false;
  }
  componentDidMount() {
    loanPoolStoreV2.checkAvailabilityMode = true;
    loanPoolStoreV2.setIsLoanPool(true);
  }
  render() {
    return (
      <div>
        <LoanPoolHeader isVisible={true} />
        <div
          style={{
            marginLeft: 59,
            background: "#f2f2f2",
            height: "calc(100vh - 101px)"
          }}
          className="ca--wrapper"
        >
          <CANormalView />
        </div>
      </div>
    );
  }
}
