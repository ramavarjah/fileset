import React from "react";
import ModelDetails from "../../components/checkAvailability/ModelDetails";
import loanPoolStoreV2 from "src/stores/loanPoolStoreV2";
import CACalendar from "src/views/Components/CACalendar";
import moment from "moment";
import dateArray from "moment-array-dates";
import { Table, Switch, DatePicker, Icon } from "antd";
import LPModelModal from "src/views/LoanPoolNewUI/components/borrowablegrid/LPModelModal";
import { observer } from "mobx-react";
import UIFunctions from "src/helpers/UIFunctions";
const { RangePicker } = DatePicker;

@observer
export default class CANormalView extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isImageMode: false,
      selectAll: false,
      markers: [],
      selectedDates: [],
      markersArray: [],
      isMarkers: false,
      item: {}
    };
    this.calendarData = [];
    this.calendarHeader = [];
  }

  // check availability calendar

  onSelectionChange = (date, props) => {
    const { selectedDates, markers } = this.state;
    const dateObj = moment(
      `${props.month}-${date.currentTarget.textContent}-${props.year}`,
      "MM-DD-YYYY"
    );

    let newMarkers = [...markers, { blue: [dateObj] }];
    if (selectedDates.length == 0) {
      this.setState(
        {
          item: props.rItem,
          selectedDates: [dateObj],
          markers: newMarkers,
          markersArray: [...this.state.markersArray, { lightblue: [dateObj] }]
        },
        () =>
          this.setState({
            selectedDates: [dateObj],
            markersArray: [...this.state.markersArray, { lightblue: [dateObj] }]
          })
      );
    } else if (selectedDates.length == 1) {
      if (
        selectedDates[0].format("MM-DD-YYYY") == dateObj.format("MM-DD-YYYY")
      ) {
        return;
      }
      this.setState(prevState => ({
        selectedDates: [...prevState.selectedDates, dateObj],
        markers: newMarkers,
        isMarkers: true
      }));

      newMarkers = dateArray
        .range(
          moment(selectedDates[0] > dateObj ? dateObj : selectedDates[0]),
          moment(dateObj > selectedDates[0] ? dateObj : selectedDates[0]),
          "MM-DD-YYYY",
          true
        )
        .map(i => moment(i, "MM-DD-YYYY"));
      this.setState({
        markers: [...markers, { blue: newMarkers }],
        markersArray: [...markers, { lightblue: newMarkers }],
        isMarkers: true
      });
    } else {
      if (
        selectedDates[1].format("MM-DD-YYYY") == dateObj.format("MM-DD-YYYY")
      ) {
        return;
      }
      newMarkers = markers.filter(i => !i.blue && !i.lightblue);
      this.setState(() => ({
        selectedDates: [],
        markers: newMarkers,
        markersArray: newMarkers,
        isMarkers: false
      }));
    }
  };

  onHoverChange = (date, props) => {
    const { selectedDates, markers } = this.state;
    const dateObj = moment(
      `${props.month}-${date.currentTarget.textContent}-${props.year}`,
      "MM-DD-YYYY"
    ).format("MM-DD-YYYY");

    let newMarkers = [];
    let startDate = null;
    let endDate = null;
    if (selectedDates.length == 0) {
      newMarkers = markers.filter(i => !i.lightblue);
      this.setState({ markers: newMarkers });
      return;
    }
    if (selectedDates.length == 1) {
      startDate = selectedDates[0].format("MM-DD-YYYY");
    }
    if (selectedDates.length == 2) {
      endDate = selectedDates[1].format("MM-DD-YYYY");
    }
    if (endDate) {
      newMarkers = markers.filter(i => !i.lightblue);
      this.setState({ markers: newMarkers, markersArray: newMarkers });
      return;
    }
    if (startDate) {
      let updatedMarkers = markers.filter(i => !i.lightblue);
      if (startDate > dateObj) {
        const TstartDate = moment(startDate, "MM-DD-YYYY")
          .subtract(1, "days")
          .format("MM-DD-YYYY");
        if (TstartDate == dateObj) {
          newMarkers.push(moment(dateObj, "MM-DD-YYYY"));
          const TAfterDate = moment(dateObj, "MM-DD-YYYY")
            .add(1, "days")
            .format("MM-DD-YYYY");
          let newMarkerss = [];
          newMarkerss.push(moment(TstartDate, "MM-DD-YYYY"));
          newMarkerss.push(moment(TAfterDate, "MM-DD-YYYY"));
          this.setState({
            markers: [...updatedMarkers, { lightblue: newMarkers }],
            markersArray: [...updatedMarkers, { lightblue: newMarkerss }]
          });
          return;
        }

        newMarkers = dateArray
          .range(moment(dateObj), moment(TstartDate), "MM-DD-YYYY", true)
          .map(i => moment(i, "MM-DD-YYYY"));
        this.setState({
          markers: [...updatedMarkers, { lightblue: newMarkers }],
          markersArray: [...updatedMarkers, { lightblue: newMarkers }]
        });
        let newMarkerss = dateArray
          .range(moment(dateObj), moment(startDate), "MM-DD-YYYY", true)
          .map(i => moment(i, "MM-DD-YYYY"));
        this.setState({
          markersArray: [...updatedMarkers, { lightblue: newMarkerss }]
        });

        return;
      }

      if (startDate == dateObj) {
        // const newMarkerss = [...markers];
        this.setState({
          markersArray: [...updatedMarkers, { lightblue: [moment(dateObj)] }],
          markers: updatedMarkers
        });
        return;
      }
      const TstartDate = moment(startDate, "MM-DD-YYYY")
        .add(1, "days")
        .format("MM-DD-YYYY");
      if (TstartDate == dateObj) {
        newMarkers.push(moment(dateObj, "MM-DD-YYYY"));
        const TbeforeDate = moment(dateObj, "MM-DD-YYYY")
          .subtract(1, "days")
          .format("MM-DD-YYYY");
        let newMarkerss = [];
        newMarkerss.push(moment(TbeforeDate, "MM-DD-YYYY"));
        newMarkerss.push(moment(TstartDate, "MM-DD-YYYY"));
        this.setState({
          markers: [...updatedMarkers, { lightblue: newMarkers }],
          markersArray: [...updatedMarkers, { lightblue: newMarkerss }]
        });
        return;
      }

      newMarkers = dateArray
        .range(moment(TstartDate), moment(dateObj), "MM-DD-YYYY", true)
        .map(i => moment(i, "MM-DD-YYYY"));
      let newMarkerss = dateArray
        .range(moment(startDate), moment(dateObj), "MM-DD-YYYY", true)
        .map(i => moment(i, "MM-DD-YYYY"));
      this.setState({
        markers: [...updatedMarkers, { lightblue: newMarkers }],
        markersArray: [...updatedMarkers, { lightblue: newMarkerss }]
      });
    }
  };
  getCalendar = (
    month,
    year,
    markers,
    selectedDates,
    newMarkers,
    plannedDisposalDate,
    item
  ) => {
    return (
      <CACalendar
        year={year}
        month={month}
        markers={markers}
        onSelectionChange={this.onSelectionChange}
        onHoverChange={this.onHoverChange}
        selectedDates={selectedDates}
        newMarkers={newMarkers}
        plannedDisposalDate={plannedDisposalDate}
        item={item}
      />
    );
  };

  getModelDetails = record => {
    return (
      <ModelDetails
        details={record}
        mode={this.state.isImageMode ? "details" : "image"}
        onAddToCart={this.onAddToCart}
        imageSource={record.ModelNo}
        onClickModal={() => this.handleModal(record)}
      />
    );
  };
  handleModal = data => {
    loanPoolStoreV2.setIsModelModalOpen(data);
  };
  getCalendarRange = (startDate, endDate, markers) => {
    let range = [];
    range = dateArray
      .range(moment(startDate), moment(endDate), "MM-DD-YYYY", true)
      .map(i => moment(i).format("MM-YYYY"));

    this.calendarHeader = [
      {
        dataIndex: "assets",
        width: 225,
        fixed: "left"
      }
    ];

    let finalRange = [];
    finalRange = range.filter(function(item, i, ar) {
      return ar.indexOf(item) === i;
    });
    finalRange.map(i => {
      this.calendarHeader.push({
        dataIndex: i,
        width: 225
      });
    });
    //apply map for dynamically getting getcalendar here

    let tempObj = {};
    this.calendarData = [];
    loanPoolStoreV2.filteredItemsToShowCheckAvailability.map(item => {
      tempObj["assets"] = this.getModelDetails(item);

      const nMark = [...markers, ...item["markers"]];
      const plannedDisposalDate = item["PlannedDisposalDate"];
      //props item variable is used
      finalRange.map(i => {
        tempObj[i] = this.getCalendar(
          i.substr(0, 2),
          i.substr(i.length - 4),
          this.state.isMarkers
            ? nMark
            : this.state.item.UniqueID == item.UniqueID
            ? [...markers, ...item["markers"]]
            : [...item["markers"]],
          this.state.selectedDates,
          this.state.item.UniqueID == item.UniqueID
            ? this.state.markersArray
            : [],
          plannedDisposalDate,
          item
        );
      });
      this.calendarData.push(tempObj);
      tempObj = {};
    });
  };

  // loading mask
  loadingMask = (e, bool) => {
    //vanila js for loading mask
    if (e) {
      const removeChild = e.querySelector("i");
      removeChild.remove();
      const addChild = document.createElement("i");
      if (bool) {
        e.setAttribute("id", "loadingBtn");
        addChild.setAttribute("class", "anticon anticon-spin anticon-loading");
      } else {
        e.removeAttribute("id", "loadingBtn");

        addChild.setAttribute("class", "anticon anticon-shopping-cart");

        addChild.style.color = "#42da81";
        setTimeout(() => {
          e.removeAttribute("loading", "true");
          const allElements = document.querySelectorAll(
            ".ant-table-fixed button"
          );
          [...allElements].map(element =>
            element.removeAttribute("disabled", "true")
          );
        }, 0);
      }
      e.appendChild(addChild);
    }
  };
  // asset details
  onAddToCart = (e, details) => {
    //eslint-disable-next-line
    const { markers, ...nDetails } = details;
    if (this.state.selectedDates.length == 2) {
      const selectedDates = this.state.selectedDates.sort((a, b) => a - b); //to sort the dates in correct order
      nDetails.RequestedStartDate = selectedDates[0];
      nDetails.RequestedEndDate = selectedDates[1];
      const allElements = document.querySelectorAll(".ant-table-fixed button");
      [...allElements].map(element => {
        element.setAttribute("disabled", "true");
      });
      this.loadingMask(e.target, true);
      loanPoolStoreV2.addToCart(nDetails).then(() => {
        const element = document.getElementById("loadingBtn");
        this.loadingMask(element, false);
        this.setState({ btn_disabled: true });
      });
    } else {
      UIFunctions.Toast("Please provide start and end dates", "warn");
    }
  };
  componentDidMount() {
    const arrowLeft = document.getElementById("arrowLeft");
    const arrowRight = document.getElementById("arrowRight");
    // document.getElementsByClassName("ant-table-body")[0].scrollLeft += 290;
    arrowRight.onclick = function() {
      document.getElementsByClassName("ant-table-body")[0].scrollLeft +=
        window.innerWidth - 360;
    };
    arrowLeft.onclick = function() {
      document.getElementsByClassName("ant-table-body")[0].scrollLeft -=
        window.innerWidth - 360;
    };
    if (loanPoolStoreV2.filteredItemsToShowCheckAvailability.length == 0) {
      loanPoolStoreV2.rerenderCheckAvailability();
      return;
    }
    if (loanPoolStoreV2.caCheckboxedItems.length > 0) {
      loanPoolStoreV2.rerenderCheckAvailability();
    }
    if (loanPoolStoreV2.filteredItemsToShowCheckAvailability.length > 0) {
      return;
    }
  }
  componentWillUnmount() {
    // if (loanPoolStoreV2.caCheckboxedItems.length > 0) {
    //   loanPoolStoreV2.caCheckboxedItems = [];
    //   loanPoolStoreV2.caPagination["pageSize"] = 10;
    //   loanPoolStoreV2.rerenderCheckAvailability();
    // } else {
    loanPoolStoreV2.lpborrowableDoNotUpdate = [
      ...loanPoolStoreV2.lpborrowableSelectedRows
    ];
    loanPoolStoreV2.caPagination["pageSize"] = 10;
    loanPoolStoreV2.caPagination["pageNumber"] = 1;
    // }
    loanPoolStoreV2.startDateCheckAvailability = moment()
      .startOf("day")
      .toISOString();
    loanPoolStoreV2.endDateCheckAvailability = moment()
      .add(6, "months")
      .endOf("day")
      .toISOString();
  }

  //range picker

  onRangeChange = date => {
    if (date.length == 2) {
      loanPoolStoreV2.setAvailabilityDates(date);
    }
  };
  // shouldComponentUpdate() {
  //   if (
  //     this.state.selectedDates.length == 0 ||
  //     this.state.selectedDates.length > 2
  //   ) {
  //     return false;
  //   }
  //   return true;
  // }

  //modal
  handleModalClose() {
    loanPoolStoreV2.isModelModalOpen = false;
  }
  handleTableChange = pagination => {
    const pager = { ...loanPoolStoreV2.caPagination };
    pager.pageNumber = pagination.current;

    loanPoolStoreV2.caPagination = pager;

    loanPoolStoreV2.rerenderCheckAvailability();
  };

  render() {
    const { markers } = this.state;
    this.getCalendarRange(
      loanPoolStoreV2.startDateCheckAvailability,
      loanPoolStoreV2.endDateCheckAvailability,
      markers
    );
    const tableStyles = {
      x: window.innerWidth - 20,
      y: window.innerHeight - 195
    };
    return (
      <div className="CA-Outer">
        <div
          id="arrowLeft"
          className="arrow"
          style={{
            height: 52,
            width: 27,
            position: "fixed",
            zIndex: "10",
            top: "50%",
            transform: "translateY(50%)",
            left: "309px",
            background: "#646C72",
            border: "1px solid #5C6368",
            boxShadow: " 0 0 3px 0 rgba(0,0,0,0.61), 0 0 4px 0 rgba(0,0,0,0.5)",
            borderBottomRightRadius: 112,
            borderTopRightRadius: 117,
            cursor: "pointer"
          }}
        >
          <Icon
            type="arrow-left"
            style={{
              position: "absolute",
              top: "50%",
              transform: "translate(-50%,-50%)",
              left: "50%",
              fontSize: 19,
              color: "#fff",
              cursor: "pointer"
            }}
          />
        </div>
        <div
          id="arrowRight"
          className="arrow"
          style={{
            height: 52,
            width: 27,
            position: "fixed",
            zIndex: "10",
            top: "50%",
            transform: "translateY(50%)",
            right: "20px",
            background: "#646C72",
            border: "1px solid #5C6368",
            boxShadow: " 0 0 3px 0 rgba(0,0,0,0.61), 0 0 4px 0 rgba(0,0,0,0.5)",
            borderBottomLeftRadius: 112,
            borderTopLeftRadius: 117,
            cursor: "pointer"
          }}
        >
          <Icon
            type="arrow-right"
            style={{
              position: "absolute",
              top: "50%",
              transform: "translate(-50%,-50%)",
              left: "50%",
              fontSize: 19,
              color: "#fff",
              cursor: "pointer"
            }}
          />
        </div>
        <div
          className="CA-TableControls"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-end",
            minHeight: 55,
            margin: "0 24px"
          }}
        >
          <div
            className="CA-leftPanel"
            style={{
              color: "#646C72",
              fontFamily: "Open Sans",
              fontSize: 13,
              letterSpacing: 0.87,
              lineHeight: "18px",
              flex: 1,
              alignItems: "flex-end",
              display: "flex"
            }}
          >
            <span style={{ marginRight: "12px", height: "24px" }}>Details</span>
            <Switch
              className="details-switch"
              style={{
                marginBottom: "2px",
                marginRight: "90px"
              }}
              checkedChildren="ON"
              unCheckedChildren="OFF"
              size="medium"
              onChange={checked => this.setState({ isImageMode: checked })}
            />
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "flex-end",
              flexWrap: "wrap",
              width: "56%"
            }}
          >
            <RangePicker
              onChange={this.onRangeChange}
              style={{ width: 322, height: 29 }}
              defaultValue={[
                moment(loanPoolStoreV2.startDateCheckAvailability),
                moment(loanPoolStoreV2.endDateCheckAvailability)
              ]}
            />
            <div style={{ margin: "0 8px" }}>
              <span
                style={{
                  margin: "0 8px",
                  color: "#979797",
                  fontFamily: "Open Sans",
                  fontSize: 13,
                  letterSpacing: 0.47,
                  lineHeight: "18px"
                }}
              >
                <span
                  style={{
                    height: 14,
                    width: 14,
                    backgroundColor: "#FFD893",
                    display: "inline-block",
                    marginRight: 8
                  }}
                />
                Requested
              </span>
              <span
                style={{
                  margin: "0 8px",
                  color: "#979797",
                  fontFamily: "Open Sans",
                  fontSize: 13,
                  letterSpacing: 0.47,
                  lineHeight: "18px"
                }}
              >
                <span
                  style={{
                    height: 14,
                    width: 14,
                    backgroundColor: "#FFBDCD",
                    display: "inline-block",
                    marginRight: 8
                  }}
                />
                Loaned/ Not Available
              </span>
              <span
                style={{
                  margin: "0 8px",
                  color: "#979797",
                  fontFamily: "Open Sans",
                  fontSize: 13,
                  letterSpacing: 0.47,
                  lineHeight: "18px"
                }}
              >
                <span
                  style={{
                    height: 14,
                    width: 14,
                    backgroundColor: "#D2D5DF",
                    display: "inline-block",
                    marginRight: 8
                  }}
                />
                Service
              </span>
            </div>
          </div>
        </div>
        <div className="ca--table">
          <Table
            columns={this.calendarHeader}
            dataSource={this.calendarData}
            // pagination={{ showSizeChanger: true }}
            pagination={loanPoolStoreV2.caPagination}
            loading={!loanPoolStoreV2.caPaginationLoader}
            onChange={this.handleTableChange}
            scroll={tableStyles}
            id="tableContainer"
          />
        </div>

        {loanPoolStoreV2.isModelModalOpen ? (
          <LPModelModal
            visible={loanPoolStoreV2.isModelModalOpen}
            onClose={this.handleModalClose.bind(this)}
            modelModalData={loanPoolStoreV2.isModelModalOpen}
            selectedDates={this.state.selectedDates}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}
