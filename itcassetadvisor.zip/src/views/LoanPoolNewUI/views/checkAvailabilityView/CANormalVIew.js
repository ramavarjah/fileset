
import React from "react";
import dateArray from "moment-array-dates";
import moment from "moment";
import UIFunctions from "src/helpers/UIFunctions";
import {MultiGrid,AutoSizer} from 'react-virtualized'
import {  Switch, DatePicker, Icon,Spin,Pagination } from "antd";
const { RangePicker } = DatePicker;
import CACalendarLatest from 'src/views/Components/CACalendarLatest';
import loanPoolStoreV2 from "src/stores/loanPoolStoreV2";
import ModelDetails from "../../components/checkAvailability/ModelDetails";
import { setTimeout } from "timers";
import { observer } from "mobx-react";
import LPModelModal from "src/views/LoanPoolNewUI/components/borrowablegrid/LPModelModal";
import LinearProgress from '@material-ui/core/LinearProgress';

const STYLE = {
  border: '1px solid #ddd',
  backgroundColor: "#fffff"
};
const STYLE_BOTTOM_LEFT_GRID = {
  borderRight: '2px solid #aaa',
  backgroundColor: '#f7f7f7',
};
const STYLE_TOP_LEFT_GRID = {
  borderBottom: '2px solid #aaa',
  borderRight: '2px solid #aaa',
  fontWeight: 'bold',
};
const STYLE_TOP_RIGHT_GRID = {
  borderBottom: '2px solid #aaa',
  fontWeight: 'bold',
};

@observer
class CANormalView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      num: 6,
      selectedDates: {},
      columnCount: 50,
      rowCount:10,
      isImageMode: false,
      currentPage:1,
      gridColumnCount: 5,
      fixedColumnCount: 1,
      fixedRowCount: 0,
      scrollToColumn: 0,
      scrollToRow: 0,
    }
    this.theGrid = React.createRef();
    this.auto_sizer = React.createRef();
    this.calendarData = [];
    this._cellRenderer = this._cellRenderer.bind(this);
    this._onScrollToColumnChange = this._createEventHandler('scrollToColumn');
    this._onScrollToRowChange = this._createEventHandler('scrollToRow');
    this.onPageChange = this.onPageChange.bind(this);
  }
  componentDidMount(){
    loanPoolStoreV2.setIsBackArrowVisible(true);
    this.calendarData = [];
    if(loanPoolStoreV2.filteredItemsToShowCheckAvailability[0])
    {
    loanPoolStoreV2.filteredItemsToShowCheckAvailability[0].map(item => {
      this.calendarData.push(this.getModelDetails(item));
    });
  }
       loanPoolStoreV2.startDateAvailabilityData = moment()
      .startOf("day")
      .toISOString();
      loanPoolStoreV2.endDateAvailabilityData = moment()
      .add(10, "months")
      .endOf("day")
      .toISOString();
    loanPoolStoreV2.rerenderCheckAvailability().then(()=>{
      this.calendarData = [];
      loanPoolStoreV2.filteredItemsToShowCheckAvailability[0].map(item => {
        this.calendarData.push(this.getModelDetails(item));
      });
      let selectedDatess = {};
      dateArray.range(loanPoolStoreV2.startDateCheckAvailability,loanPoolStoreV2.endDateCheckAvailability, "YYYY-MM-DD", true).map(i => {
        if (selectedDatess[moment(i).format("YYYY")])
          selectedDatess[moment(i).format("YYYY")][moment(i).format("MM")] = {
            ...selectedDatess[moment(i).format("YYYY")][
              moment(i).format("MM")
            ],
            [moment(i).format("DD")]: true
          };
        else {
          selectedDatess[moment(i).format("YYYY")] = {
            [moment(i).format("MM")]: {
              [moment(i).format("DD")]: true
            }
          };
        }
      });
      this.setState({ selectedDates: selectedDatess });
      // if(loanPoolStoreV2.filteredItemsToShowCheckAvailability[0]){
      //   let scrollClass =  document.getElementsByClassName("ReactVirtualized__Grid");
      //   let customScrollHeight = loanPoolStoreV2.filteredItemsToShowCheckAvailability[0].length * 253;
      //   if(scrollClass[1].clientHeight >= customScrollHeight){
      //    scrollClass[1].style.overflow = "hidden";
      //   }
      //   else{
      //     scrollClass[1].style.overflow = "auto";
      // //    scrollClass[1].style.overflowX  = "hidden";
      //   }
      // }
    })
    const canvas = document.createElement('canvas');
    canvas.style.position = 'absolute';
    canvas.style.top = 0;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.pointerEvents = 'none';
    document.body.appendChild(canvas);
  }
  componentDidUpdate (prevProps, prevState) {
    if (this.state.isImageMode !== prevState.isImageMode || this.state.currentPage !== prevState.currentPage || this.state.rowCount !==prevState.rowCount) {
      this.calendarData = [];
      loanPoolStoreV2.filteredItemsToShowCheckAvailability[0].map(item => {
      this.calendarData.push(this.getModelDetails(item));
      });
    }
    this.theGrid.current.forceUpdateGrids();
  }
  componentWillUnmount() {
    loanPoolStoreV2.lpborrowableDoNotUpdate = [
      ...loanPoolStoreV2.lpborrowableSelectedRows
    ];
    loanPoolStoreV2.caPagination["pageSize"] = 10;
    loanPoolStoreV2.caPagination["pageNumber"] = 1;
    loanPoolStoreV2.startDateCheckAvailability = moment()
      .startOf("day")
      .toISOString();
    loanPoolStoreV2.endDateCheckAvailability = moment()
      .add(1, "months")
      .endOf("day")
      .toISOString();
  }

  months = num => {
    let lastDay = moment();
    lastDay = moment(lastDay).add(num-1, "month");
    let months = [];
      months.push({
        month: moment(lastDay).format("MM"),
        year: moment(lastDay).format("YYYY")
      });  
    return months;
  };
  
  getFirstDate(obj) {
    let year = Object.keys(obj)[0];
    let selectedYear = Object.values(obj)[0];
    let month = Object.keys(selectedYear)[0];
    let dateobj = Object.values(selectedYear)[0];
    let date = Object.keys(dateobj)[0];
    return moment(`${year}-${month}-${date}`);
  }
  getStartNendDate = (d1, d2) => (d1 > d2 ? { d1: d2, d2: d1 } : { d1, d2 });

  getSelectedDates = (arr, month, year) => {
    if (arr[year])
      if (arr[year][month]) return arr[year][month];
      else return {};
    else return {};
  };
  handleDayClick = (e, month, year) => {
    const { selectedDates } = this.state;
    const date = moment(`${year}-${month}-${e.currentTarget.innerText}`).format(
      "DD"
    );
    let selectedDatess = {};

    if (Object.keys(selectedDates).length == 0) {
      selectedDatess[year] = {
        [month]: {
          [date]: true
        }
      };
      this.setState({
        selectedDates: selectedDatess
      });
      return;
    } else {
      const jsonObj = JSON.stringify(selectedDates);
      const occurance = (jsonObj.match(/true/g) || []).length;
      if (occurance === 1) {
        let dateObj = this.getFirstDate(selectedDates);
        selectedDatess = selectedDates;
        let dates = this.getStartNendDate(
          dateObj,
          moment(`${year}-${month}-${date}`)
        );
        if (
          dateObj.format("YYYY-MM-DD") ==
          moment(`${year}-${month}-${date}`).format("YYYY-MM-DD")
        ) {
          return;
        }
        dateArray.range(dates.d1, dates.d2, "YYYY-MM-DD", true).map(i => {
          if (selectedDatess[moment(i).format("YYYY")])
            selectedDatess[moment(i).format("YYYY")][moment(i).format("MM")] = {
              ...selectedDatess[moment(i).format("YYYY")][
                moment(i).format("MM")
              ],
              [moment(i).format("DD")]: true
            };
          else {
            selectedDatess[moment(i).format("YYYY")] = {
              [moment(i).format("MM")]: {
                [moment(i).format("DD")]: true
              }
            };
          }
        });
        let newdate=[dates.d1,dates.d2];
        loanPoolStoreV2.setAvailabilityDates(newdate);
       // this.onRangeChange(newdate);
        loanPoolStoreV2.caPaginationLoader = true;
        this.setState({ selectedDates: selectedDatess });
      } else {
        this.setState({ selectedDates: {} });
      }
    }
   //  document.getElementsByClassName("ReactVirtualized__Grid")[1].scrollLeft += 5;
  };
  getAvailabilityData = (month,year,UniqueID) => {
    let availabilityDataForThisMonth = {};
    //compare month,year,uniqueid with api data and return availability data for that month.
    loanPoolStoreV2.filteredItemsToShowCheckAvailability[1].map((currElement, index) => {
      Object.entries(loanPoolStoreV2.filteredItemsToShowCheckAvailability[1][index]).forEach(entry => {  
        let key = entry[0];
        let value = entry[1];
        let check = UniqueID+"-"+year+"-"+month
          if(key == check) {
              availabilityDataForThisMonth =value;
          }
    
      });
    })

  return availabilityDataForThisMonth;
  }
  onRangeChange = date => {
    if (date.length == 2) {
      loanPoolStoreV2.setAvailabilityDates(date);
      let selectedDatess = {};
      dateArray.range(loanPoolStoreV2.startDateCheckAvailability,loanPoolStoreV2.endDateCheckAvailability, "YYYY-MM-DD", true).map(i => {
        if (selectedDatess[moment(i).format("YYYY")])
          selectedDatess[moment(i).format("YYYY")][moment(i).format("MM")] = {
            ...selectedDatess[moment(i).format("YYYY")][
              moment(i).format("MM")
            ],
            [moment(i).format("DD")]: true
          };
        else {
          selectedDatess[moment(i).format("YYYY")] = {
            [moment(i).format("MM")]: {
              [moment(i).format("DD")]: true
            }
          };
        }
      });
      this.setState({ selectedDates: selectedDatess });
      loanPoolStoreV2.caPaginationLoader = true;
    }
  };


  onRightClick = () => {
    loanPoolStoreV2.startDateAvailabilityData =  moment(loanPoolStoreV2.endDateAvailabilityData).startOf('month').toISOString();
    loanPoolStoreV2.endDateAvailabilityData =    moment(loanPoolStoreV2.endDateAvailabilityData).add(3, 'months').startOf('month').toISOString();
    loanPoolStoreV2.rerenderCheckAvailabilityCalender();
      let columnCount = this.state.columnCount;
      columnCount += 3;
      this.setState({columnCount:columnCount});
      document.getElementsByClassName("ReactVirtualized__Grid")[1].scrollLeft += 750;
 
  }
  
  onLeftClick = () => {
    document.getElementsByClassName("ReactVirtualized__Grid")[1].scrollLeft -= 750;
  }

  handleModalClose() {
    loanPoolStoreV2.isModelModalOpen = false;
  }
  handleModal = data => {
    loanPoolStoreV2.setIsModelModalOpen(data);
  };
  getModelDetails = record => {
    return (
      <ModelDetails
        details={record}
        mode={this.state.isImageMode ? "details" : "image"}
        onAddToCart={this.onAddToCart}
        imageSource={record.ModelNo}
        onClickModal={() => this.handleModal(record)}
      />
    );
  };
  onAddToCart = (e, details) => {
       //eslint-disable-next-line
    const { markers, ...nDetails } = details;
    const selectedDatesCalender = this.state.selectedDates;
    const selectedDates = [loanPoolStoreV2.startDateCheckAvailability,loanPoolStoreV2.endDateCheckAvailability]
    var size = Object.keys(selectedDatesCalender).length;
    if (size > 0) {
      nDetails.RequestedStartDate = selectedDates[0];
      nDetails.RequestedEndDate = selectedDates[1];
      const allElements = document.querySelectorAll(".ant-table-fixed button");
      [...allElements].map(element => {
        element.setAttribute("disabled", "true");
      });
      this.loadingMask(e.target, true);
      loanPoolStoreV2.addToCart(nDetails).then(() => {
        const element = document.getElementById("loadingBtn");
        this.loadingMask(element, false);
        this.setState({ btn_disabled: true });
      });
    } else {
      UIFunctions.Toast("Please provide start and end dates", "warn");
    }
  };
  loadingMask = (e, bool) => {
    //vanila js for loading mask
    if (e) {
      const removeChild = e.querySelector("i");
      removeChild.parentNode.removeChild(removeChild);
      const addChild = document.createElement("i");
      if (bool) {
        e.setAttribute("id", "loadingBtn");
        addChild.setAttribute("class", "anticon anticon-spin anticon-loading");
      } else {
        e.removeAttribute("id", "loadingBtn");

        addChild.setAttribute("class", "anticon anticon-shopping-cart");

        addChild.style.color = "#42da81";
        setTimeout(() => {
          e.removeAttribute("loading", "true");
          const allElements = document.querySelectorAll(
            ".ant-table-fixed button"
          );
          [...allElements].map(element =>
            element.removeAttribute("disabled", "true")
          );
        }, 0);
      }
      e.appendChild(addChild);
    }
  };
  //--------------------grid-------//
 _cellRenderer({columnIndex, key, rowIndex, style}) {
    let selectedDates = this.state.selectedDates;
    if(this.calendarData[rowIndex] !== undefined  && this.calendarData[rowIndex].props !== undefined){
    let UniqueID = this.calendarData[rowIndex].props.details.UniqueID;
    let PlannedDisposalDate = this.calendarData[rowIndex].props.details.PlannedDisposalDate;
    return (
      columnIndex == 0 ? (
        <div className={style.Cell} key={key} style={style}>
          {this.calendarData[rowIndex]}
          </div>
      ):(
      <div className={style.Cell} key={key} style={style} >
              {
                   this.months(columnIndex).map(({ month, year }) => (
                      <CACalendarLatest 
                      key={month + year}
                      month={month}
                      year={year}
                      selectedDates={this.getSelectedDates(selectedDates, month, year)}
                      onDayClick={e => this.handleDayClick(e, month, year)} 
                      PlannedDisposalDate={PlannedDisposalDate}
                      availabilityData={this.getAvailabilityData(month,year,UniqueID)}
                      />
                    ))
          }
          </div>
      )
    );}
    else{
      return;
    }
  }

  _createEventHandler(property) {
    return event => {
      const value = parseInt(event.target.value, 10) || 0;

      this.setState({
        [property]: value,
      });
    };
  }
  getAssets = ()=>{
    this.calendarData = [];
    if(loanPoolStoreV2.filteredItemsToShowCheckAvailability[0])
    {
    loanPoolStoreV2.filteredItemsToShowCheckAvailability[0].map(item => {
    this.calendarData.push(this.getModelDetails(item));
    })
  }
  }
  disabledDate = current => {
    return (
      current &&
      current <=
      moment()
        .endOf("day")
        .subtract(1, "day")
    );
  };
  onShowSizeChange = (current, pageSize)=> {
    const pager = { ...loanPoolStoreV2.caPagination };
    pager.pageNumber = current;
    loanPoolStoreV2.caPagination = pager;
    loanPoolStoreV2.onShowSizeChange(current,pageSize);
    loanPoolStoreV2.startDateAvailabilityData = moment()
    .startOf("day")
    .toISOString();
    loanPoolStoreV2.endDateAvailabilityData = moment()
    .add(10, "months")
    .endOf("day")
    .toISOString();
    loanPoolStoreV2.rerenderCheckAvailability().then(()=>
      this.setState({rowCount:pageSize}));
  }
  onPageChange = (page)=> {
    const pager = { ...loanPoolStoreV2.caPagination };
    pager.pageNumber = page;
    loanPoolStoreV2.caPagination = pager;
    loanPoolStoreV2.startDateAvailabilityData = moment()
    .startOf("day")
    .toISOString();
    loanPoolStoreV2.endDateAvailabilityData = moment()
    .add(10, "months")
    .endOf("day")
    .toISOString();
    loanPoolStoreV2.rerenderCheckAvailability().then(()=>{
      this.setState({currentPage:page})});
    //  this.theGrid.current.forceUpdateGrids();
  }
    getRowCount(c1,c2){
    return c1>c2?c2:c1;
    }
  render() {
    this.getAssets();
    let outerstyle = {
      borderColor: "#f2f2f2",
      height: window.innerHeight - 102,
    }
    let gridStyle = {
      height: window.innerHeight - 102 - 100,
    }
    let defaultDate = 
      [
        moment(loanPoolStoreV2.startDateCheckAvailability),
        moment(loanPoolStoreV2.endDateCheckAvailability)
      ]  
    const {
      columnCount
    } = this.state

    const rowCount = this.getRowCount(this.state.rowCount,loanPoolStoreV2.filteredItemsToShowCheckAvailability[0]?loanPoolStoreV2.filteredItemsToShowCheckAvailability[0].length:this.state.rowCount) 

      return (
        <div className="CA-Outer" style={outerstyle}>       
        <div
          id="arrowLeft"
          className="arrow"
          style={{
            height: 52,
            width: 27,
            position: "fixed",
            zIndex: "10",
            top: "50%",
            transform: "translateY(50%)",
            left: "314px",
            background: "#646C72",
            border: "1px solid #5C6368",
            boxShadow: " 0 0 3px 0 rgba(0,0,0,0.61), 0 0 4px 0 rgba(0,0,0,0.5)",
            borderBottomRightRadius: 112,
            borderTopRightRadius: 117,
            cursor: "pointer"
          }}
        >
          <Icon
            type="arrow-left"
            style={{
              position: "absolute",
              top: "50%",
              transform: "translate(-50%,-50%)",
              left: "50%",
              fontSize: 19,
              color: "#fff",
              cursor: "pointer"
            }}
            onClick = {this.onLeftClick.bind(this)}
          />
        </div>
        <div
          id="arrowRight"
          className="arrow"
          style={{
            height: 52,
            width: 27,
            position: "fixed",
            zIndex: "10",
            top: "50%",
            transform: "translateY(50%)",
            right: "25px",
            background: "#646C72",
            border: "1px solid #5C6368",
            boxShadow: " 0 0 3px 0 rgba(0,0,0,0.61), 0 0 4px 0 rgba(0,0,0,0.5)",
            borderBottomLeftRadius: 112,
            borderTopLeftRadius: 117,
            cursor: "pointer"
          }}
          onClick = {this.onRightClick.bind(this)}
        >
          <Icon
            type="arrow-right"
            style={{
              position: "absolute",
              top: "50%",
              transform: "translate(-50%,-50%)",
              left: "50%",
              fontSize: 19,
              color: "#fff",
              cursor: "pointer"
            }}
          />
        </div>
        <div
          className="CA-TableControls"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-end",
            minHeight: 55,
            margin: "0 24px"
          }}
        >
          <div
            className="CA-leftPanel"
            style={{
              color: "#646C72",
              fontFamily: "Open Sans",
              fontSize: 13,
              letterSpacing: 0.87,
              lineHeight: "18px",
              flex: 1,
              alignItems: "flex-end",
              display: "flex"
            }}
          >
            <span style={{ marginRight: "12px", height: "24px" }}>Details</span>
            <Switch
              className="details-switch"
              style={{
                marginBottom: "2px",
                marginRight: "90px"
              }}
              checkedChildren="ON"
              unCheckedChildren="OFF"
              size="medium"
              onChange={checked => this.setState({ isImageMode: checked })}
            />
          </div>
          <div 
              style={{display: "flex",
              justifyContent: "flex-end",
              alignItems: "flex-end",
              flexWrap: "wrap",
              height: "30px"}}
            >
        <Pagination showSizeChanger onShowSizeChange={this.onShowSizeChange} onChange={this.onPageChange} defaultCurrent={1} total={loanPoolStoreV2.caPagination.total} />
          </div>
        <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "flex-end",
              flexWrap: "wrap",
              width: "56%"
            }}
          >
            <RangePicker
              onChange={this.onRangeChange}
              style={{ width: 322, height: 29 }}
              defaultValue={defaultDate}
              value = {defaultDate}
            />
            <div style={{ margin: "0 8px" }}>
              <span
                style={{
                  margin: "0 8px",
                  color: "#979797",
                  fontFamily: "Open Sans",
                  fontSize: 13,
                  letterSpacing: 0.47,
                  lineHeight: "18px"
                }}
              >
                <span
                  style={{
                    height: 14,
                    width: 14,
                    backgroundColor: "#FFD893",
                    display: "inline-block",
                    marginRight: 8
                  }}
                />
                Requested
              </span>
              <span
                style={{
                  margin: "0 8px",
                  color: "#979797",
                  fontFamily: "Open Sans",
                  fontSize: 13,
                  letterSpacing: 0.47,
                  lineHeight: "18px"
                }}
              >
                <span
                  style={{
                    height: 14,
                    width: 14,
                    backgroundColor: "#FFBDCD",
                    display: "inline-block",
                    marginRight: 8
                  }}
                />
                Loaned/Not Available
              </span>
              <span
                style={{
                  margin: "0 8px",
                  color: "#979797",
                  fontFamily: "Open Sans",
                  fontSize: 13,
                  letterSpacing: 0.47,
                  lineHeight: "18px"
                }}
              >
                <span
                  style={{
                    height: 14,
                    width: 14,
                    backgroundColor: "#D2D5DF",
                    display: "inline-block",
                    marginRight: 8
                  }}
                />
                Service
              </span>
            </div>
            </div>
            </div>
     <Spin spinning={!loanPoolStoreV2.caPaginationLoader} delay={100}>
     <div  style={{marginTop:10,marginRight:25,marginLeft:25,height:12,marginBottom:-8}}>
     {loanPoolStoreV2.caAvailabilityLoader == 0?"":
    <LinearProgress />}
    </div>
     <div style={gridStyle} className="ca--table">
      <AutoSizer >
          {({width,height}) => (
            <MultiGrid
              {...this.state}
              ref={this.theGrid}
              cellRenderer={this._cellRenderer}
              columnWidth={230}
              columnCount={columnCount}
              // enableFixedColumnScroll
              //enableFixedRowScroll
              height={height}
              rowHeight={253}
              rowCount={rowCount}
              style={STYLE}
              styleBottomLeftGrid={STYLE_BOTTOM_LEFT_GRID}
              styleTopLeftGrid={STYLE_TOP_LEFT_GRID}
              styleTopRightGrid={STYLE_TOP_RIGHT_GRID}
              width={width}
             // hideTopRightGridScrollbar
             // hideBottomLeftGridScrollbar
            />
          )}
        </AutoSizer>
        </div>
        </Spin>
        {loanPoolStoreV2.isModelModalOpen ? (
          <LPModelModal
            visible={loanPoolStoreV2.isModelModalOpen}
            onClose={this.handleModalClose.bind(this)}
            modelModalData={loanPoolStoreV2.isModelModalOpen}
            selectedDates={this.state.selectedDates}
          />
        ) : (
          ""
        )}
    </div>
      )
}}

export default CANormalView;