import React, { Component } from "react";
import { observer } from "mobx-react";
import { Layout } from "antd";
import PropTypes from "prop-types";
import LoanPoolHeader from "./LoanPoolHeader";
import Sidebar from "./../../components/Sidebar/Sidebar";
import "./Loanpool.css";
@observer
class LoanPoolLandingPage extends Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            isOpen: false
        };
    }
    toggle() {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }
    render() {
        return (
            <Layout>
                <Layout>
                    <LoanPoolHeader className="header" />
                </Layout>
                <Layout>
                    <Sidebar />
                </Layout>
            </Layout>
        );
    }
}

export default LoanPoolLandingPage;

LoanPoolLandingPage.contextTypes = {
    router: PropTypes.func.isRequired
};
