import React, { Component } from "react";
import { observer } from "mobx-react";
import { Layout, Icon, Row, Col, Divider } from "antd";
import PropTypes from "prop-types";
import Autosuggest from "react-autosuggest";
//const { SubMenu } = Menu;
const { Header } = Layout;
// Imagine you have a list of languages that you'd like to autosuggest.
const languages = [
    {
        name: "C",
        year: 1972
    },
    {
        name: "Java",
        year: 1972
    },
    {
        name: "JavaScript",
        year: 1972
    },
    {
        name: "Ruby",
        year: 1972
    },
    {
        name: "Elm",
        year: 2012
    }
];

// Teach Autosuggest how to calculate suggestions for any given input value.
const getSuggestions = value => {
    const inputValue = value.trim().toLowerCase();
    const inputLength = inputValue.length;

    return inputLength === 0
        ? []
        : languages.filter(
            lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
        );
};

// When suggestion is clicked, Autosuggest needs to populate the input
// based on the clicked suggestion. Teach Autosuggest how to calculate the
// input value for every given suggestion.

// Use your imagination to render suggestions.
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;
@observer
class LoanPoolHeader extends Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            isOpen: false,
            value: "",
            suggestions: []
        };
    }

  onChange = (event, { newValue }) => {
      this.setState({
          value: newValue
      });
  };

  // Autosuggest will call this function every time you need to update suggestions.
  // You already implemented this logic above, so just use it.
  onSuggestionsFetchRequested = ({ value }) => {
      this.setState({
          suggestions: getSuggestions(value)
      });
  };
  getSuggestionValue = suggestion => suggestion.name;

  // Autosuggest will call this function every time you need to clear suggestions.
  onSuggestionsClearRequested = () => {
      this.setState({
          suggestions: []
      });
  };
  toggle() {
      this.setState({
          isOpen: !this.state.isOpen
      });
  }
  render() {
      const { value, suggestions } = this.state;

      // Autosuggest will pass through all these props to the input.
      const inputProps = {
          placeholder: "Type a programming language",
          value,
          onChange: this.onChange
      };
      return (
          <Header className="header s whitebg" style={{ lineHeight: "64px" }}>
              <Row>
                  <Col span={1} />
                  <Col span={1}>
                      <Icon type="search" style={{ fontSize: "x-large" }} />
                  </Col>
                  <Col span={4}>
                      <Autosuggest
                          suggestions={suggestions}
                          onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                          onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                          getSuggestionValue={this.getSuggestionValue}
                          renderSuggestion={renderSuggestion}
                          inputProps={inputProps}
                      />
                  </Col>

                  <Col span={1}>
                      <Divider type="vertical" />
                  </Col>
                  <Col span={5}>col-6</Col>
                  <Col span={6}>col-6</Col>
                  <Col span={6}>col-6</Col>
              </Row>
          </Header>
      );
  }
}

export default LoanPoolHeader;

LoanPoolHeader.contextTypes = {
    router: PropTypes.func.isRequired
};
