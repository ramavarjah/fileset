import React, { Component } from "react";
import { observer } from "mobx-react";
import { Layout, Menu, Icon } from "antd";
import PropTypes from "prop-types";

const { Header } = Layout;
@observer
class LoanPoolSideBar extends Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            isOpen: false
        };
    }
    toggle() {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }
    render() {
        return (
            <Header className="header whitebg">
                <div className="logo">
                    <Icon type="search" />
                </div>
                <Menu
                    theme="dark"
                    mode="horizontal"
                    defaultSelectedKeys={["2"]}
                    style={{ lineHeight: "64px" }}
                >
                    <Menu.Item key="1">nav 1</Menu.Item>
                    <Menu.Item key="2">nav 2</Menu.Item>
                    <Menu.Item key="3">nav 3</Menu.Item>
                </Menu>
            </Header>
        );
    }
}

export default LoanPoolSideBar;

LoanPoolSideBar.contextTypes = {
    router: PropTypes.func.isRequired
};
