import React from "react";
import userStore from "../../../../stores/userStore";
import UIFunctions from "../../../../helpers/UIFunctions";
import Functions from "../../../../api/Functions";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import tabModelStore from "../../../../stores/tabModelStore";
import moment from "moment";
import { Row, Col, Form, Input, Button } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;
const { TextArea } = Input;
import { Redirect } from "react-router-dom";
import mobx from "mobx";
// import { createBrowserHistory } from "history";
// const history = createBrowserHistory();
const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 24 }
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 24 }
  }
};
@observer
class AddFormNewRequest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      requestorname: "",
      requestoremailAddress: "",
      totalloancost: 0,
      loading: false,
      startValue: null,
      endValue: null,
      endOpen: false,
      requestormobile: "",
      chargecode: "",
      Location: "",
      justification: "",
      LPrequestSuccess: false,
      requeststartDate: moment().startOf("day"),
      requestendDate: moment()
        .add(1, "day")
        .startOf("day")
    };
  }
  onChange = (field, value) => {
    this.setState({
      [field]: value
    });
  };
  disabledStartDate = current => {
    return (
      current &&
      current <=
        moment()
          .endOf("day")
          .subtract(1, "day")
    );
  };

  //   disabledEndDate = endValue => {
  //       const startValue = this.state.requeststartDate;
  //       if (!endValue || !startValue) {
  //           return false;
  //       }
  //       return endValue.clone().endOf("day") <= startValue.valueOf();
  //   };
  //   onStartChange = value => {
  //       this.onChange("requeststartDate", value);
  //       const endDate = this.props.form.getFieldValue("requestendDate");
  //       if (value && moment(value) > moment(endDate)) {
  //           let requestendDate = value;
  //           this.props.form.setFieldsValue({
  //               requestendDate
  //           });
  //       }
  //   };
  componentDidUpdate() {}

  onEndChange = value => {
    this.onChange("requestendDate", value);
  };
  totalLoanCost = () => {
    var total = 0;
    var items = loanPoolStoreV2.getDataFromDuplicate
      ? loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets
      : loanPoolStoreV2.cartItems;
    items.map(a => {
      // get startdate and end date to calculate total loan cost
      var startDate = loanPoolStoreV2.getDataFromDuplicate
        ? moment(a.StartDate).format()
        : moment(a.RequestedStartDate).format();
      var endDate = loanPoolStoreV2.getDataFromDuplicate
        ? moment(a.EndDate).format()
        : moment(a.RequestedEndDate).format();
      var diff = moment(endDate).diff(startDate, "days")+1;
      if (a.LoanDailyCost >= 0) total = +(a.LoanDailyCost * diff) + total;
    });
    // if total is not valid set 0 as total
    if (!total) total = 0;
    return total;
  };
  ERJustificationAndLocation = (input) => {
    let ERAsset = {
      justification :"",
      Location : ""
    }
    let cartItems = mobx.toJS(input);
    let ERAssets = cartItems.filter(function (el) {
      return (
        el.HasExternalRequest == true
      );
    });
    if (ERAssets.length == cartItems.length & ERAssets.length > 0) {
      ERAsset.justification = ERAssets[0].JustificationER;
      ERAsset.Location = ERAssets[0].Location;
      ERAssets.map(a => {
        ERAsset.justification =
          ERAsset.justification == a.JustificationER
          ? ERAsset.justification
            : "";
        ERAsset.Location =
          ERAsset.Location == a.Location ? ERAsset.Location : "";
      })
    }
    return ERAsset;
  };
  handleStartOpenChange = open => {
    if (!open) {
      this.setState({ endOpen: true });
    }
  };

  handleEndOpenChange = open => {
    this.setState({ endOpen: open });
  };
  componentDidMount() {
    if (!loanPoolStoreV2.getDataFromDuplicate) {
      const firstName = userStore.userDetails
        ? userStore.userDetails.firstName
        : "Invalid name";
      const lastName = userStore.userDetails
        ? userStore.userDetails.lastName
        : "";
      let requestoremailAddress = userStore.userDetails
        ? userStore.userDetails.emailAddress
        : "Invalid email address";

      let requestorname = "No Name";
      if (firstName || lastName) {
        requestorname = firstName + " " + lastName;
      }
      if (!requestoremailAddress) {
        requestoremailAddress = "No Email Address";
      }
      let requestormobile = userStore.userDetails
        ? userStore.userDetails.mobilePhone
        : userStore.userDetails.phoneNo;
      if (!requestormobile) {
        requestormobile = "";
      }
      let ERAsset = this.ERJustificationAndLocation(loanPoolStoreV2.cartItems);
      let justification = ERAsset.justification;
      let Location = ERAsset.Location;
      let requeststartDate = moment().startOf("day");
      let requestendDate = moment()
        .add(1, "day")
        .startOf("day")
        .add(1, "day")
        .startOf("day");
      const totalloancost = this.totalLoanCost();

      this.props.form.setFieldsValue({
        requeststartDate,
        requestendDate,
        requestorname,
        requestoremailAddress,
        totalloancost,
        requestormobile,
        justification,
        Location
      });
      this.setState({ requestorname, requestoremailAddress, totalloancost, justification, Location, requestormobile });
    } else {
      let requestorname =
        loanPoolStoreV2.selectedRowForDuplicateRequest[0].RequestorName;
      let requestoremailAddress =
        loanPoolStoreV2.selectedRowForDuplicateRequest[0].RequestorEmail;
      let totalloancost =
        loanPoolStoreV2.selectedRowForDuplicateRequest[0].TotalLoanCost;
      let requestormobile =
        loanPoolStoreV2.selectedRowForDuplicateRequest[0].PhoneNumber;
      let chargecode =
        loanPoolStoreV2.selectedRowForDuplicateRequest[0].RequestorName;
      let Location = loanPoolStoreV2.selectedRowForDuplicateRequest[0].Location;
      let justification =
        loanPoolStoreV2.selectedRowForDuplicateRequest[0].Justification;
      this.setState({
        requestorname: requestorname,
        requestoremailAddress: requestoremailAddress,
        totalloancost: totalloancost,
        requestormobile: requestormobile,
        chargecode: chargecode,
        Location: Location,
        justification: justification
      });
      this.props.form.setFieldsValue({
        requestorname,
        requestoremailAddress,
        totalloancost,
        requestormobile,
        chargecode,
        Location,
        justification
      });
    }
  }

  handleClear = () => {
    this.props.form.resetFields();
    this.resetForm();
  };
  resetForm = () => {
    const { requestorname, requestoremailAddress, totalloancost, justification, Location, requestormobile } = this.state;
    const { chargecode } = "";
    this.props.form.setFieldsValue({
      requestorname,
      requestoremailAddress,
      totalloancost,
      requestormobile,
      chargecode,
      Location,
      justification
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    //check if cart is empty or not
    if (loanPoolStoreV2.getDataFromDuplicate) {
      if (loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets.length < 1) {
        return UIFunctions.Toast(
          "Please add some items to duplicate request",
          "warn"
        );
      }
    } else {
      if (loanPoolStoreV2.cartItems.length == 0) {
        return UIFunctions.Toast("Please add some items to the cart", "warn");
      }
    }
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        this.setState({ loading: true });
        loanPoolStoreV2.setIsNewRequestLoading(true);
        //extracting values without email and name using es2018 destrcturing; avoid the eslint email id, name error
        var requestDate = moment()
          .startOf("day")
          .toISOString();
        if (!loanPoolStoreV2.getDataFromDuplicate) {
          const {
            // eslint-disable-next-line
            requestoremailAddress, // eslint-disable-next-line
            requestorname, // eslint-disable-next-line
            totalloancost,
            ...newRequestFormData
          } = values;
          loanPoolStoreV2.setNewRequestFormDetails(newRequestFormData);

          const {
            requestormobile,
            Location,
            justification
          } = loanPoolStoreV2.newRequestFormDetails;
          let { chargecode } = loanPoolStoreV2.newRequestFormDetails;
          const ERAssets = [];

          const Assets = [];
          loanPoolStoreV2.cartItems.filter(i => {
            if (i.HasExternalRequest == false) {
              const { RequestedStartDate, RequestedEndDate } = i;
              Assets.push({
                asset: i.UniqueID,
                startDate: RequestedStartDate,
                endDate: RequestedEndDate
              });
            } else {
              const { RequestedStartDate, RequestedEndDate } = i;
              ERAssets.push({
                Manufacturer: i.Manufacturer,
                ModelNo: i.ModelNo,
                Description: i.Description == undefined ? "" : i.Description,
                startDate: RequestedStartDate,
                endDate: RequestedEndDate,
                JustificationER:
                  i.JustificationER == undefined ? "" : i.JustificationER,
                NotesER: i.NotesER == undefined ? "" : i.NotesER,
                LocationER: i.Location == undefined ? "" : i.Location,
                HasExternalRequest: i.HasExternalRequest,
                ContactER: i.ContactER
              });
            }
          });

          /* eslint-disable  */
          chargecode = chargecode == undefined ? "" : chargecode;
          let CustomerId =
            userStore.CustomerId == undefined ? "" : userStore.CustomerId;
          Functions.CreateNewLoanPoolRequest(
            userStore.CustomerId,
            justification,
            Location,
            chargecode,
            requestormobile,
            Assets,
            ERAssets,
            requestDate
          )
            .then(resp => {
              if (resp.data.success) {
                UIFunctions.Toast(
                  "Loan Request Submitted Successfully!",
                  "success"
                );
                loanPoolStoreV2.setDoNotUpdateLPRequests(false)
                loanPoolStoreV2.doNotUpdate = false;
                loanPoolStoreV2.setLpborrowableSelectedRows([]);
                loanPoolStoreV2.caCheckboxedItems = [];
                Functions.BadgeCounterForApprover().then(response => {
                  tabModelStore.loanPoolNotificationCount =
                    response.data.notificationCount;
                });
                loanPoolStoreV2.clearCart().then(() => {
                  this.setState({ LPrequestSuccess: true });
                  loanPoolStoreV2.setIsNewRequestLoading(false);
                });
              } else {
                UIFunctions.Toast("Loan Request Creation Failed!", "error");
                loanPoolStoreV2.setIsNewRequestLoading(false);
              }
            })
            .catch(() => {
              UIFunctions.Toast("Loan Request Creation Failed!", "error");
              loanPoolStoreV2.setIsNewRequestLoading(false);
            });
        } else {
          const {
            requestorname, // eslint-disable-next-line
            requestoremailAddress,
            requestormobile,
            chargecode,
            Location,
            justification
          } = values;
          let assetsArray = [];
          const ERAssets = [];
          
          loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets.filter(i => {
          
          
            if (i.HasExternalRequest == false) {
              const { StartDate, EndDate } = i;
              assetsArray.push({
                asset: i.UniqueID,
                startDate:new Date(StartDate).toISOString(),
                endDate: new Date(EndDate).toISOString()
                
              }); 
            } else {
              const { StartDate, EndDate } = i;
              ERAssets.push({
                Manufacturer: i.Manufacturer,
                ModelNo: i.ModelNo,
                Description: i.Description == undefined ? "" : i.Description,
                startDate:new Date(StartDate).toISOString(),
                endDate: new Date(EndDate).toISOString(),
                JustificationER:
                  i.JustificationER == undefined ? "" : i.JustificationER,
                NotesER: i.NotesER == undefined ? "" : i.NotesER,
                LocationER: i.Location == undefined ? "" : i.Location,
                HasExternalRequest: i.HasExternalRequest,
                ContactER: i.ContactER
              });
               
            }
          });
           
          
          Functions.CreateNewLoanPoolRequest(
            requestorname,
            justification,
            Location,
            chargecode,
            requestormobile,
            assetsArray,
            ERAssets,
            requestDate
          )
            .then(resp => {
              if (resp.data.success) {
                UIFunctions.Toast(
                  "Loan Request Submitted Successfully!",
                  "success"
                );
                loanPoolStoreV2.setDoNotUpdateLPRequests(false)
                loanPoolStoreV2.doNotUpdate = false;
                Functions.BadgeCounterForApprover().then(response => {
                  tabModelStore.loanPoolNotificationCount =
                    response.data.notificationCount;
                });
                loanPoolStoreV2.setIsNewRequestLoading(false);
                loanPoolStoreV2.getDataFromDuplicate = false;
                loanPoolStoreV2.selectedRowForDuplicateRequest = [];
                loanPoolStoreV2.setLpborrowableSelectedRows([]);
                loanPoolStoreV2.caCheckboxedItems = [];
                this.setState({ LPrequestSuccess: true });
              } else {
                UIFunctions.Toast("Loan Request Creation Failed!", "error");
                loanPoolStoreV2.setIsNewRequestLoading(false);
              }
            })
            .catch(() => {
              UIFunctions.Toast("Loan Request Creation Failed!", "error");
              loanPoolStoreV2.setIsNewRequestLoading(false);
            });
        }
      }
    });
  };
  render() {
    const contentStyles = {
      height: "100%",
      overflow: "auto",
      padding: "25px 39px 50px 30px",
      color: " #646C72",
      fontFamily: "Open Sans",
      fontSize: 13,
      letterSpacing: 0.65,
      lineHeight: 18,
      backgroundColor: "#fff"
    };
    const {loading}=this.state
    const { getFieldDecorator } = this.props.form;
    const LPrequestSuccess = this.state.LPrequestSuccess;
    let totalLoanCost = loanPoolStoreV2.isDailyLoanCost
      ? this.totalLoanCost()
      : "";
    return LPrequestSuccess ? (
      <Redirect to="/loan-pool-notifications" />
    ) : (
      <div
        className="lp-grid-wrapper"
        style={{
          padding: 15,
          height: "100%"
        }}
      >
        <h4 style={styleSheets.bottomGridHeaderText}>New Request Form</h4>
        <div className="external-modal" style={contentStyles}>
          <Form
            style={{ width: "100%" }}
            className="request-ant-form-wrapper"
            onSubmit={this.handleSubmit.bind(this)}
          >
            <Row gutter={16}>
              <Col span={6}>
                <FormItem label="Requestor Name" {...formItemLayout}>
                  {getFieldDecorator("requestorname", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the requestor name"
                      }
                    ]
                  })(
                    <Input
                      disabled
                      style={{
                        maxwidth: "322px",
                        height: "29px",
                        opacity: 0.6,
                        fontSize: "14px",
                        letterSpacing: "0.7px"
                      }}
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Requestor Email Address">
                  {getFieldDecorator("requestoremailAddress", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the requestor email address"
                      }
                    ]
                  })(
                    <Input
                      disabled
                      style={{
                        fontSize: "14px",
                        letterSpacing: "0.7px",
                        maxwidth: "322px",
                        height: "29px",
                        opacity: 0.6
                      }}
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Requestor Contact Number">
                  {getFieldDecorator("requestormobile", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the requestor contact number"
                      }
                    ]
                  })(
                    <Input
                      style={{
                        fontSize: "14px",
                        letterSpacing: "0.7px",
                        maxwidth: "322px",
                        height: "29px"
                      }}
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Charge Code">
                  {getFieldDecorator("chargecode")(
                    <Input
                      style={{
                        fontSize: "14px",
                        letterSpacing: "0.7px",
                        maxwidth: "322px",
                        height: "29px"
                      }}
                    />
                  )}
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  /*className="requestor-label"*/
                  label="Loaned Assets Location"
                >
                  {getFieldDecorator("Location", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the location"
                      }
                    ]
                  })(
                    <Input
                      style={{
                        fontSize: "14px",
                        letterSpacing: "0.7px",
                        maxwidth: "322px",
                        height: "29px"
                      }}
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Total Loan Cost">
                  {/* {getFieldDecorator("totalloancost", {
                                      initialValue: this.totalLoanCost()
                                  })( */}
                  <Input
                    style={{
                      fontSize: "14px",
                      letterSpacing: "0.7px",
                      maxwidth: "185px",
                      height: "29px",
                      opacity: 0.6
                    }}
                    disabled
                    value={totalLoanCost}
                  />
                  {/* )} */}
                </FormItem>
                <FormItem {...formItemLayout} label="Justification">
                  {getFieldDecorator("justification", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the justification"
                      }
                    ]
                  })(
                    <TextArea
                      style={{
                        fontSize: "14px",
                        letterSpacing: "0.7px",
                        maxwidth: "573px",
                        height: "208px"
                      }}
                      autosize={{ minRows: 11, maxRows: 11 }}
                    />
                  )}
                </FormItem>
              </Col>
              <Col
                span={6}
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <FormItem>
                  <span
                    style={{
                      display: "flex",
                      justifyContent: "right",
                      marginTop: "368px"
                    }}
                  >
                    <Button
                      className="equipment-btn equipment-clear-btn"
                      icon="close"
                      onClick={this.handleClear}
                    >
                      Clear
                    </Button>
                    <Button
                    loading={loading}
                      className="equipment-btn equipment-save-btn"
                      htmlType="submit"
                    >
                      Submit
                    </Button>
                  </span>
                </FormItem>
              </Col>
            </Row>
          </Form>
        </div>
      </div>
    );
  }
}

const NewRequestForm = Form.create()(AddFormNewRequest);
export default NewRequestForm;
const styleSheets = {
  bottomGridHeaderText: {
    color: "#646C72",
    fontFamily: "Open Sans",
    fontSize: 14,
    letterSpacing: 0.51,
    lineHeight: "19px",
    marginBottom: 9
  }
};
