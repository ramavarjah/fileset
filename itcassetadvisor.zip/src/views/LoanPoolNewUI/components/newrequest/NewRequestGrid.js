import React, { Component } from "react";
import { Table, Button, Tooltip, DatePicker } from "antd";
import mobx from "mobx";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import noDataImage from "../../../../../public/img/no-data-placeholder_standard.png";
import moment from "moment";
import { observer } from "mobx-react";
import AssetCard from "src/views/Components/Cards/AssetCard";
import UIFunctions from "src/helpers/UIFunctions";
const RangePicker = DatePicker.RangePicker;
import { Redirect } from "react-router-dom";
@observer
class NewRequestGrid extends Component {
  constructor(props) {
    super(props);
    this.state = {
      removeCartLoading: false,
      iconClickedData: {},
      duplicateItems: [],
      goToLandingPage: false
    };
    this.columnDefs = [
      {
        title: "",
        dataIndex: "",
        width: 220,
        render: params => (
          <AssetCard
            modelNo={params.ModelNo}
            dummyUrl="/img/no-asset-image.png"
            alt="keysightAssetImage"
            width={params.HasExternalRequest ? "200px" : "146px"}
            height="146px"
            hasExternalRequest={params.HasExternalRequest}
          />
        )
      },
      {
        title: "MODEL NUMBER",
        dataIndex: "ModelNo",
        render: text => (
          <Tooltip title={text}>
            <span>{text}</span>
          </Tooltip>
        )
      },
      {
        title: "LOCATION",
        dataIndex: "Location",
        render: text => (
          <Tooltip title={text}>
            <span>{text}</span>
          </Tooltip>
        )
      },
      {
        title: "EQUIPMENT NUMBER",
        dataIndex: "EquipmentNo",
        width: 170,
        render: text => (
          <Tooltip title={text}>
            <span>{text}</span>
          </Tooltip>
        )
      },
      {
        title: "MANUFACTURER",
        dataIndex: "Manufacturer",
        render: text => (
          <Tooltip title={text}>
            <span>{text}</span>
          </Tooltip>
        )
      },
      {
        title: "COORDINATOR",
        dataIndex: "Coordinator",
        render: text => (
          <Tooltip title={text}>
            <span>{text}</span>
          </Tooltip>
        )
      },
      {
        title: "REQUESTED DATE RANGE",
        dataIndex: "RequestDateRange",
        width: 220,
        render: (text, record) => (
          <Tooltip
            title={`${moment(
              loanPoolStoreV2.getDataFromDuplicate
                ? record.StartDate
                : record.RequestedStartDate
            ).format("YYYY-MM-DD")}-${moment(
              loanPoolStoreV2.getDataFromDuplicate
                ? record.EndDate
                : record.RequestedEndDate
            ).format("YYYY-MM-DD")}`}
          >
            <span style={{ width: 250 }}>
              <RangePicker
                allowClear={false}
                onChange={e => this.onChange(e, record)}
                defaultValue={[
                  moment(
                    loanPoolStoreV2.getDataFromDuplicate
                      ? record.StartDate
                      : record.RequestedStartDate
                  ),
                  moment(
                    loanPoolStoreV2.getDataFromDuplicate
                      ? record.EndDate
                      : record.RequestedEndDate
                  )
                ]}
                disabledDate={this.disabledDate}
                style={{ width: "100%", cursor: "pointer" }}
              />
            </span>
          </Tooltip>
        )
      },
      {
        title: "",
        dataIndex: "",
        width: 150,
        render: record => (
          <span>
            <Tooltip title={"Delete"}>
              <Button
                shape="circle"
                icon="close-circle-o"
                className="delete-item-icon"
                disabled={this.state.removeCartLoading ? true : false}
                onClick={() => this.onDeleteItem(record)}
                loading={
                  this.state.removeCartLoading
                    ? record.UniqueID == this.state.iconClickedData.UniqueID
                      ? true
                      : false
                    : false
                }
              />
            </Tooltip>
          </span>
        )
      }
    ];
  }
  componentDidMount() {
    if (loanPoolStoreV2.getDataFromDuplicate) {
      let items = loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets;
      loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets = items;
      this.setState({ duplicateItems: items });
    }
  }

  onDeleteItem = item => {
    let self = this;
    if (!loanPoolStoreV2.getDataFromDuplicate) {
      if (loanPoolStoreV2.cartItems.length == 1) {
        UIFunctions.Confirm({
          zIndex: 2000,
          title:
            "Deleting this asset will cancel the current request and redirect you to the landing page.",
          okText: "OK",
          cancelText: "Cancel",
          onOk() {
            self.setState({ removeCartLoading: true, iconClickedData: item });
            loanPoolStoreV2.setIsDailyLoanCost(true);
            loanPoolStoreV2
              .removeFromCart(item)
              .then(() => self.setState({ removeCartLoading: false }))
              .catch(() => self.setState({ removeCartLoading: false }));
            loanPoolStoreV2.doNotUpdate = true;
            self.setState({ goToLandingPage: true });
          },
          onCancel() {}
        });
      } else {
        this.setState({ removeCartLoading: true, iconClickedData: item });
        loanPoolStoreV2.setIsDailyLoanCost(true);
        loanPoolStoreV2
          .removeFromCart(item)
          .then(() => this.setState({ removeCartLoading: false }))
          .catch(() => this.setState({ removeCartLoading: false }));
      }
    } else {
      if (this.state.duplicateItems.length == 1) {
        UIFunctions.Confirm({
          zIndex: 2000,
          title:
            "Deleting this asset will cancel the current request and redirect you to the landing page.",
          okText: "OK",
          cancelText: "Cancel",
          onOk() {
            self.setState({ removeCartLoading: true, iconClickedData: item });
            let temp = self.state.duplicateItems.filter(function(obj) {
              return obj.EquipmentNo !== item.EquipmentNo;
            });
            self.setState({ duplicateItems: temp });
            setTimeout(2000);
            loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets = temp;
            self.setState({ removeCartLoading: false });
            loanPoolStoreV2.doNotUpdate = true;
            self.setState({ goToLandingPage: true });
          }
        });
      } else {
        this.setState({ removeCartLoading: true, iconClickedData: item });
        let temp = this.state.duplicateItems.filter(function(obj) {
          return obj.EquipmentNo !== item.EquipmentNo;
        });
        this.setState({ duplicateItems: temp });
        setTimeout(2000);
        loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets = temp;
        this.setState({ removeCartLoading: false });
      }
    }
  };
  disabledDate = current => {
    return (
      current &&
      current <=
        moment()
          .endOf("day")
          .subtract(1, "day")
    );
  };
  onChange = (val, data) => {
    if (loanPoolStoreV2.getDataFromDuplicate) {
      this.state.duplicateItems.map(i => {
        if (data.UniqueID == i.UniqueID) {
          (i.StartDate = val[0].toISOString()),
            (i.EndDate = val[1].toISOString());
        }
      });
      loanPoolStoreV2.selectedRowForDuplicateRequest[0].assets.map(i => {
        if (data.UniqueID == i.UniqueID) {
          (i.StartDate = val[0].toISOString()),
            (i.EndDate = val[1].toISOString());
        }
      });
    } else {
      loanPoolStoreV2.cartItems.map(i => {
        if (data.UniqueID == i.UniqueID) {
          (i.RequestedStartDate = val[0].toISOString()),
            (i.RequestedEndDate = val[1].toISOString());
        }
      });
    }
  };
  render() {
    const cartItem = mobx.toJS(loanPoolStoreV2.cartItems);
    const duplicatItems = this.state.duplicateItems;
    const goToLandingPage = this.state.goToLandingPage;
    return goToLandingPage ? (
      <Redirect to="/loan-pool-notifications" />
    ) : (
      <div
        className="lp-grid-wrapper"
        style={{
          padding: 15,
          height: "100%"
        }}
      >
        <div className="rowLPRequestModel">
          <span className="selected-custom-badge">
            {loanPoolStoreV2.getDataFromDuplicate
              ? duplicatItems.length
              : loanPoolStoreV2.cartItems.length}
          </span>
          <h4 style={styleSheets.bottomGridHeaderText}>Selected Assets</h4>
        </div>
        <section className="lpSelectAssets newRequestGrid ">
          <Table
            dataSource={
              loanPoolStoreV2.getDataFromDuplicate
                ? duplicatItems.map(e => e)
                : cartItem.reverse().map(e => e)
            }
            columns={this.columnDefs}
            pagination={false}
            scroll={{ y: true }}
            locale={{
              emptyText: (
                <div>
                  <img src={noDataImage} />
                </div>
              )
            }}
          />
        </section>
      </div>
    );
  }
}
export default NewRequestGrid;
const styleSheets = {
  bottomGridHeaderText: {
    color: "#646C72",
    fontFamily: "Open Sans",
    fontSize: 14,
    letterSpacing: 0.51,
    lineHeight: "19px",
    marginBottom: 9
  },
  requestGridStyles: {
    minHeight: 338,
    fontSize: 13,
    fontWeight: "500",
    borderColor: "#f2f2f2",
    width: "calc(100vw -100)",
    border: "1px solid #E5E5E5"
  }
};
