import React, { Component } from "react";
import userStore from "../../../../stores/userStore";
import UIFunctions from "../../../../helpers/UIFunctions";
import Functions from "../../../../api/Functions";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import moment from "moment";
import mobx from "mobx";
import { Row, Col, Form, Input, DatePicker, Button, Spin } from "antd";

const FormItem = Form.Item;
const { TextArea } = Input;
const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 24 }
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 24 }
  }
};

class AddFormExternalRequest extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isButtonDisabled: false,
      name: "",
      emailAddress: "",
      mobile: "",
      loading: false,
      startValue: null,
      endValue: null,
      endOpen: false,
      startDate: moment().startOf("day"),
      returnDate: moment()
        .add(1, "day")
        .startOf("day")
    };
  }
  onChange = (field, value) => {
    this.setState({
      [field]: value
    });
  };
  disabledStartDate = current => {
    return (
      current &&
      current <=
        moment()
          .endOf("day")
          .subtract(1, "day")
    );
  };

  disabledEndDate = endValue => {
    const startValue = this.state.startDate;
    if (!endValue || !startValue) {
      return false;
    }
    return endValue.clone().endOf("day") <= startValue.valueOf();
  };
  onStartChange = value => {
    this.onChange("startDate", value);
    const endDate = this.props.form.getFieldValue("returnDate");
    if (value && moment(value) > moment(endDate)) {
      let returnDate = value;
      this.props.form.setFieldsValue({
        returnDate
      });
    }
  };

  onEndChange = value => {
    this.onChange("returnDate", value);
  };

  handleStartOpenChange = open => {
    if (!open) {
      this.setState({ endOpen: true });
    }
  };

  handleEndOpenChange = open => {
    this.setState({ endOpen: open });
  };
  componentDidMount() {
    //scroll starts here
    const element = document.getElementsByClassName("ant-modal-body");
    if (element) {
      element[0].scrollTop = element[0].scrollHeight - 655;
    }
    //scroll ends here
    const firstName = userStore.userDetails
      ? userStore.userDetails.firstName
      : "Invalid name";
    const lastName = userStore.userDetails
      ? userStore.userDetails.lastName
      : "";
    let emailAddress = userStore.userDetails
      ? userStore.userDetails.emailAddress
      : "Invalid email address";
    const mobile = userStore.userDetails ? userStore.userDetails.phoneNo : "";
    let name = "No Name";
    if (firstName || lastName) {
      name = firstName + " " + lastName;
    }
    if (!emailAddress) {
      emailAddress = "No emailAddress";
    }
    let startDate = moment().startOf("day");
    let returnDate = moment()
      .add(1, "day")
      .startOf("day")
      .add(1, "day")
      .startOf("day");
    this.props.form.setFieldsValue({
      startDate,
      returnDate,
      name,
      emailAddress,
      mobile
    });
    this.setState({ name, emailAddress, mobile });
  }
  handleCancel = () => {
    this.props.handleCancelButton();
  };
  resetForm = () => {
    const { name, emailAddress } = this.state;
    this.props.form.setFieldsValue({
      name,
      emailAddress
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        this.setState({
          loading: true,
          isButtonDisabled: true
        });
        //extracting values without email and name using es2018 destrcturing; avoid the eslint email id, name error
        // eslint-disable-next-line
        const { emailAddress, name, ...externalRequestFormData } = values;
        loanPoolStoreV2.setExternalRequestFormDetails(externalRequestFormData);
        const {
          startDate,
          returnDate,
          mobile,
          location,
          modelno,
          manufacturer,
          justification,
          description,
          notes
        } = mobx.toJS(loanPoolStoreV2.externalRequestFormDetails);
        let Requestor = loanPoolStoreV2.requestAwaitingModelOpen.RequestorEmail;
        let requestId = this.props.data;
        loanPoolStoreV2.setIsRequestModalLoading(true);
        Functions.AppendNewERToRequest(
          startDate.toISOString(),
          returnDate.toISOString(),
          requestId,
          modelno,
          Requestor,
          description == undefined ? "" : description,
          manufacturer,
          justification == undefined ? "" : justification,
          notes == undefined ? "" : notes,
          location == undefined ? "" : location,
          mobile
        )
          .then(response => {
            if (response.data.success) {
              UIFunctions.Toast(
                "Equipment request created successfully",
                "success"
              );
              loanPoolStoreV2.rerenderRequests().then(() => {
                loanPoolStoreV2.setDoNotUpdateLPRequests(false);
                this.setState({ loading: false });
                loanPoolStoreV2.setIsRequestModalLoading(false);
              });
            } else {
              UIFunctions.Toast(
                "Equipment request could not be created",
                "error"
              );
              loanPoolStoreV2.setIsRequestModalLoading(false);
            }

            this.props.handleCancelButton();
          })
          .catch(() => {
            this.setState({ loading: false });
            UIFunctions.Toast("Something did not work", "warn");
            loanPoolStoreV2.setIsRequestModalLoading(false);
          });
      }
    });
  };

  render() {
    const contentStyles = {
      maxHeight: 700,
      overflow: "auto",
      padding: "0px 50px 5px 50px",
      color: " #646C72",
      fontFamily: "Open Sans",
      fontSize: 13,
      letterSpacing: 0.65,
      lineHeight: 18
    };
    const { getFieldDecorator } = this.props.form;
    const { loading } = this.state;
    return (
      <div style={contentStyles} width="850px" className="external-modal">
        <Spin spinning={loading} delay={500}>
          <Form
            style={{ width: "100%" }}
            className="external-ant-form-wrapper"
            onSubmit={this.handleSubmit.bind(this)}
          >
            <Row gutter={16}>
              <Col span={10}>
                <FormItem label="Name" {...formItemLayout}>
                  {getFieldDecorator("name", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the name"
                      }
                    ]
                  })(<Input disabled style={{ opacity: 0.6 }} />)}
                </FormItem>
                <div className="equipment-date-grouping">
                  <FormItem {...formItemLayout} label="Start Date">
                    {getFieldDecorator("startDate", {
                      rules: [
                        {
                          required: true,
                          message: "Please enter start date"
                        }
                      ]
                    })(
                      <DatePicker
                        format="YYYY-MM-DD"
                        disabledDate={this.disabledStartDate}
                        onChange={this.onStartChange}
                        onOpenChange={this.handleStartOpenChange}
                      />
                    )}
                  </FormItem>
                  <FormItem {...formItemLayout} label="Return Date">
                    {getFieldDecorator("returnDate", {
                      rules: [
                        {
                          required: true,
                          message: "Please enter return date"
                        }
                      ]
                    })(
                      <DatePicker
                        format="YYYY-MM-DD"
                        disabledDate={this.disabledEndDate}
                        onChange={this.onEndChange}
                        onOpenChange={this.handleEndOpenChange}
                      />
                    )}
                  </FormItem>
                </div>
                <FormItem {...formItemLayout} label="Email Address">
                  {getFieldDecorator("emailAddress", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the email address"
                      }
                    ]
                  })(<Input disabled style={{ opacity: 0.6 }} />)}
                </FormItem>
                <FormItem {...formItemLayout} label="Contact Number">
                  {getFieldDecorator("mobile", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the contact number"
                      }
                    ]
                  })(<Input />)}
                </FormItem>
                <FormItem {...formItemLayout} label="Location">
                  {getFieldDecorator("location", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the location"
                      }
                    ]
                  })(<Input />)}
                </FormItem>
                <FormItem {...formItemLayout} label="Model No">
                  {getFieldDecorator("modelno", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the model number"
                      }
                    ]
                  })(<Input />)}
                </FormItem>
                <FormItem {...formItemLayout} label="Manufacturer">
                  {getFieldDecorator("manufacturer", {
                    rules: [
                      {
                        required: true,
                        message: "Please enter the manufacturer"
                      }
                    ]
                  })(<Input />)}
                </FormItem>
              </Col>
              <Col
                span={2}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                }}
              >
                <div className="equipment-request-form-divider" />
              </Col>
              <Col span={12}>
                <FormItem {...formItemLayout} label="Justification">
                  {getFieldDecorator("justification")(
                    <TextArea autosize={{ minRows: 7, maxRows: 7 }} />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Description">
                  {getFieldDecorator("description")(
                    <TextArea autosize={{ minRows: 7, maxRows: 7 }} />
                  )}
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="Notes/ Options/ Accessories"
                >
                  {getFieldDecorator("notes")(
                    <TextArea autosize={{ minRows: 6.5, maxRows: 6.5 }} />
                  )}
                </FormItem>
              </Col>
            </Row>
            <Row style={{ marginTop: 8 }}>
              <Col
                span={10}
                style={{
                  display: "flex",
                  justifyContent: "center",
                  marginLeft: 450
                }}
              >
                <FormItem>
                  <Button
                    className="equipment-btn equipment-clear-btn"
                    icon="close"
                    onClick={this.handleCancel}
                  >
                    <span style={{ marginLeft: 2 }}>Cancel</span>
                  </Button>
                  <Button
                    className="equipment-btn equipment-save-btn"
                    htmlType="submit"
                    disabled={this.state.isButtonDisabled}
                    onClick={this.handleSubmit}
                  >
                    Submit
                  </Button>
                </FormItem>
              </Col>
            </Row>
          </Form>
        </Spin>
      </div>
    );
  }
}

const AddExRequestToRequest = Form.create()(AddFormExternalRequest);
export default AddExRequestToRequest;
