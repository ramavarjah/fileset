import React, { Component } from "react";
import { Icon } from "antd";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";

export default class CustomHeader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            view: loanPoolStoreV2.reviewerMode
                ? loanPoolStoreV2.reviewerViewMode
                : loanPoolStoreV2.normalViewMode
        };
    }
    onMenuClicked() {
        loanPoolStoreV2.reviewerMode
            ? loanPoolStoreV2.reviewerViewMode == "REQUESTFULLSCREEN"
                ? loanPoolStoreV2.setReviewerViewMode("NORMAL")
                : loanPoolStoreV2.setReviewerViewMode("REQUESTFULLSCREEN")
            : loanPoolStoreV2.normalViewMode == "REQUESTFULLSCREEN"
                ? loanPoolStoreV2.setNormalViewMode(loanPoolStoreV2.initialNormalViewMode)
                : loanPoolStoreV2.setNormalViewMode("REQUESTFULLSCREEN");

        this.setState({
            view: loanPoolStoreV2.reviewerMode
                ? loanPoolStoreV2.reviewerViewMode
                : loanPoolStoreV2.normalViewMode
        });
    }
    render() {
        let type = this.state.view == "REQUESTFULLSCREEN" ? "shrink" : "arrows-alt";
        return (
            <a onClick={this.onMenuClicked.bind(this)}>
                <Icon type={type} style={{ color: "#646C72" }} theme="outlined" />
            </a>
        );
    }
}
