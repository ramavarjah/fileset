import React from "react";
import { Icon, DatePicker, Table } from "antd";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import Functions from "../../../../api/Functions";
import Autosuggest from "react-autosuggest";
import moment from "moment";
import { observer } from "mobx-react";
const { RangePicker } = DatePicker;
import noDataImage from "../../../../../public/img/no-data-placeholder_standard.png";
import _ from "lodash";
const renderSuggestion = suggestion => (
  <div
    style={{
      color: "white",
      zIndex: 10000000,
      backgroundColor: "grey",
      marginBottom: 1,
      borderBottomColor: "black"
    }}
  >
    {suggestion.searchStr}
  </div>
);
const getSuggestionValue = suggestion => suggestion.searchStr;

@observer
class AddItemToRequest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
      isRequestCartOpen: false,
      value: "",
      suggestions: [],
      searchOn: false,
      isExternalRequestModalOpen: false,
      loading: false
    };
    this.search = _.debounce(this.search.bind(this), 1000);
  }
  componentDidMount() {
    //scroll starts here
    const element = document.getElementsByClassName("ant-modal-body");
    if (element) {
      element[0].scrollTop = element[0].scrollHeight;
    }
    //scroll ends here
  }

  onChange = (event, { newValue }) => {
    this.setState({
      value: newValue
    });
  };
  onSearchclick() {
    this.setState({
      searchOn: true
    });
  }
  _handleKeyPress = e => {
    if (e.key === "Enter") {
      this.onSearchButton();
    }
  };

  onSearchButton() {
    loanPoolStoreV2.addToRequestStringSearch = true;
    var queryStringinput = this.state.value;
    if (queryStringinput.length >= 2) {
      loanPoolStoreV2.addToRequestPaginationLoader = false;
      Functions.GetLoanableAssetsDataForGlobalSearch({
        InputJson: {
          StartDate: loanPoolStoreV2.startDateForAddToRequest,
          EndDate: loanPoolStoreV2.endDateForAddToRequest,
          AvailabilityThreshold: "",
          queryString: queryStringinput,
          Context: "AddtoRequest",
          pageNumber: loanPoolStoreV2.addToRequestPagination.pageNumber,
          pageSize: loanPoolStoreV2.addToRequestPagination.pageSize
        }
      })
        .then(resp => {
          loanPoolStoreV2.borrowableAssetsforAddToRequest = [];
          loanPoolStoreV2.borrowableAssetsforAddToRequest =
            resp.data.gridData.data;
          loanPoolStoreV2.addToRequestPagination["total"] = resp.data.total;
          loanPoolStoreV2.addToRequestPaginationLoader = true;
        })
        .catch(() => {
          loanPoolStoreV2.addToRequestPaginationLoader = true;
        });
    }
  }

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  search(value) {
    this.setState({ loading: true });
    if (value.value.length >= 2) {
      Functions.GetSolrSearchResult(value.value, "LoanPool")
        .then(resp => {
          this.setState({ loading: false });
          var srcStr = value.value;
          var response = resp.data.response;
          var data = [];
          if (response && response.numFound > 0) {
            var docs = response.docs;
            var len = docs.length;
            var regEx = new RegExp(srcStr, "i");
            var exist;
            var test = {};
            var displayNames = JSON.parse(
              JSON.stringify(loanPoolStoreV2.gridDataModel)
            );

            for (var j = 0; j < displayNames.length; j++) {
              test[displayNames[j].key] = displayNames[j].name;
            }

            for (var i = 0; i < len; i++) {
              for (var key in docs[i]) {
                if (typeof docs[i][key] != "string") {
                  docs[i][key] = "" + docs[i][key];
                }
                if (
                  typeof docs[i][key] === "string" &&
                  docs[i][key].search(regEx) >= 0
                ) {
                  exist = false;

                  for (var index = 0; index < data.length; index++) {
                    var item = data[index];

                    if (
                      item.colName === key &&
                      item.searchValue === docs[i][key]
                    ) {
                      exist = true;
                    }
                  }

                  if (!exist) {
                    if (key !== "UniqueID") {
                      data.push({
                        colName: key,
                        searchValue: docs[i][key],
                        searchStr: docs[i][key] + " in " + test[key]
                      });
                    }
                  }
                }
              }
            }
            this.setState({ suggestions: data });
          }
          this.setState({ suggestions: data });
        })
        .catch(() => this.setState({ loading: false }));
    } else {
      this.setState({ loading: false });
    }
  }

  onSuggestionSelected = (event, { suggestion }) => {
    loanPoolStoreV2.addToRequestStringSearch = false;
    loanPoolStoreV2.borrowableAssetsforAddToRequest = [];
    loanPoolStoreV2.addToRequestPagination.total = 0;
    loanPoolStoreV2.addToRequestPagination.pageNumber = 1;
    loanPoolStoreV2.addToRequestPaginationLoader = true;
    var selectedSuggestion = {};
    selectedSuggestion[suggestion.colName] = suggestion.searchValue;
    loanPoolStoreV2.loanableAssetsDirectSearchForAddToRequest(
      selectedSuggestion
    );
  };
  onRangeChange = data => {
    loanPoolStoreV2.startDateForAddToRequest = data[0].toISOString();
    loanPoolStoreV2.endDateForAddToRequest = data[1].toISOString();
    if (loanPoolStoreV2.borrowableAssetsforAddToRequest != null) {
      if (loanPoolStoreV2.addToRequestStringSearch) {
        this.onSearchButton();
      } else {
        loanPoolStoreV2.rerenderAddToRequest();
      }
    }
  };
  handleTableChange = pagination => {
    const pager = { ...loanPoolStoreV2.addToRequestPagination };
    pager.pageNumber = pagination.current;
    loanPoolStoreV2.addToRequestPagination = pager;
    if (loanPoolStoreV2.addToRequestStringSearch) {
      this.onSearchButton();
    } else {
      loanPoolStoreV2.rerenderAddToRequest();
    }
  };

  render() {
    const { value, suggestions } = this.state;
    const columns = loanPoolStoreV2.borrowableAssetsHeaderForAddToRequest;
    const inputProps = {
      placeholder: "Search to add item...",
      value,
      onChange: this.onChange
    };
    const searchstyle = {
      backgroundColor: value ? " #3385FF" : "#EEEEEE",
      color: value ? "#FFFFFF" : "#646C72"
    };
    const { loading } = this.state;
    return (
      <div className="add-item-to-request">
        <div className="header-same-class">
          <div
            className="header-common-class header-same-class header-search-wrapper "
            onClick={this.onSearchclick.bind(this)}
            onKeyPress={this._handleKeyPress}
          >
            <Autosuggest
              id="asset-quick-search"
              suggestions={suggestions}
              onSuggestionsFetchRequested={this.search.bind(this)}
              onSuggestionsClearRequested={this.onSuggestionsClearRequested}
              getSuggestionValue={getSuggestionValue}
              renderSuggestion={renderSuggestion}
              onSuggestionSelected={this.onSuggestionSelected}
              inputProps={inputProps}
            />
            <div className="header-searchbox-icon" style={searchstyle}>
              <Icon
                type={loading ? "loading" : "search"}
                style={{ color: "inherit" }}
                onClick={this.onSearchButton.bind(this)}
              />
            </div>
          </div>
         <div className = "calendar-picker-clear">
          
            <RangePicker
              onChange={this.onRangeChange}
              style={{ width: 200, marginLeft: -330 }}
              defaultValue={[
                moment(loanPoolStoreV2.startDateForAddToRequest),
                moment(loanPoolStoreV2.endDateForAddToRequest)
              ]}
            />
          </div>
        </div>
        <br />
        <div className="add-to-request-table">
          {loanPoolStoreV2.borrowableAssetsforAddToRequest.length > 0 ||
          !loanPoolStoreV2.addToRequestPaginationLoader ? (
            <Table
              dataSource={loanPoolStoreV2.borrowableAssetsforAddToRequest}
              columns={columns}
              scroll={{ y: true }}
              pagination={loanPoolStoreV2.addToRequestPagination}
              loading={!loanPoolStoreV2.addToRequestPaginationLoader}
              onChange={this.handleTableChange}
              style={{ width: 800, height: 410, marginLeft: -112 }}
            />
          ) : (
            <div style={{ width: 800, height: 279, marginLeft: -112 }}>
              <div style={{ width: 167, marginLeft: 320, marginTop: 120 }}>
                <img height=" 146px" width="167px" src={noDataImage} />
                <p>No Search Results</p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default AddItemToRequest;
