import React from "react";
import { Modal } from "antd";
import { Row, Col, Button, Icon, Spin, Tooltip } from "antd";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import * as mobx from "mobx";
import moment from "moment";
import UIFunctions from "../../../../helpers/UIFunctions";
import { observer } from "mobx-react";
import PropTypes from "prop-types";
import AddItemToRequest from "../../components/requestgrid/AddItemToRequest";
import AddExRequestToRequest from "./AddExRequestToRequest";
import AssetCard from "src/views/Components/Cards/AssetCard";
@observer
class LoanPoolRequestModalView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      approvalLoading: false,
      disapproveLoading: false,
      iconClickedData: {},
      externalRequest: true,
      addItem: true,
      cancelMode: false
    };
  }
  handleDecline = () => {
    this.setState({ addItem: true });
    this.setState({ externalRequest: true });
    this.setState({ cancelMode: false });
    loanPoolStoreV2.addItemToRequest = false;
    loanPoolStoreV2.addExternalRequestToRequest = false;
    loanPoolStoreV2.borrowableAssetsforAddToRequest = [];
    loanPoolStoreV2.addToRequestPagination.total = 0;
    loanPoolStoreV2.addToRequestPagination.pageNumber = 1;
    loanPoolStoreV2.addToRequestPaginationLoader = true;
    this.props.handleDecline();
  };
  componentWillUnmount() {
    loanPoolStoreV2.addItemToRequest = false;
    loanPoolStoreV2.addExternalRequestToRequest = false;
    loanPoolStoreV2.borrowableAssetsforAddToRequest = [];
    loanPoolStoreV2.addToRequestPagination.total = 0;
    loanPoolStoreV2.addToRequestPagination.pageNumber = 1;
    loanPoolStoreV2.addToRequestPaginationLoader = true;
  }
  approveLoanRequest = record => {
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to approve the request?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({ approvalLoading: true, iconClickedData: record });
        loanPoolStoreV2
          .approveLoanRequest(record)
          .then(() => {
            setTimeout(() => self.setState({ approvalLoading: false }), 5000);
          })
          .catch(() => self.setState({ approvalLoading: false }));
      },
      onCancel() {}
    });
  };
  disapproveLoanRequest = record => {
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to reject the request?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({ disapproveLoading: true, iconClickedData: record });
        loanPoolStoreV2
          .disapproveLoanRequest(record)
          .then(() =>
            setTimeout(() => self.setState({ disapproveLoading: false }), 5000)
          )
          .catch(() => self.setState({ disapproveLoading: false }));
      },

      onCancel() {}
    });
  };
  handleAdd = () => {
    loanPoolStoreV2.addItemToRequest = true;
    this.setState({ addItem: false });
    this.setState({ externalRequest: false });
    this.setState({ cancelMode: true });
  };
  handleAddExternal = () => {
    loanPoolStoreV2.addExternalRequestToRequest = true;
    this.setState({ addItem: false });
    this.setState({ externalRequest: false });
    this.setState({ cancelMode: false });
  };
  handleCancelButton = () => {
    this.setState({ addItem: true });
    this.setState({ externalRequest: true });
    this.setState({ cancelMode: false });
    loanPoolStoreV2.addItemToRequest = false;
    loanPoolStoreV2.addExternalRequestToRequest = false;
    loanPoolStoreV2.borrowableAssetsforAddToRequest = [];
    loanPoolStoreV2.addToRequestPagination.total = 0;
    loanPoolStoreV2.addToRequestPagination.pageNumber = 1;
    loanPoolStoreV2.addToRequestPaginationLoader = true;
  };
  getAllAsset = () => {
    const data = mobx.toJS(this.props.modalRequestData.assets);
    if (data && data.length > 0) {
      return data.map((item, index) =>
        item.Coordinator != item.Requestor || item.type == "Submitted To Me" ? (
          <div key={index}>
            <hr style={{ borderColor: "#C3C3C3", marginBottom: 25 }} />
            <Row gutter={16}>
              <Col xs={24} sm={8} md={10} lg={10} xl={10}>
                <div
                  className="request-modal-asset-details"
                  style={{
                    // marginLeft: 18,
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center"
                  }}
                >
                  <AssetCard
                    modelNo={item.ModelNo}
                    dummyUrl="/img/no-asset-image.png"
                    alt="keysightAssetImage"
                    width={item.HasExternalRequest ? "200px" : "146px"}
                    height="146px"
                    hasExternalRequest={item.HasExternalRequest}
                  />
                </div>
              </Col>

              <Col xs={24} sm={16} md={10} lg={10} xl={10}>
                <Row gutter={24}>
                  {item.HasExternalRequest ? (
                    <div className="request-modal-asset-details request-results">
                      <h4
                        className="request-results"
                        style={{ color: "#3385FF", fontWeight: "700" }}
                      >
                        Model No: {item.ModelNo}
                      </h4>
                      <h4 className="request-results">
                        Manufacturer: {item.Manufacturer}
                      </h4>

                      <h4 className="request-results">
                        Description: {item.Description}
                      </h4>

                      <h4 className="request-results">
                        Requested Location: {item.LocationER}
                      </h4>
                      <h4 className="request-results">
                        Contact Number: {item.ContactER}
                      </h4>

                      <h4 className="request-results-justification">
                        Justification:
                        <Tooltip
                          title={item.JustificationER}
                          placement="topLeft"
                        >
                          {item.JustificationER}
                        </Tooltip>
                      </h4>
                      <h4 className="request-results-justification">
                        Notes/Options/Accessories:
                        <Tooltip title={item.NotesER} placement="topLeft">
                          {item.NotesER}
                        </Tooltip>
                      </h4>

                      <h4 className="request-results">
                        Requested Date Range:{" "}
                        {moment(item.StartDate).format("YYYY-MM-DD")} -{" "}
                        {moment(item.EndDate).format("YYYY-MM-DD")}
                      </h4>
                    </div>
                  ) : (
                    <div className="request-modal-asset-details request-results">
                      <h4
                        className="request-results"
                        style={{ color: "#3385FF", fontWeight: "700" }}
                      >
                        Model No: {item.ModelNo ? item.ModelNo : ""}
                      </h4>
                      <h4 className="request-results">
                        Equipment Number:{" "}
                        {item.EquipmentNo ? item.EquipmentNo : ""}
                      </h4>
                      <h4 className="request-results">
                        Manufacturer:{" "}
                        {item.Manufacturer ? item.Manufacturer : ""}
                      </h4>
                      <h4 className="request-results">
                        Serial Number: {item.SerialNo ? item.SerialNo : ""}
                      </h4>
                      <h4 className="request-results">
                        Description: {item.Description ? item.Description : ""}
                      </h4>
                      <h4 className="request-results">
                        Coordinator: {item.Coordinator ? item.Coordinator : ""}
                      </h4>
                      <h4 className="request-results">
                        Requested Date Range:{" "}
                        {moment(item.StartDate).format("YYYY-MM-DD")} -{" "}
                        {moment(item.EndDate).format("YYYY-MM-DD")}
                      </h4>
                    </div>
                  )}
                </Row>
              </Col>
              <Col xs={24} sm={6} md={4} lg={4} xl={4}>
                <div className="request-modal-asset-details">
                  {this.props.showApprovalButtons ? (
                    <div style={{ position: "relative", top: 50 }}>
                      {item.status === "Approved" ||
                      item.status == "Rejected" ||
                      item.status == "Cancelled" ? (
                        <span
                          style={{
                            color:
                              item.status === "Approved" ? "#3ABF72" : "#FF3E39"
                          }}
                        >
                          {item.status}
                        </span>
                      ) : (
                        <span style={{ display: "inline-block" }}>
                          <Button
                            shape="circle"
                            icon="close-circle-o"
                            className="iconStyle"
                            style={{
                              marginRight: 24,
                              color: "#FF3E39",
                              fontSize: 27,
                              border: "none",
                              width: 17,
                              height: 17
                            }}
                            loading={
                              this.state.disapproveLoading
                                ? item.workFlowId ==
                                  this.state.iconClickedData.workFlowId
                                  ? true
                                  : false
                                : false
                            }
                            disabled={
                              this.state.approvalLoading ||
                              this.state.disapproveLoading
                                ? true
                                : false
                            }
                            onClick={() => this.disapproveLoanRequest(item)}
                          />
                          <Button
                            shape="circle"
                            icon="check-circle-o"
                            className="iconStyle"
                            style={{
                              color: "#3ABF72",
                              border: "none",
                              marginRight: 24,
                              fontSize: 27,
                              width: 17,
                              height: 17
                            }}
                            loading={
                              this.state.approvalLoading
                                ? item.workFlowId ==
                                  this.state.iconClickedData.workFlowId
                                  ? true
                                  : false
                                : false
                            }
                            disabled={
                              this.state.disapproveLoading ||
                              this.state.approvalLoading
                                ? true
                                : false
                            }
                            onClick={() => this.approveLoanRequest(item)}
                          />
                        </span>
                      )}
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </Col>
            </Row>
          </div>
        ) : (
          ""
        )
      );
    }
  };

  render() {
    const { isRequestModalOpen, modalRequestData } = this.props;
    const modalTop = {
      top: (window.innerHeight - 520) / 2,
      padding: 0
    };
    const {
      RequestorEmail,
      requestId,
      requestDate,
      DisplayRequestId,
      Justification
    } = modalRequestData;
    const contentStyles = {
      color: "rgba(12,34,45)",
      fontWeight: "500",
      maxHeight: 500,
      overflow: "auto"
    };
    return (
      <div>
        <Modal
          title={`Request: ${DisplayRequestId}`}
          visible={isRequestModalOpen}
          onCancel={this.handleDecline.bind(this)}
          bodyStyle={contentStyles}
          footer={null}
          centered
          width="850px"
          style={modalTop}
          className="request-modal"
          maskClosable={false}
        >
          <Spin spinning={loanPoolStoreV2.isRequestModalLoading} delay={100}>
            <div id="LPRequestModel">
              <div className="rowLPRequestModel">
                <div className="divLPRequestModel1">
                  <h4 className="request-details">Requested By:</h4>
                  <div className="RequestorEmailLPR">{RequestorEmail}</div>
                  <h4 className="request-details-justification">
                    Justification:
                  </h4>
                  <div>
                    <Tooltip title={Justification} placement="topLeft">
                      {Justification}
                    </Tooltip>
                  </div>
                </div>
                <div className="divLPRequestModel2">
                  <h4 className="request-details">Date Created:</h4>
                  <div>{moment(requestDate).format("YYYY-MM-DD")}</div>
                </div>
              </div>
            </div>
            {/* this will get the asset details based on the asset available  */}
            {this.getAllAsset()}
          </Spin>
          <div className="plain-divider-horizontal" />
          <div className="add-requests">
            {this.state.addItem ? (
              <div className="addToRequest-buttons">
                <div>
                  <Button
                    size="medium"
                    type="primary"
                    style={{ marginLeft: "18px" }}
                    onClick={this.handleAdd.bind(this)}
                    className="addItem-to-request-button"
                  >
                    <Icon type="plus" />
                    Add Item
                  </Button>
                </div>
                <div className="plain-divider" />
              </div>
            ) : (
              ""
            )}
            {this.state.externalRequest ? (
              <div>
                <Button
                  size="medium"
                  type="primary"
                  style={{ marginLeft: "18px" }}
                  onClick={this.handleAddExternal.bind(this)}
                  className="addEx-to-request-button"
                >
                  <Icon type="plus" />
                  External Request
                </Button>
              </div>
            ) : (
              ""
            )}
            {this.state.cancelMode ? (
              <div className="addToRequest-buttons">
                <div>
                  <Button
                    size="medium"
                    type="primary"
                    style={{ marginLeft: "18px" }}
                    onClick={this.handleCancelButton.bind(this)}
                    className="cancel-to-request-button"
                  >
                    <Icon type="close" />
                    Cancel
                  </Button>
                </div>
                <div className="plain-divider" />
              </div>
            ) : (
              ""
            )}
            <div>
              {loanPoolStoreV2.addItemToRequest ? <AddItemToRequest /> : ""}
            </div>
          </div>
          <br />
          {loanPoolStoreV2.addExternalRequestToRequest ? (
            <div>
              <AddExRequestToRequest
                data={requestId}
                handleCancelButton={this.handleCancelButton}
              />
            </div>
          ) : (
            ""
          )}
          {loanPoolStoreV2.addItemToRequest ||
          loanPoolStoreV2.addExternalRequestToRequest ? (
            <div style={{ marginTop: -15 }}>
              <a
                href="#LPRequestModel"
                style={{ fontSize: 18, fontWeight: 900 }}
              >
                <Icon type="arrow-up" />
              </a>
            </div>
          ) : (
            ""
          )}
        </Modal>
      </div>
    );
  }
}

export default LoanPoolRequestModalView;
LoanPoolRequestModalView.propTypes = {
  isRequestModalOpen: PropTypes.object,
  modalRequestData: PropTypes.object,
  showApprovalButtons: PropTypes.bool,
  handleDecline: PropTypes.func
};
