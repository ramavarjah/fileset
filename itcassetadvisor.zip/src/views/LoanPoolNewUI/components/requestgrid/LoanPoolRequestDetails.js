import React from "react";
import { Table, Form, Select, Progress, Tooltip, Button } from "antd";
import RequestApprovalLogModal from "../requestapprovalloggrid/RequestApprovalLogModal";
import { observer } from "mobx-react";
import moment from "moment";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import CustomHeader from "./RequestDetailsCustomHeader";
import mobx from "mobx";
import UIFunctions from "src/helpers/UIFunctions";
const FormItem = Form.Item;
const Option = Select.Option;
import { createBrowserHistory } from "history";
const history = createBrowserHistory();
import { Redirect } from "react-router-dom";
import noDataImage from "../../../../../public/img/no-data-placeholder_standard.png";
const reqOptions = [
  { value: "Open", displayName: "Open Loans" },
  { value: "Approved", displayName: "Approved Loans" },
  { value: "Active", displayName: "Active Loans" },
  { value: "Closed", displayName: "Closed Loans" },
  // { value: "Requested", displayName: "External Loans" },
  { value: "Overdue", displayName: "Overdue Loans" },
  { value: "All", displayName: "All Loans" }
];
@observer
export default class LoanPoolRequestDetails extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      allLoanPoolRequestsNull: false,
      loading: false,
      requestStatus: "Open",
      authenticated: false,
      selectedRowKeys: [] // Check here to configure the default column
    };
    this.currentRowHeight = "45";
    this.columnDefs = [
      {
        title: "REQUEST NUMBER",
        dataIndex: "DisplayRequestId",
        width: 200,

        render: (text, record) => (
          <Tooltip title={record.DisplayRequestId}>
            <span>
              <a
                style={{ color: "#3385FF" }}
                href="#"
                onClick={() => this.onCellClicked(record)}
              >
                {record.DisplayRequestId}
              </a>
            </span>
          </Tooltip>
        )
      },
      {
        title: "REQUEST STATUS",
        dataIndex: "status",
        width: 200,
        render: function(params) {
          if (params == "Approved") {
            return (
              <div style={{ marginLeft: 4 }}>
                <Tooltip title={params}>
                  <span style={{ color: "#42DA81" }}>
                    <span
                      style={{
                        display: "inline-block",
                        height: 11,
                        width: 11,
                        backgroundColor: "#42DA81",
                        borderRadius: "50%"
                      }}
                    />
                    &nbsp;&nbsp;&nbsp;
                    {params}
                  </span>
                </Tooltip>
              </div>
            );
          } else if (params == "Active") {
            return (
              <div style={{ marginLeft: 4 }}>
                <Tooltip title={params}>
                  <span style={{ color: "#3385FF" }}>
                    <span
                      style={{
                        display: "inline-block",
                        height: 11,
                        width: 11,
                        backgroundColor: "#3385FF",
                        borderRadius: "50%"
                      }}
                    />
                    &nbsp;&nbsp;&nbsp;
                    {params}
                  </span>
                </Tooltip>
              </div>
            );
          } else if (params == "Overdue") {
            return (
              <div style={{ marginLeft: 4 }}>
                <Tooltip title={params}>
                  <span style={{ color: "#ff3e39" }}>
                    <span
                      style={{
                        display: "inline-block",
                        height: 11,
                        width: 11,
                        backgroundColor: "#ff3e39",
                        borderRadius: "50%"
                      }}
                    />
                    &nbsp;&nbsp;&nbsp;
                    {params}
                  </span>
                </Tooltip>
              </div>
            );
          } else if (params == "Open") {
            return (
              <div style={{ marginLeft: 4 }}>
                <Tooltip title={params}>
                  <span style={{ color: "#FFAE1C" }}>
                    <span
                      style={{
                        display: "inline-block",
                        height: 11,
                        width: 11,
                        backgroundColor: "#FFAE1C",
                        borderRadius: "50%"
                      }}
                    />
                    &nbsp;&nbsp;&nbsp;
                    {params}
                  </span>
                </Tooltip>
              </div>
            );
          } else {
            return (
              <div style={{ marginLeft: 4 }}>
                <Tooltip title={params}>
                  <span style={{ color: "#979797" }}>
                    <span
                      style={{
                        display: "inline-block",
                        height: 11,
                        width: 11,
                        backgroundColor: "#979797",
                        borderRadius: "50%"
                      }}
                    />
                    &nbsp;&nbsp;&nbsp;
                    {params}
                  </span>
                </Tooltip>
              </div>
            );
          }
        }
      },
      {
        title: "DATE CREATED",
        dataIndex: "requestDate",
        width: 180,
        defaultSortOrder: "descend",
        render: function(params) {
          return (
            <div style={{ marginLeft: 4 }}>
              <Tooltip title={moment(params).format("YYYY-MM-DD")}>
                {moment(params).format("YYYY-MM-DD")}
              </Tooltip>
            </div>
          );
        }
      },
      {
        title: "PROGRESS",
        dataIndex: "progress",
        width: 160,
        render: (text, record) => {
          if (record.status == "Closed") {
            ("");
          } else {
            let defaultValue = "";
            if (this.getPercent(record) == 0) {
              defaultValue = "Awaiting Approval";
            } else if (this.getPercent(record) == 25) {
              defaultValue = "Request Approved";
            } else if (this.getPercent(record) == 50) {
              defaultValue = "Asset Prepared";
            } else if (this.getPercent(record) == 75) {
              defaultValue = "Asset Delivered";
            } else {
              defaultValue = "Asset Received";
            }
            return (
              <Tooltip title={defaultValue}>
                <span
                  className="progressBar-requestdetail"
                  style={{ width: 150, color: "#3385FF" }}
                >
                  &nbsp;&nbsp;&nbsp;
                  <Progress percent={this.getPercent(record)} strokeWidth={5} />
                </span>
              </Tooltip>
            );
          }
        }
      }
      // {
      //   dataIndex: "",
      //   title: ""
      // }
    ];
  }
  onCellClicked(data) {
    loanPoolStoreV2.setIsRequestModelModalOpen(data);
  }
  onGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  };
  dateFormatter = params => {
    return moment(params.value).format("YYYY-MM-DD");
  };
  getRowHeight = () => {
    return parseInt(this.currentRowHeight);
  };

  // Request modal methods-starts here
  handleDecline = () => {
    loanPoolStoreV2.setIsRequestModelModalOpen(false);
  };
  // Request modal methods-Ends here

  // logic for dropdown request status
  handleRequestStatus(value) {
    this.setState({ selectedRowKeys: [] });
    this.setState({ requestStatus: value });
    loanPoolStoreV2.selectedRowForDuplicateRequest = [];
  }
  onSelectChange = (selectedRowKeys, selectedRows) => {
    this.setState({ selectedRowKeys });
    let tempRows = JSON.parse(JSON.stringify(selectedRows));
    loanPoolStoreV2.selectedRowForDuplicateRequest = tempRows;
  };
  test() {
    return;
  }
  onDuplicate = () => {
    let self = this;
    if (loanPoolStoreV2.selectedRowForDuplicateRequest.length == 0) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Please select any one Request!"
      });
    } else if (loanPoolStoreV2.selectedRowForDuplicateRequest.length == 1) {
      UIFunctions.Confirm({
        zIndex: 2000,
        title: "Are you sure you want to create Duplicate Request?",
        okText: "Yes",
        cancelText: "No",
        onOk() {
          self.setState({ authenticated: true });
          loanPoolStoreV2.getDataFromDuplicate = true;
          history.push("/loan-pool-notifications/loan-pool-new-request");
        },
        onCancel() {}
      });
    } else {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Please select only one Request!"
      });
    }
  };
  getPercent = data => {
    const status =
      data && data.ProgressStatus
        ? data.ProgressStatus
        : {
            assetReceived: "",
            awaitingApproval: "",
            deliveryingAsset: "",
            preparingAsset: ""
          };
    if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "" &&
      status.deliveryingAsset == "" &&
      status.assetReceived == ""
    ) {
      return 25;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "" &&
      status.assetReceived == ""
    ) {
      return 50;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "finish" &&
      status.assetReceived == ""
    ) {
      return 75;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "finish" &&
      status.assetReceived == "finish"
    ) {
      return 100;
    } else {
      return 0;
    }
  };

  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange
    };
    let allLoanPoolRequests = [];
    if (this.state.requestStatus == "Open")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests1.filter(
        i => i.status == "Open"
      );
    else if (this.state.requestStatus == "Approved")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests1.filter(
        i => i.status == "Approved"
      );
    else if (this.state.requestStatus == "Active")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests1.filter(
        i => i.status == "Active"
      );
    else if (this.state.requestStatus == "Closed")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests1.filter(
        i => i.status == "Closed"
      );
    else if (this.state.requestStatus == "Overdue")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests1.filter(
        i => i.status == "Overdue"
      );
    else if (this.state.requestStatus == "Requested")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests1.filter(
        i => i.HasExternalRequest == true
      );
    else {
      allLoanPoolRequests = mobx.toJS(loanPoolStoreV2.allLoanPoolRequests1);
    }

    var colDefs = this.columnDefs.map(i => i);
    if (allLoanPoolRequests.length == 0) {
      colDefs.push({
        dataIndex: "fullscreen",
        width: 50
      });
      loanPoolStoreV2.setShowIcon(false);
    } else {
      colDefs.push({
        dataIndex: "fullscreen",
        title: <CustomHeader />,
        width: 50
      });
      loanPoolStoreV2.setShowIcon(true);
    }
    const marginStyling = {
      marginTop: loanPoolStoreV2.normalViewMode == "REQUESTFULLSCREEN" ? 25 : 0
    };
    const requestGridStyles = {
      height:
        loanPoolStoreV2.normalViewMode == "REQUESTFULLSCREEN"
          ? window.innerHeight - 200
          : "",
      fontSize: 13,
      fontWeight: "500",
      borderColor: "#f2f2f2"
    };
    let { state } = this;
    return (
      <section className="lp-grid-wrapper" style={marginStyling}>
        <div className="request-header">
          <div>
            <FormItem style={{ marginBottom: 10 }}>
              <Select
                dropdownClassName="loanPoolDropdown"
                className="request-header-dropdown"
                placeholder="Open Loans"
                onChange={this.handleRequestStatus.bind(this)}
                value={state.requestStatus}
              >
                {reqOptions.map((i, index) => (
                  <Option key={index} value={i.value}>
                    {i.displayName}
                  </Option>
                ))}
              </Select>
            </FormItem>
          </div>
          <div>
            {this.state.authenticated ? (
              <Redirect to="/loan-pool-notifications/loan-pool-new-request" />
            ) : (
              <FormItem style={{ marginBottom: 10, marginLeft: 20 }}>
                <Button
                  className="check-availibility-button"
                  type="primary"
                  onClick={this.onDuplicate.bind(this)}
                >
                  <span>Duplicate Request</span>
                </Button>
              </FormItem>
            )}
          </div>
        </div>

        <div style={requestGridStyles} className="antd-request-grid">
          <Table
            dataSource={allLoanPoolRequests}
            columns={colDefs}
            getRowHeight={this.getRowHeight.bind(this)}
            rowSelection={rowSelection}
            pagination={false}
            loading={!loanPoolStoreV2.dataLoadedForSTMLP}
            scroll={{ y: true }}
            locale={{
              emptyText: (
                <div className="emptytext">
                  <img src={noDataImage} />
                  <p
                    style={{
                      height: "31%",
                      position: "absolute",
                      bottom: "-45%",
                      left: "50%",
                      transform: " translate(-50%, -50%)"
                    }}
                  >
                    No {state.requestStatus == "All" ? "" : state.requestStatus}{" "}
                    Loans
                  </p>
                </div>
              )
            }}
          />
        </div>
        {loanPoolStoreV2.isRequestModelModalOpen ? (
          <RequestApprovalLogModal
            isRequestModalOpen={loanPoolStoreV2.isRequestModelModalOpen}
            handleDecline={this.handleDecline.bind(this)}
            modalRequestData={loanPoolStoreV2.isRequestModelModalOpen}
            showApprovalButtons={false}
            bool={true}
          />
        ) : (
          ""
        )}
      </section>
    );
  }
}
