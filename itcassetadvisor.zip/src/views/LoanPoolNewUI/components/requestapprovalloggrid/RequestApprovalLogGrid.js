import React, { Component } from "react";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import CustomHeader from "../requestgrid/RequestDetailsCustomHeader";
import moment from "moment";
import RequestApprovalLogModal from "./RequestApprovalLogModal";
import { Table, Select, Progress, Tooltip } from "antd";
import { observer } from "mobx-react";
import noDataImage from "../../../../../public/img/no-data-placeholder_standard.png";
// import mobx from "mobx";
const Option = Select.Option;

@observer
class RequestApprovalLogGrid extends Component {
  constructor(props) {
    super(props);
    this.state = {
      allLoanPoolRequestsNull: false,
      loading: false,
      requestStatus: "Approved",
      isDropDownVisible: false,
      selectedRowKeys: [] // Check here to configure the default column
    };
    this.columnDefs = [
      {
        title: "",
        dataIndex: "",
        width: 35
      },
      {
        title: "REQUEST NUMBER",
        dataIndex: "DisplayRequestId",

        render: (text, record) => (
          <Tooltip title={record.DisplayRequestId}>
            <span>
              <a
                style={{ color: "#3385FF" }}
                href="#"
                onClick={() => this.onCellClicked(record)}
              >
                {record.DisplayRequestId}
              </a>
            </span>
          </Tooltip>
        )
      },
      {
        title: "REQUEST STATUS",
        dataIndex: "status",

        render: function(params) {
          if (params == "Approved") {
            return (
              <Tooltip title={params}>
                <span style={{ color: "#42DA81" }}>
                  <span
                    style={{
                      display: "inline-block",
                      height: 11,
                      width: 11,
                      backgroundColor: "#42DA81",
                      borderRadius: "50%"
                    }}
                  />
                  &nbsp;&nbsp;&nbsp;
                  {params}
                </span>
              </Tooltip>
            );
          } else if (params == "Active") {
            return (
              <Tooltip title={params}>
                <span style={{ color: "#3385FF" }}>
                  <span
                    style={{
                      display: "inline-block",
                      height: 11,
                      width: 11,
                      backgroundColor: "#3385FF",
                      borderRadius: "50%"
                    }}
                  />
                  &nbsp;&nbsp;&nbsp;
                  {params}
                </span>
              </Tooltip>
            );
          } else if (params == "Overdue") {
            return (
              <Tooltip title={params}>
                <span style={{ color: "#ff3e39" }}>
                  <span
                    style={{
                      display: "inline-block",
                      height: 11,
                      width: 11,
                      backgroundColor: "#ff3e39",
                      borderRadius: "50%"
                    }}
                  />
                  &nbsp;&nbsp;&nbsp;
                  {params}
                </span>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip title={params}>
                <span style={{ color: "#979797" }}>
                  <span
                    style={{
                      display: "inline-block",
                      height: 11,
                      width: 11,
                      backgroundColor: "#979797",
                      borderRadius: "50%"
                    }}
                  />
                  &nbsp;&nbsp;&nbsp;
                  {params}
                </span>
              </Tooltip>
            );
          }
        }
      },
      {
        title: "REQUESTED BY",
        dataIndex: "RequestorEmail",
        render: params => (
          <Tooltip title={params}>
            <span> {params}</span>
          </Tooltip>
        )
      },
      {
        title: "REVIEW DATE",
        dataIndex: "requestDate",

        render: function(params) {
          return (
            <Tooltip title={moment(params).format("YYYY-MM-DD")}>
              <span>{moment(params).format("YYYY-MM-DD")}</span>
            </Tooltip>
          );
        }
      },
      {
        title: "PROGRESS",
        dataIndex: "progress",
        width: 160,
        render: (text, record) => {
          if (record.status == "Closed") {
            ("");
          } else {
            let defaultValue = "";
            if (this.getPercent(record) == 0) {
              defaultValue = "Awaiting Approval";
            } else if (this.getPercent(record) == 25) {
              defaultValue = "Request Approved";
            } else if (this.getPercent(record) == 50) {
              defaultValue = "Asset Prepared";
            } else if (this.getPercent(record) == 75) {
              defaultValue = "Asset Delivered";
            } else {
              defaultValue = "Asset Received";
            }
            return (
              <Tooltip title={defaultValue}>
                <span
                  className="progressBar-requestdetail"
                  style={{ width: 150, color: "#3385FF" }}
                >
                  &nbsp;&nbsp;&nbsp;
                  <Progress percent={this.getPercent(record)} strokeWidth={5} />
                </span>
              </Tooltip>
            );
          }
        }
      },
      {
        title: "PROGRESS UPDATE",
        dataIndex: "",
        width: 160,
        render: (text, record) => {
          const percent = this.getPercent(record);
          return record.status == "Closed" ||
            record.status == "Open" ||
            percent == 0
            ? ""
            : this.menu(record, percent);
        }
      }
    ];
  }
  menu = (record, percent) => {
    let defaultValue = "";
    if (percent == 25) {
      defaultValue = "Request Approved";
    } else if (percent == 50) {
      defaultValue = "Asset Prepared";
    } else if (percent == 75) {
      defaultValue = "Asset Delivered";
    } else {
      defaultValue = "Asset Received";
    }

    return (
      <Select
        value={defaultValue}
        className="progessUpdateOnAwaitingLog"
        key={defaultValue}
      >
        <Option
          value="Request Approved"
          key="Request Approved"
          title=" "
          className="log-menu"
          disabled={defaultValue == "Request Approved"}
        >
          <Tooltip title="Request Approved">
            <a
              onClick={
                defaultValue == "Request Approved"
                  ? ""
                  : () =>
                      loanPoolStoreV2.assetProgressUpdate(
                        "awaitingApproval",
                        record
                      )
              }
              disabled={defaultValue == "Request Approved"}
            >
              Request Approved
            </a>
          </Tooltip>
        </Option>
        <Option
          value="Asset Prepared"
          key="Asset Prepared"
          title=" "
          className="log-menu"
          disabled={defaultValue == "Asset Prepared"}
        >
          <Tooltip title="Asset Prepared">
            <a
              onClick={
                defaultValue == "Asset Prepared"
                  ? ""
                  : () =>
                      loanPoolStoreV2.assetProgressUpdate(
                        "preparingAsset",
                        record
                      )
              }
              disabled={defaultValue == "Asset Prepared"}
            >
              Asset Prepared
            </a>
          </Tooltip>
        </Option>
        <Option
          value="Asset Delivered"
          key="Asset Delivered"
          title=" "
          className="log-menu"
          disabled={defaultValue == "Asset Delivered"}
        >
          <Tooltip title="Asset Delivered">
            <a
              onClick={
                defaultValue == "Asset Delivered"
                  ? ""
                  : () =>
                      loanPoolStoreV2.assetProgressUpdate(
                        "deliveryingAsset",
                        record
                      )
              }
              disabled={defaultValue == "Asset Delivered"}
            >
              Asset Delivered
            </a>
          </Tooltip>
        </Option>
        <Option
          value="Asset Received"
          defaultValue="Asset Received"
          title=" "
          className="log-menu"
          disabled={defaultValue == "Asset Received"}
        >
          <Tooltip title="Asset Received">
            <a
              onClick={
                defaultValue == "Asset Received"
                  ? ""
                  : () =>
                      loanPoolStoreV2.assetProgressUpdate(
                        "assetReceived",
                        record
                      )
              }
              disabled={defaultValue == "Asset Received"}
            >
              Asset Received
            </a>
          </Tooltip>
        </Option>
      </Select>
    );
  };

  getPercent = data => {
    const status =
      data && data.ProgressStatus
        ? data.ProgressStatus
        : {
            assetReceived: "",
            awaitingApproval: "",
            deliveryingAsset: "",
            preparingAsset: ""
          };
    if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "" &&
      status.deliveryingAsset == "" &&
      status.assetReceived == ""
    ) {
      return 25;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "" &&
      status.assetReceived == ""
    ) {
      return 50;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "finish" &&
      status.assetReceived == ""
    ) {
      return 75;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "finish" &&
      status.assetReceived == "finish"
    ) {
      return 100;
    } else {
      return 0;
    }
  };
  // logic for dropdown request status
  handleRequestStatus(value) {
    this.setState({ requestStatus: value });
  }
  onCellClicked(data) {
    loanPoolStoreV2.setIsRequestModelModalOpen(data);
  }
  // Request modal methods-starts here
  handleDecline() {
    loanPoolStoreV2.setIsRequestModelModalOpen(false);
  }
  componentDidMount() {
    const element = document.querySelector(
      ".request-approval-grid .ant-table-body"
    );
    element.addEventListener("scroll", this.closeDropDown, true);
  }
  componentWillUnmount() {
    const element = document.querySelector(
      ".request-approval-grid .ant-table-body"
    );
    element.removeEventListener("scroll", this.closeDropDown, true);
  }
  closeDropDown = () => {
    const menus = document.getElementsByClassName("ant-select-dropdown");
    [...menus].map(e => e.classList.add("ant-select-dropdown-hidden"));
  };
  markAsReturned = () => {};
  render() {
    const requestApprovalStyles = {
      height:
        loanPoolStoreV2.reviewerViewMode == "REQUESTFULLSCREEN"
          ? window.innerHeight - 150
          : ""
    };
    let allLoanPoolRequests = [];
    if (this.state.requestStatus == "Approved")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests.filter(
        i => i.status == "Approved"
      );
    else if (this.state.requestStatus == "Active")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests.filter(
        i => i.status == "Active"
      );
    else if (this.state.requestStatus == "Closed")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests.filter(
        i => i.status == "Closed"
      );
    else if (this.state.requestStatus == "Requested")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests.filter(
        i => i.HasExternalRequest == true
      );
    else if (this.state.requestStatus == "Overdue")
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests.filter(
        i => i.status == "Overdue"
      );
    else {
      allLoanPoolRequests = loanPoolStoreV2.allLoanPoolRequests.filter(
        i => i.status != "Open"
      );
    }
    var colDefs = this.columnDefs.map(i => i);
    if (allLoanPoolRequests.length == 0) {
      colDefs.push({
        dataIndex: "fullscreen",
        width: 50
      });
      loanPoolStoreV2.setShowIcon(false);
    } else {
      colDefs.push({
        dataIndex: "fullscreen",
        title: <CustomHeader />,
        width: 50
      });
      loanPoolStoreV2.setShowIcon(true);
    }
    return (
      <section
        className="lp-section-box lpSelectAssets lp-grid-wrapper"
        style={{ marginTop: 25 }}
      >
        <div style={{ marginBottom: 8 }}>
          <span style={styleSheets.bottomGridHeaderText}>
            Request Approval Log
          </span>
          <Select
            dropdownClassName="reviewerModeDropdown"
            className="request-header-dropdown"
            placeholder="Approved Loans"
            onChange={this.handleRequestStatus.bind(this)}
            value={this.state.requestStatus}
          >
            <Option value="Approved">Approved Loans</Option>
            <Option value="Active">Active Loans</Option>
            <Option value="Closed">Closed Loans</Option>
            {/* <Option value="Requested">External Loans</Option> */}
            <Option value="Overdue">Overdue Loans</Option>
            <Option value="All">All Loans</Option>
          </Select>
        </div>
        <div style={requestApprovalStyles} className="request-approval-grid">
          <Table
            dataSource={allLoanPoolRequests}
            columns={colDefs}
            loading={!loanPoolStoreV2.dataLoadedForAllLP}
            scroll={{
              y: true
            }}
            pagination={{
              showSizeChanger: true,
              placement: "topCenter"
            }}
            locale={{
              emptyText: (
                <div>
                  <img src={noDataImage} />
                  <p
                    style={{
                      height: "40%",
                      position: "absolute",
                      bottom: "-38%",
                      left: "49%",
                      transform: " translate(-50%, -50%)"
                    }}
                  >
                    No{" "}
                    {this.state.requestStatus == "All"
                      ? ""
                      : this.state.requestStatus}{" "}
                    Loans
                  </p>
                </div>
              )
            }}
            className="request-approval-grid"
          />
        </div>
        )
        {loanPoolStoreV2.isRequestModelModalOpen ? (
          <RequestApprovalLogModal
            isRequestModalOpen={loanPoolStoreV2.isRequestModelModalOpen}
            handleDecline={this.handleDecline.bind(this)}
            modalRequestData={loanPoolStoreV2.isRequestModelModalOpen}
            showApprovalButtons={false}
          />
        ) : (
          ""
        )}
      </section>
    );
  }
}
const styleSheets = {
  bottomGridHeaderText: {
    color: "#979797",
    fontFamily: "Open Sans",
    fontSize: 13,
    letterSpacing: 0.47,
    lineHeight: "18px",
    marginRight: 24
  }
};
export default RequestApprovalLogGrid;
