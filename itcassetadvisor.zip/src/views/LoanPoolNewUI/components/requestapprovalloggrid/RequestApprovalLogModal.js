import React from "react";
import { Row, Col, Button, Icon, Form, Modal, DatePicker, Spin } from "antd";
import * as mobx from "mobx";
import { observer } from "mobx-react";
import moment from "moment";
import CustomSteps from "../steps/Steps";
import loanPoolStoreV2 from "src/stores/loanPoolStoreV2";
import UIFunctions from "src/helpers/UIFunctions";
import PropTypes from "prop-types";
import AssetCard from "src/views/Components/Cards/AssetCard";

const RangePicker = DatePicker.RangePicker;

// return the coloring of the status
function handleDescription(status) {
  if (status == "Approved") {
    return (
      <span style={{ color: "#95D8B1", fontWeight: "500" }}>
        {status == "Approved" ? <Icon type="check" theme="outlined" /> : ""}
        {status}
      </span>
    );
  } else if (status == "Rejected" || status == "Overdue" ) {
    return <span style={{ color: "red" }}>{status}</span>;
  } else if (status == "Active") {
    return <span style={{ color: "#3385FF" }}>{status}</span>;
  } else if (status == "Open") {
    return <span style={{ color: "#FFAE1C" }}>{status}</span>;
  } else if (!status) {
    return <span style={{ color: "#737a80 ", fontWeight: "500" }} />;
  } else {
    return (
      <span style={{ color: "#737a80 ", fontWeight: "500" }}>{status}</span>
    );
  }
}
//header component
function Title({ ModelNo, status }) {
  return (
    <span className="model-modal-header">
      Request: {ModelNo} <span className="vertical-small-divider" />
      {handleDescription(status)}
    </span>
  );
}
@observer
class requestApprovalLogModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      iconClickedData: {},
      disapproveLoading: false
    };
  }

  handleDecline = () => {
    this.props.handleDecline();
  };
  markAsReturned = (record, bool) => {
    var self = this;
    const date = this.props.form
      .getFieldValue(`date-picker${record.workFlowId}`)
      .toISOString();
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to return the asset?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({ returnLoading: true, iconClickedData: record });
        loanPoolStoreV2
          .markAsReturned(record, date, bool)
          .then(() => {
            setTimeout(() => self.setState({ returnLoading: false }), 5000);
          })
          .catch(() => self.setState({ returnLoading: false }));
      },
      onCancel() {}
    });
  };
  disabledDate = (current, StartDate) => {
    return (current && current < moment(StartDate)) || current > moment();
  };
  cancelLoanRequest = (record, bool) => {
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to cancel the request?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({ disapproveLoading: true, iconClickedData: record });
        loanPoolStoreV2
          .cancelLoanRequest(record, bool)
          .then(() => {
            setTimeout(() => self.setState({ disapproveLoading: false }), 5000);
          })
          .catch(() => self.setState({ disapproveLoading: false }));
      },

      onCancel() {}
    });
  };
  getAllAsset = ({ RequestorEmail, requestDate, status }, progressBar) => {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: { span: 6 },
        sm: { span: 6 }
      },
      wrapperCol: {
        xs: { span: 6 },
        sm: { span: 6 }
      }
    };
    const data = mobx.toJS(this.props.modalRequestData.assets);
    if (data && data.length > 0) {
      return data.map((item, index) => (
        <div key={index}>
          {status != "Closed" ? (
            <hr style={{ borderColor: "#C3C3C3", marginBottom: 25 }} />
          ) : (
            ""
          )}

          <Row gutter={16}>
            <Col xs={24} sm={8} md={10} lg={10} xl={10}>
              <div
                className="request-modal-asset-details"
                style={{
                  //marginLeft: 18,
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: "-4px"
                }}
              >
                <AssetCard
                  modelNo={item.ModelNo}
                  dummyUrl="/img/no-asset-image.png"
                  alt="keysightAssetImage"
                  width={item.HasExternalRequest ? "250px" : "200px"}
                  height="170px"
                  hasExternalRequest={item.HasExternalRequest}
                />
                {status != "Overdue" &&
                ((item.status === "Approved" &&
                progressBar < 75) | (item.status === "Requested" && loanPoolStoreV2.reviewerMode == false )) ? (
                  <Button
                    className="ant-btn-cancel-btn"
                    icon="close"
                    style={{
                      height: 30,
                      width: 137,
                      border: "1px solid #FF3E39",
                      borderRadius: 3,
                      backgroundColor: "rgba(255,62,57,0.06)",
                      color: "rgba(255, 62, 57,.7)",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      marginRight: "3px"
                    }}
                    loading={
                      this.state.disapproveLoading
                        ? item.workFlowId ==
                          this.state.iconClickedData.workFlowId
                          ? true
                          : false
                        : false
                    }
                    disabled={
                      !this.state.disapproveLoading &&
                      ((item.status === "Approved" &&
                      progressBar < 75)
                      | (item.status === "Requested" && loanPoolStoreV2.reviewerMode == false))
                        ? false
                        : true
                    }
                    onClick={() =>
                      this.cancelLoanRequest(item, this.props.bool)
                    }
                  >
                    Cancel Request
                  </Button>
                ) : (
                  ""
                )}
              </div>
            </Col>

            <Col xs={24} sm={16} md={10} lg={10} xl={10}>
              <Row gutter={24}>
                {item.HasExternalRequest ? (
                  <div className="request-modal-asset-details request-results">
                    <h4
                      className="request-results"
                      style={{ color: "#3385FF", fontWeight: "700" }}
                    >
                      Model No: {item.ModelNo}
                    </h4>

                    <h4 className="request-results">
                      Manufacturer: {item.Manufacturer}
                    </h4>
                    <h4 className="request-results">
                      Description: {item.Description}
                    </h4>
                    <h4 className="request-results">
                      Requested Location: {item.LocationER}
                    </h4>
                    <h4 className="request-results">
                      Justification: {item.JustificationER}
                    </h4>
                    <h4 className="request-results">
                      Contact Number: {item.ContactER}
                    </h4>
                    <h4 className="request-results">
                      Notes/Options/Accessories: {item.NotesER}
                    </h4>
                    <h4 className="request-results">
                      Requested Date Range: <br />
                      <RangePicker
                        style={{ width: "200px" }}
                        ranges={{
                          Today: [moment(), moment()],
                          "This Month": [moment(), moment().endOf("month")]
                        }}
                        value={[moment(item.StartDate), moment(item.EndDate)]}
                        disabled={true}
                      />
                    </h4>
                    <h4 className="request-results">
                      {loanPoolStoreV2.reviewerMode &&
                      moment() >= moment(item.StartDate) &&
                      (item.status === "Approved" ||
                        item.status === "Overdue" ||
                        item.status === "Returned") &&
                      (progressBar == 100 || item.status === "Returned") ? (
                        <div>
                          Returned Date:
                          <div style={{ display: "flex" }}>
                            <Form.Item {...formItemLayout}>
                              {getFieldDecorator(
                                `date-picker${item.workFlowId}`,
                                {
                                  initialValue: item.ReturnedDate
                                    ? moment(item.ReturnedDate)
                                    : moment(item.StartDate)
                                }
                              )(
                                <DatePicker
                                  disabledDate={e =>
                                    this.disabledDate(e, moment(item.StartDate))
                                  }
                                  style={{ width: "100px" }}
                                  disabled={
                                    item.status === "Approved" ||
                                    (item.status === "Overdue" &&
                                      progressBar == 100 &&
                                      moment() >= moment(item.StartDate))
                                      ? false
                                      : true
                                  }
                                />
                              )}
                            </Form.Item>
                            <Button
                              type="Button"
                              className="aaSmallBtn btn btn-primary btn-sm"
                              style={{
                                marginTop: "1px",
                                backgroundColor: "rgba(51,133,255,.06)",
                                color: "rgba(51,133,255,.7)",
                                borderColor: "rgba(51,133,255,.7)",
                                fontSize: "12px"
                              }}
                              loading={
                                this.state.returnLoading
                                  ? item.workFlowId ==
                                    this.state.iconClickedData.workFlowId
                                    ? true
                                    : false
                                  : false
                              }
                              disabled={
                                (!this.state.returnLoading &&
                                  item.status === "Approved") ||
                                (item.status === "Overdue" &&
                                  progressBar == 100 &&
                                  moment() >= moment(item.StartDate))
                                  ? false
                                  : true
                              }
                              onClick={() =>
                                this.markAsReturned(item, this.props.bool)
                              }
                            >
                              <Icon type="check" />
                              {item.status == "Returned"
                                ? "Returned"
                                : "Mark as Returned"}
                            </Button>
                          </div>
                        </div>
                      ) : (
                        ""
                      )}
                    </h4>
                  </div>
                ) : (
                  <div className="request-modal-asset-details request-results">
                    <h4
                      className="request-results"
                      style={{ color: "#3385FF", fontWeight: "700" }}
                    >
                      Model No: {item.ModelNo}
                    </h4>
                    <h4 className="request-results">
                      Equipment Number: {item.EquipmentNo}
                    </h4>
                    <h4 className="request-results">
                      Manufacturer: {item.Manufacturer}
                    </h4>
                    <h4 className="request-results">
                      Serial Number: {item.SerialNo}
                    </h4>
                    <h4 className="request-results">
                      Description: {item.Description}
                    </h4>
                    <h4 className="request-results">
                      Requested Date Range: <br />
                      <RangePicker
                        style={{ width: "200px" }}
                        ranges={{
                          Today: [moment(), moment()],
                          "This Month": [moment(), moment().endOf("month")]
                        }}
                        value={[moment(item.StartDate), moment(item.EndDate)]}
                        disabled={true}
                      />
                    </h4>
                    <h4 className="request-results">
                      Coordinator: {item.Coordinator}
                    </h4>
                    <h4 className="request-results">
                      Requested By: {RequestorEmail}
                    </h4>
                    <h4 className="request-results">
                      Date Created: {moment(requestDate).format("YYYY-MM-DD")}
                    </h4>
                    <h4 className="request-results">
                      {loanPoolStoreV2.reviewerMode &&
                      moment() >= moment(item.StartDate) &&
                      (item.status === "Approved" ||
                        item.status === "Overdue" ||
                        item.status === "Returned") &&
                      (progressBar == 100 || item.status === "Returned") ? (
                        <div>
                          Returned Date:
                          <div style={{ display: "flex" }}>
                            <Form.Item {...formItemLayout}>
                              {getFieldDecorator(
                                `date-picker${item.workFlowId}`,
                                {
                                  initialValue: item.ReturnedDate
                                    ? moment(item.ReturnedDate)
                                    : moment(item.StartDate)
                                }
                              )(
                                <DatePicker
                                  disabledDate={e =>
                                    this.disabledDate(e, moment(item.StartDate))
                                  }
                                  style={{ width: "100px" }}
                                  disabled={
                                    (item.status === "Approved" ||
                                      item.status === "Overdue") &&
                                    progressBar == 100 &&
                                    moment() >= moment(item.StartDate)
                                      ? false
                                      : true
                                  }
                                />
                              )}
                            </Form.Item>
                            <Button
                              type="Button"
                              className="aaSmallBtn btn btn-primary btn-sm"
                              style={{
                                marginTop: "1px",
                                backgroundColor: "rgba(51,133,255,.06)",
                                color: "rgba(51,133,255,.7)",
                                borderColor: "rgba(51,133,255,.7)",
                                fontSize: "12px"
                              }}
                              loading={
                                this.state.returnLoading
                                  ? item.workFlowId ==
                                    this.state.iconClickedData.workFlowId
                                    ? true
                                    : false
                                  : false
                              }
                              disabled={
                                !this.state.returnLoading &&
                                (item.status === "Approved" ||
                                  item.status === "Overdue") &&
                                progressBar == 100 &&
                                moment() >= moment(item.StartDate)
                                  ? false
                                  : true
                              }
                              onClick={() => this.markAsReturned(item)}
                            >
                              <Icon type="check" />
                              {item.status == "Returned"
                                ? "Returned"
                                : "Mark as Returned"}
                            </Button>
                          </div>
                        </div>
                      ) : (
                        ""
                      )}
                    </h4>
                  </div>
                )}
              </Row>
            </Col>
            <Col xs={24} sm={6} md={4} lg={4} xl={4}>
              <div
                className="request-modal-asset-details"
                style={{ position: "relative", top: 100 }}
              >
                <h4
                  className="request-results"
                  style={{
                    color:
                      item.status === "Approved"
                        ? "#3ABF72"
                        : item.status === "Rejected" ||
                          item.status === "Overdue" ||
                          item.status === "Cancelled"
                        ? "#FF3E39"
                        : "",
                    fontWeight: "bold"
                  }}
                >
                  {item.status}
                </h4>
              </div>
            </Col>
          </Row>
        </div>
      ));
    }
  };
  getPercent = status => {
    if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "" &&
      status.deliveryingAsset == "" &&
      status.assetReceived == ""
    ) {
      return 25;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "" &&
      status.assetReceived == ""
    ) {
      return 50;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "finish" &&
      status.assetReceived == ""
    ) {
      return 75;
    } else if (
      status.awaitingApproval == "finish" &&
      status.preparingAsset == "finish" &&
      status.deliveryingAsset == "finish" &&
      status.assetReceived == "finish"
    ) {
      return 100;
    } else {
      return 0;
    }
  };
  render() {
    const { isRequestModalOpen, modalRequestData } = this.props;
    const stepStatus =
      modalRequestData && modalRequestData.ProgressStatus
        ? modalRequestData.ProgressStatus
        : {
            assetReceived: "",
            awaitingApproval: "",
            deliveryingAsset: "",
            preparingAsset: ""
          };
    const modalTop = {
      top: (window.innerHeight - 500) / 2,
      padding: 0
    };
    const { DisplayRequestId, status } = modalRequestData;
    const contentStyles = {
      color: "rgba(12,34,45)",
      fontWeight: "500",
      maxHeight: 410,
      overflow: "auto"
    };
    return (
      <div>
        <Modal
          title={<Title ModelNo={DisplayRequestId} status={status} />}
          visible={isRequestModalOpen}
          onCancel={this.handleDecline.bind(this)}
          bodyStyle={contentStyles}
          footer={null}
          centered
          width="761px"
          style={modalTop}
          className="request-modal"
          maskClosable={false}
        >
          <Spin
            spinning={loanPoolStoreV2.isRequestModalLoading}
            delay={100}
          >  
          {modalRequestData && modalRequestData.status == "Closed" ? (
            ""
          ) : (
            <CustomSteps
              stepStatus={stepStatus}
              percent={this.getPercent(stepStatus)}
              strokeWidth={12}
            />
          )}

          {/* this will get the asset details based on the asset available  */}
          {this.getAllAsset(modalRequestData, this.getPercent(stepStatus))}
          </Spin>
        </Modal>
      </div>
    );
  }
}

const RequestApprovalLogModal = Form.create()(requestApprovalLogModal);
export default RequestApprovalLogModal;

RequestApprovalLogModal.propTypes = {
  isRequestModalOpen: PropTypes.object,
  modalRequestData: PropTypes.object,
  handleDecline: PropTypes.func
};

Title.propTypes = {
  ModelNo: PropTypes.string,
  status: PropTypes.string
};
