import React from "react";
import { Modal, Button, Icon, Tooltip } from "antd";
import VerticalDivider from "../dividers/VerticalDivider";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import UIFunctions from "src/helpers/UIFunctions";
import PropTypes from "prop-types";
import { observer } from "mobx-react";
import AssetCard from "src/views/Components/Cards/AssetCard";
function handleDescription(CalibrationStatus) {
  if (CalibrationStatus == "Calibrated") {
    return (
      <span style={{ color: "#95D8B1", fontWeight: "500" }}>
        <Icon type="check" theme="outlined" />
        {CalibrationStatus}
      </span>
    );
  } else if (CalibrationStatus == "Not Calibrated") {
    return (
      <span>
        <Icon style={{ color: "red" }} type="exclamation" theme="outlined" />
        {CalibrationStatus}
      </span>
    );
  } else if (!CalibrationStatus) {
    return <span style={{ color: "#737a80 ", fontWeight: "500" }} />;
  } else {
    return (
      <span style={{ color: "#737a80 ", fontWeight: "500" }}>
        {CalibrationStatus}
      </span>
    );
  }
}

function Title(props) {
  return (
    <span className="model-modal-header">
      Model No. {props.ModelNo} <span className="vertical-small-divider" />
      {handleDescription(props.CalibrationStatus)}
    </span>
  );
}
@observer
class LPModelModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      addingToCart: false
    };
  }
  handleDecline() {
    this.props.onClose();
  }
  addToCart = () => {
    // eslint-disable-next-line
    const { markers, ...nDetails } = this.props.modelModalData;
    if (typeof this.props.selectedDates == "object") {
    const selectedDatesCalender = this.props.selectedDates
    var size = Object.keys(selectedDatesCalender).length;
      if (size > 0)  {
        const selectedDates = [loanPoolStoreV2.startDateCheckAvailability,loanPoolStoreV2.endDateCheckAvailability]
        nDetails.RequestedStartDate = selectedDates[0];
        nDetails.RequestedEndDate = selectedDates[1];
      } else {
        UIFunctions.Toast("Please provide start and end dates","warn");
        return;
      }
    }
    this.setState({ addingToCart: true });
    loanPoolStoreV2
      .addToCart(nDetails)
      .then(() => this.setState({ addingToCart: false }))
      .catch(() => this.setState({ addingToCart: false }));
  };
  render() {
    const { visible, modelModalData } = this.props;
    const modalTop = {
      top: (window.innerHeight - 406) / 2,
      padding: 0
    };
    const {
      ModelNo,
      Manufacturer,
      Location,
      EquipmentNo,
      Organization,
      Description,
      CalibrationStatus,
      UniqueID,
      Options,
      HardwareVersion,
      Accessories
    } = modelModalData;
    const contentStyles = {
      color: "rgba(12,34,45)",
      fontWeight: "500",
      maxHeight: 370,
      overflow: "auto",
      padding: 0
    };
    const btnStyle = {
      width: 198,
      border: "none",
      color: "rgba(0, 0, 0, 0.25)",
      backgroundColor: "#f7f7f7",
      borderRadius: 0
    };
    let btn_disabled = false;
    loanPoolStoreV2.cartItems.map(i => {
      if (i.UniqueID === UniqueID) {
        btn_disabled = true;
      }
    });
    return (
      <div>
        <Modal
          title={
            <Title ModelNo={ModelNo} CalibrationStatus={CalibrationStatus} />
          }
          visible={visible}
          onCancel={
            this.state.addingToCart ? "" : this.handleDecline.bind(this)
          }
          maskClosable={false}
          bodyStyle={contentStyles}
          footer={null}
          centered
          width="871px"
          style={modalTop}
          className="model-Modalclass"
        >
          <div className="model-modal-wrapper">
            <div className="model-modal-left">
              <div className="modal-add-cart-btn">
                <Tooltip
                  title={
                    btn_disabled ? "Item already in the cart" : "Add to cart"
                  }
                >
                  <Button
                    className="add-to-cart"
                    type="primary"
                    onClick={this.addToCart}
                    icon="shopping-cart"
                    loading={this.state.addingToCart}
                    disabled={btn_disabled}
                    style={btn_disabled ? btnStyle : {}}
                  >
                    {btn_disabled ? "Added to Cart!" : "Add to Cart"}
                  </Button>
                </Tooltip>
              </div>
              <div className="model-text">
                <p>{Description}</p>
                <AssetCard
                  modelNo={ModelNo}
                  dummyUrl="/img/no-asset-image.png"
                  width="200"
                  height="170px"
                  hasExternalRequest={false}
                />
              </div>
            </div>
            <VerticalDivider />
            <div className="model-modal-right">
              <div>
                <h4 style={{ color: "#3385FF", fontWeight: "700" }}>Details:</h4>
                <section>
                  <div className="model-modal-details">
                    <h4>
                      Equipment Number:
                      <span className="model-modal-same">{EquipmentNo}</span>
                    </h4>
                    <h4>
                      Manufacturer:
                      <span className="model-modal-same">{Manufacturer}</span>
                    </h4>
                    <h4>
                      Organization:
                      <span className="model-modal-same">{Organization}</span>
                    </h4>
                    <h4>
                      Location:
                      <span className="model-modal-same">{Location}</span>
                    </h4>
                    <h4>
                      Hardware Version:
                      <span className="model-modal-same">
                        {HardwareVersion}
                      </span>
                    </h4>
                    <h4>
                      Accessories:
                      <span className="model-modal-same">{Accessories}</span>
                    </h4>
                    <h4>
                      Options:
                      <span className="model-modal-same">{Options}</span>
                    </h4>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}

export default LPModelModal;
LPModelModal.propTypes = {
  onClose: PropTypes.func,
  visible: PropTypes.bool,
  selectedDates: PropTypes.array
};
Title.propTypes = {
  ModelNo: PropTypes.string,
  CalibrationStatus: PropTypes.string
};
