import React from "react";
import { Table, Row, Col, Button, Icon, Tooltip } from "antd";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import { observer } from "mobx-react";
import LPModelModal from "./LPModelModal";
import { Link } from "react-router-dom";
import noDataImage from "../../../../../public/img/no-data-placeholder_standard.png";

@observer
class LoanPoolBorrowableAssets extends React.Component {
  static defaultProps = { rowKey: "EquipmentNo" };

  constructor(props) {
    super(props);
    this.state = {
      currentPageSize: 10,
      modelModalData: {},
      rowSelection: "multiple",
      lastPageFound: false,
      currentLimit: 25,
      totalPages: 0,
      startItem: 1,
      lastItem: 25,
      isDensityApplied: "false",
      currentDensityState: "default",
      currentPage: 1,
      loading: false,
      checkAvailibilty: false
    };
    this.currentRowHeight = "45";
  }

  onGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  };
  onCellClicked(record) {
    loanPoolStoreV2.setIsModelModalOpen(!this.isModelModalOpen);
    record.RequestedStartDate = loanPoolStoreV2.loanStartDate;
    record.RequestedEndDate = loanPoolStoreV2.loanEndDate;
    this.setState({
      modelModalData: record
    });
  }
  selectAllChange = (selected) => {
    let lpborrowableSelectedRows = [];
    if (selected) {
      loanPoolStoreV2.caCheckboxedItems = loanPoolStoreV2.borrowableAssets;
      loanPoolStoreV2.borrowableAssets.map(i => {
        lpborrowableSelectedRows.push(i.UniqueID)
      })
    }
    loanPoolStoreV2.setLpborrowableSelectedRows(lpborrowableSelectedRows)
  }
  handleModalClose() {
    loanPoolStoreV2.isModelModalOpen = false;
  }
  getRowHeight = () => {
    return parseInt(this.currentRowHeight);
  };
  onSelectChange = ( selectedRowKeys, selectedRows) => {
    loanPoolStoreV2.caCheckboxedItems = selectedRows;
    loanPoolStoreV2.lpborrowableSelectedRows = selectedRowKeys;
    if (selectedRows.length == 0) {
      loanPoolStoreV2.caCheckboxedItems = loanPoolStoreV2.borrowableAssets;
    }
  };
  onShowSizeChange(e) {
    var currentSize = e.target.value;
    this.setState({
      currentPageSize: currentSize
    });
  }
  render() {
    const columns = loanPoolStoreV2.borrowableAssetsHeader.map(i => {
      if (i.dataIndex == "ModelNo") {
        i["render"] = (text, record) => (
          <Tooltip title={record.ModelNo}>
            <span>
              <a
                style={{ color: "#3385FF" }}
                href="#"
                onClick={() => this.onCellClicked(record)}
              >
                {record.ModelNo}
              </a>
            </span>
          </Tooltip>
        );
      }
      return i;
    });
    const rowSelection = {
      selectedRowKeys: loanPoolStoreV2.lpborrowableSelectedRows,
      onChange: this.onSelectChange,
      onSelectAll:this.selectAllChange
    };

    const { modelModalData } = this.state;

    const borrowableGridStyles = {
      borderColor: "#f2f2f2",
      fontSize: 13,
      fontWeight: "500"
    };
    let searchResults =
      loanPoolStoreV2.borrowableAssets.length === 1
        ? `${loanPoolStoreV2.borrowableAssets.length} Result`
        : `${loanPoolStoreV2.borrowableAssets.length} Results`;
    return (
      <div className="lpn-grid-wrapper" style={{ marginTop: 24 }}>
        <Row style={{ maxWidth: 1300, height: 32 }}>
          <Col span={16}>
            <div style={{ color: "#79838c", paddingBottom: 4 }}>
              Borrowable Asset
              {loanPoolStoreV2.lastSelectedSuggestion !== null ? (
                <span style={{ marginLeft: 5 }}>
                  |{" "}
                  <span className="search-result-output">
                    <strong>{searchResults} </strong>
                    {loanPoolStoreV2.borrowableAssets.length === 1
                      ? `fits your current search parameters`
                      : `fit your current search parameters`}
                  </span>{" "}
                </span>
              ) : (
                ""
              )}
            </div>
          </Col>
          <Col
            span={8}
            style={{
              paddingBottom: 10,
              marginTop: -5,
              textAlign: "right"
            }}
          >
            <Link to="/loan-pool-notifications/check-availability">
              <Button
                type="primary"
                className="check-availibility-button"
                disabled={!loanPoolStoreV2.caPaginationLoader}
              >
                <Icon type="calendar" className="Check-button" />

                <span
                  style={{
                    color: !loanPoolStoreV2.caPaginationLoader ? "#ccc" : "#fff"
                  }}
                >
                  Check Availability
                </span>
              </Button>
            </Link>
          </Col>
        </Row>

        <div
          id="borrowableGridStyles"
          style={borrowableGridStyles}
          className="antd-grid"
        >
          <Table
            dataSource={loanPoolStoreV2.borrowableAssets.map(e => e)}
            columns={columns}
            onGridReady={this.onGridReady.bind(this)}
            getRowHeight={this.getRowHeight.bind(this)}
            rowSelection={rowSelection}
            loading={!loanPoolStoreV2.dataLoaded}
            scroll={{ y: true }}
            pagination={{
              showSizeChanger: true
            }}
            locale={{
              emptyText: (
                <div>
                  <img src={noDataImage} />
                  <p
                    style={{
                      height: "40%",
                      position: "absolute",
                      bottom: "-37%",
                      left: "49%",
                      transform: " translate(-50%, -50%)"
                    }}
                  >
                   {loanPoolStoreV2.isSearchApiCalled?"No Search Results":"No Borrowable Assets"}
                  </p>
                </div>
              )
            }}
          />
        </div>

        {loanPoolStoreV2.isModelModalOpen ? (
          <LPModelModal
            visible={loanPoolStoreV2.isModelModalOpen}
            onClose={this.handleModalClose.bind(this)}
            modelModalData={modelModalData}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}
export default LoanPoolBorrowableAssets;
