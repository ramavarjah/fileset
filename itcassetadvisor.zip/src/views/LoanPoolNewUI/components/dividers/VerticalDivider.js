import React from "react";

const VerticalDivider = ({ height, height1 }) => (
  <div
    style={{ height: (height ? height : "") || (height1 ? height1 : "") }}
    className="vertical-divider"
  />
);

export default VerticalDivider;
