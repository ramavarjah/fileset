import React from "react";
import { Button, Tooltip } from "antd";
import loanPoolStoreV2 from "src/stores/loanPoolStoreV2";
import PropTypes from "prop-types";
import AssetCard from "src/views/Components/Cards/AssetCard";

class ModelDetails extends React.Component {
  render() {
    let btn_disabled = false;
    const {
      mode,
      details,
      imageSource,
      onAddToCart,
      onClickModal
    } = this.props;
    const {
      Description,
      EquipmentNo,
      Manufacturer,
      Coordinator,
      ModelNo,
      UniqueID
    } = details;

    loanPoolStoreV2.cartItems.map(i => {
      if (i.UniqueID === UniqueID) {
        btn_disabled = true;
      }
    });
    const btnStyle = {
      border: "none",
      color: btn_disabled ? "#42da81" : "#646C72",
      backgroundColor: "#ffffff",
      marginTop: "5px",
      marginBottom: "10px",
      fontSize: "17px",
      fontWeight: 500
    };
    return (
      <div>
        <div
          style={{
            width: "215px",
            height: "220px",
            padding: "12px 12px",
            marginTop: "5px"
          }}
        >
          <div
            style={{
              height: "18px",
              width: "205px",
              color: "#3385FF",
              fontFamily: "Open Sans",
              fontSize: "11px",
              fontWeight: 600,
              letterSpacing: "0.59px",
              lineHeight: "18px"
            }}
          >
            <span
              style={{
                height: "18px",
                width: "205px",
                color: "#3385FF",
                fontFamily: "Open Sans",
                fontSize: "11px",
                fontWeight: 600,
                letterSpacing: "0.59px",
                lineHeight: "18px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
              }}
            >
              <span style={{ color: "#5d646a" }}>Model No: </span>
              <a onClick={onClickModal} style={{ marginRight: "auto" }}>
                {ModelNo}
              </a>
              <Tooltip
                title={
                  btn_disabled ? "Item already in the cart" : "Add to cart"
                }
              >
                <Button
                  type="primary"
                  onClick={e => onAddToCart(e, details)}
                  icon="shopping-cart"
                  disabled={btn_disabled}
                  // disabled={btn_disabled}
                  style={btnStyle}
                />
              </Tooltip>
            </span>
          </div>
          {mode == "image" ? (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "23px"
              }}
            >
              <AssetCard
                modelNo={imageSource}
                dummyUrl="/img/no-asset-image.png"
                width="150px"
                height="150px"
                hasExternalRequest={false}
              />
            </div>
          ) : (
            <div
              style={{
                width: "209px",
                color: "#646C72",
                fontFamily: "Open Sans",
                fontSize: "11px",
                letterSpacing: "0.59px",
                lineHeight: "18px",
                marginTop: 16,
                padding: ""
              }}
            >
              <section>
                <div
                  style={{
                    width: "209px",
                    color: "#646C72",
                    fontFamily: "Open Sans",
                    fontSize: "11px",
                    letterSpacing: "0.59px",
                    lineHeight: "18px"
                  }}
                >
                  <h4
                    style={{
                      width: "209px",
                      color: "#646C72",
                      fontFamily: "Open Sans",
                      fontSize: "11px",
                      letterSpacing: "0.59px",
                      lineHeight: "18px",
                      marginTop: "8px"
                    }}
                  >
                    Description:
                    <span style={{ marginLeft: "3px" }}>{Description}</span>
                  </h4>
                  <h4
                    style={{
                      width: "209px",
                      color: "#646C72",
                      fontFamily: "Open Sans",
                      fontSize: "11px",
                      letterSpacing: "0.59px",
                      lineHeight: "18px",
                      marginTop: "8px"
                    }}
                  >
                    Equipment Number:
                    <span style={{ marginLeft: "3px" }}>{EquipmentNo}</span>
                  </h4>
                  <h4
                    style={{
                      width: "209px",
                      color: "#646C72",
                      fontFamily: "Open Sans",
                      fontSize: "11px",
                      letterSpacing: "0.59px",
                      lineHeight: "18px",
                      marginTop: "8px"
                    }}
                  >
                    Manufacturer:
                    <span style={{ marginLeft: "3px" }}>{Manufacturer}</span>
                  </h4>
                  <h4
                    style={{
                      width: "209px",
                      color: "#646C72",
                      fontFamily: "Open Sans",
                      fontSize: "11px",
                      letterSpacing: "0.59px",
                      lineHeight: "18px",
                      marginTop: "8px"
                    }}
                  >
                    Coordinator:
                    <span style={{ display: "inline-block" }}>
                      {Coordinator}
                    </span>
                  </h4>
                </div>
              </section>
            </div>
          )}
        </div>
      </div>
    );
  }
}
export default ModelDetails;
ModelDetails.propTypes = {
  mode: PropTypes.string,
  onAddToCart: PropTypes.func,
  onClickModal: PropTypes.func,
  imageSource: PropTypes.string,
  details: PropTypes.object
};
