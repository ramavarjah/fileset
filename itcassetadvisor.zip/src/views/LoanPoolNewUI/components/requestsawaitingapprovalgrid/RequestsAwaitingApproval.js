import React, { Component } from "react";
import { Table, Checkbox, Button, Tooltip } from "antd";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import moment from "moment";
import LoanPoolRequestModalView from "../../components/requestgrid/LoanPoolRequestModalView";
import noDataImage from "../../../../../public/img/no-data-placeholder_standard.png";
import UIFunctions from "../../../../helpers/UIFunctions";
import { observer } from "mobx-react";

//component
@observer
class RequestsAwaitingApproval extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expandedRowKeys: [],
      enable: false,
      isRequestModelModalOpen: false,
      loading: false,
      approvalLoading: false,
      disapproveLoading: false,
      approveEquipmentLoading: false,
      disapproveEquipmentLoading: false,
      iconClickedData: {}
    };
    this.columnDefs = [
      {
        title: "",
        dataIndex: "",
        width: 35
      },
      {
        title: "APPROVAL",
        dataIndex: "approval",
        width: 150,
        render: (text, record) =>
          record.DisplayRequestId &&
          record.DisplayRequestId.startsWith("ER") ? (
            <span style={{ display: "inline-block" }}>
              <Tooltip title={"Decline"}>
                <Button
                  shape="circle"
                  icon="close-circle-o"
                  className="iconStyle"
                  style={{
                    marginRight: 16,
                    color: "#FF3E39",
                    border: "none",
                    width: 17,
                    height: 17
                  }}
                  loading={
                    this.state.disapproveEquipmentLoading
                      ? record.requestId == this.state.iconClickedData.requestId
                        ? true
                        : false
                      : false
                  }
                  disabled={
                    this.state.disapproveEquipmentLoading ||
                    this.state.approveEquipmentLoading ||
                    this.state.disapproveLoading ||
                    this.state.approvalLoading
                      ? true
                      : false
                  }
                  onClick={() => this.disapproveEquipmentRequest(record)}
                />
              </Tooltip>
              <Tooltip title={"Approve"}>
                <Button
                  shape="circle"
                  icon="check-circle-o"
                  className="iconStyle"
                  style={{
                    marginRight: 16,
                    color: "#3ABF72",
                    border: "none",
                    width: 17,
                    height: 17
                  }}
                  loading={
                    this.state.approveEquipmentLoading
                      ? record.requestId == this.state.iconClickedData.requestId
                        ? true
                        : false
                      : false
                  }
                  disabled={
                    this.state.disapproveEquipmentLoading ||
                    this.state.approveEquipmentLoading ||
                    this.state.disapproveLoading ||
                    this.state.approvalLoading
                      ? true
                      : false
                  }
                  onClick={() => this.approveEquipmentRequest(record)}
                />
              </Tooltip>
            </span>
          ) : record.assets && record.assets.length > 1 ? (
            <span>
              <Checkbox
                type="checkbox"
                className="offscreen"
                onChange={e => this.onChange(e, record)}
              >
                <Tooltip title={"Multiple"}>
                  <i className="icon-layers intoTheScreen iconStyle" />
                </Tooltip>
              </Checkbox>
            </span>
          ) : (
            <span style={{ display: "inline-block" }}>
              <Tooltip title={"Decline"}>
                <Button
                  shape="circle"
                  icon="close-circle-o"
                  className="iconStyle"
                  style={{
                    marginRight: 16,
                    color: "#FF3E39",
                    border: "none",
                    width: 17,
                    height: 17
                  }}
                  loading={
                    this.state.disapproveLoading
                      ? this.handleLoading(record)
                      : false
                  }
                  disabled={
                    this.state.approvalLoading ||
                    this.state.disapproveLoading ||
                    this.state.disapproveEquipmentLoading ||
                    this.state.approveEquipmentLoading
                      ? true
                      : false
                  }
                  onClick={() => this.disapproveLoanRequest(record)}
                />
              </Tooltip>
              <Tooltip title={"Approve"}>
                <Button
                  shape="circle"
                  icon="check-circle-o"
                  className="iconStyle"
                  style={{
                    marginRight: 16,
                    color: "#3ABF72",
                    border: "none",
                    width: 17,
                    height: 17
                  }}
                  onClick={() => this.approveLoanRequest(record)}
                  loading={
                    this.state.approvalLoading
                      ? this.handleLoading(record)
                      : false
                  }
                  disabled={
                    this.state.disapproveLoading ||
                    this.state.approvalLoading ||
                    this.state.approveEquipmentLoading ||
                    this.state.disapproveEquipmentLoading
                      ? true
                      : false
                  }
                />
              </Tooltip>
            </span>
          )
      },

      {
        title: "REQUEST NUMBER",
        dataIndex: "DisplayRequestId",
        width: 180,
        render: (text, record) => (
          <Tooltip title={record.DisplayRequestId}>
            <span>
              <a
                style={{ color: "#3385FF" }}
                href="#"
                onClick={() => this.onCellClicked(record)}
              >
                {record.DisplayRequestId}
              </a>
            </span>
          </Tooltip>
        )
      },
      {
        title: "REQUESTED BY",
        dataIndex: "RequestorEmail",
        render: (text, record) =>
          record.assets && record.assets.length > 1 ? (
            <Tooltip title="Multiple">
              <span>Multiple</span>{" "}
            </Tooltip>
          ) : (
            <Tooltip title={record.RequestorEmail}>
              <span>{record.RequestorEmail}</span>
            </Tooltip>
          )
      },
      {
        dataIndex: "EquipmentNo",
        title: "EQUIPMENT NUMBER",
        width: 180,
        render: (text, record) =>
          record.assets && record.assets.length > 1 ? (
            <Tooltip title="Multiple">
              <span>Multiple</span>{" "}
            </Tooltip>
          ) : (
            <Tooltip
              title={
                (record.assets && record.assets[0].EquipmentNo) ||
                (record.EquipmentNo == "undefined" ? "" : record.EquipmentNo) ||
                ""
              }
            >
              <span>
                {(record.assets && record.assets[0].EquipmentNo) ||
                  (record.EquipmentNo == "undefined"
                    ? ""
                    : record.EquipmentNo) ||
                  ""}
              </span>
            </Tooltip>
          )
      },
      {
        title: "MODEL NUMBER",
        dataIndex: "ModelNo",

        render: (text, record) =>
          record.assets && record.assets.length > 1 ? (
            <Tooltip title="Multiple">
              <span>Multiple</span>{" "}
            </Tooltip>
          ) : (
            <Tooltip
              title={
                (record.assets && record.assets[0].ModelNo) ||
                (record.ModelNo == "undefined" ? "" : record.ModelNo) ||
                ""
              }
            >
              <span>
                {(record.assets && record.assets[0].ModelNo) ||
                  (record.ModelNo == "undefined" ? "" : record.ModelNo) ||
                  ""}
              </span>
            </Tooltip>
          )
      },
      {
        title: "REQUESTED TIME",
        dataIndex: "",
        render: (text, record) =>
          record.assets && record.assets.length > 1 ? (
            <Tooltip title="Multiple">
              <span>Multiple</span>{" "}
            </Tooltip>
          ) : (
            <Tooltip
              title={`${moment(record.StartDate).format("YYYY-MM-DD")} -
                ${moment(record.EndDate).format("YYYY-MM-DD")}`}
            >
              <span>
                {`${moment(record.StartDate).format("YYYY-MM-DD")} -
                  ${moment(record.EndDate).format("YYYY-MM-DD")}`}
              </span>
            </Tooltip>
          )
      }
    ];
  }
  approveLoanRequest = record => {
    //   this.setState({ iconClickedData: record });
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to approve the request?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({ approvalLoading: true, iconClickedData: record });
        loanPoolStoreV2
          .approveLoanRequest(record)
          .then(() =>
            setTimeout(() => self.setState({ approvalLoading: false }), 5000)
          )
          .catch(() => this.setState({ approvalLoading: false }));
      },
      onCancel() {}
    });
  };
  disapproveLoanRequest = record => {
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to reject the request?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({ disapproveLoading: true, iconClickedData: record });
        loanPoolStoreV2
          .disapproveLoanRequest(record)
          .then(() =>
            setTimeout(() => self.setState({ disapproveLoading: false }), 5000)
          )
          .catch(() => this.setState({ disapproveLoading: false }));
      },
      onCancel() {}
    });
  };
  handleLoading = record => {
    let recordd = {};
    let iconData = {};
    if (record.assets && this.state.iconClickedData.assets) {
      recordd = record.assets[0];
      iconData = this.state.iconClickedData.assets[0];
    } else {
      recordd = record;
      iconData = this.state.iconClickedData;
    }
    return recordd.workFlowId == iconData.workFlowId ? true : false;
  };
  approveEquipmentRequest = record => {
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to approve the request?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({
          approveEquipmentLoading: true,
          iconClickedData: record
        });
        loanPoolStoreV2
          .approveEquipmentRequest(record)
          .then(() =>
            self.setState({
              approveEquipmentLoading: false
            })
          )
          .catch(() => this.setState({ approveEquipmentLoading: false }));
      },
      onCancel() {}
    });
  };

  disapproveEquipmentRequest = record => {
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure you want to approve the request?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({
          disapproveEquipmentLoading: true,
          iconClickedData: record
        });
        loanPoolStoreV2
          .disapproveEquipmentRequest(record)
          .then(() =>
            self.setState({
              disapproveEquipmentLoading: false
            })
          )
          .catch(() => this.setState({ disapproveEquipmentLoading: false }));
      },
      onCancel() {}
    });
  };
  //handling cell click
  onCellClicked(data) {
    loanPoolStoreV2.setRequestAwaitingModelOpen(data);
  }

  //handling the multiple asset toggle button
  onChange = (e, record) => {
    this.handleClick(record, e.target.checked);
  };
  handleClick = ({ key }, enable) => {
    const keys = this.state.expandedRowKeys;
    const expandedRowKeys = enable
      ? keys.concat(key)
      : keys.filter(k => k !== key);
    this.setState({ expandedRowKeys });
  };

  // Request modal methods-starts here
  handleDecline() {
    loanPoolStoreV2.setRequestAwaitingModelOpen(false);
    loanPoolStoreV2.addItemToRequest = false;
  }

  render() {
    return (
      <section className="lp-section-box" style={{ marginTop: 24 }}>
        <h4 style={styleSheets.topGridHeaderText}>
          Requests Awaiting Approval
        </h4>

        <Table
          dataSource={loanPoolStoreV2.processAwaitingRequest(
            loanPoolStoreV2.allLoanPoolRequests
          )}
          columns={this.columnDefs}
          scroll={{ y: "30vh" }}
          pagination={false}
          expandedRowKeys={this.state.expandedRowKeys}
          expandIconColumnIndex={-1}
          loading={!loanPoolStoreV2.dataLoadedForApprovalLP}
          expandIconAsCell={false}
          locale={{
            emptyText: (
              <div>
                <img src={noDataImage} />
                <p 
                    style={{
                    height: "31%",
                    position: "absolute",
                    bottom: "-37%",
                    left: "50%",
                    transform: " translate(-50%, -50%)"
                  }}
                > No Requests Awaiting Approval</p>
              </div>
            )
          }}
          className="request-awaiting-grid"
        />
        {loanPoolStoreV2.requestAwaitingModelOpen ? (
          <LoanPoolRequestModalView
            isRequestModalOpen={loanPoolStoreV2.requestAwaitingModelOpen}
            handleDecline={this.handleDecline.bind(this)}
            modalRequestData={loanPoolStoreV2.requestAwaitingModelOpen}
            showApprovalButtons={true}
          />
        ) : (
          ""
        )}
      </section>
    );
  }
}
const styleSheets = {
  topGridHeaderText: {
    color: "#979797",
    fontFamily: "Open Sans",
    fontSize: 13,
    letterSpacing: 0.47,
    lineHeight: "18px",
    marginBottom: 10
  }
};
export default RequestsAwaitingApproval;
