import React from "react";
import { Tooltip, Progress, Steps } from "antd";
import PropTypes from "prop-types";

const Step = Steps.Step;

let isPreviousStatusFinish = false;
const getStatus = status => {
  if (status == "finish") {
    isPreviousStatusFinish = true;
    return "Finished";
  } else if (status == "wait") {
    if (isPreviousStatusFinish) {
      isPreviousStatusFinish = !isPreviousStatusFinish;
      return "In-Progress";
    } else {
      return "Yet to Start";
    }
  } else if (status == "process") {
    return "In-Progress";
  } else {
    return "";
  }
};
const customDot = (dot, { status }) => (
  <Tooltip
    title={
      <span className="step-tooltip-status">
        Status:
        {getStatus(status)}
      </span>
    }
  >
    <span>{dot}</span>
  </Tooltip>
);

const CustomSteps = ({ stepStatus, percent, strokeWidth }) => (
  <div>
    <div
      style={{
        width: 272,
        margin: "45px auto",
        color: "#108ee9"
      }}
    >
      <Progress percent={percent} strokeWidth={strokeWidth} />
    </div>
    <div
      className="request-approval-stage-steps"
      style={{
        margin: "45px auto"
      }}
    >
      <Steps progressDot={customDot}>
        <Step
          title="Request Approved"
          status={stepStatus.awaitingApproval}
          data-status={stepStatus.awaitingApproval}
        />
        <Step
          title="Asset Prepared"
          status={stepStatus.preparingAsset}
          data-status={stepStatus.preparingAsset}
        />
        <Step
          title="Asset Delivered"
          status={stepStatus.deliveryingAsset}
          data-status={stepStatus.deliveryingAsset}
        />
        <Step
          title="Asset Received"
          status={stepStatus.assetReceived}
          data-status={stepStatus.assetReceived}
        />
      </Steps>
    </div>
  </div>
);

export default CustomSteps;
CustomSteps.propTypes = {
  stepStatus: PropTypes.object,
  percent: PropTypes.number,
  strokeWidth: PropTypes.number
};
