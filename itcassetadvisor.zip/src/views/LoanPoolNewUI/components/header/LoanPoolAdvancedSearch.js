import React, { Component } from "react";
import { observer } from "mobx-react";
import moment from "moment";
import "../../css/LPNew.scss";
import {
  Cascader,
  Card,
  Row,
  Form,
  Input,
  DatePicker,
  Icon,
  Col,
  Select,
  Button,
  Spin
} from "antd";
const FormItem = Form.Item;
// import Slider from "react-rangeslider";
import "react-rangeslider/umd/rangeslider.css";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import PropTypes from "prop-types";
import Autosuggest from "react-autosuggest";
import styled from "styled-components";
const RangePicker = DatePicker.RangePicker;

const Div = styled.div`
.manufacturerWrapper{
  align-items:flex-end;
.header-close-icon-ML{
  position: absolute;
  right: 42px;
  height: 200px;
  width: 50%;
  margin-right: 2px;
  margin-top: 2px;
  i{
    font-size:14px;
    :hover{
      color:rgb(255, 61, 95);
      cursor:pointer;
    }
  }

  .disabled-close-icon{
    font-size:14px;
    :hover{
      color:inherit;
      cursor: inherit;
    }
  }
}`;

/*eslint-disable*/
const element = document.getElementsByClassName("loanPoolWrapper")[0];

//console.log("element",element)

@observer
class LoanPoolAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      availabilityThreashold: 0,
      reverseValue: 8,
      lastSelectedSuggestion: null,
      searchValues: null,
      manufacturerValue: "",
      suggestions: [],
      isloading: false
    };
  }
  onChange = (event, { newValue }) => {
    this.setState({
      manufacturerValue: newValue
    });
    this.props.form.setFieldsValue({ Manufacturer: newValue });
  };
  // shouldComponentUpdate(nextProps, nextState) {
  //     if (!nextProps.lastSelectedSuggestion) return true;
  //     if (this.props.lastSelectedSuggestion === nextProps.lastSelectedSuggestion)
  //         return true;
  //     else {
  //         setTimeout(() => {
  //             this.props.form.setFieldsValue(nextProps.lastSelectedSuggestion);
  //         }, 500);
  //     }
  //     if (this.state.searchValues === nextState.searchValues) return false;
  //     return true;
  // }
  handleClear = () => {
    this.props.form.resetFields();
    this.resetForm();

    this.setState({ availabilityThreashold: 0 });
  };
  handleSubmit = () => {
    this.props.form.validateFieldsAndScroll((err, values) => {
      let defaultVal = {
        ModelNo: "",
        ProductCategory: "",
        Manufacturer: "",
        EquipmentNo: "",
        EquipmentType: "",
        CalibrationStatus: "",
        Organization: "",
        Location: "",
        Coordinator: "",
        User: "",
        StartDate: moment().startOf("day"),
        EndDate: moment()
          .add(1, "M")
          .startOf("day")
      };
      let searchValues = { ...defaultVal, ...values };
      this.setState({ searchValues: values });
      values.LoanDateRange
        ? ((searchValues.StartDate = values.LoanDateRange[0]),
          (searchValues.EndDate = values.LoanDateRange[1]))
        : "";
      delete searchValues.LoanDateRange;
      searchValues.AvailabilityThreshold = this.state.availabilityThreashold;
      loanPoolStoreV2.loanableAssetsAdvancedSearch(searchValues);
      loanPoolStoreV2.setIsSearchApiCalled(true);
      //clear solr search field if any other search parameters found
      Object.values(searchValues).map(i => {
        if (!(i === "" || i === 0 || moment(i).isValid() || i === undefined)) {
          let lastValue = Object.values(
            loanPoolStoreV2.lastSelectedSuggestion
          )[0];
          if (lastValue != i)
            document.getElementsByClassName(
              "react-autosuggest__input"
            )[0].value = "";
        }
      });
    });
  };
  resetForm = () => {
    if (
      loanPoolStoreV2.normalViewMode ||
      loanPoolStoreV2.reviewerViewMode != "ADVANCED"
    ) {
      // loanPoolStoreV2.resetlastAdvSearchData(null);
      return;
    }
    this.props.form.setFieldsValue({
      ModelNo: "",
      ProductCategory: "",
      Manufacturer: "",
      EquipmentNo: "",
      EquipmentType: "",
      CalibrationStatus: "",
      Organization: "",
      Location: "",
      Coordinator: "",
      User: "",
      LoanDateRange: [
        moment().startOf("day"),
        moment()
          .add(1, "M")
          .startOf("day")
      ]
    });
  };
  disabledDate = current => {
    return (
      current &&
      current <=
        moment()
          .endOf("day")
          .subtract(1, "day")
    );
  };
  componentDidMount() {
    if (
      (loanPoolStoreV2.normalViewMode == "ADVANCED") &
      (this.state.searchValues == null) &
      (loanPoolStoreV2.reviewerMode == false)
    ) {
      loanPoolStoreV2.dataLoaded = false;
      loanPoolStoreV2.loanableAssetsAdvancedSearch(
        loanPoolStoreV2.lastAdvSearchData
      );
    }
    loanPoolStoreV2.setAdvancedSearchForm(this.props.form);
  }
  //   componentDidUpdate() {
  //       setTimeout(() => {
  //           this.props.form.validateFieldsAndScroll((err, values) => {
  //               let onlyValues = Object.values(values);
  //               var found = onlyValues.find(function(element) {
  //                   return element !== undefined;
  //               });
  //               if (!found && !this.state.searchValues) return this.resetForm();

  //               if (!JSON.stringify(this.state.searchValues)) return;
  //               if (JSON.stringify(values) == JSON.stringify(this.state.searchValues))
  //                   return;
  //               let valuesWithoutDate = JSON.parse(JSON.stringify(values));
  //               delete valuesWithoutDate.LoanDateRange;
  //               // console.log(
  //               //   "valuesWithoutDate",
  //               //   Object.keys(valuesWithoutDate).length,
  //               //   JSON.stringify(valuesWithoutDate) ? true : false
  //               // );
  //               if (Object.keys(valuesWithoutDate).length) return;
  //               let searchValues = this.state.searchValues;
  //               if (searchValues) {
  //                   // console.log("searchValues", searchValues);
  //                   searchValues.LoanDateRange == undefined
  //                       ? (searchValues.LoanDateRange = [
  //                           moment().startOf("day"),
  //                           // .toISOString(),
  //                           moment()
  //                               .add(1, "M")
  //                               .startOf("day")
  //                           // .toISOString()
  //                       ])
  //                       : "";
  //                   // console.log("searchValues", searchValues);
  //                   this.props.form.setFieldsValue(searchValues);
  //               }
  //           });
  //       }, 500);
  //   }
  closeCascaderMenu = () => {
    // ant-cascader-menus  ant-cascader-menus-placement-bottomLeft  ant-cascader-menus-hidden
    const menus = document.getElementsByClassName("ant-cascader-menus");
    [...menus].map(e => e.classList.add("ant-cascader-menus-hidden"));
  };

  getSuggestions = value => {
    const list = loanPoolStoreV2.getManufacturerList();
    // console.log('List of Mnfct :',list);
    const inputValue = value.trim().toLowerCase();
    const inputLength = inputValue.length;

    return inputLength === 0
      ? []
      : list.filter(
          item =>
            // item.toLowerCase().slice(0, inputLength) === inputValue
            item.toLowerCase().indexOf(inputValue.toLowerCase()) === 0
        );
  };
  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      isloading: true,
      suggestions: this.getSuggestions(value)
    });
  };
  onSuggestionSelected = (event, { suggestion }) => {
    //eslint-disable-next-line
    //console.log("onSuggestionSelected", (event, { suggestion }));
    this.setState({
      manufacturerValue: suggestion,
      isSelected: true,
      isloading: false
    });
    this.props.form.setFieldsValue({ Manufacturer: suggestion });
    // $(this.autocompleteInputClass).autocomplete("{Manufacturer:suggestion}", "delay", 1000);
  };
  // Autosuggest will call this function every time you need to clear suggestions.
  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: [],
      isloading: false
    });
  };
  // getSuggestionValue = suggestion => suggestion;
  getSuggestionValue = suggestion => {
    //console.log('Suggestipoons',suggestion);
    return "test";
  };
  renderSuggestion = suggestion => <div>{suggestion}</div>;
  render() {
    const { getFieldDecorator } = this.props.form;
    const { manufacturerValue, suggestions, isloading } = this.state;
    const { disabled } = this.props;
    const propValue = this.props.form.getFieldValue("Manufacturer");
    //console.log("propValue",propValue,value );
    //console.log("Value",value );
    // const { availabilityThreashold } = this.state;
    // var sliderPercent = availabilityThreashold + "%";
    const cardStyle = {
      maxHeight: window.innerHeight - 250,
      width: "100%",
      marginTop: 8,
      overflow: "auto"
    };
    const inputProps = {
      placeholder: "",
      value: propValue ? propValue : manufacturerValue ? manufacturerValue : "",
      onChange: this.onChange,
      disabled: disabled
    };
    let clearButton;

    clearButton = (
      <Icon
        className={disabled ? "disabled-close-icon" : "close-icon"}
        type="close"
        onClick={
          disabled ? () => {} : () => this.onChange("e", { newValue: "" })
        }
      />
    );

    //eslint-disable-next-line
    // console.log("onSuggestionSelected",val );

    // return !loanPoolStoreV2.dataLoaded ? (
    //   <Card style={cardStyle} loading />
    // ) : (
    return (
      <div className="lp-grid-wrapper" style={{ marginTop: 25 }}>
        <div style={{ color: "#79838c", marginBottom: 4 }}>Refine Search</div>
        <Spin spinning={!loanPoolStoreV2.dataLoaded} delay={300}>
          <Card style={cardStyle} onScroll={this.closeCascaderMenu}>
            <Form
              onSubmit={this.handleSubmit}
              autoComplete="off"
              layout="vertical"
              className="advance-search-form"
            >
              <FormItem label="Loan Date Range">
                {getFieldDecorator("LoanDateRange")(
                  <RangePicker style={{ width: "100%" }} />
                )}
              </FormItem>
              {/* <FormItem label="Availability Threshold">
              {getFieldDecorator("slider", {})(
                <Row>
                  <Col span={18}>
                    <div className="slider orientation-reversed">
                      <div className="slider-group">
                        <div className="slider-horizontal">
                          <Slider
                            className="custom-slider"
                            style={{ backgroundColor: "#108ee9" }}
                            min={0}
                            max={100}
                            value={availabilityThreashold}
                            orientation="horizontal"
                            onChange={val =>
                              this.setState({ availabilityThreashold: val })
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </Col>
                  <Col span={5}>
                    <div style={{ marginTop: 2, marginLeft: 5 }}>
                      <Input value={sliderPercent} disabled />
                    </div>
                  </Col>
                </Row>
              )}
            </FormItem> */}
              <FormItem label="Model Number">
                {getFieldDecorator("ModelNo", {})(<Input />)}
              </FormItem>
              <FormItem label="Manufacturer">
                {getFieldDecorator("Manufacturer", {
                  rules: []
                })(
                  // <Select
                  //   placeholder="Please select a manufacturer"
                  //   allowClear
                  //   getPopupContainer={trigger => trigger.parentElement}
                  // >
                  //   {loanPoolStoreV2
                  //     .getManufacturerList()
                  //     .map(dropdown => (
                  //       <option key={dropdown}>{dropdown}</option>
                  //     ))}
                  // </Select>
                  // const getSuggestions = value => {
                  //   // const listOfManufacturer = loanPoolStoreV2.getManufacturerList();
                  // }

                  // const getSuggestionValue = suggestion => suggestion.name;

                  // // Use your imagination to render suggestions.
                  // const renderSuggestion = suggestion => (
                  //   <div>
                  //     {suggestion.name}
                  //   </div>
                  // );

                  // this.state = {
                  //       value: '',
                  //       suggestions: []
                  //     };
                  //   }

                  //   onChange = (event, { newValue }) => {
                  //     this.setState({
                  //       value: newValue
                  //     });
                  //   };

                  //   onSuggestionsFetchRequested = ({ value }) => {
                  //     this.setState({
                  //       suggestions: getSuggestions(value)
                  //     });
                  //   };

                  //   // Autosuggest will call this function every time you need to clear suggestions.
                  //   onSuggestionsClearRequested = () => {
                  //     this.setState({
                  //       suggestions: []
                  //     });
                  //   };

                  // render() {
                  //   const { value, suggestions } = this.state;

                  //   // Autosuggest will pass through all these props to the input.
                  //   const inputProps = {
                  //     placeholder: 'Please select a manufacturer',
                  //     value,
                  //     onChange: this.onChange
                  //   };

                  // Finally, render it!
                  // return (
                  <Div className="manufacturerWrapper">
                    <Autosuggest
                      suggestions={suggestions}
                      onSuggestionsFetchRequested={
                        this.onSuggestionsFetchRequested
                      }
                      onSuggestionsClearRequested={
                        this.onSuggestionsClearRequested
                      }
                      getSuggestionValue={this.getSuggestions}
                      renderSuggestion={this.renderSuggestion}
                      onSuggestionSelected={this.onSuggestionSelected}
                      inputProps={inputProps}
                    />
                    <div className="header-close-icon-ML">{clearButton}</div>

                    <Icon
                      type={isloading ? "loading" : "search"}
                      style={{ fontSize: "14px" }}
                    />
                  </Div>
                )}
              </FormItem>
              <FormItem label="Product Category">
                {getFieldDecorator("ProductCategory", {})(
                  <Select
                    placeholder="Please select a product category"
                    allowClear
                    getPopupContainer={trigger => trigger.parentElement}
                  >
                    {loanPoolStoreV2
                      .getPageWiseDropDownValues("ProductCategory")
                      .map(dropdown => (
                        <option key={dropdown}>{dropdown}</option>
                      ))}
                  </Select>
                )}
              </FormItem>

              <FormItem label="Equipment Number">
                {getFieldDecorator("EquipmentNo", {})(<Input />)}
              </FormItem>
              <FormItem label="Equipment Type">
                {getFieldDecorator("EquipmentType", {})(
                  <Select
                    placeholder="Please select an equipment type"
                    allowClear
                    getPopupContainer={trigger => trigger.parentElement}
                  >
                    {loanPoolStoreV2
                      .getPageWiseDropDownValues("EquipmentType")
                      .map(dropdown => (
                        <option key={dropdown}>{dropdown}</option>
                      ))}
                  </Select>
                )}
              </FormItem>
              <FormItem label="Last Reported Condition">
                {getFieldDecorator("LastReportedCondition", {})(
                  <Select
                    placeholder="Please select a Last Reported Condition"
                    allowClear
                    getPopupContainer={trigger => trigger.parentElement}
                  >
                    {loanPoolStoreV2
                      .getPageWiseDropDownValues("LastReportedCondition")
                      .map(dropdown => (
                        <option key={dropdown}>{dropdown}</option>
                      ))}
                  </Select>
                )}
              </FormItem>
              <FormItem label="Calibration Status">
                {getFieldDecorator("CalibrationStatus", {})(
                  <Select
                    placeholder="Please select Calibration Status"
                    allowClear
                    getPopupContainer={trigger => trigger.parentElement}
                  >
                    {loanPoolStoreV2
                      .getPageWiseDropDownValues("CalibrationStatus")
                      .map(dropdown => (
                        <option key={dropdown}>{dropdown}</option>
                      ))}
                  </Select>
                )}
              </FormItem>
              <FormItem label="Organization">
                {getFieldDecorator("Organization", {})(
                  <Cascader
                    getPopupContainer={this.getContainer}
                    trigger="click"
                    options={loanPoolStoreV2.OrganizationTree}
                    changeOnSelect
                    popupClassName="Advance-org"
                    placeholder="Please select an organization"
                  />
                )}
              </FormItem>
              <FormItem label="Location">
                {getFieldDecorator("Location", {})(
                  <Cascader
                    getPopupContainer={this.getContainer}
                    trigger="click"
                    options={loanPoolStoreV2.LocationTree}
                    changeOnSelect
                    popupClassName="Advance-org"
                    placeholder="Please select a location"
                  />
                )}
              </FormItem>
            </Form>
          </Card>
          <Card style={{ marginTop: 8, bottom: 15, height: 80 }}>
            <Row gutter={20}>
              <Col span={4} />
              <Col span={8}>
                <Button
                  size="large"
                  style={{ marginLeft: "-25px" }}
                  onClick={this.handleClear.bind(this)}
                  id="clr_button"
                >
                  <Icon type="close" />
                  Clear
                </Button>
              </Col>
              <Col span={8}>
                <Button
                  size="large"
                  type="primary"
                  id="btn_advsearch"
                  style={{ backgroundColor: "green", marginLeft: "5px" }}
                  onClick={this.handleSubmit.bind(this)}
                >
                  <Icon type="search" />
                  Search
                </Button>
              </Col>
            </Row>
          </Card>
        </Spin>
      </div>
    );
  }
}

export default Form.create()(LoanPoolAdvancedSearch);

LoanPoolAdvancedSearch.propTypes = {
  form: PropTypes.object,
  disabled: PropTypes.bool
};
