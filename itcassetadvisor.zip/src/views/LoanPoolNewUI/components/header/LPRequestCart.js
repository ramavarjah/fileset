import React from "react";
import { Modal, Icon, Row, Col, Button, DatePicker } from "antd";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import AssetCard from "src/views/Components/Cards/AssetCard";
import mobx from "mobx";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import moment from "moment";
const RangePicker = DatePicker.RangePicker;

function Title() {
  const cartItem = mobx.toJS(loanPoolStoreV2.cartItems);
  return (
    <span className="model-modal-header">
      <Icon
        className="shoppingcart-icon"
        type="shopping-cart"
        theme="outlined"
      />
      Request Cart
      {cartItem.length != 0 ? (
        <div
          className="proceed-checkout"
          style={{ justifyContent: "center", alignItems: "center" }}
        >
          <span className="vertical-small-divider" />

          <Link to="/loan-pool-notifications/loan-pool-new-request">
            <span
              className="proceed-checkout"
              style={{ color: "#ffae1c" }}
              onClick={() => {
                loanPoolStoreV2.getDataFromDuplicate = false;
              }}
            >
              <Icon
                className="right-arrow-cart"
                type="arrow-right"
                theme="outlined"
              />
              Proceed to Checkout
            </span>
          </Link>
        </div>
      ) : (
        ""
      )}
    </span>
  );
}
class LPRequestCart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      removeCartLoading: false,
      iconClickedData: {},
      disabledDateRange: false
    };
  }
  handleDecline() {
    this.props.onClose();
  }
  onDeleteItem = item => {
    this.setState({ removeCartLoading: true, iconClickedData: item });
    loanPoolStoreV2
      .removeFromCart(item)
      .then(() => this.setState({ removeCartLoading: false }))
      .catch(() => this.setState({ removeCartLoading: false }));
  };
  disabledDate = current => {
    return (
      current &&
      current <=
        moment()
          .endOf("day")
          .subtract(1, "day")
    );
  };
  onDateRangeChange = (val, data) => {
    data.RequestedStartDate = val[0].toISOString();
    data.RequestedEndDate = val[1].toISOString();
    this.setState({
      removeCartLoading: true,
      disabledDateRange: true
    });
    loanPoolStoreV2
      .updateCartItems(data)
      .then(() =>
        this.setState({
          removeCartLoading: false,
          disabledDateRange: false
        })
      )
      .catch(() =>
        this.setState({
          removeCartLoading: false,
          disabledDateRange: false
        })
      );
  };
  getAllItems = () => {
    const cartItem = mobx.toJS(loanPoolStoreV2.cartItems);
    cartItem["Action"] = "EXIST";
    return cartItem
      .slice(0)
      .reverse()
      .map((item, index) => (
        <div key={index}>
          <hr />
          <Row>
            <Row gutter={24}>
              <Col xs={24} sm={6} md={8} lg={8} xl={8} />{" "}
              {/* to get empty space */}
            </Row>
            <Row gutter={24}>
              <Col xs={24} sm={8} md={8} lg={8} xl={8}>
                <div
                  className="request-modal-asset-details"
                  style={{ marginTop: 30 }}
                >
                  <AssetCard
                    modelNo={item.ModelNo}
                    dummyUrl="/img/no-asset-image.png"
                    alt="keysightAssetImage"
                    width={item.HasExternalRequest ? "250px" : "170px"}
                    height="170px"
                    hasExternalRequest={item.HasExternalRequest}
                    size={true}
                  />
                </div>
              </Col>
              <Col xs={18} sm={14} md={14} lg={14} xl={14}>
                <div className="request-modal-asset-details request-cart-results">
                  <p
                    className="request-cart-results"
                    style={{ color: "#3385FF", fontWeight: "700" }}
                  >
                    {item.Description == "undefined" ? "" : item.Description}
                  </p>
                  <p
                    className="request-cart-results"
                    style={{ color: "#3385FF", fontWeight: "700" }}
                  >
                    Details:
                  </p>
                  {item.HasExternalRequest ? (
                    <div className="model-modal-details">
                      <h4 className="request-details">
                        Model Number:{" "}
                        <span className="request-cart-results">
                          {item.ModelNo == "undefined" ? "" : item.ModelNo}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Manufacturer:{" "}
                        <span className="request-cart-results">
                          {item.Manufacturer == "undefined"
                            ? ""
                            : item.Manufacturer}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Request Location:{" "}
                        <span className="request-cart-results">
                          {item.Location == "undefined" ? "" : item.Location}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Requested Date Range:{" "}
                        <span className="request-cart-results">
                          <RangePicker
                            allowClear={false}
                            onChange={e => this.onDateRangeChange(e, item)}
                            defaultValue={[
                              moment(
                                loanPoolStoreV2.getDataFromDuplicate
                                  ? item.StartDate
                                  : item.RequestedStartDate
                              ),
                              moment(
                                loanPoolStoreV2.getDataFromDuplicate
                                  ? item.EndDate
                                  : item.RequestedEndDate
                              )
                            ]}
                            disabledDate={this.disabledDate}
                            disabled={this.state.disabledDateRange}
                            style={{ width: "200px", cursor: "pointer" }}
                          />
                        </span>
                      </h4>
                    </div>
                  ) : (
                    <div className="model-modal-details">
                      <h4 className="request-details">
                        Equipment Number:{" "}
                        <span className="request-cart-results">
                          {item.EquipmentNo == "undefined"
                            ? ""
                            : item.EquipmentNo}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Manufacturer:{" "}
                        <span className="request-cart-results">
                          {item.Manufacturer == "undefined"
                            ? ""
                            : item.Manufacturer}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Model Number:{" "}
                        <span className="request-cart-results">
                          {item.Manufacturer == "undefined" ? "" : item.ModelNo}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Organization:{" "}
                        <span className="request-cart-results">
                          {item.Organization == "undefined"
                            ? ""
                            : item.Organization}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Location:{" "}
                        <span className="request-cart-results">
                          {item.Location == "undefined" ? "" : item.Location}
                        </span>
                      </h4>
                      <h4 className="request-details">
                        Requested Date Range:{" "}
                        <span className="request-cart-results">
                          <RangePicker
                            allowClear={false}
                            onChange={e => this.onDateRangeChange(e, item)}
                            defaultValue={[
                              moment(
                                loanPoolStoreV2.getDataFromDuplicate
                                  ? item.StartDate
                                  : item.RequestedStartDate
                              ),
                              moment(
                                loanPoolStoreV2.getDataFromDuplicate
                                  ? item.EndDate
                                  : item.RequestedEndDate
                              )
                            ]}
                            disabledDate={this.disabledDate}
                            disabled={this.state.disabledDateRange}
                            style={{ width: "200px", cursor: "pointer" }}
                          />
                        </span>
                      </h4>
                    </div>
                  )}
                </div>
              </Col>
              <Col xs={2} sm={2} md={2} lg={2} xl={2}>
                <div
                  className="request-modal-asset-details"
                  style={{ marginTop: 75 }}
                >
                  {/* {item.showApprovalButtons ? "" : <p>Actions</p>} - for reviwer mode */}
                  <div>
                    <Button
                      shape="circle"
                      icon="close-circle-o"
                      className="delete-item-icon"
                      loading={
                        this.state.removeCartLoading
                          ? item.UniqueID == this.state.iconClickedData.UniqueID
                            ? true
                            : false
                          : false
                      }
                      disabled={this.state.removeCartLoading ? true : false}
                      onClick={() => this.onDeleteItem(item)}
                    />
                  </div>
                </div>
              </Col>
            </Row>
          </Row>
          <br />
        </div>
      ));
  };
  render() {
    const { visible } = this.props;
    const cartItem = mobx.toJS(loanPoolStoreV2.cartItems);
    let assetsArray = [];
    loanPoolStoreV2.cartItems.map(i => {
      const { RequestedStartDate, RequestedEndDate } = i;
      assetsArray.push({
        asset: i.UniqueID,
        startDate: RequestedStartDate,
        endDate: RequestedEndDate
      });
    });

    const cartTop = {
      top: (window.innerHeight - 500) / 2,
      padding: 0
    };
    const contentStyles = {
      color: "rgba(12,34,45)",
      fontWeight: "500",
      maxHeight: 450,
      overflow: "auto",
      padding: 16
    };
    return (
      <div>
        <Modal
          title={<Title />}
          visible={visible}
          bodyStyle={contentStyles}
          onCancel={
            this.state.removeCartLoading ? "" : this.handleDecline.bind(this)
          }
          maskClosable={false}
          footer={null}
          width="750px"
          style={cartTop}
          className="request-cart-modal"
        >
          <div>
            {cartItem.length > 0 ? (
              <div className="outerDiv">{this.getAllItems()}</div>
            ) : (
              <div>
                <p
                  className="emptyCart-message"
                  style={{ textAlign: "center" }}
                >
                  <Icon type="shopping-cart" style={{ fontSize: 60 }} />
                  <br />
                  Your cart is empty!
                </p>
              </div>
            )}
          </div>
        </Modal>
      </div>
    );
  }
}

export default LPRequestCart;
LPRequestCart.propTypes = {
  visible: PropTypes.bool,
  onClose: PropTypes.func
};
