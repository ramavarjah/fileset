import React, { Component } from "react";
import { observer } from "mobx-react";
import { Layout, Button, Icon, Switch } from "antd";
import Autosuggest from "react-autosuggest";
import loanPoolStoreV2 from "../../../../stores/loanPoolStoreV2";
import permissionStore from "src/stores/permissionStore";
import Functions from "../../../../api/Functions";
import _ from "lodash";
import LPRequestCart from "./LPRequestCart";
import ExternalRequestModalForm from "./ExternalRequestModalForm";
import NotificationBadge, { Effect } from "react-notification-badge";
import tabModelStore from "../../../../stores/tabModelStore";
import moment from "moment";
import { createBrowserHistory } from "history";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import { setTimeout } from "timers";
const { Header } = Layout;
const history = createBrowserHistory();
import mobx from "mobx";
import UIFunctions from "src/helpers/UIFunctions";
import userStore from "src/stores/userStore";
// import debounce from "loadash"
// When suggestion is clicked, Autosuggest needs to populate the input
// based on the clicked suggestion. Teach Autosuggest how to calculate the
// input value for every given suggestion.
// Use your imagination to render suggestions.
const renderSuggestion = suggestion => (
  <div
    style={{
      color: "white",
      zIndex: 10000000,
      backgroundColor: "grey",
      marginBottom: 1,
      borderBottomColor: "black"
    }}
  >
    {suggestion.searchStr}
  </div>
);
const getSuggestionValue = suggestion => suggestion.searchStr;

@observer
class LoanPoolHeader extends Component {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.state = {
      pressEnter: true,
      isOpen: false,
      isRequestCartOpen: false,
      value: "",
      suggestions: [],
      searchOn: false,
      isExternalRequestModalOpen: false,
      loading: false,
      toggleState: false,
      lastQS: undefined
    };
    this.search = _.debounce(this.search.bind(this), 300);
  }

  onChange = (event, { newValue, method }) => {
    if (method == "up" || method == "down") {
      this.setState({ pressEnter: false });
    }
    this.setState({
      value: newValue
    });
  };
  onSearchclick() {
    this.setState({
      searchOn: true
    });
  }
  filterIt = (localItems, queryStringinput) => {
    let local = mobx.toJS(localItems);
    for (let i = 0; i < local.length; i++) {
      for (let prop in local[i]) {
        if (prop != "markers") {
          local[i][prop] = local[i][prop].toString().toLowerCase();
        }
      }
    }
    return local.filter(obj =>
      Object.keys(obj).some(function (key) {
        if (
          key != "Availability" &&
          key != "LoanDailyCost" &&
          key != "markers"
        ) {
          return obj[key].includes(queryStringinput.toLowerCase());
        }
      })
    );
  };
  onSearchButton() {
    var queryStringinput = this.state.value;
    if (queryStringinput.length >= 0) {
      if (loanPoolStoreV2.checkAvailabilityMode) {
        this.setState({ loading: true });
        let results = [];
        let localItems = loanPoolStoreV2.itemsToShowCheckAvailability[0];
        results = this.filterIt(localItems, queryStringinput);
        let localItemsJS = mobx.toJS(localItems);
        let filteredresult = [];
        for (let i = 0; i < results.length; i++) {
          outerloop: for (let j = 0; j < localItemsJS.length; j++) {
            if (results[i].EquipmentNo.toLowerCase() === localItemsJS[j].EquipmentNo.toLowerCase()) {
              filteredresult.push(localItemsJS[j]);
              break outerloop;
            }
          }
        }
        setTimeout(() => {
          this.setState({ loading: false });
          loanPoolStoreV2.filteredItemsToShowCheckAvailability[0] = filteredresult;
        }, 500);
      } else {
        if (queryStringinput.length >= 2) {
          loanPoolStoreV2.dataLoaded = false;
          let test = queryStringinput.indexOf(' in ');
          if (test > - 1) {
            let testObj = {}
            let displayNames = JSON.parse(
              JSON.stringify(loanPoolStoreV2.gridDataModel)
            );
            for (let j = 0; j < displayNames.length; j++) {
              testObj[displayNames[j].key] = displayNames[j].name;
            }
            let searchValue = queryStringinput.substring(0, test);
            let colName = queryStringinput.substring(test + 4, queryStringinput.length);
            let colNameKey = ""
            Object.entries(testObj).forEach(entry => {
              let key = entry[0];
              let value = entry[1];
              if (value == colName) {
                colNameKey = key
              }
            })
            let selectedSuggestion = {};
            selectedSuggestion[colNameKey] = searchValue;
            loanPoolStoreV2.setNormalViewMode("ADVANCED");
            loanPoolStoreV2.setIsSearchApiCalled(true);
            loanPoolStoreV2.loanableAssetsDirectSearch(selectedSuggestion);
          }
          else {
            Functions.GetLoanableAssetsDataForGlobalSearch({
              InputJson: {
                StartDate: moment()
                  .startOf("day")
                  .toISOString(),
                EndDate: moment()
                  .add(1, "M")
                  .startOf("day")
                  .toISOString(),
                AvailabilityThreshold: "",
                queryString: queryStringinput,
                Context: "LoanPool"
              }
            }).then(resp => {
              loanPoolStoreV2.setQueryOutputBorrowableAssets([]);
              loanPoolStoreV2.borrowableAssets = resp.data.gridData.data;
              loanPoolStoreV2.setCompleteBorrowableAssets(loanPoolStoreV2.borrowableAssets);
              loanPoolStoreV2.setQueryOutputBorrowableAssets(resp.data.gridData.data);
              loanPoolStoreV2.caCheckboxedItems = resp.data.gridData.data;
              loanPoolStoreV2.dataLoaded = true;
              function parseDataForForm(dataa) {
                let data = dataa;
                data.Location ? (data.Location = this.parseTree(data.Location)) : "";
                data.Organization
                  ? (data.Organization = this.parseTree(data.Organization))
                  : "";
                return data;
              }
              if (loanPoolStoreV2.advancedSearchForm) {
                loanPoolStoreV2.advancedSearchForm.setFieldsValue(
                  parseDataForForm(loanPoolStoreV2.lastAdvSearchData)
                );
              }
              loanPoolStoreV2.reviewerMode
                ? loanPoolStoreV2.setReviewerViewMode("NORMAL")
                : loanPoolStoreV2.setNormalViewMode("ADVANCED");
            });
          }
        }
      }
    }
  }
  _handleKeyPress = e => {
    if (e.key === "Enter") {
      this.state.pressEnter ? this.onSearchButton() : "";
    }
  };
  onRequestCart() {
    this.setState({
      isRequestCartOpen: true
    });
  }
  handleRequestCartClose() {
    this.setState({ isRequestCartOpen: false });
  }
  // Autosuggest will call this function every time you need to clear suggestions.
  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };
  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }
  search(value) {

    if (!loanPoolStoreV2.checkAvailabilityMode) {
      if (value.value.length >= 2) {
        this.setState({ loading: true, lastQS: value.value });
        Functions.GetSolrSearchResult(value.value, "LoanPool")
          .then(resp => {

            const { lastQS } = this.state
            if (lastQS !== value.value) return //prevent all previous requests

            var srcStr = value.value;
            var response = resp.data.response;
            var data = [];
            if (response && response.numFound > 0) {
              var docs = response.docs;
              var len = docs.length;
              var regEx = new RegExp(srcStr, "i");
              var exist;
              var test = {};
              var displayNames = JSON.parse(
                JSON.stringify(loanPoolStoreV2.gridDataModel)
              );
              for (var j = 0; j < displayNames.length; j++) {
                test[displayNames[j].key] = displayNames[j].name;
              }
              for (var i = 0; i < len; i++) {
                for (var key in docs[i]) {
                  if (typeof docs[i][key] != "string") {
                    docs[i][key] = "" + docs[i][key];
                  }
                  if (
                    typeof docs[i][key] === "string" &&
                    docs[i][key].search(regEx) >= 0
                  ) {
                    exist = false;

                    for (var index = 0; index < data.length; index++) {
                      var item = data[index];

                      if (
                        item.colName === key &&
                        item.searchValue === docs[i][key]
                      ) {
                        exist = true;
                      }
                    }

                    if (!exist) {
                      if (key !== "UniqueID") {
                        data.push({
                          colName: key,
                          searchValue: docs[i][key],
                          searchStr: docs[i][key] + " in " + test[key]
                        });
                      }
                    }
                  }
                }
              }
              this.setState({ suggestions: data, loading: false });
            }
            this.setState({ suggestions: data, loading: false });
          })
          .catch(() => this.setState({ loading: false }));
      }
    } else {
      this.setState({ loading: false });
    }
  }

  onSuggestionSelected = (event, { suggestion }) => {
    document.getElementById("clr_button").click();
    var selectedSuggestion = {};
    selectedSuggestion[suggestion.colName] = suggestion.searchValue;
    loanPoolStoreV2.setNormalViewMode("ADVANCED");
    loanPoolStoreV2.setIsSearchApiCalled(true);
    loanPoolStoreV2.loanableAssetsDirectSearch(selectedSuggestion);
    setTimeout(() => {
      // document.getElementById("btn_advsearch").click();
      this.setState({ pressEnter: true });
    }, 1000);
  };
  onExternalRequest = () => {
    this.setState({ isExternalRequestModalOpen: true });
  };
  handleExternalRequestModalClose() {
    this.setState({ isExternalRequestModalOpen: false });
  }
  onLeftClick = () => {
    loanPoolStoreV2.doNotUpdate = true;
    loanPoolStoreV2.borrowableAssets = loanPoolStoreV2.completeBorrowableAssets;
    loanPoolStoreV2.getDataFromDuplicate = false;
    history.go(-1);
  };
  onRightClick = () => {
    loanPoolStoreV2.doNotUpdate = true;
    loanPoolStoreV2.borrowableAssets = loanPoolStoreV2.completeBorrowableAssets;
    loanPoolStoreV2.getDataFromDuplicate = false;
    history.go(1);
  };
  onHomeClick = () => {
    loanPoolStoreV2.setIsBackArrowVisible(false);
    loanPoolStoreV2.doNotUpdate = true;
    loanPoolStoreV2.setNormalViewMode("NORMAL");
    loanPoolStoreV2.setInitialNormalViewMode("NORMAL");
    loanPoolStoreV2.lpborrowableSelectedRows = [];
    loanPoolStoreV2.setIsSearchApiCalled(false);
    loanPoolStoreV2.resetAdvSearchData();
    this.setState({ value: "" });
    loanPoolStoreV2.caCheckboxedItems = [];
    loanPoolStoreV2.borrowableAssets = loanPoolStoreV2.allBorrowableAssets;
    loanPoolStoreV2.getDataFromDuplicate = false;
    if (loanPoolStoreV2.reviewerMode == true) {
      setTimeout(() => {
        document.getElementById("reviewerModeswitch").click();
      }, 0);
    }
  };
  toggleTheSwitch = () => {
    var permission = mobx.toJS(permissionStore.getpermissions);
    if (
      userStore.userDetails &&
      userStore.userDetails.UserName ==
      `${userStore.userDetails.CustomerId}-Admin`
    ) {
      UIFunctions.ShowInfo({
        zIndex: 2000,
        title: "Default site admin cannot access this feature."
      });
      this.setState({ toggleState: false });
    } else if (!permission.icons.LPCordinator & permission.icons.Admin) {
      UIFunctions.ShowInfo({
        zIndex: 2000,
        title:
          "Please make yourself a loan pool coordinator to access reviewer mode."
      });
      this.setState({ toggleState: false });
    } else {
      this.setState({ toggleState: !loanPoolStoreV2.reviewerMode });
      loanPoolStoreV2.setReviewerMode(!loanPoolStoreV2.reviewerMode);
      if (
        loanPoolStoreV2.reviewerMode &&
        !loanPoolStoreV2.doNotUpdateLPRequests
      ) {
        loanPoolStoreV2.requestSubmittedToMe();
      }
      else if (!loanPoolStoreV2.doNotUpdateLPRequests) {
        loanPoolStoreV2.rerenderRequests1();
      }
      loanPoolStoreV2.setDoNotUpdateLPRequests(true);
    }
  };
  componentDidMount() {
    loanPoolStoreV2.setIsBackArrowVisible(false);
    if (permissionStore.permissions.icons) {
      var permission = mobx.toJS(permissionStore.getpermissions);
      if (!permission.icons.LPCordinator) {
        if (!permission.icons.Admin) {
          loanPoolStoreV2.setIsLPReviewer(false);
        }
        else {
          loanPoolStoreV2.setIsLPReviewer(true);
        }
      } else {
        loanPoolStoreV2.setIsLPReviewer(true);
      }
    } else {
      Functions.GetPermissionBasedColumns()
        .then(response => {
          permissionStore.setPermissions(JSON.stringify(response.data));
        })
        .then(() => {
          permission = mobx.toJS(permissionStore.getpermissions);
          if (!permission.icons.LPCordinator) {
            if (!permission.icons.Admin) {
              loanPoolStoreV2.setIsLPReviewer(false);
            }
            else {
              loanPoolStoreV2.setIsLPReviewer(true);
            }
          } else {
            loanPoolStoreV2.setIsLPReviewer(true);
          }
        });
    }
  }
  render() {
    const {
      value,
      suggestions,
      isRequestCartOpen,
      isExternalRequestModalOpen
    } = this.state;
    const { loading } = this.state;

    // Autosuggest will pass through all these props to the input.
    const inputProps = {
      placeholder: "Quick Search...",
      value,
      onChange: this.onChange,
      disabled: loanPoolStoreV2.reviewerMode
    };
    const searchstyle = {
      backgroundColor: value ? " #3385FF" : "#EEEEEE",
      color: value ? "#FFFFFF" : "#646C72",
      top: 16
    };
    const badgestyle = {
      color: "white",
      backgroundColor: "#ff4051",
      top: "",
      left: "",
      bottom: "-8px",
      right: "-11px"
    };

    return (
      <Header className="header s whitebg">
        {this.props.isVisible ? (
          <div className="header-same-class">
            {loanPoolStoreV2.reviewerMode ? (
              ""
            ) : (
                <div
                  className="header-common-class header-same-class header-search-wrapper "
                  onClick={this.onSearchclick.bind(this)}
                  onKeyPress={this._handleKeyPress.bind(this)}
                >
                  <Autosuggest
                    id="asset-quick-search"
                    suggestions={suggestions}
                    //onSuggestionsFetchRequested={this.search.bind(this)}
                    onSuggestionsFetchRequested={this.search.bind(this)}
                    onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                    getSuggestionValue={getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    onSuggestionSelected={this.onSuggestionSelected}
                    inputProps={inputProps}
                  />
                  <div className="header-searchbox-icon" style={searchstyle}>
                    <Icon
                      type={loading ? "loading" : "search"}
                      style={{ color: "inherit", cursor: "pointer" }}
                      onClick={this.onSearchButton.bind(this)}
                    />
                  </div>
                </div>
              )}
            {loanPoolStoreV2.reviewerMode ? (
              ""
            ) : (
                <div style={{ marginLeft: 10, marginRight: 16, marginTop: -2 }}>
                  <Button
                    type="primary"
                    onClick={this.onExternalRequest.bind(this)}
                  >
                    External Request
                </Button>
                  {isExternalRequestModalOpen ? (
                    <ExternalRequestModalForm
                      visible={isExternalRequestModalOpen}
                      onClose={this.handleExternalRequestModalClose.bind(this)}
                    />
                  ) : (
                      ""
                    )}
                </div>
              )}
            {loanPoolStoreV2.reviewerMode ? (
              <div style={{ marginLeft: 15 }} />
            ) : (
                <div className="header-divider" />
              )}
            <div className="header-cart">
              <span className="custom-badge">
                <span className="custom-badge-count">
                  {loanPoolStoreV2.cartItems.length}
                </span>
              </span>
              <Button onClick={this.onRequestCart.bind(this)}>
                <Icon type="shopping-cart" theme="outlined" />
                <span>Request Cart</span>
              </Button>
            </div>
            {isRequestCartOpen ? (
              <LPRequestCart
                visible={isRequestCartOpen}
                onClose={this.handleRequestCartClose.bind(this)}
              />
            ) : (
                ""
              )}
          </div>
        ) : (
            ""
          )}

        <div className="header-same-class">
          {this.props.isVisible &&
            loanPoolStoreV2.IsLPReviewer &&
            !loanPoolStoreV2.checkAvailabilityMode ? (
              <div className="header-same-class">
                <div
                  className="header-common-class"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center"
                  }}
                >
                  <span
                    className="header-review-toggle"
                    style={{
                      color: loanPoolStoreV2.reviewerMode ? "#108ee9" : "#ddd"
                    }}
                  >
                    Review
                </span>
                  <Switch
                    className="review-switch"
                    style={{
                      marginBottom: "2px",
                      marginRight: "5px"
                    }}
                    checked={this.state.toggleState}
                    checkedChildren="ON"
                    unCheckedChildren="OFF"
                    size="medium"
                    id="reviewerModeswitch"
                    onChange={this.toggleTheSwitch}
                  />
                  <span style={{ marginLeft: 23, marginRight: -8 }}>
                    {tabModelStore.loanPoolNotificationCount != 0 ? (
                      <NotificationBadge
                        count={tabModelStore.loanPoolNotificationCount}
                        effect={Effect.SCALE}
                        style={badgestyle}
                      />
                    ) : (
                        ""
                      )}
                  </span>
                </div>
              </div>
            ) : (
              ""
            )}
          <div
            className="header-same-class"
            style={{
              justifyContent: this.props.isVisible
                ? "space-between"
                : "flex-end",
              width: this.props.isVisible ? "auto" : "calc(100vw - 100px)"
            }}
          >
            <div className="header-common-class">
              {loanPoolStoreV2.isBackArrowVisible ?
                (<Icon
                  type="left"
                  theme="outlined"
                  style={{ color: "#646C72", cursor: "pointer" }}
                  className="header-arrow-icons "
                  onClick={this.onLeftClick.bind(this)}
                />) : (" ")}
              <Icon
                type="right"
                theme="outlined"
                style={{ color: "#646C72", cursor: "pointer" }}
                className="header-arrow-icons "
                onClick={this.onRightClick.bind(this)}
              />
            </div>
            <div className="header-divider" />
            <span className="lp-title nowrap  header-common-class">
              <Link
                to={{
                  pathname: "/loan-pool-notifications",
                  state: "desiredState"
                }}
                onClick={this.onHomeClick.bind(this)}
              >
                <a>
                  <span>Loan Pool</span>
                </a>
              </Link>
            </span>
          </div>
        </div>
      </Header>
    );
  }
}

export default LoanPoolHeader;
LoanPoolHeader.propTypes = {
  isVisible: PropTypes.bool
};
