// import ReactDOM from 'react-dom';
import React, { Component } from "react";
import logoImage from "../images/keysight_logo_light.png";
import URL from "../../../api/Urls";
import { observable } from "mobx";
import { observer } from "mobx-react";
import userStore from "../../../stores/userStore";
import { signIn } from "../../../helpers/auth";
import AssetDetails from "../../../components/AssetDetails/AssetDetails";
import ForgotPassword from "../../../components/ForgotPassword/forgotpassword";
import tabModelStore from "../../../stores/tabModelStore";
import addAssetsStore from "../../../stores/addAssetsStore";
import ForgotPasswordStore1 from "../../../stores/ForgotPasswordStore";
import { Alert } from "reactstrap";
import Footer from "../../../components/Footer";
import PropTypes from "prop-types";

@observer
class Login extends Component {
	constructor(props) {
		super(props);
		this.state = {
			menuType: "tab-1",
			errmessage: "",
			loggingIn: false
		};
		this.doLogin = this.doLogin.bind(this);
	}
	@observable
	active = false;
	componentDidMount() {
		document.getElementsByTagName("BODY")[0].className =
			"loginBkg pace-done pace-done";
		document.getElementsByTagName("BODY")[0].id = "particles-js";
	}
	componentWillUnmount() {
		// console.log("testUnmount");
		document.getElementsByTagName("BODY")[0].className = "";
		document.getElementsByTagName("BODY")[0].id = "particles-js";
	}

	handleClickLogin(e) {
		e.preventDefault();
		document.getElementById("tab-1").className = "nav-link active";
		document.getElementById("tab-2").classList.remove("active");
		this.setState({ menuType: e.target.id, errmessage: "" });
	}

	handleClickSearch(e) {
		e.preventDefault();
		document.getElementById("tab-2").className = "nav-link active";
		document.getElementById("tab-1").classList.remove("active");
		this.setState({ menuType: e.target.id });
		tabModelStore.setErrorMessage("");
	}

	doLogin(e) {
		e.preventDefault();
		let { userName, password } = this.state;
		if (!userName || !password) {
			this.setState({
				errmessage: "Username or Password cannot be blank!"
			});
			return;
		}
		this.setState({ loggingIn: true });
		// this.setState({
		//   userName: '',
		//   password: ''
		// });
		// //console.log("request:triggering",userName,password);
		this.active = true;
		// let username = this.state.username;
		// let password = this.state.password;
		// var credentials = btoa(username + ':' + password);

		if (userName.indexOf("@") > 0) {
			userName = userName.toLowerCase();
		}

		const encodedString = new Buffer(userName + ":" + password).toString(
			"base64"
		);
		//console.log("creds1:", encodedString);
		var BasicAuth = "EXT " + encodedString;

		var data = {};
		data.userName = userName;
		//console.log("BAsic", BasicAuth);
		var headers = {
			Authorization: BasicAuth,
			Accept: "application/json",
			"Content-Type": "application/json"
		};

		signIn({
			method: "post",
			url: URL.login,
			headers: headers,
			data: data
		})
			.then(resp => {
				this.setState({ loggingIn: false });
				if (resp.status == "200") {
					//    var user =resp.headers['twx-mobile-token'];
					// //console.log(user);
					if (resp.data.isValid) {
						userStore.setMe(userName);
						localStorage.setItem("tabPreference","{}");
					} else {
						e.preventDefault();
						this.setState({
							errmessage: resp.data.message
						});
					}
					//console.log("got", resp);
				} else {
					resp =
						typeof resp == "string"
							? resp
							: resp.data == undefined || resp.data == ""
							? "Invalid user name or password"
							: resp.data;
					this.setState({
						errmessage: resp
					});
				}
			})
			.catch(resp => {
				this.setState({ loggingIn: false });
				resp =
					typeof resp == "string"
						? resp
						: resp.data == undefined || resp.data == ""
						? "Invalid user name or password"
						: resp.data;
				this.setState({
					errmessage: resp
				});
			});
	}

	render() {
		let { userName, password, serialNumber, modelNumber } = this.state;
		let { isLoginPending, isLoginSuccess, loginError } = this.props;
		return (
			<div className="app flex-row align-items-center">
				<div className="container loginContainer">
					{/*****Login Container*****/}
					<div className="loginMenu">
						{/*****Login Window*****/}
						<img src={logoImage} alt="" id="keysightLogo" />
						<ul className="nav nav-tabs" id="loginTabs" role="tablist">
							<li className="nav-item">&nbsp;</li>
						</ul>
						<div className="tab-content" id="myTabContent">
							{/*****Tab Content*****/}
							{this.state.menuType == "tab-1" ? (
								<form>
									<div
										className="tab-pane fade show active"
										id="tab-1-content"
										role="tabpanel"
										aria-labelledby="tab-1"
									>
										{/*****Login Form*****/}
										<div className="input-group usernameInput">
											<span className="input-group-addon" id="sizing-addon2">
												<i className="icon-user" />
											</span>
											<input
												type="text"
												name="userName"
												onChange={e =>
													this.setState({ userName: e.target.value })
												}
												value={userName}
												className="form-control"
												placeholder="Username or Email"
												aria-describedby="sizing-addon2"
											/>
										</div>
										<div className="input-group passwordInput">
											<span className="input-group-addon" id="sizing-addon2">
												<i className="icon-lock" />
											</span>
											<input
												type="password"
												name="password"
												onChange={e =>
													this.setState({ password: e.target.value })
												}
												value={password}
												className="form-control"
												placeholder="Password"
												aria-describedby="sizing-addon2"
											/>
										</div>
										<a href="#">
											<span
												className="forgotPassword"
												onClick={() => ForgotPasswordStore1.toggleModal()}
											>
												Forgot Password
											</span>
										</a>

										<div className="message">
											{isLoginPending && <div>Please wait...</div>}
											{isLoginSuccess && <div>Success.</div>}
											{loginError && <div>{loginError.message}</div>}
										</div>
										{this.state.errmessage ? (
											<Alert color="danger"> {this.state.errmessage} </Alert>
										) : null}
										{/* <aside className="loginMenuInfo">
                        Login to see details for multiple assets+{this.active}
                      </aside> */}
										<a href="#">
											<button
												onClick={this.doLogin}
												disabled={this.state.loggingIn}
												type="submit"
												className="loginButton btn btn-primary btn-lg btn-block"
												id="loginButton"
											>
												{this.state.loggingIn ? "Logging in.." : "LOGIN"}
											</button>
										</a>
									</div>
								</form>
							) : (
								<div
									className="tab-pane fade active show"
									id="tab-2-content"
									role="tabpanel"
									aria-labelledby="tab-2"
								>
									{/*****Search Form*****/}
									<div className="input-group usernameInput">
										<span className="input-group-addon" id="sizing-addon2">
											<i className="icon-magnifier" />
										</span>
										<input
											type="text"
											className="form-control"
											placeholder="Serial Number"
											aria-label="Username"
											aria-describedby="sizing-addon2"
											onChange={e =>
												this.setState({ serialNumber: e.target.value })
											}
											value={serialNumber}
										/>
									</div>
									<div className="input-group passwordInput">
										<span className="input-group-addon" id="sizing-addon2">
											<i className="icon-magnifier" />
										</span>
										<input
											type="text"
											className="form-control"
											placeholder="Model Number"
											aria-label="Username"
											aria-describedby="sizing-addon2"
											onChange={e =>
												this.setState({ modelNumber: e.target.value })
											}
											value={modelNumber}
										/>
									</div>
									{tabModelStore.getErrorMessage ? (
										<Alert color="danger">
											{" "}
											{tabModelStore.getErrorMessage}{" "}
										</Alert>
									) : null}
									<aside className="searchMenuInfo">
										Skip the login to see details for a single asset
									</aside>
									<button
										onClick={addAssetsStore.toggleAssetDetailsModal}
										type="button"
										className="loginButton btn btn-primary btn-lg btn-block"
										id="searchAssetButton"
									>
										SEARCH
									</button>
								</div>
							)}
						</div>
					</div>
				</div>

				{/****** FOOTER*****/}
				<Footer />
				{addAssetsStore.assetDetailModalOpen ? (
					<AssetDetails ModelNo={modelNumber} SerialNo={serialNumber} />
				) : (
					""
				)}
				{ForgotPasswordStore1.assetDetailModalOpen ? <ForgotPassword /> : null}
			</div>
		);
	}
}
Login.propTypes = {
	isLoginPending: PropTypes.String,
	isLoginSuccess: PropTypes.String,
	loginError: PropTypes.String
};
export default Login;
