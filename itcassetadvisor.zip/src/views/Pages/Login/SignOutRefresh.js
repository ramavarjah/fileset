import React from "react";
import { Modal, Icon } from "antd";
import "./refresh.scss";

export default class SignOutRefresh extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const contentStyles = {
      color: "rgba(12,34,45)",
      fontWeight: "650",
      height: 60,
      overflow: "hidden",
      fontSize: 19
    };
    const modalTop = {
      top: (window.innerHeight - 500) / 2,
      padding: 0
    };
    return (
      <div>
        <Modal
          className="sign-out-refresh"
          centered={true}
          visible={true}
          footer={null}
          bodyStyle={contentStyles}
          closable={false}
          width="250px"
          style={modalTop}
        >
          <span style={{ marginLeft: "25px", marginTop: "20px" }}>
            <Icon type="loading" />
            <span
              style={{ color: "#3385FF", marginLeft: "10px", opacity: 0.8 }}
            >
              Signing Out
            </span>
          </span>
        </Modal>
      </div>
    );
  }
}
