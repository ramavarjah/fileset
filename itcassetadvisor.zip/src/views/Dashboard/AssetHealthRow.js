import React, { Component } from "react";
import { Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import addAssetsStore from "./../../stores/addAssetsStore";

import PropTypes from "prop-types";
import "../../helpers/Antd/antd.css"; // new line of code

class AssetHealthRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentStep: "step1"
    };
  }

  toggleNew() {
    addAssetsStore.setHealthModalOpen(false);
    this.setState({ currentStep: "step1" });
  }
  secondToggleNew() {
    this.setState({ currentStep: "step1" });
  }

  componentDidMount() {
    // //console.log('ccccc', JSON.parse(this.props.HealthCode))
  }
  handleClick() {
    this.setState({ currentStep: "step2" });
  }

  render() {
    return (
      <div className="loanPool row">
        {this.props.openModal &&
        !this.props.singleClick &&
        this.props.DoubleClick &&
        this.props.ClassName == "react-grid-Cell" ? (
          <Modal
            isOpen={addAssetsStore.setHealthModalOpen}
            toggle={this.toggleNew.bind(this)}
            className="modal-dialog modal-lg newWidth"
            id="createAssetModal"
          >
            <ModalHeader
              className="row modalHeader LoanPoolModal"
              style={{
                borderBottom: "1px solid #cfd8dc",
                backgroundColor: "#fff"
              }}
            >
              <span className="createAssetLabel" style={{ color: "#3385FF" }}>
                Asset Health Row Details -{" "}
                {JSON.parse(this.props.HealthCode).EquipmentNo}{" "}
              </span>
              <span
                onClick={this.toggleNew.bind(this)}
                style={{ cursor: "pointer" }}
              >
                <i className="icon-close" style={{ top: 0 }} />
              </span>
            </ModalHeader>

            <ModalBody className="healthBody">
              {this.state.currentStep == "step1" ? (
                <div>Row data Chart will go here...</div>
              ) : (
                ""
              )}
              {this.state.currentStep == "step2" ? (
                <div>
                  <h4> Next pageChart Detail will goes here...</h4>
                </div>
              ) : (
                ""
              )}
            </ModalBody>

            <ModalFooter style={{ backgroundColor: "#2d2d32", padding: 25 }}>
              {/* 'Footer Buttons' */}
              <div id="createAssetFooterButtons" style={{ margin: "0 500px" }}>
                {this.state.currentStep == "step1" ? (
                  <div className="twoItems">
                    <button
                      type="button"
                      className="createButton aaSmallBtn btn btn-primary btn-sm"
                      bsSize="large"
                      onClick={this.toggleNew.bind(this)}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      className="createButton aaSmallBtn btn btn-primary btn-sm"
                      bsSize="large"
                      onClick={this.handleClick.bind(this)}
                    >
                      Clickme
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    className="createButton aaSmallBtn btn btn-primary btn-sm"
                    bsSize="large"
                    onClick={this.secondToggleNew.bind(this)}
                  >
                    Cancel
                  </button>
                )}
              </div>
            </ModalFooter>
          </Modal>
        ) : (
          ""
        )}
      </div>
    );
  }
}
AssetHealthRow.propTypes = {
  openModal: PropTypes.String,
  singleClick: PropTypes.String,
  DoubleClick: PropTypes.String,
  ClassName: PropTypes.String,
  HealthCode: PropTypes.String
};
export default AssetHealthRow;
