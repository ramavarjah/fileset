import React, { Component } from "react";
import "amcharts3";
import "amcharts3/amcharts/serial";
import AmCharts from "@amcharts/amcharts3-react";
import tabModelStore from "../../stores/tabModelStore";
import Functions from "../../api/Functions";
import { observer } from "mobx-react";
import { Spin } from "antd";

@observer
class AssetHealthTrend extends Component {
  constructor(props) {
    super(props);

    this.state = {
      dataProvider: [],
      loaded: false
    };
    this.componentDidMountInRender = this.componentDidMountInRender.bind(this);
  }
  UNSAFE_componentWillReceiveProps() {
    this.componentDidMountInRender();
  }

  componentDidMountInRender() {
    tabModelStore.setTrendLoadingMask(true);

    var deviceName = tabModelStore.datacontext.device;
    var AssetName = tabModelStore.datacontext.thingname;
    var metricName = tabModelStore.datacontext.metricName;
    var Units = tabModelStore.datacontext.Units;
    var startDate = tabModelStore.datacontextStartDate;
    var endDate = tabModelStore.datacontextEndDate;
    var bucket = tabModelStore.trendBucketType;
    var roundOffDigits = tabModelStore.datacontext.roundoffdigits;

    Functions.GetHealthTrendData(
      deviceName,
      startDate,
      endDate,
      AssetName,
      metricName,
      Units,
      bucket,
      roundOffDigits
    ).then(resp => {
      var dataSet = resp.data;

      var EquipmentNumber = dataSet.EquipmentNo;
      var dataProvider = resp.data.data;
      var Title;
      if (
        deviceName != "" &&
        deviceName != undefined &&
        metricName != "" &&
        metricName != undefined
      ) {
        Title = deviceName + "-" + metricName;
      } else if (deviceName != "" && deviceName != undefined) {
        Title = deviceName;
      } else {
        Title = "";
      }

      dataProvider = dataProvider.map(i => {
        var retObj = i;
        retObj.EquipmentNumber = EquipmentNumber;
        retObj.deviceName = deviceName;
        retObj.metricName = metricName;
        retObj.Units = Units;
        return retObj;
      });

      var graph = new AmCharts.AmGraph();
      graph.bullet = "round";
      graph.id = "AmGraph-1";
      graph.connect = false;
      graph.gapPeriod = 1.1;
      graph.lineColor = "#ffb21d";
      graph.lineThickness = 1;
      graph.title = dataSet.graphs;
      graph.valueField = dataSet.graphs;
      graph.balloonText =
        "<span style='font-weight: 400'>" +
        dataSet.graphs +
        ":\n<b>[[value]]</b>\nDate: [[category]]</span>"; //--COS

      var config = {
        hideCredits: true,
        type: "serial",
        theme: "dark",
        categoryField: "date",
        dataDateFormat: "",
        mouseWheelScrollEnabled: true,
        color: "#E7E7E7",
        fontFamily: "Roboto",
        export: {
          reviver: function(obj) {
            if (obj.className.indexOf("amcharts-title-Title-1") > -1) {
              obj.text = "Equipment No:" + EquipmentNumber + "\t " + obj.text;
            }
          },
          enabled: true,
          backgroundColor: "#000",
          fallback: false,
          menu: [
            {
              class: "export-main amcharts-export-custom",
              menu: ["PNG", "JPG", "CSV", "PDF"]
            }
          ],

          exportFields: [
            "EquipmentNumber",
            "date",
            "deviceName",
            "metricName",
            "Units",
            deviceName
          ],
          columnNames: {
            metricName: "Metric Name",
            deviceName: "Device Name",
            Units: "Units",
            EquipmentNumber: "Equipment Number",
            date: "Date Time",
            [deviceName]: "Current Value"
          }
        },

        categoryAxis: {
          minPeriod: "DD",
          parseDates: true
        },
        chartCursor: {
          enabled: true,
          oneBalloonOnly: true
        },
        chartScrollbar: {
          enabled: true,
          graph: "ValueAxis-1",
          oppositeAxis: true,
          offset: 10,
          scrollbarHeight: 30,
          backgroundAlpha: 0,
          selectedBackgroundAlpha: 0.1,
          selectedBackgroundColor: "#888888",
          graphFillAlpha: 0,
          graphLineAlpha: 0.5,
          selectedGraphFillAlpha: 0,
          selectedGraphLineAlpha: 1,
          autoGridCount: true,
          color: "#AAAAAA"
        },
        trendLines: [],
        graphs: [],
        guides: [],
        valueAxes: [
          {
            id: "ValueAxis-1",
            titleBold: true,
            title: "name"
          }
        ],

        allLabels: [],
        balloon: {
          adjustBorderColor: false,
          color: "#1c1d21",
          borderAlpha: 0,
          borderThickness: 0,
          pointerOrientation: "down",
          cornerRadius: 3,
          verticalPadding: 10,
          horizontalPadding: 10,
          fontSize: 14,
          textAlign: "left"
        },
        legend: {
          enabled: false,
          useGraphSettings: true,
          color: "#FFFFFF",
          fontSize: 10,
          markerSize: 12
        },
        titles: [
          {
            id: "Title-1",
            size: 15,
            text: Title
          }
        ],
        dataProvider: []
      };

      config.dataProvider = dataProvider;
      config.graphs.push(graph);
      config.dataDateFormat = "";
      config.categoryAxis.minPeriod = dataSet.minPeriod;
      config.chartCursor.enabled = true;
      config.chartCursor.categoryBalloonDateFormat = dataSet.DateFormat;
      config.categoryAxis.equalSpacing = true;
      tabModelStore.setTrendLoadingMask(true);

      config.valueAxes[0].title =
        dataSet.Units && dataSet.metricName
          ? `${tabModelStore.datacontext.device}; ${dataSet.metricName} (${
              dataSet.Units
            })`
          : `${tabModelStore.datacontext.device} (${dataSet.Units})`;

      this.setState({
        dataProvider: config,
        loaded: true
      });
      tabModelStore.setTrendLoadingMask(false);
    });
  }
  componentDidMount() {
    this.componentDidMountInRender();
  }

  render() {
    return tabModelStore.trendLoadingMask |
      (this.state.dataProvider.length == 0) ? (
      <Spin spinning={true} style={{ width: "100%", height: 320 }} />
    ) : (
      <div className="chartBg chartBg1">
        <AmCharts.React
          style={{ width: "100%", height: 320 }}
          options={this.state.dataProvider}
        />
      </div>
    );
  }
}

export default AssetHealthTrend;
