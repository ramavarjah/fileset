import React, { Component } from "react";
import { Toolbar } from "react-data-grid-addons";
import KSGrid from "./ag/KSGrid";
import userStore from "../../stores/userStore";
import { observer } from "mobx-react";
import AssetHealth from "./AssetHealth";
import tabModelStore from "../../stores/tabModelStore";
import addAssetsStore from "../../stores/addAssetsStore";
import PropTypes from "prop-types";
import "../../helpers/Antd/antd.css"; // new line of code

@observer
class Dashboard extends Component {
    constructor(props) {
        super(props);
        this.rowGetter = this.rowGetter.bind(this);
        tabModelStore.setIsAssetListView(true);
        tabModelStore.setIsChartView(false);
        tabModelStore.setIsVisible(false);
    }
  static defaultProps = { rowKey: "UniqueID" };

  state = {
      value: undefined,
      selectedIds: [],
      columns: tabModelStore.currentTabColoumnsArray
  };
  onChange = value => {
      this.setState({ value });
  };
  componentWillUnmount() {}

  componentDidMount() {
      var self = this;
      if (userStore.lastPath === "/dashboard" || userStore.lastPath === "/")
          return;
      self.props.history.push(userStore.lastPath);
      setTimeout(() => {
          userStore.setlastPath("/dashboard");
      }, 1000);
  }
  rowGetter(i) {
      var rtn = tabModelStore.currentScreenDataArray[i];
      return rtn;
  }

  onRowsSelected = rows => {
      addAssetsStore.dashboardAddCheck(rows);
  };

  onRowsDeselected = rows => {
      const rowIds = rows.map(r => r.row[this.props.rowKey]);
      addAssetsStore.dashboardRemoveCheck(rows, rowIds);
  };

  handleGridSort = (sortColumn, sortDirection) => {
      const comparer = (a, b) => {
          if (sortDirection === "ASC") {
              return a[sortColumn] > b[sortColumn] ? 1 : -1;
          } else if (sortDirection === "DESC") {
              return a[sortColumn] < b[sortColumn] ? 1 : -1;
          }
      };

      const rows =
      sortDirection === "NONE"
          ? this.state.originalRows.slice(0)
          : this.state.rows.sort(comparer);

      this.setState({ rows });
  };

  onHeaderDrop = (source, target) => {
      const stateCopy = Object.assign({}, this.state);
      const columnSourceIndex = this.state.columns.findIndex(
          i => i.key === source
      );
      const columnTargetIndex = this.state.columns.findIndex(
          i => i.key === target
      );

      stateCopy.columns.splice(
          columnTargetIndex,
          0,
          stateCopy.columns.splice(columnSourceIndex, 1)[0]
      );

      const emptyColumns = Object.assign({}, this.state, { columns: [] });
      this.setState(emptyColumns);

      const reorderedColumns = Object.assign({}, this.state, {
          columns: stateCopy.columns
      });
      this.setState(reorderedColumns);
  };

  render() {
      return (
          <div className="">
              <AssetHealth
                  openModal={addAssetsStore.healthModalOpen}
                  HealthCode={addAssetsStore.rowData}
              />
              <KSGrid />
          </div>
      );
  }
}

export default Dashboard;

export class CustomToolbar extends Toolbar {
    render() {
        return (
            <div className="react-grid-Toolbar">
                <div className="tools">
                    <p>ToolBar</p>
                </div>
            </div>
        );
    }
}

Dashboard.propTypes = {
    rowKey: PropTypes.object
};
