import React, { Component } from "react";
import tabModelStore from "../../stores/tabModelStore";
import UIFunctions from "../../helpers/UIFunctions";

class DashboardFooter extends Component {
    handlePageSize(e) {
        var currentLimit = e.target.value;
        tabModelStore.setCurrentLimit(currentLimit);
        tabModelStore.setDataLoaded(false);
        tabModelStore.setCurrentStart(0);
        tabModelStore.setCurrentPage(1);
        UIFunctions.ReRenderGrid().then(() => {
            tabModelStore.setDataLoaded(true);
            //console.log('resp', resp);
        });
    }
    handleRefresh() {
        tabModelStore.setDataLoaded(false);
        UIFunctions.ReRenderGrid().then(() => {
            tabModelStore.setDataLoaded(true);
            //console.log('resp', resp);
        });
    }

    handleNextPage() {
        var currentPage = tabModelStore.currentPage;
        var totalItems = tabModelStore.currentScreenData.total;
        var currentLimit = tabModelStore.currentLimit;
        var totalPages = parseInt(totalItems / currentLimit);
        var remainder = totalItems % currentLimit;
        if (remainder > 0) {
            totalPages = totalPages + 1;
        }
        currentPage = currentPage + 1;
        var currentStart = currentPage * currentPage;
        if (currentPage != totalPages) {
            tabModelStore.setCurrentPage(currentPage);
            tabModelStore.setCurrentStart(currentStart);
            tabModelStore.setCurrentPage(+currentPage);
            tabModelStore.setDataReloading(true);
            tabModelStore.setCurrentScreenDataArray([]);
            UIFunctions.ReRenderGrid()
                .then(() => {
                    tabModelStore.setDataReloading(false);
                })
                .catch(() => {});
        }
    }
    handleLastPage() {
        var currentPage = tabModelStore.currentPage;
        var totalItems = tabModelStore.currentScreenData.total;
        var currentLimit = tabModelStore.currentLimit;
        var totalPages = parseInt(totalItems / currentLimit);
        var remainder = totalItems % currentLimit;
        if (remainder > 0) {
            totalPages = totalPages + 1;
        }
        currentPage = totalPages;
        var currentStart = currentPage * currentPage;
        tabModelStore.setCurrentPage(currentPage);
        tabModelStore.setCurrentStart(currentStart);
        tabModelStore.setDataReloading(true);
        tabModelStore.setCurrentScreenDataArray([]);
        UIFunctions.ReRenderGrid().then(() => {
            tabModelStore.setDataReloading(false);
        });
    }

    handleFirstPage() {
        var currentPage = tabModelStore.currentPage;
        var totalItems = tabModelStore.currentScreenData.total;
        var currentLimit = tabModelStore.currentLimit;
        var totalPages = parseInt(totalItems / currentLimit);
        var remainder = totalItems % currentLimit;
        if (remainder > 0) {
            totalPages = totalPages + 1;
        }
        currentPage = 1;
        var currentStart = currentPage * currentPage;
        if (currentPage != totalPages) {
            tabModelStore.setCurrentPage(currentPage);
            tabModelStore.setCurrentStart(currentStart);

            tabModelStore.setCurrentPage(+currentPage);
            tabModelStore.setDataReloading(true);
            tabModelStore.setCurrentScreenDataArray([]);
            UIFunctions.ReRenderGrid().then(() => {
                tabModelStore.setDataReloading(false);
            });
        }
    }
    handlePrevPage() {
        var currentPage = tabModelStore.currentPage;
        var totalItems = tabModelStore.currentScreenData.total;
        var currentLimit = tabModelStore.currentLimit;
        var totalPages = parseInt(totalItems / currentLimit);
        var remainder = totalItems % currentLimit;
        if (remainder > 0) {
            totalPages = totalPages + 1;
        }
        currentPage = currentPage - 1;
        var currentStart = currentPage * currentPage;
        if (currentPage != totalPages) {
            tabModelStore.setCurrentPage(currentPage);
            tabModelStore.setCurrentStart(currentStart);

            tabModelStore.setCurrentPage(+currentPage);
            tabModelStore.setDataReloading(true);
            tabModelStore.setCurrentScreenDataArray([]);
            UIFunctions.ReRenderGrid().then(() => {
                tabModelStore.setDataReloading(false);
            });
        }
    }

    render() {
        var totalItems = tabModelStore.currentScreenData.total;
        var currentPage = tabModelStore.currentPage;
        var currentLimit = tabModelStore.currentLimit;
        var totalPages = parseInt(totalItems / currentLimit);
        var remainder = totalItems % currentLimit;
        if (remainder > 0) {
            totalPages = totalPages + 1;
        }
        return (
            <div>
                <nav className="navbar navbar-dark bg-dark paginationBar">
                    <div className="col-sm-3 paginationButtons">
                        <ul>
                            <li
                                className="pageControls"
                                onClick={
                                    currentPage != 1 ? this.handleFirstPage.bind(this) : ""
                                }
                            >
                                <a href="#">
                                    <i className="fa fa-angle-double-left" />
                                </a>
                            </li>
                            <li
                                className="pageControls"
                                onClick={currentPage != 1 ? this.handlePrevPage.bind(this) : ""}
                            >
                                <a href="#">
                                    <i className="fa fa-angle-left" />
                                </a>
                            </li>
                            <li>
                                <span className="page">Page</span>
                            </li>
                            <li>
                                <input
                                    className="pageNumberInput"
                                    type="text"
                                    name=""
                                    value={tabModelStore.currentPage}
                                />
                            </li>
                            <li>
                                <span className="of38">of {totalPages}</span>
                            </li>
                            <li
                                className="pageControls"
                                onClick={
                                    currentPage != totalPages
                                        ? this.handleNextPage.bind(this)
                                        : ""
                                }
                            >
                                <a href="#">
                                    <i className="fa fa-angle-right" />
                                </a>
                            </li>
                            <li
                                className="pageControls"
                                onClick={
                                    currentPage != totalPages
                                        ? this.handleLastPage.bind(this)
                                        : ""
                                }
                            >
                                <a href="#">
                                    <i className="fa fa-angle-double-right" />
                                </a>
                            </li>
                            <li
                                className="pageControls"
                                onClick={this.handleRefresh.bind(this)}
                            >
                                <a href="#">
                                    <i className="icon-refresh" />
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div className="col-sm-1 pageSize">
                        <select
                            id="tabSelect"
                            className="dashfooterSelect"
                            onChange={this.handlePageSize.bind(this)}
                        >
                            <option key={25}>25</option>
                            <option key={50}>50</option>
                            <option key={75}>75</option>
                            <option key={100}>100</option>
                            <option key={150}>150</option>
                            <option key={200}>200</option>
                            <option key={250}>250</option>
                        </select>
                    </div>

                    <div className="col-sm-2 displayDensity">
                        <ul>
                            <li className="densityButtons">
                                <span className="displayDensityLabel">Display Density</span>
                            </li>
                            <li
                                className="densityButtons"
                                onClick={this.handleDensityDefault.bind(this)}
                            >
                                <a href="#">
                                    <i className="fa fa-th" />
                                </a>
                            </li>
                            <li
                                className="densityButtons"
                                onClick={this.handleDensityMedium.bind(this)}
                            >
                                <a href="#">
                                    <i className="fa fa-th" />
                                </a>
                            </li>
                            <li
                                className="densityButtons"
                                onClick={this.handleDensityLarge.bind(this)}
                            >
                                <a href="#">
                                    <i className="fa fa-th" />
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div className="col-sm-1 exportOptions">
                        <div className="btn-group dropup">
                            <i
                                className="icon-share-alt dropdown-toggle"
                                data-toggle="dropdown"
                                id="exportButton"
                                aria-expanded="false"
                            />
                            <div className="dropdown-menu">
                                <a className="dropdown-item" href="#">
                                    <span>Download</span>
                                    <i className="icon-cloud-download" />
                                </a>
                                <a className="dropdown-item" href="#">
                                    <span>Print</span>
                                    <i className="icon-printer" />
                                </a>
                            </div>
                        </div>
                    </div>

                    <div className="col-sm-1 resetSorters">
                        <button
                            type="button"
                            id="resetSorters"
                            className="btn btn-primary btn-sm"
                        >
              Reset Sorters
                        </button>
                    </div>
                </nav>
            </div>
        );
    }
}

export default DashboardFooter;
