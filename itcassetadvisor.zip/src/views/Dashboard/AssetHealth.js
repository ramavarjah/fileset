import React, { Component } from "react";
import { Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import addAssetsStore from "./../../stores/addAssetsStore";
import "../../helpers/Antd/antd.css"; // new line of code
import AssetHealthTrend from "./AssetHealthTrend";
import UIFunctions from "./../../helpers/UIFunctions";
import AssetHealthProperty from "../../views/Dashboard/AssetHealthModel/AssetHealthProperty";
import tabModelStore from "./../../stores/tabModelStore";
import { observer } from "mobx-react";
import { DatePicker, Select, Row, Col, Icon } from "antd";
import Functions from "../../api/Functions";
const Option = Select.Option;
const { RangePicker } = DatePicker;
import PropTypes from "prop-types";

import moment from "moment";

@observer
class AssetHealth extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentStep: "step1",
            startDate: moment(
                new Date(new Date().setHours(0, 0, 0, 0)),
                "YYYY-MM-DD"
            ),
            endDate: moment(
                new Date(new Date().setHours(23, 59, 59, 999)),
                "YYYY-MM-DD"
            ),
            refreshToggle: false
        };
        this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
        this.handleExpandErrorsClick = this.handleExpandErrorsClick.bind(this);
    }

    toggleNew() {
        if (tabModelStore.datacontextState == "step1") {
            addAssetsStore.setHealthModalOpen(false);
        } else {
            this.handleBackButtonClick();
            return true;
        }
        tabModelStore.setDataContextState("step1");
    }
    secondToggleNew() {
        tabModelStore.setDataContextState("step1");
    }
    handleClick() {
        var refreshToggle = !this.state.refreshToggle;
        this.setState({
            currentStep: "step2",
            refreshToggle: refreshToggle
        });
    }
    handleStartEndDate(val) {
        tabModelStore.setTrendPreset("Custom");
        tabModelStore.setDataContextStartDate(val[0].toISOString());
        tabModelStore.setDataContextEndDate(val[1].toISOString());
    }
  handleBackButtonClick = () => {
      tabModelStore.setDataContextState("step1");
      tabModelStore.setTrendBucketType("Hours");
      tabModelStore.setTrendPreset("Today");
      tabModelStore.datacontextStartDate = moment()
          .startOf("day")
          .toISOString();
      tabModelStore.datacontextEndDate = moment()
          .endOf("day")
          .toISOString();
  };

  handleExpandErrorsClick = () => {
      tabModelStore.setDataContextState("step3");
  };
  handleRefresh() {
      var refreshToggle = !this.state.refreshToggle;
      this.setState({ refreshToggle: refreshToggle });
  }
  ResetAllHealthParams() {
      var self = this;
      UIFunctions.ShowConfirm({
          title: "Are you sure you want to reset All?",
          okText: "Yes",
          cancelText: "No",
          onOk() {
              Functions.ResetAllHealthParamsMinMax(
                  JSON.parse(self.props.HealthCode).UniqueID
              ).then(() => {});
          },
          onCancel() {}
      });
  }
  handleTrendBucketType(e) {
      var bucketType = e;
      if (bucketType === "Hours") {
          tabModelStore.setTrendBucketType("Hours");
      } else if (bucketType === "Days") {
          tabModelStore.setTrendBucketType("Days");
      } else {
          tabModelStore.setTrendBucketType("Months");
      }
  }
  handleTrendPreset(e) {
      var datePreset = e;
      if (datePreset == "Custom") {
          return tabModelStore.setTrendPreset(datePreset);
      }
      this.setState({
          preset: datePreset
      });

      if (datePreset === "Today") {
          var startDate = moment()
              .startOf("day")
              .toISOString();
          var endDate = moment()
              .endOf("day")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      } else if (datePreset === "Last Week") {
          let startDate = moment()
              .subtract(1, "weeks")
              .startOf("week")
              .toISOString();
          let endDate = moment()
              .subtract(1, "weeks")
              .endOf("week")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      } else if (datePreset === "Last Month") {
          let startDate = moment()
              .subtract(1, "month")
              .startOf("month")
              .toISOString();
          let endDate = moment()
              .subtract(1, "month")
              .endOf("month")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      } else if (datePreset === "Yesterday") {
          let startDate = moment()
              .subtract(1, "days")
              .startOf("day")
              .toISOString();
          let endDate = moment()
              .subtract(1, "days")
              .endOf("day")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      } else if (datePreset === "This Week-to-date") {
          let startDate = moment()
              .startOf("week")
              .toISOString();
          let endDate = moment()
              .endOf("day")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      } else if (datePreset === "This Month-to-date") {
          let startDate = moment()
              .startOf("month")
              .toISOString();
          let endDate = moment()
              .endOf("day")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      } else if (datePreset === "Last Week-to-date") {
          let startDate = moment()
              .subtract(1, "weeks")
              .startOf("week")
              .toISOString();
          let endDate = moment()
              .endOf("day")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      } else if (datePreset === "Last Month-to-date") {
          let startDate = moment()
              .subtract(1, "months")
              .startOf("month")
              .toISOString();
          let endDate = moment()
              .endOf("day")
              .toISOString();
          tabModelStore.setDataContextStartDate(moment(startDate));
          tabModelStore.setDataContextEndDate(moment(endDate));
          tabModelStore.setTrendPreset(datePreset);
      }
  }
  render() {
      const RowItem = props => (
          <Row className="warningsList">
              <Col span={5}>{props.time}</Col>
              <Col span={11}>{props.message}</Col>
              <Col span={8}>
                  <div
                      className={
                          props.type == "Error"
                              ? "warningsListTypeError"
                              : "warningsListTypeWarning"
                      }
                  >
                      {props.type}
                  </div>
              </Col>
          </Row>
      );
      return (
          <div>
              {this.props.openModal ? (
                  <div>
                      <Modal
                          isOpen={addAssetsStore.setHealthModalOpen}
                          className="modal-dialog modal-lg newWidth assetHealthModal"
                          id="createAssetModal"
                      >
                          <ModalHeader className="row modalHeader LoanPoolModal">
                              <Row>
                                  <Col span={8}>
                                      <span
                                          className="createAssetLabel"
                                          style={{ color: "#3385FF" }}
                                      >
                      Asset Health //{" "}
                                          <span className="assetHealthEquipmentNo">
                                              {JSON.parse(this.props.HealthCode).EquipmentNo}
                                          </span>{" "}
                                      </span>
                                  </Col>
                                  <Col span={8} style={{ textAlign: "center" }}>
                                      {tabModelStore.datacontextState == "step1" ? (
                                          <span
                                              onClick={this.ResetAllHealthParams.bind(this)}
                                              className="resetAllButton"
                                          >
                                              <Icon type="retweet" /> Reset All
                                          </span>
                                      ) : (
                                          ""
                                      )}
                                  </Col>
                                  <Col span={8}>
                                      <span
                                          onClick={this.toggleNew.bind(this)}
                                          style={{ cursor: "pointer" }}
                                      >
                                          <i
                                              className="icon-close"
                                              style={{ top: "0", paddingTop: "0px" }}
                                          />
                                      </span>
                                  </Col>
                              </Row>
                          </ModalHeader>

                          <ModalBody>
                              <div
                                  style={{
                                      height:
                      tabModelStore.datacontextState == "step1"
                          ? window.innerHeight - 347
                          : 0,
                                      overflowY: "auto"
                                  }}
                              >
                                  <AssetHealthProperty
                                      isVisible={tabModelStore.datacontextState == "step1"}
                                      handleClick={this.handleClick}
                                      uniqueId={JSON.parse(this.props.HealthCode).UniqueID}
                                      loading={tabModelStore.errorNWarningslistsLoaded}
                                  />
                              </div>
                              {tabModelStore.datacontextState == "step2" ? (
                                  <div
                                      style={{
                                          height: window.innerHeight - 377,
                                          overflowY: "auto"
                                      }}
                                  >
                                      <AssetHealthTrend onRefresh={this.state.refreshToggle} />
                                      <div className="assetHealthTrendFooterContainer">
                                          <div className="trendDatePresetSelectBoxWrapper pull-left">
                                              <Select
                                                  className="trendDatePresetSelectBox"
                                                  style={{ width: 150 }}
                                                  defaultValue="Today"
                                                  onChange={this.handleTrendPreset.bind(this)}
                                                  value={
                                                      tabModelStore.trendPreset != ""
                                                          ? tabModelStore.trendPreset
                                                          : "Today"
                                                  }
                                              >
                                                  <Option value="Today">Today</Option>
                                                  <Option value="This Week-to-date">
                            This Week-to-date
                                                  </Option>
                                                  <Option value="This Month-to-date">
                            This Month-to-date
                                                  </Option>
                                                  <Option value="Yesterday">Yesterday</Option>
                                                  <Option value="Last Week">Last Week</Option>
                                                  <Option value="Last Week-to-date">
                            Last Week-to-date
                                                  </Option>
                                                  <Option value="Last Month">Last Month</Option>
                                                  <Option value="Last Month-to-date">
                            Last Month-to-date
                                                  </Option>
                                                  <Option value="Custom">Custom</Option>
                                              </Select>
                                          </div>
                                          <div className="trendDateRangePickerWrapper pull-left">
                                              <RangePicker
                                                  className="trendDateRangePicker"
                                                  format="YYYY-MM-DD"
                                                  allowClear={false}
                                                  defaultValue={[
                                                      moment().startOf("day"),
                                                      moment().endOf("day")
                                                  ]}
                                                  value={[
                                                      moment(tabModelStore.datacontextStartDate),
                                                      moment(tabModelStore.datacontextEndDate)
                                                  ]}
                                                  onChange={this.handleStartEndDate}
                                              />
                                          </div>

                                          <div className="trendViewByDaysSelectBoxWrapper pull-left">
                                              <Select
                                                  className="trendViewByDaysSelectBox"
                                                  defaultValue="Hours"
                                                  onChange={this.handleTrendBucketType.bind(this)}
                                                  value={
                                                      tabModelStore.trendBucketType != ""
                                                          ? tabModelStore.trendBucketType
                                                          : "Hours"
                                                  }
                                              >
                                                  <Option value="Hours">View by Hours</Option>
                                                  <Option value="Days">View by Days</Option>
                                                  <Option value="Months">View by Months</Option>
                                              </Select>
                                          </div>
                                          {/* Refresh */}
                                          <div className="row reset-utilization-settings pull-left">
                                              <i
                                                  className="icon-refresh"
                                                  onClick={this.handleRefresh.bind(this)}
                                              />
                                          </div>
                                      </div>
                                  </div>
                              ) : (
                                  ""
                              )}
                              {tabModelStore.datacontextState == "step3" ? (
                                  <div className="warningsListWrapper">
                                      <div className="warningsListTitleBarContainer">
                                          <Row>
                                              <Col span={12}>
                                                  <h5>ERRORS & WARNINGS</h5>
                                              </Col>
                                          </Row>
                                      </div>
                                      <div className="warningsListBodyContainer">
                                          <Row className="warningsListHeader">
                                              {/*heading*/}
                                              <Col span={5}>
                                                  <h5>Time</h5>
                                              </Col>
                                              <Col span={11}>
                                                  <h5>Message</h5>
                                              </Col>
                                              <Col span={8}>
                                                  <h5>Type</h5>
                                              </Col>
                                              {/*body*/}

                                              {/*body ends here*/}
                                          </Row>
                                          <div
                                              style={{
                                                  height: window.innerHeight - 347,
                                                  overflowY: "scroll"
                                              }}
                                          >
                                              {tabModelStore.errorsList.map(item => (
                                                  <RowItem
                                                      time={item.timestamp}
                                                      type="Error"
                                                      message={item.message}
                                                      key={item}
                                                  />
                                              ))}
                                              {tabModelStore.warningsList.map(item => (
                                                  <RowItem
                                                      time={item.timestamp}
                                                      type="Warning"
                                                      message={item.message}
                                                      key={item}
                                                  />
                                              ))}
                                          </div>
                                      </div>
                                  </div>
                              ) : (
                                  ""
                              )}
                          </ModalBody>
                          <ModalFooter>
                              {tabModelStore.datacontextState != "step1" ? (
                                  <div className="footerBackWrapper">
                                      <Row>
                                          <Col span={24} style={{ textAlign: "center" }}>
                                              <button
                                                  className="btn btn-primary btn-sm backButton"
                                                  onClick={this.handleBackButtonClick}
                                              >
                                                  <i className="fa fa-arrow-circle-o-left" /> Back
                                              </button>
                                          </Col>
                                      </Row>{" "}
                                      {/*Back*/}
                                  </div>
                              ) : (
                                  ""
                              )}
                          </ModalFooter>
                      </Modal>
                  </div>
              ) : (
                  ""
              )}
          </div>
      );
  }
}
export default AssetHealth;

AssetHealth.propTypes = {
    openModal: PropTypes.object,
    HealthCode: PropTypes.object
};
