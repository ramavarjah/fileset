import React from "react";
import * as PropTypes from "prop-types";

export default class HealthCellRenderer extends React.Component {
    render() {
        const rowData = this.props.data;
        return rowData.HealthStatus;
    }
}

// the grid will always pass in one props called 'params',
// which is the grid passing you the params for the cellRenderer.
// this piece is optional. the grid will always pass the 'params'
// props, so little need for adding this validation meta-data.
HealthCellRenderer.propTypes = {
    params: PropTypes.object,
    data: PropTypes.object
};
