/* eslint react/no-deprecated: 0 */
import React, { Component } from "react";
import { AgGridReact } from "ag-grid-react";
import RowDataFactory from "./RowDataFactory";
import DateComponent from "./DateComponent";
import "ag-grid/dist/styles/ag-grid.css";
import "ag-grid/dist/styles/theme-fresh.css";
import tabModelStore from "../../../stores/tabModelStore";
import addAssetsStore from "../../../stores/addAssetsStore";
import {
  defaultColumnState,
  defaultColIdState,
  defaultPinState,
  defaultColWidth
} from "./Constants";
import "./styles.css";
// import printjs from '../../../../libs/printJs/dist/print.min'
import "./RichGridExample.css";
import UIFunctions from "../../../helpers/UIFunctions";
import Functions from "../../../api/Functions";
// take this line out if you do not want to use ag-Grid-Enterprise
import "ag-grid-enterprise";
import { observer } from "mobx-react";
import { isSessionValid } from "../../../api/request";
import { Button, Spin } from "antd";
import _ from "lodash";
@observer
export default class KSGrid extends Component {
  constructor() {
    super();

    this.state = {
      lastPageFound: false,
      currentLimit: tabModelStore.getActiveTab.Pagination,
      totalPages: 0,
      startItem: 1,
      lastItem: 25,
      quickFilterText: null,
      showToolPanel: false,
      columnDefs: tabModelStore.currentTabColoumnsArray,
      rowData: tabModelStore.currentScreenDataArray,
      overlayLoadingTemplate:
        '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>',
      overlayNoRowsTemplate:
        '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow;">No Data Found</span>',
      icons: {
        columnRemoveFromGroup: '<i class="fa fa-remove"/>',
        filter: '<i class="fa fa-filter"/>',
        sortAscending: '<i class="fa fa-long-arrow-down"/>',
        sortDescending: '<i class="fa fa-long-arrow-up"/>',
        groupExpanded: '<i class="fa fa-minus-square-o"/>',
        groupContracted: '<i class="fa fa-plus-square-o"/>',
        columnGroupOpened: '<i class="fa fa-minus-square-o"/>',
        columnGroupClosed: '<i class="fa fa-plus-square-o"/>'
      },
      isDensityApplied: "false",
      currentDensityState: tabModelStore.getActiveTab.DisplayDensity,
      bottomFooterHeight: 165,
      currentTabId: ""
    };
    var thisRef = this;
    // the grid options are optional, because you can provide every property
    // to the grid via standard React properties. however, the react interface
    // doesn't block you from using the standard JavaScript interface if you
    // wish. Maybe you have the gridOptions stored as JSON on your server? If
    // you do, the providing the gridOptions as a standalone object is just
    // what you want!
    this.getContextMenuItems = function getContextMenuItems() {
      var result = ["copy", "separator", "copyWithHeaders"];
      return result;
    };
    this.getMainMenuItems = params => {
      // switch (params.column.getId()) {
      //     case "athlete":
      var menuItems = params.defaultItems.slice(0);
      // console.log("params", params, menuItems);
      // console.log("getColumnState()", params.columnApi.getColumnState());
      // var index = menuItems.indexOf("autoSizeAll");
      // if (index !== -1) menuItems.splice(index, 1);
      var index = menuItems.indexOf("autoSizeThis");
      if (index !== -1) menuItems.splice(index, 1);
      index = menuItems.indexOf("autoSizeThis");
      if (index !== -1) menuItems.splice(index, 1);
      index = menuItems.indexOf("resetColumns");
      if (index !== -1) menuItems.splice(index, 1);
      index = menuItems.indexOf("toolPanel");
      if (index !== -1) menuItems.splice(index, 1);
      menuItems.push("separator");
      menuItems.push({
        name: "Reset Columns",
        action: function() {
          var payloadString = JSON.stringify(defaultPinState);
          params.columnApi.setColumnState(defaultColumnState);
          tabModelStore.setColumnOrder(defaultColIdState);
          tabModelStore.setPinnedColumn(payloadString);
          tabModelStore.setColumnWidth(defaultColWidth);
        }
      });

      menuItems.push({
        name: "Show all columns",
        action: function() {
          var columnstate = [];
          var newColumnstate = [];
          var payload = [];
          columnstate = params.columnApi.getColumnState();
          //console.log("ag-Grid:showall", columnstate);
          columnstate.map(item => {
            item.colId == "thingName"
              ? (item.hide = true)
              : (item.hide = false);
            newColumnstate.push(item);
            payload.push(item.colId);
          });
          Functions.AssetGridColumnShow(payload);
          params.columnApi.setColumnState(newColumnstate);
        }
      });
      menuItems.push({
        name: "Hide all columns",
        action: () => {
          var columnState = params.columnApi.getColumnState();
          var newColumnState = [];
          if (columnState) {
            columnState.map((item) => {
                //making EquipmentNo column visible othervise header itself will not be there for re enabling and checkbox as well 
                (item.colId == "EquipmentNo") | (item.colId == 0)
                ? (item.hide = false)
                : (item.hide = true);
              newColumnState.push(item);
            });
            var payloadArrayHide = [];
            newColumnState.map(function(e) {
              if (e.hide) payloadArrayHide.push(e.colId);
            });
            Functions.AssetGridColumnHide(payloadArrayHide);
            params.columnApi.setColumnState(newColumnState);
          }
        }
      });
      menuItems.push("separator");
      menuItems.push({
        name: "Reset Sorters",
        action: this.resetColumnSorting.bind(this)
      });
      // menuItems.push({
      //   name: "Export Grid as CSV",
      //   action:this.onExport.bind(this)
      // });

      return menuItems;
    };
    this.gridOptions = {
      //We register the react date component that ag-grid will use to render
      dateComponentFramework: DateComponent,
      // this is how you listen for events using gridOptions
      onModelUpdated: function() {},
      defaultColDef: {
        //  headerComponentFramework: SortableHeaderComponent,
        headerComponentParams: {
          menuIcon: "fa-bars"
        }
      },
      // this is a simple property
      rowBuffer: 10, // no need to set this, the default is fine for almost all scenarios,
      //  floatingFilter: true
      getRowHeight: function() {
        if (
          thisRef.state != undefined &&
          thisRef.state.currentDensityState == "medium"
        ) {
          return 43;
        } else if (
          thisRef.state != undefined &&
          thisRef.state.currentDensityState == "large"
        ) {
          return 50;
        } else {
          return 35;
        }
      }
    };

    this.onDragStopped = this.onDragStopped.bind(this);
    this.onColumnPinned = this.onColumnPinned.bind(this);
    this.onGridReady = this.onGridReady.bind(this);
    this.onRowSelected = this.onRowSelected.bind(this);
    this.onCellClicked = this.onCellClicked.bind(this);
    this.onRowDoubleClicked = this.rowDoubleClicked.bind(this);
    //this.onVirtualColumnsChanged = this.onVirtualColumnsChanged.bind(this);
    this.onWinResize = this.onWinResize.bind(this);
    this.checkDashboardChecks = this.checkDashboardChecks.bind(this);
    this.onSortChanged = this.onSortChanged.bind(this);
    this.debouncedPagination = _.debounce(
      this.debouncedPagination.bind(this),
      200
    );
    // this.onModelUpdated = this.onModelUpdated.bind(this);
    this.onColumnResized = _.debounce(this.onColumnResized.bind(this), 200);
  }
  componentDidMount = () => {
    //this.handleDensityDefault();
    this.onWinResize();
    document.getElementById("pageInput").value = tabModelStore.currentPage;
  };

  checkDashboardChecks() {
    // console.log('check changed', this.api, addAssetsStore.dashboardChecked.length);
    var self = this;
    setTimeout(function() {
      self.formLoaded = true;
      self.api && addAssetsStore.dashboardChecked.length == 0
        ? self.api.deselectAll()
        : "";
    }, 400);
  }
  handlePageSize(e) {
    var currentLimit = e.target.value;
    this.setState({ currentLimit: currentLimit });
    this.api.paginationSetPageSize(currentLimit);
    tabModelStore.setPagination(currentLimit);
    //Issue Fix - disorientation/center Mis alignment of text on increasing the display density and increasing the number of items on the page
    if (this.state != undefined && this.state.currentDensityState == "medium") {
      this.handleDensityMedium();
    } else if (
      this.state != undefined &&
      this.state.currentDensityState == "large"
    ) {
      this.handleDensityLarge();
    } else {
      this.handleDensityDefault();
    }
    //end here
  }
  onToggleToolPanel(event) {
    this.setState({ showToolPanel: event.target.checked });
  }

  onGridReady(params) {
    // console.log("ongridready", params);
    this.api = params.api;
    this.columnApi = params.columnApi;
    this.setState({ totalPages: this.api.paginationGetTotalPages() });
    // console.log("Total Pages : ", this.api.paginationGetTotalPages())
    this.onPaginationChanged();
    var sortedColumn = [];
    tabModelStore.getActiveTab.SortedColumns.array
      ? (sortedColumn = JSON.parse(
          JSON.stringify(tabModelStore.getActiveTab.SortedColumns.array)
        ))
      : (sortedColumn = []);
    tabModelStore.setPinnedColumn(
      JSON.stringify(tabModelStore.getActiveTab.PinColumn)
    );
    Functions.GetGridDataModel(tabModelStore.getActiveTab.TabId).then(resp => {
      tabModelStore.setCurrentTabColoumns(resp);
    });
    this.setState({ currentTabId: tabModelStore.getActiveTab.TabId });
    this.api.setSortModel(sortedColumn);
  }
  onSortChanged() {
    // console.log("onSortChanged Called");
    var activeTabId = JSON.parse(JSON.stringify(tabModelStore.getActiveTab))
      .TabId;
    // console.log("active id tab", activeTabId, " test", this.api);
    var sortModel = JSON.stringify(this.api.getSortModel());
    var SortData = {};
    SortData.sorter = sortModel;
    SortData.TabId = activeTabId;
    // console.log("current Tab id", activeTabId);
    // console.log("onSortChanged", sortModel);
    Functions.SetColumnSort(SortData);

    var activeTab = tabModelStore.activeTab;
    activeTab.SortedColumns.array = sortModel;
    tabModelStore.setActiveTab(activeTab);
  }
  // demo to set the sortting from the array
  // put this inside componentDidMount when you get the sortmodel from server _Sooraj
  // var dummySort = [{ "colId": "IsConnected", "sort": "desc" }];
  // this.api.setSortModel(dummySort)

  handleRefresh() {
    tabModelStore.reRenderGrid();
    // console.log("test1");
  }

  setCountryVisible(visible) {
    this.columnApi.setColumnVisible("country", visible);
  }

  onQuickFilterText(event) {
    this.setState({ quickFilterText: event.target.value });
  }
  onDragStopped() {
    var payload = {};
    if (this.columnApi.getAllGridColumns()) {
      var order = this.columnApi.getAllGridColumns();
      order.map((item, index) => {
        var colId = item.colId;
        payload[colId] = index;
      });
      // console.log("payload", payload);
    }
    tabModelStore.setColumnOrder(payload);
  }
  onColumnResized() {
    var payload = {};
    if (this.columnApi.getAllGridColumns()) {
      var order = this.columnApi.getAllGridColumns();
      order.map(item => {
        payload[item.colId] = item.actualWidth;
      });
      //  console.log({ payload, order });
    }
    tabModelStore.setColumnWidth(payload);
  }

  onColumnPinned() {
    // console.log("pinedfunction..");
    var payload = {
      PinnedColumn: {
        pinleft: [],
        pinright: []
      }
    };
    if (this.columnApi.getAllGridColumns()) {
      var order = this.columnApi.getAllGridColumns();
      order.map((item, index) => {
        var pinned = item.pinned;
        var colId = item.colId;
        if (pinned == "left") {
          // console.log("leftpineed");
          payload.PinnedColumn.pinleft.push({ colId: colId, fieldId: index });
          //payload.PinnedColumn.pinleft[i].colId = colId;
        }
        if (pinned == "right") {
          // console.log("rightpinned");
          payload.PinnedColumn.pinright.push({ colId: colId, fieldId: index });
        }
      });
      var payloadString = JSON.stringify(payload);
    }
    tabModelStore.setPinnedColumn(payloadString);
  }
  onCellClicked(event) {
    function clearSelection() {
      if (window.getSelection) {
        window.getSelection().removeAllRanges();
      } else if (document.selection) {
        document.selection.empty();
      }
    }
    // console.log('onCellClicked: ', event, ', col ' + event.column.colId);
    if (event.data.HealthCode == "GREY") return;
    if (event.column.colId == "HealthStatus") {
      var row = event.data;
      var json = JSON.stringify(row);
      addAssetsStore.setRowData(json);
      addAssetsStore.setDoubleClick(false);
      addAssetsStore.setSingleClick(true);
      addAssetsStore.setHealthModalOpen(true);
      setTimeout(() => {
        clearSelection();
      }, 100);
    }
  }

  onRowSelected() {
    // console.log('onRowSelected ');
    var self = this;

    if (self.state.selecting) return;
    // console.log('onRowSelected: ', this.state.selecting, tabModelStore.gridOptions.api.getSelectedRows());
    let p1 = new Promise(resolve => {
      self.setState({ selecting: true });

      addAssetsStore.dashboardAddCheck(this.api.getSelectedRows());
      resolve("success");
    });
    p1.then(() => {
      self.setState({ selecting: false });
      // console.log(addAssetsStore.rowArrayData)

      //loop through the ks grid and filters out is the row selected or not in the grid
      var isTrue = false;
      addAssetsStore.rowArrayData.map(item =>
        item != undefined ? (isTrue = true) : (isTrue = false)
      );
      isTrue
        ? addAssetsStore.setIsDashboardSelected(true)
        : addAssetsStore.setIsDashboardSelected(false);
      addAssetsStore.setDataForBulkEdit(this.api.getSelectedRows());
    });
  }

  rowDoubleClicked(event) {
    if (!isSessionValid()) return;
    addAssetsStore.setDoubleClickedUniqueID(event.data.UniqueID);
    var row = event.data;
    var json = JSON.stringify(row);
    addAssetsStore.setRowData(json);
    addAssetsStore.toggleAssetDetailsModal();
  }

  onRefreshData() {
    let newRowData = new RowDataFactory().createRowData();
    this.setState({
      rowData: newRowData
    });
  }

  invokeSkillsFilterMethod() {
    let skillsFilter = this.api.getFilterInstance("skills");
    let componentInstance = skillsFilter.getFrameworkComponentInstance();
    componentInstance.helloFromSkillsFilter();
  }

  dobFilter() {
    let dateFilterComponent = this.gridOptions.api.getFilterInstance("dob");
    dateFilterComponent.setFilterType("equals");
    dateFilterComponent.setDateFrom("2000-01-01");
    setTimeout(() => {
      this.gridOptions.api.onFilterChanged();
    }, 0);
  }

  onPaginationChanged() {
    if (this.api) {
      this.setState({ lastPageFound: this.api.paginationIsLastPageFound() });
      tabModelStore.setCurrentLimit(this.api.paginationGetPageSize());
      tabModelStore.setCurrentPage(this.api.paginationGetCurrentPage() + 1);

      var currentPage = this.api.paginationGetCurrentPage();
      var currentPageSize = this.api.paginationGetPageSize();
      var startItem = currentPage * currentPageSize + 1;

      var lastItem = +parseInt(startItem) + parseInt(currentPageSize) - 1;
      if (lastItem > tabModelStore.currentScreenDataArray.length)
        lastItem = tabModelStore.currentScreenDataArray.length;
      this.setState({
        totalPages: this.api.paginationGetTotalPages(),
        startItem,
        lastItem
      });
      // console.log("new current Pages : ", currentPage, currentPageSize);
      // console.log("new current Pages : ", startItem, lastItem);

      // setState(!this.api.paginationIsLastPageFound());
    }
  }
  getTable(arrays, selectedRows) {
    // console.log("arrays", arrays);
    // console.log(" selectedRows", selectedRows);
    var content = [];
    content.push({ text: "Keysight Asset Advisor", style: "header" });
    arrays.map(i => {
      //each table starts
      var table = {};
      table.style = "tableExample";
      var headerRow = [];
      i.map(item => {
        // styling table header
        var headerItm = {};
        headerItm.text = item.headerName;
        headerItm.style = "tableHeader";
        headerRow.push(headerItm);
      });
      var tableBody = [];
      tableBody.push(headerRow);
      selectedRows.map(ii => {
        //each rows start
        var it = [];
        i.map(header => {
          //mapping with headers
          if (ii[header.field]) {
            // console.log("typeof", header.field, typeof (ii[header.field]))
            header.field == "HealthStatus"
              ? it.push(ii[header.field].props.title)
              : ii[header.field]
              ? it.push(ii[header.field])
              : it.push("_");
          } else {
            it.push("");
          }
          // console.log("ii", ii);
          // ii[i[0]]
        });
        // console.log("it", it);
        tableBody.push(it);
      });
      // console.log("tableBody", tableBody);
      var tableItem = {
        body: tableBody
      };
      tableItem.widths = [100, 100, 100, 100, 100];
      // console.log("tableItem", tableItem);
      table["table"] = tableItem;
      table["layout"] = {
        hLineWidth: function(i, node) {
          return i === 0 || i === node.table.body.length ? 2 : 1;
        },
        vLineWidth: function(i, node) {
          return i === 0 || i === node.table.widths.length ? 2 : 1;
        },
        hLineColor: function(i, node) {
          return i === 0 || i === node.table.body.length ? "black" : "gray";
        },
        vLineColor: function(i, node) {
          return i === 0 || i === node.table.widths.length ? "black" : "gray";
        }
        // paddingLeft: function(i, node) { return 4; },
        // paddingRight: function(i, node) { return 4; },
        // paddingTop: function(i, node) { return 2; },
        // paddingBottom: function(i, node) { return 2; },
        // fillColor: function (i, node) { return null; }
      };

      content.push(table);
    });
    // console.log("content", content);
    return content;
  }
  onPrint() {
    var selectedRows = [];
    selectedRows = this.api.getSelectedRows();
    if (!selectedRows || selectedRows.length === 0)
      return UIFunctions.Toast(
        "Please select one or more assets to print !",
        "warn"
      );
    var newArray = [];
    var arrays = [];
    tabModelStore.currentTabColoumnsArray.map(function(e) {
      var item = {};
      item.field = e.field;
      item.headerName = e.headerName;
      newArray.push(item);
    });
    while (newArray.length > 0)
      arrays.push(newArray.splice(0, 5) ? newArray.splice(0, 5) : "_");
    // console.log(arrays);
  }
  onExport() {
    var columnState = this.columnApi.getColumnState();
    var basecolumnState = [];
    columnState.map(item => {
      //current columnstate
      item.colId == "0" || item.hide ? "" : basecolumnState.push(item.colId);
    });
    // this.columnApi.setColumnState(columnState);// set new state

    var params = {};
    params.processCellCallback = function(params) {
      if (params.value && params.column.colId === "HealthStatus") {
        // console.log(params);
        var newParams = params;
        newParams.value = newParams.value.props.title;
        return newParams.value;
      } else {
        return params.value;
      }
    };
    params.customHeader = "Keysight Asset Advisor - Asset Data \n";
    if (addAssetsStore.rowArrayData.length > 0) params.onlySelected = true;

    params.columnKeys = basecolumnState;
    this.api.exportDataAsCsv(params);
  }
  handleDensityDefault() {
    this.setState({
      isDensityApplied: "false",
      currentDensityState: "default"
    });
    this.setState({ currentDensityState: "default" });
    tabModelStore.setCurrentDensity("default");
    setTimeout(() => {
      //setting it so that it balance the the lag
      this.gridOptions.api.resetRowHeights();
      this.gridOptions.api.onRowHeightChanged();
    }, 0);
  }
  handleDensityMedium() {
    this.setState({ isDensityApplied: "true", currentDensityState: "medium" });

    this.setState({ currentDensityState: "medium" });
    tabModelStore.setCurrentDensity("medium");
    setTimeout(() => {
      //setting it so that it balance the the lag
      this.gridOptions.api.resetRowHeights();
      this.gridOptions.api.onRowHeightChanged();
    }, 0);
  }
  handleDensityLarge() {
    this.setState({ isDensityApplied: "true", currentDensityState: "large" });
    tabModelStore.setCurrentDensity("large");
    setTimeout(() => {
      //setting it so that it balance the the lag
      this.gridOptions.api.resetRowHeights();
      this.gridOptions.api.onRowHeightChanged();
    }, 0);
  }
  _handleKeyPress = e => {
    if (e.key === "Enter") {
      this.paginationGoToPage(e.target.value);
    }
  };
  /*onVirtualColumnsChanged() {

        if (this.state.isDensityApplied == "true") {
            if (this.state.currentDensityState == "medium") {
                this.handleDensityMedium();
            }
            else {
                this.handleDensityLarge();
            }
        }

    }*/
  onWinResize() {
    var gridElem = document.getElementById("ksgridContainer");
    if (gridElem) {
      var footerElem = document.getElementById("footer");
      var mainFooter = document.getElementById("mainFooter");
      var appHeader = document.getElementById("app-header");
      // console.log("heights", footerElem.clientHeight, mainFooter.clientHeight, appHeader.clientHeight);
      var footerPlusBottomElemHeight =
        footerElem.clientHeight +
        mainFooter.clientHeight +
        appHeader.clientHeight -
        7;
      this.setState({ bottomFooterHeight: footerPlusBottomElemHeight });
    }
  }
  resetColumnSorting() {
    this.api.setSortModel(null);
  }
  onBtFirst() {
    this.api.paginationGoToFirstPage();
  }
  onBtLast() {
    this.api.paginationGoToLastPage();
  }
  onBtNext() {
    this.api.paginationGoToNextPage();
  }
  onBtPrevious() {
    this.api.paginationGoToPreviousPage();
  }
  getTotalPages() {
    return this.api.paginationGetTotalPages();
  }
  paginationGoToPage(e) {
    if (e > 0) {
      this.debouncedPagination(parseInt(e) - 1);
    }
    if (e <= 0) {
      document.getElementById("pageInput").value = tabModelStore.currentPage;
      UIFunctions.ShowWarning({ zIndex: 2000, title: "Invalid PageValue!" });
    }
  }
  debouncedPagination(page) {
    this.api.paginationGoToPage(page);
  }

  colVisibilityChanged(e) {
    // console.log("colVisibilityChanged", e);
    var columnState = [];
    var newColumnState = [];
    var allHidden = false;
    columnState = e.columnApi.getColumnState();
    columnState.map(item => {
      //current columnstate
      item.hide ? "" : (allHidden = true);
    });
    if (e.column.colId == "EquipmentNo") {
      e.column.hide = false; //getting current column name
      var pos = 0;
      columnState.map((item, index) => {
        if (item.colId == "EquipmentNo") pos = index;
      });
      columnState[pos] = e.column; //push to new state
      e.columnApi.setColumnState(columnState); // set new state
      return UIFunctions.Toast("You cannot hide equipment number.", "warn");
    }

    if (!allHidden) {
      //dont allow user to hide the last column
      e.column.hide = false; //getting current column name
      newColumnState.push(e.column); //push to new state
      e.columnApi.setColumnState(newColumnState); // set new state
      return UIFunctions.Toast("You cannot hide all the columns.", "warn");
    }
    e.visible
      ? Functions.AssetGridColumnShow(
          [e.column.colId],
          tabModelStore.activeTab.TabId
        )
      : Functions.AssetGridColumnHide(
          [e.column.colId],
          tabModelStore.activeTab.TabId
        );
  }
  // onModelUpdated(params) {
  //     console.log("onModelUpdated called");
  //     var sortedColumn = [];
  //     (tabModelStore.getActiveTab.SortedColumns.array) ? sortedColumn = JSON.parse(JSON.stringify(tabModelStore.getActiveTab.SortedColumns.array)) : sortedColumn = []
  //     console.log("onModelupdated", sortedColumn, params);
  //     console.log("onModelupdated_", this.state.currentTabId, tabModelStore.getActiveTab.TabId);
  //     console.log("onModelupdated_", this.state.currentTabId != tabModelStore.getActiveTab.TabId);
  //     if (this.state.currentTabId != tabModelStore.getActiveTab.TabId) {
  //         params.api.setSortModel(sortedColumn);
  //         this.setState({ "currentTabId": tabModelStore.getActiveTab.TabId })
  //     }
  // }
  // componentDidUpdate() {
  //     console.log("componentDidUpdate called",!tabModelStore.dataLoaded);
  //     if (!tabModelStore.dataLoaded) return;
  //     console.log("dataLoaded", tabModelStore.dataLoaded)
  //     var sortedColumn = [];
  //     sortedColumn = (tabModelStore.getActiveTab.SortedColumns.array) ? JSON.parse(JSON.stringify(tabModelStore.getActiveTab.SortedColumns.array)) :  [];
  //     // console.log("onModelupdated", sortedColumn, params);
  //     // console.log("onModelupdated_", this.state.currentTabId, tabModelStore.getActiveTab.TabId);
  //     // console.log("onModelupdated_bool", this.state.currentTabId != tabModelStore.getActiveTab.TabId);
  //     console.log("sortedColumn",sortedColumn)
  //     if (this.state.currentTabId != tabModelStore.getActiveTab.TabId) {
  //         this.api && this.api.setSortModel(sortedColumn);
  //         this.setState({ "currentTabId": tabModelStore.getActiveTab.TabId })
  //     }
  // }
  componentWillReceiveProps() {
    // console.log("tabcheckksgrid..", tabModelStore.tabCheck);
    //console.log("pineed....",tabModelStore.getActiveTab.PinColumn.PinnedColumn.pinleft[0].colId);
    var currentDensity = tabModelStore.getActiveTab.DisplayDensity;
    var currentLimit = tabModelStore.getActiveTab.Pagination;
    if (this.state.currentTabId !== tabModelStore.getActiveTab.TabId) {
      this.setState({ currentLimit: currentLimit });
      this.api.paginationSetPageSize(currentLimit);
      if (currentDensity == "medium") {
        this.setState({ currentDensityState: "medium" });
        this.gridOptions.api.resetRowHeights();
        this.gridOptions.api.onRowHeightChanged();
      } else if (currentDensity == "large") {
        this.setState({ currentDensityState: "large" });
        this.gridOptions.api.resetRowHeights();
        this.gridOptions.api.onRowHeightChanged();
      } else {
        this.setState({ currentDensityState: "default" });
        this.gridOptions.api.resetRowHeights();
        this.gridOptions.api.onRowHeightChanged();
        tabModelStore.tabCheck = false;
      }
      this.setState({ currentTabId: tabModelStore.getActiveTab.TabId });
    }
  }
  render() {
    window.addEventListener("resize", this.onWinResize);
    addAssetsStore.dashboardChecked ? this.checkDashboardChecks() : "";
    // console.log('rowData', tabModelStore.dataLoaded, tabModelStore.currentScreenDataArray.map(e => e));
    // var footerElem = document.getElementById("app-header");
    // var headerHeight = footerElem.clientHeight ;
    return (
      <div id="main-grid-container">
        <Spin spinning={!tabModelStore.dataLoaded} delay={500}>
          <div style={{ paddingTop: 13, marginLeft: 59 }}>
            <div
              id="ksgridContainer"
              style={{
                height: window.innerHeight - this.state.bottomFooterHeight,
                width: "100%",
                backgroundColor: "white",
                color: "#666"
              }}
              className="ag-fresh"
            >
              {/*MAIN GRID CONFIG/SETUP*/}
              <AgGridReact
                // ref="myGrid"
                // gridOptions is optional - it's possible to provide
                // all values as React props
                gridOptions={this.gridOptions}
                onDragStopped={this.onDragStopped}
                onColumnPinned={this.onColumnPinned}
                getMainMenuItems={this.getMainMenuItems}
                onModelUpdated={this.onModelUpdated} //(e)=>console.log("changed")}
                // listening for events
                onGridReady={this.onGridReady}
                onRowSelected={this.onRowSelected}
                onCellClicked={this.onCellClicked}
                onRowDoubleClicked={this.onRowDoubleClicked}
                onColumnResized={this.onColumnResized}
                //onVirtualColumnsChanged={this.onVirtualColumnsChanged}
                // binding to simple properties
                onColumnVisible={this.colVisibilityChanged}
                showToolPanel={this.state.showToolPanel}
                quickFilterText={this.state.quickFilterText}
                getContextMenuItems={this.getContextMenuItems}
                // binding to an object property
                icons={this.state.icons}
                // binding to array properties
                columnDefs={tabModelStore.currentTabColoumnsArray.map(e => e)}
                // rowData={tabModelStore.currentScreenDataArray}
                pagination={true}
                paginationPageSize={this.state.currentLimit}
                rowData={tabModelStore.currentScreenDataArray.map(e => e)}
                // no binding, just providing hard coded strings for the properties
                suppressRowClickSelection="true"
                rowSelection="multiple"
                enableColResize="true"
                enableSorting="true"
                //  enableFilter="true"
                groupHeaders="true"
                suppressPaginationPanel={true}
                //rowHeight="35"
                headerHeight="55"
                onPaginationChanged={this.onPaginationChanged.bind(this)}
                // overlayLoadingTemplate={this.state.overlayLoadingTemplate}
                overlayNoRowsTemplate={this.state.overlayNoRowsTemplate}
                onSortChanged={this.onSortChanged}
                suppressColumnVirtualisation={true}
              />
            </div>
          </div>
        </Spin>
        <div id="footer">
          <div>
            <nav className="navbar navbar-dark bg-dark paginationBar">
              <div className="col-sm-3 paginationButtons">
                <ul>
                  <li className=" pageControls ">
                    <i
                      className="fa fa-angle-double-left clickable tooltipcss"
                      onClick={this.onBtFirst.bind(this)}
                    >
                      <span className="footertooltiptext firsttip">
                        First Page
                      </span>
                    </i>
                  </li>
                  <li className=" pageControls ">
                    <i
                      className="fa fa-angle-left clickable tooltipcss"
                      onClick={this.onBtPrevious.bind(this)}
                    >
                      <span className="footertooltiptext">Previous Page</span>
                    </i>
                  </li>
                  <li>
                    <span className="page">Page</span>
                  </li>
                  <li>
                    <input
                      id="pageInput"
                      className="pageNumberInput"
                      type="input"
                      min="1"
                      onKeyPress={this._handleKeyPress}
                      //onChange={this.paginationGoToPage.bind(this)}
                      //value={tabModelStore.currentPage}
                    />
                  </li>
                  <li>
                    <span className="of38">of {this.state.totalPages}</span>
                  </li>
                  <li className=" pageControls ">
                    <i
                      className="fa fa-angle-right clickable tooltipcss"
                      onClick={this.onBtNext.bind(this)}
                    >
                      <span className="footertooltiptext">Next Page</span>
                    </i>
                  </li>
                  <li className=" pageControls ">
                    <i
                      className="fa fa-angle-double-right clickable tooltipcss"
                      onClick={this.onBtLast.bind(this)}
                    >
                      <span className="footertooltiptext">Last Page</span>
                    </i>
                  </li>
                  <li className=" pageControls ">
                    <i
                      className="icon-refresh clickable tooltipcss"
                      onClick={this.handleRefresh.bind(this)}
                    >
                      <span className="footertooltiptext">Refresh</span>
                    </i>
                  </li>
                </ul>
              </div>

              <div className="col-sm-1 pageSize tooltipcss ">
                <select
                  id="tabSelect"
                  className="dashfooterSelect"
                  onChange={this.handlePageSize.bind(this)}
                  value={this.state.currentLimit}
                >
                  <option key={25}>25</option>
                  <option key={50}>50</option>
                  <option key={100}>100</option>
                  <option key={250}>250</option>
                  <option key={500}>500</option>
                  <option key={1000}>1000</option>
                  <option key={2500}>2500</option>
                  <option key={5000}>5000</option>
                </select>

                <span className="footertooltiptext">Page Size</span>
              </div>
              {/*============== 'Display Density Group' ==============*/}
              <div className="col-sm-2 displayDensity">
                <ul>
                  <li className="densityButtons">
                    <span className="displayDensityLabel">Display Density</span>
                  </li>
                  <li
                    className="densityButtons tooltipcss"
                    onClick={this.handleDensityDefault.bind(this)}
                  >
                    <a href="#">
                      <i
                        className={
                          "icon-menu " +
                          (this.state.currentDensityState == "default"
                            ? "selected"
                            : "")
                        }
                        style={{ fontSize: "0.8em", paddingRight: 15 }}
                      >
                        <span className="footertooltiptext">small</span>
                      </i>
                    </a>
                  </li>
                  <li
                    className="densityButtons tooltipcss"
                    onClick={this.handleDensityMedium.bind(this)}
                    style={{ marginTop: 2 }}
                  >
                    <a href="#">
                      <i
                        className={
                          "icon-menu " +
                          (this.state.currentDensityState == "medium"
                            ? "selected"
                            : "")
                        }
                        style={{ fontSize: "1.2em", paddingRight: 15 }}
                      >
                        <span className="footertooltiptext">Medium</span>
                      </i>
                    </a>
                  </li>
                  <li
                    className="densityButtons tooltipcss"
                    onClick={this.handleDensityLarge.bind(this)}
                    style={{ marginTop: -1 }}
                  >
                    <a href="#">
                      <i
                        className={
                          "icon-menu " +
                          (this.state.currentDensityState == "large"
                            ? "selected"
                            : "")
                        }
                        style={{ fontSize: "1.5em", paddingRight: 15 }}
                      >
                        <span className="footertooltiptext">Large</span>
                      </i>
                    </a>
                  </li>
                </ul>
              </div>
              {/*============== 'Export Buttons' ==============*/}
              <div className="col-sm-2 export-btn-group">
                <div
                  className="exportOptions"
                  style={{ width: "20% !important", padding: "0 0 0 0" }}
                >
                  {
                    <Button.Group className="export-btn-group">
                      <Button
                        type="primary"
                        icon="cloud-download"
                        size="small"
                        onClick={this.onExport.bind(this)}
                      >
                        Export CSV
                      </Button>
                      {/* <Button type="primary" icon="printer" size='small' disabled onClick={this.onPrint.bind(this)} >Print</Button> */}
                      {/* <Button
                        type="primary"
                        icon="close-circle-o"
                        size="small"
                        onClick={this.resetColumnSorting.bind(this)}
                      >
                        Reset Sorters
                      </Button> */}
                    </Button.Group>
                  }
                </div>
              </div>
              {/*<div className="col-sm-2 paginationLabel">*/}
              <span className="grid-page-label">
                <b>
                  {this.state.startItem}-{this.state.lastItem}{" "}
                </b>
                of
                <b> {tabModelStore.currentScreenDataArray.length}</b>
              </span>
              {/*</div>*/}
            </nav>
          </div>
        </div>
      </div>
    );
  }
}
