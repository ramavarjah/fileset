export const defaultColumnState = [
  {
    colId: "0",
    hide: false,
    aggFunc: null,
    width: 40,
    pivotIndex: null,
    pinned: "left",
    rowGroupIndex: null
  },
  {
    colId: "HealthStatus",
    hide: false,
    aggFunc: null,
    width: 110,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "IsConnected",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "AssetNo",
    hide: false,
    aggFunc: null,
    width: 160,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Barcode",
    hide: false,
    aggFunc: null,
    width: 160,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "EquipmentNo",
    hide: false,
    aggFunc: null,
    width: 200,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Manufacturer",
    hide: false,
    aggFunc: null,
    width: 210,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "AltManufacturerName",
    hide: false,
    aggFunc: null,
    width: 270,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ModelNo",
    hide: false,
    aggFunc: null,
    width: 160,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "SerialNo",
    hide: false,
    aggFunc: null,
    width: 160,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Description",
    hide: false,
    aggFunc: null,
    width: 350,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Project",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "LifeCycleStage",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "EquipmentType",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ProductCategory",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "HardwareVersion",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "FirmwareRevision",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Accessories",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Options",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "SoftwareRevision",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "SystemParent",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "SystemName",
    hide: false,
    aggFunc: null,
    width: 160,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "SystemChild",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ParentSystemName",
    hide: false,
    aggFunc: null,
    width: 200,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "PartOfSystemCalibration",
    hide: false,
    aggFunc: null,
    width: 280,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Borrowable",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Organization",
    hide: false,
    aggFunc: null,
    width: 200,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Location",
    hide: false,
    aggFunc: null,
    width: 200,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "User",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Coordinator",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "LastUpdate",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "UtilizationCategory",
    hide: false,
    aggFunc: null,
    width: 200,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "CalibrationDate",
    hide: false,
    aggFunc: null,
    width: 200,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "CalibrationInterval",
    hide: false,
    aggFunc: null,
    width: 250,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "CalibrationDueDate",
    hide: false,
    aggFunc: null,
    width: 210,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "LastReportedCondition",
    hide: false,
    aggFunc: null,
    width: 230,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "CalibrationType",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "CalibrationProvider",
    hide: false,
    aggFunc: null,
    width: 190,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "UseProviderCalibrationType",
    hide: false,
    aggFunc: null,
    width: 250,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "UseProviderCalibrationSchedule",
    hide: false,
    aggFunc: null,
    width: 280,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "UseDefaultProvider",
    hide: false,
    aggFunc: null,
    width: 200,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "RepairProvider",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ServiceLogistics",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ServiceCost",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ServiceAgreement",
    hide: false,
    aggFunc: null,
    width: 190,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "OrderDate",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "OrderNumber",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "InvoiceNumber",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "PurchasePrice",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ReceivedDate",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "OwnershipStatus",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "OwningCompany",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "PlannedDisposalDate",
    hide: false,
    aggFunc: null,
    width: 210,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ReplacementDate",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "BookValue",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "BookValueDate",
    hide: false,
    aggFunc: null,
    width: 180,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Depreciation",
    hide: false,
    aggFunc: null,
    width: 250,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "Currency",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "LoanDailyRate",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "LoanAutoCalculate",
    hide: false,
    aggFunc: null,
    width: 190,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "LoanDailyCost",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "ReplacedBy",
    hide: false,
    aggFunc: null,
    width: 150,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "InventoryDate",
    hide: false,
    aggFunc: null,
    width: 170,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  },
  {
    colId: "thingName",
    hide: true,
    aggFunc: null,
    width: 50,
    pivotIndex: null,
    pinned: null,
    rowGroupIndex: null
  }
];

export const defaultColIdState = {
  Accessories: 17,
  AltManufacturerName: 7,
  AssetNo: 3,
  Barcode: 4,
  BookValue: 54,
  BookValueDate: 55,
  Borrowable: 25,
  CalibrationDate: 32,
  CalibrationDueDate: 34,
  CalibrationInterval: 33,
  CalibrationProvider: 37,
  CalibrationType: 36,
  Coordinator: 29,
  Currency: 57,
  Depreciation: 56,
  Description: 10,
  EquipmentNo: 5,
  EquipmentType: 13,
  FirmwareRevision: 16,
  HardwareVersion: 15,
  HealthStatus: 1,
  InventoryDate: 62,
  InvoiceNumber: 47,
  IsConnected: 2,
  LastReportedCondition: 35,
  LastUpdate: 30,
  LifeCycleStage: 12,
  LoanAutoCalculate: 59,
  LoanDailyCost: 60,
  LoanDailyRate: 58,
  Location: 27,
  Manufacturer: 6,
  ModelNo: 8,
  Options: 18,
  OrderDate: 45,
  OrderNumber: 46,
  Organization: 26,
  OwnershipStatus: 50,
  OwningCompany: 51,
  ParentSystemName: 23,
  PartOfSystemCalibration: 24,
  PlannedDisposalDate: 52,
  ProductCategory: 14,
  Project: 11,
  PurchasePrice: 48,
  ReceivedDate: 49,
  RepairProvider: 41,
  ReplacedBy: 61,
  ReplacementDate: 53,
  SerialNo: 9,
  ServiceAgreement: 44,
  ServiceCost: 43,
  ServiceLogistics: 42,
  SoftwareRevision: 19,
  SystemChild: 22,
  SystemName: 21,
  SystemParent: 20,
  UseDefaultProvider: 40,
  UseProviderCalibrationSchedule: 39,
  UseProviderCalibrationType: 38,
  User: 28,
  UtilizationCategory: 31,
  thingName: 63
};
export const defaultColWidth = {
  0: 40,
  Accessories: 150,
  AltManufacturerName: 270,
  AssetNo: 160,
  Barcode: 160,
  BookValue: 150,
  BookValueDate: 180,
  Borrowable: 150,
  CalibrationDate: 200,
  CalibrationDueDate: 210,
  CalibrationInterval: 250,
  CalibrationProvider: 190,
  CalibrationType: 170,
  Coordinator: 150,
  Currency: 150,
  Depreciation: 250,
  Description: 350,
  EquipmentNo: 200,
  EquipmentType: 170,
  FirmwareRevision: 180,
  HardwareVersion: 180,
  HealthStatus: 115,
  InventoryDate: 170,
  InvoiceNumber: 170,
  IsConnected: 150,
  LastReportedCondition: 230,
  LastUpdate: 150,
  LifeCycleStage: 170,
  LoanAutoCalculate: 190,
  LoanDailyCost: 170,
  LoanDailyRate: 170,
  Location: 200,
  Manufacturer: 210,
  ModelNo: 160,
  Options: 150,
  OrderDate: 150,
  OrderNumber: 170,
  Organization: 200,
  OwnershipStatus: 180,
  OwningCompany: 180,
  ParentSystemName: 200,
  PartOfSystemCalibration: 280,
  PlannedDisposalDate: 210,
  ProductCategory: 180,
  Project: 150,
  PurchasePrice: 170,
  ReceivedDate: 170,
  RepairProvider: 170,
  ReplacedBy: 150,
  ReplacementDate: 180,
  SerialNo: 160,
  ServiceAgreement: 190,
  ServiceCost: 150,
  ServiceLogistics: 170,
  SoftwareRevision: 180,
  SystemChild: 150,
  SystemName: 160,
  SystemParent: 170,
  UseDefaultProvider: 200,
  UseProviderCalibrationSchedule: 280,
  UseProviderCalibrationType: 250,
  User: 150,
  UtilizationCategory: 200,
  thingName: 50
};

export const defaultPinState = {
  PinnedColumn: {
    pinleft: [{ colId: "0", fieldId: 0 }],
    pinright: []
  }
};
