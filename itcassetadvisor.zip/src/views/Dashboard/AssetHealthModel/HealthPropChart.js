import React, { Component } from "react";
import "amcharts3";
import "amcharts3/amcharts/serial";
import PropTypes from "prop-types";
import tabModelStore from "src/stores/tabModelStore";
import { Collapse, Icon } from "antd";
import Functions from "src/api/Functions";
import TrendChart from "./TrendChart";
import { graphAdjust, rescaler } from "src/libs/adjust";

const registry = [
  [
    {
      displayName: /Temperature Calibration Range/
    },
    rescaler
  ],
  [
    {
      displayName: /Temperature TimeScale Calibration Range/
    },
    rescaler
  ]
];

const Panel = Collapse.Panel;
const PanelWrapperHeader = ({ text, status }) => (
  <div className="panel-wrapper-header">
    <p style={{ color: status }}>{text} </p>
    {status == "RED" || status == "YELLOW" ? (
      <span>
        <Icon
          type={status == "YELLOW" ? "exclamation-circle" : "close-circle"}
          style={{ color: status }}
        />
      </span>
    ) : (
      ""
    )}
  </div>
);

class HealthPropChart extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.handleResetErrors = this.handleResetErrors.bind(this);
    this.handleResetWarnings = this.handleResetWarnings.bind(this);
  }
  handleExpandErrorsClick = () => {
    tabModelStore.setDataContextState("step3");
  };
  handleResetWarnings() {
    Functions.resetErrorOrWarning(
      this.props.uniqueId,
      tabModelStore.warningsList[0].streamId
    ).then(() => {
      tabModelStore.setErrorsNWarningsLoading(true);
    });
  }
  handleResetErrors() {
    Functions.resetErrorOrWarning(
      this.props.uniqueId,
      tabModelStore.errorsList[0].streamId
    ).then(() => {
      tabModelStore.setErrorsNWarningsLoading(true);
    });
  }
  render() {
    const { ChartData, Level } = this.props;

    function getStatus(i) {
      var returnObj = 0;
      var statuString = JSON.stringify(i);
      if (statuString.indexOf('status":"RED"') >= 0) returnObj = "RED";
      else if (statuString.indexOf('status":"YELLOW"') >= 0)
        returnObj = "YELLOW";
      return returnObj;
    }
    return (
      <div>
        {ChartData
          ? graphAdjust(ChartData, registry).map((i, index) => {
              if (i.child)
                return (
                  <Collapse
                    bordered={false}
                    accordion
                    className="health-collapse-outer"
                    key={index}
                  >
                    <Panel
                      header={
                        <PanelWrapperHeader
                          text={
                            i.name ? i.name : i.graph ? i.graph.deviceName : ""
                          }
                          status={getStatus(i)}
                        />
                      }
                      key={index}
                      style={{ borderColor: getStatus(i) ? getStatus(i) : "" }}
                    >
                      {i.child ? (
                        <HealthPropChart
                          {...this.props}
                          ChartData={i.child}
                          Level={Level + 1}
                        />
                      ) : (
                        i.graph && (
                          <TrendChart
                            {...this.props}
                            graph={i.graph}
                            i={index}
                          />
                        )
                      ) //amchart
                      }
                    </Panel>
                  </Collapse>
                );
              else
                return <TrendChart {...this.props} graph={i.graph} i={index} />;
            })
          : ""}
      </div>
    );
  }
}
export default HealthPropChart;
HealthPropChart.propTypes = {
  ChartData: PropTypes.string.isRequired,
  Level: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
  handleClick: PropTypes.func.isRequired
};
PanelWrapperHeader.propTypes = {
  text: PropTypes.string.isRequired,
  status: PropTypes.string
};
