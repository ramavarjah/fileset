import React from "react";
import Functions from "../../../api/Functions";
import CHART_CONFIG from "../../../views/Charts/chartConfig.js";
import UIFunctions from "./../../../helpers/UIFunctions";
import PropTypes from "prop-types";
import "amcharts3";
import "amcharts3/amcharts/serial";
import AmCharts from "@amcharts/amcharts3-react";
import _ from "lodash";
import { Icon } from "antd";

class TrendChart extends React.Component {
  getMaxChart(graph) {
    let config = {};
    let obj = {
      category: graph.displayName,
      tmp: 20,
      streamId: graph.streamId,
      bullet: graph.healthValue,
      GREEN: graph.Green,
      YELLOW: graph.Yellow,
      RED: Math.ceil(graph.Red),
      ChartMinValue: Math.floor(graph.minValue),
      ChartBaseValue: graph.BaseValue,
      ChartMaxValue: Math.ceil(graph.maxValue),
      device: graph.device,
      metricName: graph.metric_name,
      Units: graph.units,
      thingname: this.props.uniqueId,
      min_hold: graph.min_hold,
      max_hold: graph.max_hold,
      roundoffdigits: graph.num_double_digits
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartmax);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.category,
        x: 10,
        y: 20
      }
    ];
    config.valueAxes[0].minimum = obj.ChartMinValue;
    config.valueAxes[0].maximum = obj.ChartMaxValue;
    config.valueAxes[0].baseValue = obj.ChartBaseValue;
    config.valueAxes[0].guides[0].value = obj.min_hold;
    config.valueAxes[0].guides[1].value = obj.max_hold;
    return config;
  }
  getNoneChart = graph => {
    let config = {};
    let obj = {
      category: graph.healthValue,
      tmp: 20,
      streamId: graph.streamId,
      bullet: graph.displayName,
      device: graph.device,
      metricName: graph.metric_name,
      Units: graph.units,
      thingname: this.props.uniqueId,
      min_hold: graph.min_hold,
      max_hold: graph.max_hold,
      roundoffdigits: graph.num_double_digits
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartnone);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.bullet,
        x: 10,
        y: 20
      }
    ];
    config.categoryAxis.labelsEnabled = true;
    config.categoryAxis.boldLabels = true;
    config.categoryAxis.inside = true;
    return config;
  };
  getMaxMinChart = graph => {
    let config = {};
    let obj = {
      category: graph.displayName,
      tmp: 20,
      streamId: graph.streamId,
      bullet: graph.healthValue,
      REDN: graph.RedN,
      YELLOWN: graph.YellowN,
      GREEN: graph.Green,
      YELLOWP: graph.YellowP,
      REDP: Math.ceil(graph.RedP),
      ChartMinValue: Math.floor(graph.minValue),
      ChartBaseValue: graph.BaseValue,
      ChartMaxValue: Math.ceil(graph.maxValue),
      device: graph.device,
      metricName: graph.metric_name,
      Units: graph.units,
      thingname: this.props.uniqueId,
      min_hold: graph.min_hold,
      max_hold: graph.max_hold,
      roundoffdigits: graph.num_double_digits
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartmin_max);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.category,
        x: 10,
        y: 20
      }
    ];
    config.valueAxes[0].minimum = obj.ChartMinValue;
    config.valueAxes[0].maximum = obj.ChartMaxValue;
    config.valueAxes[0].baseValue = obj.ChartBaseValue;
    config.valueAxes[0].guides[0].value = obj.min_hold;
    config.valueAxes[0].guides[1].value = obj.max_hold;
    return config;
  };
  getMinChart = graph => {
    let config = {};
    let obj = {
      category: graph.displayName,
      tmp: 20,
      streamId: graph.streamId,
      bullet: graph.healthValue,
      RED: graph.Red,
      YELLOW: graph.Yellow,
      GREEN: Math.ceil(graph.Green),
      ChartMinValue: Math.floor(graph.minValue),
      ChartBaseValue: graph.BaseValue,
      ChartMaxValue: Math.ceil(graph.maxValue),
      device: graph.device,
      metricName: graph.metric_name,
      Units: graph.units,
      thingname: this.props.uniqueId,
      min_hold: graph.min_hold,
      max_hold: graph.max_hold,
      roundoffdigits: graph.num_double_digits
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartmin);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.category,
        x: 10,
        y: 20
      }
    ];
    config.valueAxes[0].minimum = obj.ChartMinValue;
    config.valueAxes[0].maximum = obj.ChartMaxValue;
    return config;
  };
  handleReset(graph) {
    var self = this;
    UIFunctions.ShowConfirm({
      title: `Are you sure you want to reset ${graph.deviceName} ?`,
      okText: "Yes",
      cancelText: "No",
      onOk() {
        Functions.ResetHealthParamMinMax(graph.streamId, self.props.uniqueId);
      }
    });
  }

  render() {
    let chart = {};
    const { graph, i } = this.props;
    if (graph.limit_type == "max") {
      chart.config = this.getMaxChart(graph, i);
    } else if (graph.limit_type == "none") {
      chart.config = this.getNoneChart(graph, i);
    } else if (graph.limit_type == "max_min") {
      chart.config = this.getMaxMinChart(graph, i);
    } else if (graph.limit_type == "min") {
      chart.config = this.getMaxMinChart(graph, i);
    }
    return (
      <div key={i + "am"} style={{ display: "flex" }}>
        <AmCharts.React
          key={"AM" + i}
          style={{
            width: "95%",
            height: "100px",
            float: "left"
          }}
          options={chart.config}
          onClick={this.props.handleClick}
        />
        <button
          onClick={() => this.handleReset(graph)}
          className="btn btn-primary btn-sm resetButton"
        >
          <Icon type="retweet" /> Reset
        </button>
      </div>
    );
  }
}

export default TrendChart;
TrendChart.propTypes = {
  uniqueId: PropTypes.string.isRequired,
  handleClick: PropTypes.func,
  graph: PropTypes.string,
  i: PropTypes.string
};
