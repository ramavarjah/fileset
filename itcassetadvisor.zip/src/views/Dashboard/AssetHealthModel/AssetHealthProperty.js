import React, { Component } from "react";
import "amcharts3";
import "amcharts3/amcharts/serial";
import PropTypes from "prop-types";
import HealthPropChart from "./HealthPropChart";
import tabModelStore from "../../../stores/tabModelStore";
import { Spin, Alert, Icon } from "antd";
import _ from "lodash";
import Functions from "../../../api/Functions";
import CHART_CONFIG from "../../../views/Charts/chartConfig.js";
import UIFunctions from "./../../../helpers/UIFunctions";

const PanelWrapperHeader = ({ text }) => (
  <div className="panel-wrapper-header">
    <p>{text} </p>
    <span>
      <Icon type="exclamation-circle" />
    </span>
  </div>
);

class AssetHealthProperty extends Component {
  constructor(props) {
    super(props);
    this.state = {
      view: [],
      graphData: [],
      dataLoaded: false
    };
    this.handleResetErrors = this.handleResetErrors.bind(this);
    this.handleResetWarnings = this.handleResetWarnings.bind(this);
  }
  handleExpandErrorsClick = () => {
    tabModelStore.setDataContextState("step3");
  };
  getMaxChart(resp, i) {
    let config = {};
    let obj = {
      category: resp.data.array[i].displayName,
      tmp: 20,
      streamId: resp.data.array[i].streamId,
      bullet: resp.data.array[i].healthValue,
      GREEN: resp.data.array[i].Green,
      YELLOW: resp.data.array[i].Yellow,
      RED: resp.data.array[i].Red,
      ChartMinValue: resp.data.array[i].minValue,
      ChartBaseValue: resp.data.array[i].BaseValue,
      ChartMaxValue: resp.data.array[i].maxValue,
      device: resp.data.array[i].device,
      metricName: resp.data.array[i].metric_name,
      Units: resp.data.array[i].units,
      thingname: this.props.uniqueId,
      min_hold: resp.data.array[i].min_hold,
      max_hold: resp.data.array[i].max_hold
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartmax);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.category,
        x: 10,
        y: 20
      }
    ];
    config.valueAxes[0].minimum = obj.ChartMinValue;
    config.valueAxes[0].maximum = obj.ChartMaxValue;
    config.valueAxes[0].baseValue = obj.ChartBaseValue;
    config.valueAxes[0].guides[0].value = obj.min_hold;
    config.valueAxes[0].guides[1].value = obj.max_hold;
    return config;
  }
  getNoneChart = (resp, i) => {
    let config = {};
    let obj = {
      category: resp.data.array[i].healthValue,
      tmp: 20,
      streamId: resp.data.array[i].streamId,
      bullet: resp.data.array[i].displayName,
      device: resp.data.array[i].device,
      metricName: resp.data.array[i].metric_name,
      Units: resp.data.array[i].units,
      thingname: this.props.uniqueId,
      min_hold: resp.data.array[i].min_hold,
      max_hold: resp.data.array[i].max_hold
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartnone);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.bullet,
        x: 10,
        y: 20
      }
    ];
    config.categoryAxis.labelsEnabled = true;
    config.categoryAxis.boldLabels = true;
    config.categoryAxis.inside = true;
    return config;
  };
  getMaxMinChart = (resp, i) => {
    let config = {};
    let obj = {
      category: resp.data.array[i].displayName,
      tmp: 20,
      streamId: resp.data.array[i].streamId,
      bullet: resp.data.array[i].healthValue,
      REDN: resp.data.array[i].RedN,
      YELLOWN: resp.data.array[i].YellowN,
      GREEN: resp.data.array[i].Green,
      YELLOWP: resp.data.array[i].YellowP,
      REDP: resp.data.array[i].RedP,
      ChartMinValue: Math.floor(resp.data.array[i].minValue),
      ChartBaseValue: resp.data.array[i].BaseValue,
      ChartMaxValue: Math.floor(resp.data.array[i].maxValue),
      device: resp.data.array[i].device,
      metricName: resp.data.array[i].metric_name,
      Units: resp.data.array[i].units,
      thingname: this.props.uniqueId,
      min_hold: resp.data.array[i].min_hold,
      max_hold: resp.data.array[i].max_hold
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartmin_max);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.category,
        x: 10,
        y: 20
      }
    ];
    config.valueAxes[0].minimum = obj.ChartMinValue;
    config.valueAxes[0].maximum = obj.ChartMaxValue;
    config.valueAxes[0].baseValue = obj.ChartBaseValue;
    config.valueAxes[0].guides[0].value = obj.min_hold;
    config.valueAxes[0].guides[1].value = obj.max_hold;
    return config;
  };
  getMaxMinChart = (resp, i) => {
    let config = {};
    let obj = {
      category: resp.data.array[i].displayName,
      tmp: 20,
      streamId: resp.data.array[i].streamId,
      bullet: resp.data.array[i].healthValue,
      RED: resp.data.array[i].Red,
      YELLOW: resp.data.array[i].Yellow,
      GREEN: resp.data.array[i].Green,
      ChartMinValue: resp.data.array[i].minValue,
      ChartBaseValue: resp.data.array[i].BaseValue,
      ChartMaxValue: resp.data.array[i].maxValue,
      device: resp.data.array[i].device,
      metricName: resp.data.array[i].metric_name,
      Units: resp.data.array[i].units,
      thingname: this.props.uniqueId,
      min_hold: resp.data.array[i].min_hold,
      max_hold: resp.data.array[i].max_hold
    };
    config = _.cloneDeep(CHART_CONFIG.assethealthchartmin);
    config.dataProvider = new Array();
    config.dataProvider.push(obj);
    config.allLabels = [
      {
        text: obj.category,
        x: 10,
        y: 20
      }
    ];
    config.valueAxes[0].minimum = obj.ChartMinValue;
    config.valueAxes[0].maximum = obj.ChartMaxValue;
    return config;
  };
  componentDidMount() {
    tabModelStore.setErrorsNWarningsLoading(false);
    if (!this.props.uniqueId) return;
    //console.log("Active TabId:  ", tabModelStore.getActiveTab.TabId);
    Functions.GetHealthDataGrouped(this.props.uniqueId).then(resp => {
      Functions.GetWarnings({ ThingName: this.props.uniqueId }).then(resp => {
        tabModelStore.setWarnings(resp.data.Warnings.map(e => e));

        Functions.GetErrors({ ThingName: this.props.uniqueId }).then(resp => {
          tabModelStore.setErrors(resp.data.Errors.map(e => e));
          tabModelStore.setErrorsNWarningsLoading(true);
        });
      });
      // console.log({ resp });
      this.setState({
        dataLoaded: true,
        graphData: resp.data ? resp.data.array : []
      });
    });
  }
  handleReset(row, i) {
    var self = this;
    UIFunctions.ShowConfirm({
      title: `Are you sure you want to reset ${
        self.state.view[i].config.dataProvider[0].device
      } ?`,
      okText: "Yes",
      cancelText: "No",
      onOk() {
        Functions.ResetHealthParamMinMax(row, self.props.uniqueId);
      }
    });
  }
  handleResetWarnings() {
    Functions.resetErrorOrWarning(
      this.props.uniqueId,
      tabModelStore.warningsList[0].streamId
    ).then(() => {
      tabModelStore.setErrorsNWarningsLoading(true);
    });
  }
  handleResetErrors() {
    Functions.resetErrorOrWarning(
      this.props.uniqueId,
      tabModelStore.errorsList[0].streamId
    ).then(() => {
      tabModelStore.setErrorsNWarningsLoading(true);
    });
  }
  render() {
    return (
      <div>
        {this.state.dataLoaded ? (
          this.state.view ? (
            <div style={{ display: "block" }}>
              <HealthPropChart
                {...this.props}
                ChartData={this.state.graphData.map(i => i[0])}
                Level={0}
              />
            </div>
          ) : (
            <div className="row">
              <div
                className="col-md-2 col-md-offset-5"
                style={{ margin: "auto" }}
              >
                <Alert message="No data found" type="warning" />
              </div>
            </div>
          )
        ) : (
          <Spin tip="Loading..." delay={500}>
            <div style={{ padding: "20%" }} />
          </Spin>
        )}
      </div>
    );
  }
}
export default AssetHealthProperty;
AssetHealthProperty.propTypes = {
  uniqueId: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
  handleClick: PropTypes.func.isRequired,
  visible: PropTypes.bool
};
PanelWrapperHeader.propTypes = {
  text: PropTypes.string.isRequired
};
