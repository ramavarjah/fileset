import React, { Component } from "react";
import { observer } from "mobx-react";
import Functions from "../../api/Functions";
import ooStore from "../../stores/ooStore.js";
import { AgGridReact } from "ag-grid-react";
import { Spin, Form, Input, Icon, Row, Button } from "antd";
import moment from "moment";
const FormItem = Form.Item;
const { TextArea } = Input;

@observer
class OotList1 extends Component {
    constructor(props) {
        super(props);
        this._columns = [
            { key: "id", name: "ID" },
            { key: "title", name: "Equipment Number" },
            { key: "manufacturer", name: "Manufacturer" },
            { key: "serial", name: "Serial Number" },
            { key: "count", name: "Count" }
        ];
        this.state = {
            columnDefs: [
                { field: "CaseNumber", headerName: "CaseNumber" },
                { field: "Investigator", headerName: "Investigator" },
                { field: "Status", headerName: "Status" },
                { field: "Impact", headerName: "Impact" },
                { field: "Action", headerName: "Action" },
                { field: "Description", headerName: "Description" },
                { field: "Updated", headerName: "Updated" },
                { field: "Note", headerName: "Note" }
            ],
            rowSelection: "single",
            rowClassRules: {
                "normal-row": function(params) {
                    return params.node.data.read;
                },
                "bold-row": function(params) {
                    return !params.node.data.read;
                }
            },
            editFlag: false
        };
    }

    componentDidMount() {
        ooStore.getData();
        this.props.form.setFieldsValue(ooStore.selectedRow);
    }
  onGridReady = params => {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
      params.api.sizeColumnsToFit();
  };
  onSelectionChanged = () => {
      var selection = this.gridApi.getSelectedRows();
      this.setState({
          editFlag: false
      });
      var row = null;
      if (selection.length > 0) {
          row = selection[0];
      }
      ooStore.setselectedRow(row);
      ooStore.setIsCaseSelected(true);

      if (row.read == false) {
          Functions.MarkNotificationAsRead("OOT", row.CaseId);
          ooStore.markAsReadMasterRow(row);
          this.gridApi.redrawRows();
      }
  };

  edit = () => {
      this.setState({
          editFlag: true
      });
  };

  render() {
      const editBtnClass = this.state.editFlag ? "active" : "";
      const displayClass = ooStore.isCaseSelected ? "block" : "none";
      const { getFieldDecorator } = this.props.form;
      var spanStyle = {
          color: "rgb(127, 137, 147)",
          fontSize: "15px",
          fontWeight: 500
      };
      var ootStyles = {
          clearBoth: {
              clear: "both"
          },
          colLeft: {
              height: window.innerHeight - 237,
              color: "#666"
          }
      };
      var infoStyles = {
          clearBoth: {
              clear: "both"
          },
          textStyle: {
              color: "#6a7682",
              fontSize: "1.1rem",
              marginBottom: "15px",
              textTransform: "uppercase"
          },
          requestMarginBottom: {
              fontSize: "15px",
              marginBottom: "20px"
          },
          entryInfoRightTextStyle: {
              color: "#abb2b8",
              fontWeight: "400"
          },
          entryInfoStatusTextStyle: {
              color: "#ff4d4d",
              fontWeight: "400",
              fontStyle: "italic"
          },
          information: {
              height: window.innerHeight - 237,
              backgroundColor: "#798086",
              textAlign: "center"
          },
          informationText: {
              fontSize: "20px",
              color: "#f8af2f",
              fontStyle: "italic",
              padding: "52% 20%",
              margin: "0px"
          },
          editButtonIssueLog: {
              cursor: "pointer",
              color: "#6a7682",
              fontSize: "1.1rem",
              marginBottom: "15px"
          }
      };

      const formItemLayoutTextarea = {
          labelCol: {
              xs: { span: 24 },
              sm: { span: 24 }
          },
          wrapperCol: {
              xs: { span: 24 },
              sm: { span: 24 }
          }
      };

      const heightDelta = this.state.editFlag ? 60 : 0;

      return (
          <div>
              <div className="col-md-8 pull-left">
                  <Spin spinning={!ooStore.dataLoaded} delay={500}>
                      <div
                          className="selectedAssetsText"
                          style={{ marginBottom: "15px", textTransform: "uppercase" }}
                      >
              Case Log
                      </div>
                      <div style={ootStyles.colLeft} className="OOTOpenRowGrid ag-fresh">
                          <AgGridReact
                              id="ootGrid"
                              columnDefs={ooStore.columns}
                              rowSelection={this.state.rowSelection}
                              suppressCellSelection={true}
                              onGridReady={this.onGridReady.bind(this)}
                              rowClassRules={this.state.rowClassRules}
                              enableColResize={true}
                              onSelectionChanged={this.onSelectionChanged.bind(this)}
                              rowData={ooStore.dataArray.map(e => e)}
                              rowHeight="35"
                              headerHeight="35"
                              enableSorting={true}
                          />
                      </div>
                  </Spin>
              </div>

              <div className="col-md-4 pull-left ootCaseInfo">
                  <div className="pull-left" style={infoStyles.textStyle}>
            Case Info
                  </div>
                  {ooStore.isCaseSelected ? (
                      <div style={{ display: displayClass }}>
                          <div
                              className={"editButton pull-right " + editBtnClass}
                              style={{ cursor: "pointer" }}
                              onClick={this.edit}
                          >
                              {" "}
                Edit
                              <Icon type="edit" style={{ fontWeight: 100 }} />
                          </div>
                      </div>
                  ) : (
                      <div />
                  )}
                  <div style={{ clear: "both" }} />
                  {ooStore.isCaseSelected ? (
                      <div>
                          <Form onSubmit={this.handleSubmit} style={{ width: "100%" }}>
                              <div
                                  className="OOTEntryInfo"
                                  style={{ height: window.innerHeight - 237 - heightDelta }}
                              >
                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Case Number :</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.CaseId}
                                      </span>
                                  </Row>

                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Date opened :</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {moment(ooStore.selectedRow.CreatedOn).format(
                                              "YYYY-MM-DD"
                                          )}
                                      </span>
                                  </Row>
                                  {ooStore.selectedRow.Status == "Closed" ? (
                                      <Row style={infoStyles.requestMarginBottom}>
                                          <span style={spanStyle}>Close Date :</span>{" "}
                                          <span style={infoStyles.entryInfoRightTextStyle}>
                                              {moment(ooStore.selectedRow.ClosedOn).format(
                                                  "YYYY-MM-DD"
                                              )}
                                          </span>
                                      </Row>
                                  ) : (
                                      ""
                                  )}
                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Out of Tolerance Status :</span>{" "}
                                      <span style={infoStyles.entryInfoStatusTextStyle}>
                                          {ooStore.selectedRow.Status} <i className="fa fa-bell" />
                                      </span>
                                  </Row>

                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Case Manager :</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.Investigator}
                                      </span>
                                  </Row>

                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Equipment Number :</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.EquipmentNo}
                                      </span>
                                  </Row>
                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Manufacturer:</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.Manufacturer}
                                      </span>
                                  </Row>
                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Model Number:</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.ModelNo}
                                      </span>
                                  </Row>
                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Serial Number:</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.SerialNo}
                                      </span>
                                  </Row>

                                  <Row style={infoStyles.requestMarginBottom}>
                                      <span style={spanStyle}>Impact :</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.Impact}
                                      </span>
                                  </Row>
                                  <Row>
                                      <span style={spanStyle}>Action :</span>{" "}
                                      <span style={infoStyles.entryInfoRightTextStyle}>
                                          {ooStore.selectedRow.Action}
                                      </span>
                                  </Row>
                                  <br />
                                  <Row className="clear">
                                      <Button
                                          className="viewEntryLogButton"
                                          onClick={() => this.props.setStep("step3")}
                                      >
                                          <i className="fa fa-book" /> View Entry Log
                                      </Button>
                                  </Row>
                                  <hr />
                                  <Row style={infoStyles.requestMarginBottom}>
                                      <FormItem {...formItemLayoutTextarea} label="Case Notes">
                                          {getFieldDecorator("notes", {
                                              initialValue: ooStore.selectedRow.Notes
                                          })(
                                              <TextArea
                                                  rows={4}
                                                  disabled={!this.state.editFlag}
                                                  style={{ height: window.innerHeight - 799 }}
                                              />
                                          )}
                                      </FormItem>
                                  </Row>
                              </div>
                              {this.state.editFlag ? (
                                  <div className="serviceRequestInfoButton">
                                      <div className="userSettingsButton">
                                          <FormItem>
                                              <Button
                                                  className="cancelButton"
                                                  style={{ marginLeft: 8 }}
                                                  onClick={() =>
                                                      this.setState({ isEditing: !this.state.isEditing })
                                                  }
                                              >
                          Cancel
                                              </Button>
                                              <Button
                                                  className="submitButton"
                                                  type="primary"
                                                  style={{ marginLeft: 8 }}
                                                  onClick={this.handleSubmit}
                                              >
                          Submit
                                              </Button>
                                          </FormItem>
                                      </div>
                                  </div>
                              ) : null}
                          </Form>
                      </div>
                  ) : (
                      <div>
                          <div style={infoStyles.clearBoth} />{" "}
                          <div style={infoStyles.information}>
                              <h1 style={infoStyles.informationText}>
                  Click an Item to View More Information
                              </h1>
                          </div>
                      </div>
                  )}
              </div>
              <div className="clear" />
          </div>
      );
  }
}
const OotList = Form.create()(OotList1);
export default OotList;
