import React, { Component } from "react";
import { observer } from "mobx-react";
import Functions from "../../api/Functions";
import OotList from "./OotList";
import OOTEntriesList from "./OOTEntriesList";
import AddNewCase from "./AddNewCase";
import AddNewEntry from "./AddNewEntry";
import { Icon, Row } from "antd";
import ooStore from "../../stores/ooStore";
import tabModelStore from "../../stores/tabModelStore";
import PropTypes from "prop-types";

@observer
class OOT extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentStep: "step1"
        };
    }

    handleClose(e) {
        e.preventDefault();
        ooStore.setIsCaseSelected(false);
        ooStore.setIsEntrySelected(false);
        ooStore.setCurrentStep("step1");
        this.context.router.history.push("/dashboard");
        Functions.GetNotificationCount().then(response => {
            tabModelStore.OOTNotificationCount = response.data.OOTNotificationCount;
        });
    }

    handleNewCase() {
        ooStore.setCurrentStep("step2");
    }
    handleNewEntry() {
        ooStore.setCurrentStep("step4");
    }
    handleOnCancel() {
        ooStore.setIsCaseSelected(false);
        ooStore.setIsEntrySelected(false);
        ooStore.filterQuickTag = "";
        ooStore.applyQuickTagFilter();
        return setTimeout(function() {
            ooStore.setCurrentStep("step1");
        }, 5000);
    }
    setStep(currentStep) {
        ooStore.setCurrentStep(currentStep);
    }
    handle2PageCancel(stateValue) {
        ooStore.setCurrentStep(stateValue);
    }
    handleCancel() {
        ooStore.setCurrentStep("step1");
    }
    handleSubmit() {
        alert("Submitted successfully");
    }
    render() {
        return (
            <div className="OOTWrap">
                {/****** Header ******/}
                <div className="ootWizardHeader">
                    <div className="pull-left">
                        <div className="ootWizardTitle">OUT OF TOLERANCE</div>
                    </div>
                    <div className="pull-right">
                        <Icon
                            type="close-circle-o"
                            style={{
                                color: "rgb(255,255,255)",
                                fontWeight: "100",
                                fontSize: "21px",
                                lineHeight: "normal",
                                paddingRight: "20px",
                                cursor: "pointer"
                            }}
                            onClick={this.handleClose.bind(this)}
                        />
                    </div>
                    <div className="clear" />
                </div>
                <div style={{ paddingTop: "35px" }} />
                <div className="ootContent">
                    {/****** STEP 1 Content ******/}
                    {ooStore.currentStep == "step1" ? (
                        <OotList setStep={this.setStep.bind(this)} />
                    ) : (
                        ""
                    )}

                    {/****** STEP 2 Content ******/}
                    {ooStore.currentStep == "step2" ? (
                        <AddNewCase
                            setStep={this.setStep.bind(this)}
                            onCancel={this.handleCancel.bind(this)}
                        />
                    ) : (
                        ""
                    )}
                    {/****** STEP 3 Content ******/}
                    {ooStore.currentStep == "step3" ? (
                        <OOTEntriesList setStep={this.setStep.bind(this)} />
                    ) : (
                        ""
                    )}
                    {/****** STEP 4 Content ******/}
                    {ooStore.currentStep == "step4" ? (
                        <AddNewEntry
                            setStep={this.setStep.bind(this)}
                            onCancel={this.handleCancel.bind(this)}
                        />
                    ) : (
                        ""
                    )}
                </div>

                {/****** Footer ******/}
                {ooStore.currentStep == "step3" ? (
                    <div className="ootWizardFooter">
                        <Row type="flex" justify="center">
                            <div
                                className="newCase"
                                style={{ marginRight: "25px" }}
                                onClick={this.handleOnCancel.bind(this)}
                            >
                                <Icon type="left" /> Back
                            </div>
                            <div className="newCase" onClick={this.handleNewEntry.bind(this)}>
                New Entry <i className="icon-plus ootPlus" />
                            </div>
                        </Row>
                    </div>
                ) : (
                    ""
                )}

                {ooStore.currentStep == "step1" ? (
                    <div className="ootWizardFooter">
                        <div className="newCase" onClick={this.handleNewCase.bind(this)}>
              New Case <i className="icon-plus ootPlus" />
                        </div>
                    </div>
                ) : (
                    ""
                )}
            </div>
        );
    }
}

export default OOT;

OOT.propTypes = {
    router: PropTypes.func
};
