import React, { Component } from "react";
import { observer } from "mobx-react";
import { AgGridReact } from "ag-grid-react";
import { Form, Input, Icon, Select, Row, Col, Button, Upload } from "antd";
import ooStore from "../../stores/ooStore";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";

const FormItem = Form.Item;
const { TextArea } = Input;

@observer
class AddNewEntry extends Component {
	constructor(props) {
		super(props);
		this.state = {
			columnDefs: [
				{
					headerName: "Download Link",
					field: "downloadlink",
					width: 200,
					suppressSizeToFit: true
				},
				{
					headerName: "Name",
					field: "name"
				},
				{
					headerName: "Last Modified Date",
					field: "lastmodifieddate",
					valueFormatter: this.dateFormatter
				}
			],
			rowSelection: "single",
			caseNumber: "",
			caseType: "",
			caseManager: "",
			description: "",
			history: "",
			manufacturer: "",
			allManufacturer: "",
			caseCategory: "",
			legalCase: false,
			internalCase: false,
			fileList: []
		};
	}

	handleSubmit = e => {
		e.preventDefault();
		this.props.form.validateFieldsAndScroll((err, values) => {
			if (!err) {
				Functions.CreateNewEntry(
					ooStore.selectedRow.CaseId,
					values.note,
					values.impact,
					values.status,
					values.action,
					values.investigator,
					ooStore.selectedRow.ThingName,
					ooStore.selectedRow.StreamId,
					values.quicktag,
					values.entryno
				).then(response => {
					if (response.data.success) {
						UIFunctions.Toast(
							"New entry has been created successfully",
							"success"
						);
						var caseId = ooStore.selectedRow.CaseId;
						var entryId = values.entryno;
						ooStore.entriesFileList.forEach(item => {
							var r = new FileReader();

							r.onload = function() {
								Functions.UploadFileForEntry(
									caseId,
									entryId,
									r.result,
									item.name
								).then(() => {});
							};
							r.readAsDataURL(item.originFileObj);
						});
					} else {
						UIFunctions.Toast(
							"There was an error in creating the new entry",
							"error"
						);
					}
					ooStore.setIsEntrySelected(false);
					ooStore.setCurrentStep("step3");
				});
			}
		});
	};

	handleCancel = () => {
		ooStore.setEntriesFileList([]);
		ooStore.setCurrentStep("step3");
	};

	onGridReady = params => {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
		params.api.sizeColumnsToFit();
	};

	componentDidMount() {
		ooStore.setInvestigators(ooStore.selectedRow.ThingName);
		ooStore.setEntriesFileList([]);
	}

	handleFileChange = info => {
		var newfilelist = this.state.fileList;
		const isLt10M = info.file.size / 1024 / 1024 <= 10;
		if (!isLt10M) {
			return UIFunctions.Toast(
				info.file.name + " is greater than 10MB",
				"info"
			);
		}

		info.fileList.forEach((item, i) => {
			var isNewItem = true;
			// Looping throught State-FileList to check whether the file is in the list or not
			this.state.fileList.map(fileitem => {
				item.name == fileitem.name ? (isNewItem = false) : "";
			});
			info.fileList[i].status = info.fileList[i].name;
			isNewItem && newfilelist.push(info.fileList[i]);
		});
		if (info.file.status == "removed") {
			const index = newfilelist.indexOf(info.file);
			newfilelist.splice(index, 1);
		}
		this.setState({ fileList: newfilelist });

		ooStore.setEntriesFileList(newfilelist);
	};
	render() {
		const { getFieldDecorator } = this.props.form;

		const formItemLayout = {
			labelCol: {
				xs: { span: 24 },
				sm: { span: 6 }
			},
			wrapperCol: {
				xs: { span: 24 },
				sm: { span: 14 }
			}
		};
		const formItemLayoutTextarea = {
			labelCol: {
				xs: { span: 24 },
				sm: { span: 20 }
			},
			wrapperCol: {
				xs: { span: 24 },
				sm: { span: 20 }
			}
		};
		const formItemLayoutUpload = {
			labelCol: {
				xs: { span: 24 },
				sm: { span: 6 }
			},
			wrapperCol: {
				xs: { span: 24 },
				sm: { span: 24 }
			}
		};

		const fileProps = {
			onChange: this.handleFileChange,
			multiple: true
		};

		return (
			<div className="addNewWrap">
				<div
					className="selectedAssetsText subHeading"
					style={{ paddingLeft: 20, textTransform: "uppercase" }}
				>
					New Entry / Case: {ooStore.selectedRow.CaseId}
				</div>
				<div className="ootNewCaseForm">
					<Form onSubmit={this.handleSubmit}>
						<div className="addNewootContent">
							<Row gutter={16}>
								<Col span={12}>
									<div>
										<FormItem {...formItemLayout} label="Entry No" hasFeedback>
											{getFieldDecorator("entryno", {
												rules: [
													{
														required: true,
														message: "Please input an entry number"
													}
												]
											})(<Input placeholder="Please input an entry number" />)}
										</FormItem>
										<FormItem
											{...formItemLayout}
											label="Investigator"
											hasFeedback
										>
											{getFieldDecorator("investigator", {
												rules: [
													{
														required: true,
														message: "Please select an investigator"
													}
												]
											})(
												<Select
													placeholder="Please select an investigator"
													showSearch
													filterOption={(input, option) =>
														option.props.children
															.toLowerCase()
															.indexOf(input.toLowerCase()) >= 0
													}
												>
													{ooStore.investigators.map(item => (
														<Select.Option key={item}>{item}</Select.Option>
													))}
												</Select>
											)}
										</FormItem>
										<FormItem {...formItemLayout} label="Status" hasFeedback>
											{getFieldDecorator("status", {
												rules: [
													{
														required: true,
														message: "Please select the status"
													}
												]
											})(
												<Select placeholder="Please select the status">
													<option value="Open">Open</option>
													<option value="In Progress">In Progress</option>
													<option value="Awaiting Review">
														Awaiting Review
													</option>
													<option value="Closed">Closed</option>
												</Select>
											)}
										</FormItem>
										<FormItem {...formItemLayout} label="Impact">
											{getFieldDecorator("impact", {
												rules: [
													{
														required: false,
														message: "Please select the impact"
													}
												]
											})(
												<Select placeholder="Please select the impact">
													<option value="No impact, OOT values not in used measurement range">
														No impact, OOT values not in used measurement range
													</option>
													<option value="No impact, OOT values are in used measurement range">
														No impact, OOT values are in used measurement range
													</option>
													<option value="Possible impact, see detailed analysis">
														Possible impact, see detailed analysis
													</option>
												</Select>
											)}
										</FormItem>
										<FormItem {...formItemLayout} label="Action">
											{getFieldDecorator("action", {
												rules: [
													{
														required: false,
														message: "Please select an action"
													}
												]
											})(
												<Select placeholder="Please select an action">
													<option value="No action taken">
														No action taken
													</option>
													<option value="Action taken, see notes">
														Action taken, see notes
													</option>
													<option value="Cal interval adjustment">
														Cal interval adjustment
													</option>
													<option value="Operator training">
														Operator training
													</option>
													<option value="Product warning">
														Product warning
													</option>
													<option value="Product recall">Product recall</option>
												</Select>
											)}
										</FormItem>
									</div>
								</Col>
								<Col span={12}>
									<div className="labelUploadAttachment">
										<label>Upload attachments </label>{" "}
										<Icon type="paper-clip" />
									</div>
									<div style={{ display: "flex", position: "relative" }}>
										<FormItem {...formItemLayoutUpload}>
											<Upload
												{...fileProps}
												//eslint-disable-next-line
												customRequest={() => console.log("")}
												fileList={this.state.fileList.map(e => e)}
											>
												<Button>
													<Icon type="upload" /> upload
												</Button>
											</Upload>
										</FormItem>
										<span
											style={{
												"letter-spacing": "0.5px",
												color: " #79838c",
												position: "absolute",
												left: 120,
												width: 250
											}}
										>
											{" "}
											Maximum upload file size : 10MB{" "}
										</span>
									</div>
								</Col>
							</Row>
							<div className="clear" />
							<Row gutter={16}>
								<Col span={12}>
									<FormItem {...formItemLayout} label="Quick Tag" hasFeedback>
										{getFieldDecorator("quicktag", {
											rules: [
												{
													required: true,
													message: "Please input a quick tag"
												}
											]
										})(<Input placeholder="Please input a quick tag" />)}
									</FormItem>

									<FormItem
										{...formItemLayoutTextarea}
										label="Notes"
										hasFeedback
									>
										{getFieldDecorator("note", {})(
											<TextArea
												rows={4}
												defaultValue=""
												style={{ height: window.innerHeight - 548 }}
											/>
										)}
									</FormItem>
								</Col>
								<Col span={12}>
									<Row
										className="OOTOpenRowGrid ag-fresh"
										style={{
											height: window.innerHeight - 548,
											marginTop: "34px"
										}}
									>
										<AgGridReact
											id="entryFiles"
											columnDefs={this.state.columnDefs}
											suppressCellSelection={true}
											suppressRowSelection={true}
											onGridReady={this.onGridReady.bind(this)}
											enableColResize={true}
											rowHeight="35"
											headerHeight="35"
											rowData={ooStore.entriesFileList.map(e => e)}
											style={{ height: window.innerHeight * 0.1 }}
										/>
									</Row>
								</Col>
							</Row>
						</div>
						<Row>
							<div
								className="ootWizardFooter"
								style={{ padding: "0px 50px 25px" }}
							>
								<Button
									className="cancelButton"
									onClick={this.handleCancel.bind(this)}
									type="cancel"
								>
									Cancel
								</Button>
								<Button className="submitButton" htmlType="submit">
									Submit
								</Button>
							</div>
						</Row>
					</Form>
				</div>
			</div>
		);
	}
}
const WrappedAddNewCase = Form.create()(AddNewEntry);
export default WrappedAddNewCase;
