import React, { Component } from "react";
import { observer } from "mobx-react";
import { Form, Input, Select, Row, Col, Button } from "antd";
import ooStore from "../../stores/ooStore";
const FormItem = Form.Item;
const { TextArea } = Input;
import Functions from "../../api/Functions";
@observer
class AddNewCase extends Component {
  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll((err, values) => {
          if (!err) {
              // console.log('Received values of form: ', values);
              ooStore.submitNewCase(values);
              ooStore.setCurrentStep("step1");
          }
      });
  };
  handleCancel = () => {};

  handleEquipmentChange = value => {
      ooStore.setInvestigators(value);
      this.setState({
          showInvestigator: true
      });
  };

  constructor(props) {
      super(props);
      this.state = {
          caseNumber: "",
          caseType: "",
          caseManager: "",
          description: "",
          history: "",
          manufacturer: "",
          equipmentNo: "",
          allManufacturer: "",
          caseCategory: "",
          investigator: "",
          showInvestigator: false,
          legalCase: false,
          internalCase: false
      };
      ooStore.setEquipmentNumbers();
      ooStore.setOotCaseNumber();
  }

  validateCaseNo = (rule, value, callback) => {
      Functions.ValidateOotCaseNumber(value).then(resp => {
      //console.log('ValidateEquipmentNumber', resp.data)
          if (!resp.data.isUnique || !resp.data.success) {
              callback(new Error("More than one must be selected!"));
          } else callback();
      });
  };
  render() {
      const { getFieldDecorator } = this.props.form;

      const formItemLayout = {
          labelCol: {
              xs: { span: 24 },
              sm: { span: 6 }
          },
          wrapperCol: {
              xs: { span: 24 },
              sm: { span: 14 }
          }
      };
      const formItemLayoutTextarea = {
          labelCol: {
              xs: { span: 24 },
              sm: { span: 20 }
          },
          wrapperCol: {
              xs: { span: 24 },
              sm: { span: 20 }
          }
      };

      var caseNumber = ooStore.ootcasenum;

      return (
          <div className="addNewWrap">
              <div
                  className="selectedAssetsText subHeading"
                  style={{ paddingLeft: 20, textTransform: "uppercase" }}
              >
          New Case:
              </div>
              <div className="ootNewCaseForm">
                  <Form onSubmit={this.handleSubmit}>
                      <div className="addNewootContent">
                          <Row gutter={16}>
                              <Col span={12}>
                                  <div>
                                      <FormItem
                                          {...formItemLayout}
                                          label="Case number"
                                          hasFeedback
                                      >
                                          {getFieldDecorator("caseNumber", {
                                              initialValue: caseNumber,
                                              rules: [
                                                  {
                                                      required: true,
                                                      message: "Please enter the case number"
                                                  },
                                                  {
                                                      pattern: new RegExp(
                                                          "^[a-zA-Z0-9][a-zA-Z0-9.,$;]+$"
                                                      ),
                                                      message: "Not a valid case number"
                                                  },
                                                  {
                                                      validator: this.validateCaseNo.bind(this),
                                                      message: "Case number already exist"
                                                  }
                                              ]
                                          })(<Input placeholder="Please enter the case number" />)}
                                      </FormItem>
                                      <FormItem {...formItemLayout} label="Status" hasFeedback>
                                          {getFieldDecorator("status", {
                                              rules: [
                                                  {
                                                      required: true,
                                                      message: "Please select the status"
                                                  }
                                              ]
                                          })(
                                              <Select placeholder="Please select the status">
                                                  <option value="Open">Open</option>
                                                  <option value="In Progress">In Progress</option>
                                                  <option value="Awaiting Review">
                            Awaiting Review
                                                  </option>
                                                  <option value="Closed">Closed</option>
                                              </Select>
                                          )}
                                      </FormItem>
                                      <FormItem {...formItemLayout} label="Impact">
                                          {getFieldDecorator("impact", {
                                              rules: [
                                                  {
                                                      required: false,
                                                      message: "Please select the impact"
                                                  }
                                              ]
                                          })(
                                              <Select placeholder="Please select the impact">
                                                  <option value="No impact, OOT values not in used measurement range">
                            No impact, OOT values not in used measurement range
                                                  </option>
                                                  <option value="No impact, OOT values are in used measurement range">
                            No impact, OOT values are in used measurement range
                                                  </option>
                                                  <option value="Possible impact, see detailed analysis">
                            Possible impact, see detailed analysis
                                                  </option>
                                              </Select>
                                          )}
                                      </FormItem>
                                      <FormItem {...formItemLayout} label="Action">
                                          {getFieldDecorator("action", {
                                              rules: [
                                                  {
                                                      required: false,
                                                      message: "Please select an action"
                                                  }
                                              ]
                                          })(
                                              <Select placeholder="Please select an action">
                                                  <option value="No action taken">
                            No action taken
                                                  </option>
                                                  <option value="Action taken, see notes">
                            Action taken, see notes
                                                  </option>
                                                  <option value="Cal interval adjustment">
                            Cal interval adjustment
                                                  </option>
                                                  <option value="Operator training">
                            Operator training
                                                  </option>
                                                  <option value="Product warning">
                            Product warning
                                                  </option>
                                                  <option value="Product recall">Product recall</option>
                                              </Select>
                                          )}
                                      </FormItem>
                                  </div>
                              </Col>
                              <Col span={12}>
                                  <div>
                                      <FormItem
                                          {...formItemLayout}
                                          label="Equipment number"
                                          hasFeedback
                                      >
                                          {getFieldDecorator("equipmentNo", {
                                              rules: [
                                                  {
                                                      required: true,
                                                      message: "Please select the equipment"
                                                  }
                                              ]
                                          })(
                                              <Select
                                                  placeholder="Please select an equipment"
                                                  showSearch
                                                  onChange={this.handleEquipmentChange.bind(this)}
                                                  filterOption={(input, option) =>
                                                      option.props.children
                                                          .toLowerCase()
                                                          .indexOf(input.toLowerCase()) >= 0
                                                  }
                                              >
                                                  {ooStore.equipmentNumbers.map(item => (
                                                      <Select.Option key={item.ThingName}>
                                                          {item.EquipmentNo}
                                                      </Select.Option>
                                                  ))}
                                              </Select>
                                          )}
                                      </FormItem>
                                      {this.state.showInvestigator ? (
                                          <FormItem
                                              {...formItemLayout}
                                              label="Investigator"
                                              hasFeedback
                                          >
                                              {getFieldDecorator("investigator", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select an investigator"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      placeholder="Please select an investigator"
                                                      showSearch
                                                      filterOption={(input, option) =>
                                                          option.props.children
                                                              .toLowerCase()
                                                              .indexOf(input.toLowerCase()) >= 0
                                                      }
                                                  >
                                                      {ooStore.investigators.map(item => (
                                                          <Select.Option key={item}>{item}</Select.Option>
                                                      ))}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      ) : (
                                          ""
                                      )}
                                  </div>
                              </Col>
                          </Row>
                          <Row>
                              <Col span={12}>
                                  <FormItem {...formItemLayoutTextarea} label="Description">
                                      {getFieldDecorator("description", {})(
                                          <TextArea
                                              rows={4}
                                              style={{ height: window.innerHeight - 500 }}
                                          />
                                      )}
                                  </FormItem>
                              </Col>
                              <Col span={12}>
                                  <FormItem {...formItemLayoutTextarea} label="Notes">
                                      {getFieldDecorator("note", {})(
                                          <TextArea
                                              rows={4}
                                              style={{ height: window.innerHeight - 500 }}
                                          />
                                      )}
                                  </FormItem>
                              </Col>
                          </Row>
                      </div>
                      <Row>
                          <div
                              className="ootWizardFooter"
                              style={{ padding: "0px 50px 25px" }}
                          >
                              <Button
                                  className="cancelButton"
                                  onClick={this.props.onCancel}
                                  type="cancel"
                              >
                  Cancel
                              </Button>
                              <Button className="submitButton" htmlType="submit">
                  Submit
                              </Button>
                          </div>
                      </Row>
                  </Form>
              </div>
          </div>
      );
  }
}
const WrappedAddNewCase = Form.create()(AddNewCase);
export default WrappedAddNewCase;
