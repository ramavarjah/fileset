import React, { Component } from "react";
import { observer } from "mobx-react";
import ooStore from "../../stores/ooStore.js";
import { AgGridReact } from "ag-grid-react";
import { Spin, Form, Icon, Row } from "antd";

@observer
class OOTEntriesList extends Component {
    constructor(props) {
        super(props);
        this._columns = [
            { key: "id", name: "ID" },
            { key: "title", name: "Equipment Number" },
            { key: "manufacturer", name: "Manufacturer" },
            { key: "serial", name: "Serial Number" },
            { key: "count", name: "Count" }
        ];
        this.state = {
            columnDefs: [
                {
                    field: "Link",
                    headerName: "Link",
                    cellRenderer: ooStore.linkFormatter
                },
                { field: "FileName", headerName: "File name" },
                {
                    field: "UploadedOn",
                    headerName: "Upload date",
                    valueFormatter: ooStore.dateFormatter
                }
            ],
            rowSelection: "single"
        };
    }

    componentDidMount() {
        ooStore.getEntriesData();
    }
  onGridReady = params => {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
      params.api.sizeColumnsToFit();
  };

  onFilesGridReady = params => {
      this.filesGridApi = params.api;
      this.filesGridColumnApi = params.columnApi;
      params.api.sizeColumnsToFit();
  };
  onEntriesSelectionChanged = () => {
      var selection = this.gridApi.getSelectedRows();
      var row = null;
      if (selection.length > 0) {
          row = selection[0];
      }

      ooStore.setEntriesSelectedRow(row);
      ooStore.setEntriesFileList(row.FileList);
      ooStore.setIsEntrySelected(true);
  };

  removeFilter = () => {
      ooStore.filterQuickTag = "";
      ooStore.applyQuickTagFilter();
  };

  getSampleData() {
      let rows = [
          {
              Impact: "No impact, OOT values not in used measurement range",
              Status: "In Progress",
              EquipmentNo: "1003476",
              Action: "Action taken, see notes",
              CreatedBy: "test@aademo.com",
              FileList: [],
              EntryId: "24825512",
              CaseId: "33333333",
              ThingName: "2_1003476",
              CreatedOn: "2018-02-20T17:18:27.601Z",
              Investigator: "abhiramkuncham@gmail.com",
              Notes: "undefined",
              QuickTag: "SystemInvestigation"
          },
          {
              Impact: "No impact, OOT values not in used measurement range",
              Status: "In Progress",
              EquipmentNo: "1003476",
              Action: "Action taken, see notes",
              CreatedBy: "test@aademo.com",
              FileList: [],
              EntryId: "24825513",
              CaseId: "33333333",
              ThingName: "2_1003476",
              CreatedOn: "2018-02-20T17:18:27.601Z",
              Investigator: "abhiramkuncham@gmail.com",
              Notes: "undefined",
              QuickTag: "CableCheck"
          },
          {
              Impact: "No impact, OOT values not in used measurement range",
              Status: "In Progress",
              EquipmentNo: "1003476",
              Action: "Action taken, see notes",
              CreatedBy: "test@aademo.com",
              FileList: [],
              EntryId: "24825514",
              CaseId: "33333333",
              ThingName: "2_1003476",
              CreatedOn: "2018-02-20T17:18:27.601Z",
              Investigator: "abhiramkuncham@gmail.com",
              Notes: "undefined",
              QuickTag: "UtilizationCheck"
          },
          {
              Impact: "No impact, OOT values not in used measurement range",
              Status: "In Progress",
              EquipmentNo: "1003476",
              Action: "Action taken, see notes",
              CreatedBy: "test@aademo.com",
              FileList: [],
              EntryId: "24825515",
              CaseId: "33333333",
              ThingName: "2_1003476",
              CreatedOn: "2018-02-20T17:18:27.601Z",
              Investigator: "abhiramkuncham@gmail.com",
              Notes: "undefined",
              QuickTag: "HealthCheck"
          },
          {
              Impact: "No impact, OOT values not in used measurement range",
              Status: "In Progress",
              EquipmentNo: "1003476",
              Action: "Action taken, see notes",
              CreatedBy: "test@aademo.com",
              FileList: [],
              EntryId: "24825516",
              CaseId: "33333333",
              ThingName: "2_1003476",
              CreatedOn: "2018-02-20T17:18:27.601Z",
              Investigator: "abhiramkuncham@gmail.com",
              Notes: "undefined",
              QuickTag: "CableCheck"
          }
      ];
      ooStore.entriesDataArray = rows;
      ooStore.entireData = rows;
      ooStore.entriesDataLoaded = true;
  }
  render() {
      var spanStyle = {
          color: "rgb(127, 137, 147)",
          fontSize: "15px",
          fontWeight: 500
      };

      var infoStyles = {
          clearBoth: {
              clear: "both"
          },
          colLeft: {
              height: window.innerHeight - 237,
              color: "#666"
          },
          information: {
              height: window.innerHeight - 237,
              backgroundColor: "#798086",
              textAlign: "center"
          },
          informationText: {
              fontSize: "20px",
              color: "#f8af2f",
              fontStyle: "italic",
              padding: "52% 20%",
              margin: "0px"
          },
          textStyle: {
              color: "#6a7682",
              fontSize: "1.1rem",
              marginBottom: "15px",
              textTransform: "uppercase"
          },
          entryInfoStatusTextStyle: {
              color: "#ff4d4d",
              fontWeight: "400",
              fontStyle: "italic"
          },
          entryInfoRightTextStyle: {
              color: "#abb2b8",
              fontWeight: "400"
          },
          requestMarginBottom: {
              fontSize: "15px",
              marginBottom: "20px"
          }
      };
      return (
          <Form>
              <div>
                  <div className="col-lg-8 pull-left">
                      <Spin spinning={!ooStore.entriesDataLoaded} delay={500}>
                          <div
                              style={{
                                  float: "left",
                                  width: "100%",
                                  marginBottom: "15px",
                                  textTransform: "uppercase"
                              }}
                              className="selectedAssetsText"
                          >
                              <div style={{ float: "left", marginRight: "15px" }}>
                  Entry Log / Case: {ooStore.selectedRow.CaseId}
                              </div>
                              <div style={{ display: ooStore.showDiv ? "block" : "none" }}>
                                  <div
                                      className="ootQuickTag"
                                      onClick={this.removeFilter.bind(this)}
                                  >
                                      {ooStore.filterQuickTag} <Icon type="close-circle-o" />
                                  </div>
                              </div>
                              <div style={infoStyles.clearBoth} />
                          </div>
                          <div
                              style={infoStyles.colLeft}
                              className="OOTOpenRowGrid ag-fresh"
                          >
                              <AgGridReact
                                  id="ootGrid"
                                  columnDefs={ooStore.entriesColumns}
                                  rowSelection="single"
                                  suppressCellSelection={true}
                                  onGridReady={this.onGridReady.bind(this)}
                                  enableColResize={true}
                                  rowHeight="35"
                                  headerHeight="35"
                                  onSelectionChanged={this.onEntriesSelectionChanged.bind(this)}
                                  rowData={ooStore.entriesDataArray.map(e => e)}
                              />
                          </div>
                      </Spin>
                  </div>

                  <div className="col-lg-4 pull-left">
                      <div className="pull-left" style={infoStyles.textStyle}>
              Entry Info
                      </div>
                      <div style={{ clear: "both" }} />
                      {ooStore.isEntrySelected ? (
                          <div
                              className="OOTEntryInfo"
                              style={{ height: window.innerHeight - 237 }}
                          >
                              <Row style={infoStyles.requestMarginBottom}>
                                  <span style={spanStyle}>Notes :</span>
                                  <div className="entryInfoDescription">
                                      {ooStore.entriesSelectedRow.Notes}
                                  </div>
                              </Row>
                              <hr />
                              <Row
                                  className="OOTOpenRowGrid ag-fresh"
                                  style={{ height: window.innerHeight * 0.2 }}
                              >
                                  <AgGridReact
                                      id="entryFiles"
                                      columnDefs={this.state.columnDefs}
                                      suppressCellSelection={true}
                                      suppressRowSelection={true}
                                      onGridReady={this.onFilesGridReady.bind(this)}
                                      enableColResize={true}
                                      rowHeight="35"
                                      headerHeight="35"
                                      rowData={ooStore.entriesFileList.map(e => e)}
                                      style={{ height: window.innerHeight * 0.1 }}
                                  />
                              </Row>
                          </div>
                      ) : (
                          <div>
                              <div style={infoStyles.clearBoth} />{" "}
                              <div style={infoStyles.information}>
                                  <h1 style={infoStyles.informationText}>
                    Click an Item to View More Information
                                  </h1>
                              </div>
                          </div>
                      )}
                  </div>
              </div>
              <div className="clear" />
          </Form>
      );
  }
}

export default OOTEntriesList;
