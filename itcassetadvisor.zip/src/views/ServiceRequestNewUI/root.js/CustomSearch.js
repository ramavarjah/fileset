import React from "react";
import Autosuggest from "react-autosuggest";
import { Icon } from "antd";

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = (suggestion, customRenderSuggestionStyle) => (
  <div style={customRenderSuggestionStyle}>{suggestion.name}</div>
);
const CustomSearch = ({
  suggestions,
  onSuggestionsFetchRequested,
  inputProps,
  onSuggestionsClearRequested,
  customRenderSuggestionStyle,
  searchstyle,
  onClick,
  type
}) => {
  return (
    <div>
      <div className="header-common-class header-same-class header-search-wrapper">
        <Autosuggest
          suggestions={suggestions}
          onSuggestionsFetchRequested={onSuggestionsFetchRequested}
          onSuggestionsClearRequested={onSuggestionsClearRequested}
          getSuggestionValue={getSuggestionValue}
          renderSuggestion={suggestion =>
            renderSuggestion(suggestion, customRenderSuggestionStyle)
          }
          inputProps={inputProps}
        />
        <div className="header-searchbox-icon" style={searchstyle}>
          <Icon
            type={type}
            style={{ color: "inherit", cursor: "pointer" }}
            onClick={onClick}
          />
        </div>
      </div>
    </div>
  );
};

export default CustomSearch;
