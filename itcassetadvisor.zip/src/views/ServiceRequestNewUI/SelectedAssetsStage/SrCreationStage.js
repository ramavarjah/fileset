import React from "react";
// import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import { Steps } from "antd";

const Step = Steps.Step;
const customDot = dot => <span>{dot}</span>;
function getStatusObj(currentSrStep) {
  if (currentSrStep == "step1") {
    return {
      selectedAssetsStatus: "finish",
      contactShippingStatus: "wait",
      budgetaryQuoteStatus: "wait",
      confirmationStatus: "wait"
    };
  } else if (currentSrStep == "step2") {
    return {
      selectedAssetsStatus: "finish",
      contactShippingStatus: "finish",
      budgetaryQuoteStatus: "wait",
      confirmationStatus: "wait"
    };
  } else if (currentSrStep == "step3") {
    return {
      selectedAssetsStatus: "finish",
      contactShippingStatus: "finish",
      budgetaryQuoteStatus: "finish",
      confirmationStatus: "wait"
    };
  } else if (currentSrStep == "step4") {
    return {
      selectedAssetsStatus: "finish",
      contactShippingStatus: "finish",
      budgetaryQuoteStatus: "finish",
      confirmationStatus: "finish"
    };
  } else {
    ("");
  }
}
const SrCreationStage = ({ currentSrStep }) => {
  const {
    selectedAssetsStatus,
    contactShippingStatus,
    budgetaryQuoteStatus,
    confirmationStatus
  } = getStatusObj(currentSrStep);
  return (
    <div className="selected-assets-steps">
      <Steps progressDot={customDot}>
        <Step
          title="Selected Assets"
          status={selectedAssetsStatus}
          data-status={selectedAssetsStatus}
        />
        <Step
          title="Contact & Shipping"
          status={contactShippingStatus}
          data-status={contactShippingStatus}
        />
        <Step
          title="Budgetary Quote"
          status={budgetaryQuoteStatus}
          data-status={budgetaryQuoteStatus}
        />
        <Step
          title="Confirmation"
          status={confirmationStatus}
          data-status={confirmationStatus}
        />
      </Steps>
    </div>
  );
};

export default SrCreationStage;
