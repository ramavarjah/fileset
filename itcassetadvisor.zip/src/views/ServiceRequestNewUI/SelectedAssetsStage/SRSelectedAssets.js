import React from "react";
import { Table, Button, Form, Icon, Switch, Popconfirm, Tooltip } from "antd";
import AssetCard from "src/views/Components/Cards/AssetCard";
import "./styles.scss";
import { observer } from "mobx-react";
import { createBrowserHistory } from "history";
import SRSelectedAssets2 from "./SelectedAssetsForm";
import SrCreationStage from "./SrCreationStage";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import UIFunctions from "src/helpers/UIFunctions";
import strings from "../LocalizedText/strings";
import Functions from "../../../api/Functions";
import userStore from "src/stores/userStore";
import _ from "lodash";
import EditRequestInfo from "./EditRequestInfo";
let cartItems;
import "../../../helpers/Antd/antd.css"; // new line of code

const history = createBrowserHistory();
const parseText = (text = "") =>
  text.length > 16 ? text.substring(0, 17) + "..." : text;

@observer
class SRSelectedAssets extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      removeCartLoading: false,
      iconClickedData: {},
      tableLoading: true,
      requestedService: {},
      pagination: {
        showSizeChanger: true,
        onShowSizeChange: this.onShowSizeChange,
        current: 1,
        pageNumber: 1,
        defaultPageNumber: 1,
        pageSize: 10,
        defaultPageSize: 10
      }
    };
  }
  columns = isImageEnabled => {
    let ret = [];
    if (isImageEnabled)
      ret.push({
        title: "",
        width: isImageEnabled ? "14%" : 350,
        dataIndex: "",
        render: record => (
          <AssetCard
            modelNo={record.ModelNo}
            dummyUrl="/img/no-asset-image.png"
            width="150px"
            height="150px"
            hasExternalRequest={false}
          />
        )
      });

    return [
      ...ret,
      {
        title: strings.serialNoCaps,
        width: isImageEnabled ? "12%" : "14%",
        dataIndex: "SerialNo",
        render: (text, record) => (
          <div style={{ marginLeft: 1 }}>
            <Tooltip title={record.SerialNo}>{text}</Tooltip>
          </div>
        )
      },
      {
        title: strings.modelNoCaps,
        width: isImageEnabled ? "12%" : "14%",
        dataIndex: "ModelNo",
        render: (text, record) => (
          <div style={{ marginLeft: 2 }}>
            <Tooltip title={record.ModelNo}>{text}</Tooltip>
          </div>
        )
      },
      {
        title: strings.manufacturerCaps,
        width: isImageEnabled ? "11%" : "14%",
        dataIndex: "Manufacturer",
        render: (text, record) => (
          <div style={{ marginLeft: 4 }}>
            <Tooltip title={record.Manufacturer}>{parseText(text)}</Tooltip>
          </div>
        )
      },
      {
        title: strings.calibrationTypeCaps,
        width: isImageEnabled ? "13%" : "15%",
        dataIndex: "CalibrationType",
        render: (text, record) => (
          <div style={{ marginLeft: 5 }}>
            <Tooltip title={record.CalibrationType}>{text}</Tooltip>
          </div>
        )
      },
      {
        title: strings.requestedServiceCaps,
        width: isImageEnabled ? "17%" : "18%",
        dataIndex: "requestedService",
        render: (text, record) => (
          <div style={{ marginTop: 20 }}>
            <SRSelectedAssets2
              getFieldDecorator={this.props.form.getFieldDecorator}
              eqNo={record.EquipmentNo}
              onChange={e => this.onSelectChange(e, record)}
              services={newServiceRequestStore.dropDownServices}
              requestedService={text}
            />
          </div>
        )
      },
      {
        title: strings.priceCaps,
        width: "8%",
        dataIndex: "price",
        render: () => {
          return (
            <div style={{ marginLeft: 10, color: "#3ABF72" }}>
              <Tooltip title="N/A">N/A</Tooltip>
            </div>
          );
        }
      },
      {
        title: "",
        //width: 200,
        dataIndex: "editInfo",
        render: (text, record) => (
          <div>
            <Button
              className="edit-info"
              onClick={() => this.openEditInfo(record.UniqueID)}
            >
              <Icon type="edit" />
              {strings.edit}
            </Button>
          </div>
        )
      },
      {
        title: "",
        dataIndex: "",
        //width: 50,
        render: record => (
          <span>
            <Icon
              type="cross"
              className="delete-item-icon"
              loading={
                this.state.removeCartLoading
                  ? record.UniqueID == this.state.iconClickedData.UniqueID
                    ? true
                    : false
                  : false
              }
              style={{ fontSize: "16px" }}
              disabled={this.state.removeCartLoading ? true : false}
              onClick={() =>
                this.onDeleteItem(record.UniqueID, "selectedassets")
              }
            />
          </span>
        )
      }
    ];
  };

  setRequestedServices = () => {
    cartItems = [];
    if (newServiceRequestStore.cartItems) {
      const keys = Object.keys(newServiceRequestStore.cartItems);
      keys.map(e => cartItems.push(...newServiceRequestStore.cartItems[e]));
      cartItems.map(e => (e["selectedType"] = null));
    }
  };

  onSelectChange = (e, record) => {
    newServiceRequestStore.setRequestedService(record, e);
    newServiceRequestStore.parseCartItems(record, e);
    this.setState(({ requestedService }) => {
      requestedService[record.UniqueID] = e;
      return { requestedService };
    });
  };
  handleFormData = e => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      let errors = {};
      let check = true;
      if (!err) {
        const values = Object.values(newServiceRequestStore.cartItems);
        values.map(i => {
          if (
            i[0].requestedService == "OTHER" &&
            !i[0].comments.replace(/\s/g, "").length
          )
            check = false;
        });
        Object.entries(newServiceRequestStore.cartItems).forEach(entry => {
          let value = entry[1];
          if (!value[0].requestedService || value[0].requestedService == "") {
            let key = `service${value[0].EquipmentNo}`;
            errors[key] = {
              errors: [new Error(strings.manufacturerErrorMessage)]
            };
            err = { ...errors };
          }
        });
      }
      if (!err && _.isEmpty(errors) && check) {
        newServiceRequestStore.setDummyData(values);
        this.props.history.push("/contactShipping");
      } else {
        this.setErrors(errors);
        UIFunctions.Toast(
          !check
            ? err || !_.isEmpty(errors)
              ? strings.serviceTypeNotSelectedErrorMessage
              : strings.faultEmpty
            : strings.serviceTypeNotSelectedErrorMessage,
          "error"
        );
      }
    });
  };
  setErrors = errors => {
    this.props.form.setFieldsValue(errors);
  };
  confirm = () => {
    this.props.history.push("/servicerequest");
  };
  showImage = () => {
    newServiceRequestStore.setShowImage(!newServiceRequestStore.showImage);
  };
  onDeleteItem = (UniqueID, mode) => {
    let self = this;
    if (Object.keys(newServiceRequestStore.cartItems).length == 1) {
      UIFunctions.Confirm({
        zIndex: 2000,
        title: strings.srDeleteLastAssetMsg,
        okText: strings.okCaps,
        cancelText: strings.cancelCaps,
        onOk() {
          self.setState({ iconClickedData: UniqueID });
          return newServiceRequestStore
            .srDeleteItemsFromCart(UniqueID, "", "", mode)
            .then(() => {
              self.setRequestedServices();
              self.props.history.push("/servicerequest");
            });
        },
        onCancel() {}
      });
    } else {
      this.setState({
        removeCartLoading: true,
        iconClickedData: UniqueID,
        tableLoading: true
      });
      return newServiceRequestStore
        .srDeleteItemsFromCart(UniqueID, "", "", mode)
        .then(() => {
          self.setState({ removeCartLoading: false, tableLoading: false });
          self.setRequestedServices();
        });
    }
  };
  removeAllCartItems = () => {
    Functions.RemoveAllCartItems().then(resp => {
      if (resp.data.success == true) {
        newServiceRequestStore.setCartItems(resp.data.cartItems);
        UIFunctions.Toast(strings.srAssetsRemoveAllSuccessMsg, "success");
        this.props.history.push("servicerequest");
      } else {
        ("");
      }
    });
  };
  openEditInfo = UniqueID => {
    newServiceRequestStore.setEditInfoOpen(true);
    newServiceRequestStore.updateEditInfoContent(UniqueID);
  };
  componentDidMount() {
    if (!userStore.userDetails)
      return this.props.history.push("/servicerequest");
    newServiceRequestStore.updateServieRequestStatus("step1");
    newServiceRequestStore.setnavigationArrows(false);
    newServiceRequestStore.setProceedCheckout(true);
    this.setState({ tableLoading: true });
    newServiceRequestStore
      .getFormDropDownData()
      .then(resp => {
        if (!resp.data.details.result) {
          UIFunctions.ShowError({
            zIndex: 2000,
            onOk() {
              return history.go(-1);
            },
            title: resp.data.details.error ? strings.badIsoCodeMessage : ""
          });
        }
        let response = resp.data.details.result.services;
        newServiceRequestStore.setDropDownServices(response);
        let paymentMethods = resp.data.details.result.paymentmethods;
        newServiceRequestStore.setSrPaymentMethods(paymentMethods);
        this.setRequestedServices();
        this.setState({ tableLoading: false });
      })
      .catch(() => {
        return false;
      });
  }
  componentWillUnmount() {
    newServiceRequestStore.updateEditInfoFieldsChange(false);
  }
  onPaginationChange = pagination => {
    this.setState({ pagination });
  };
  onShowSizeChange = (current, pageSize) => {
    this.setState(({ pagination }) => {
      pagination.pageSize = pageSize;
      return { pagination };
    });
  };
  render() {
    cartItems = [];
    function getCartItems(sCartItems) {
      if (sCartItems) {
        const keys = Object.keys(sCartItems);
        keys.map(e => cartItems.push(...sCartItems[e]));
        cartItems.map(e => (e["selectedType"] = null));
      }
      return cartItems;
    }
    const { pagination } = this.state;
    return (
      <React.Fragment>
        <div className="sr-selected-assets">
          <SrCreationStage
            currentSrStep={newServiceRequestStore.currentSrStep}
          />
          <Form className="form" onSubmit={this.handleFormData}>
            <div className="selected-assets-form">
              <span className="toggleSwitch">{strings.showImages}</span>
              <Switch
                checkedChildren={strings.onCaps}
                unCheckedChildren={strings.offCaps}
                onClick={this.showImage}
                defaultChecked={newServiceRequestStore.showImage}
              />
              <Table
                style={{
                  maxHeight: "100%",
                  marginLeft: "6%",
                  marginRight: "4%",
                  marginTop: "1%"
                }}
                pagination={pagination}
                onChange={this.onPaginationChange}
                columns={this.columns(newServiceRequestStore.showImage)}
                dataSource={getCartItems(newServiceRequestStore.cartItems)}
                scroll={{ y: true }}
                loading={this.state.tableLoading}
              />
              {newServiceRequestStore.editInfoOpen ? (
                <EditRequestInfo
                  setRequestedServices={this.setRequestedServices}
                />
              ) : (
                ""
              )}
              <div className="cont--button">
                <Popconfirm
                  title={strings.srAssetsRemoveAllWarningMsg}
                  okText={strings.yes}
                  cancelText={strings.no}
                  onConfirm={this.removeAllCartItems}
                >
                  <span className="remove-all">
                    <Button>
                      <Icon type="cross" theme="outlined" />
                      {strings.removeAll}
                    </Button>
                  </span>
                </Popconfirm>
                <div className="vr"> &nbsp; </div>
                <Popconfirm
                  title={strings.srAssetsCancelRequest}
                  onConfirm={this.confirm}
                  okText={strings.yes}
                  cancelText={strings.no}
                >
                  <Button className="cancel">
                    <Icon type="close" />
                    &nbsp;&nbsp; {strings.cancel}
                  </Button>
                </Popconfirm>
                &nbsp;&nbsp;
                <Button className="continue" type="submit" htmlType="submit">
                  <Icon type="arrow-right" />
                  &nbsp;&nbsp; {strings.continue}
                </Button>
              </div>
            </div>
          </Form>
        </div>
      </React.Fragment>
    );
  }
}

export default Form.create()(SRSelectedAssets);
