import React from "react";
import styled from "styled-components";
import { Form, Select } from "antd";
import strings from "../LocalizedText/strings";

const FormItem = Form.Item;
const Option = Select.Option;

const Div = styled.div`
  .ant-select-selection {
    border: 0px solid #ffffff !important;
    background-color: #ffffff;
  }
  .ant-select-dropdown-menu-item {
    color: #3385ff;
    white-space: normal !important;
  }
  .ant-select-selection-selected-value {
    color: #3385ff;
  }
  .ant-select-selection__placeholder,
  .ant-select-search__field__placeholder {
    color: #3385ff;
  }
  .dropdown {
    display: flex;
  }
  .mandatory-field {
    color: red;
  }
`;

const SRSelectedAssets2 = props => {
  return (
    <Div>
      <span className="dropdown">
        <span key="" className="mandatory-field">
          *
        </span>
        <FormItem validateStatus={props.requestedService ? "" : "error"}>
          <Select
            dropdownClassName="reqServiceDropDown"
            style={{ width: 180 }}
            placeholder={strings.srServiceType}
            onChange={props.onChange}
            value={props.requestedService ? props.requestedService : undefined}
          >
            {props.services.map(dropdown => (
              <Option key={dropdown.id}>{dropdown.description}</Option>
            ))}
          </Select>
        </FormItem>
      </span>
    </Div>
  );
};

export default SRSelectedAssets2;
