import React from "react";
import strings from "../LocalizedText/strings";
import {
  Form,
  Row,
  Col,
  Input,
  Upload,
  Icon,
  Button,
  Select,
  DatePicker
} from "antd";
import styled from "styled-components";
import newServiceRequestStore from "src/stores/newServiceRequestStore";
import _ from "lodash";
import moment from "moment";
import UIFunctions from "../../../helpers/UIFunctions";

const Div = styled.div`
  .ant-form-item-label label {
    margin-bottom: 1px;
  }
  .ant-form-item {
    margin-bottom: 4px;
  }
  textarea.ant-input {
    max-width: 95%;
  }
  .ant-form-item-control {
    line-height: 24px;
  }
`;
function disabledDate(current) {
  return current < moment().endOf("day");
}
const { TextArea } = Input;
const Option = Select.Option;
const infoKeys = ["Manufacturer", "SerialNo", "ModelNo", "EquipmentNo"];
const formItemLayout = {
  wrapperCol: { span: 16 }
};
const formItemLayoutText = {
  wrapperCol: { span: 24 }
};

class EditRequestInfoForm extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    this.props.editInfoFormData();
    this.creditCardPaymentChecking(newServiceRequestStore.editInfoContent.paymentMethod);
  }
  creditCardPaymentChecking(value)
  {
    if (value == "C") {
      newServiceRequestStore.setIsCreditCardPayment(true);
      var orderNumber = "";
      var { setFieldsValue } = this.props;
      setFieldsValue({
        orderNumber
      });
    }
    else {
      newServiceRequestStore.setIsCreditCardPayment(false);
    }
  }
  componentWillUnmount() {
    newServiceRequestStore.updateEditInfoFieldsChange(false);
    newServiceRequestStore.setIsCreditCardPayment(false);
  }
  handlePaymentMethodChange = (value) => {
    newServiceRequestStore.updateEditInfoFieldsChange(true);
    this.creditCardPaymentChecking(value);
  };
  render() {
    const { srPaymentMethods } = newServiceRequestStore;
    const { getFieldDecorator } = this.props;
    const { editInfoContent } = newServiceRequestStore;
    const { dropDownServices } = newServiceRequestStore;
    let hasEditInfo =
      _.difference(infoKeys, Object.keys(editInfoContent)).length === 0;
    if (!hasEditInfo) return UIFunctions.Toast(strings.errorMessage, "error");

    return (
      <Div>
        <Row>
          <Col span={1} />
          <Col span={11}>
            <Form.Item label={strings.manufacturer}>
              {getFieldDecorator("Manufacturer", {
                rules: [
                  {
                    required: false
                  }
                ]
              })}
              {editInfoContent.Manufacturer
                ? editInfoContent.Manufacturer
                : strings.noData}
            </Form.Item>
            <Form.Item label={strings.serialNumber}>
              {getFieldDecorator("SerialNo", {
                rules: [
                  {
                    required: false
                  }
                ]
              })}
              {editInfoContent.SerialNo
                ? editInfoContent.SerialNo
                : strings.noData}
            </Form.Item>
            <Form.Item label={strings.modelNumber}>
              {getFieldDecorator("ModelNo", {
                rules: [
                  {
                    required: false
                  }
                ]
              })}{" "}
              {editInfoContent.ModelNo
                ? editInfoContent.ModelNo
                : strings.noData}
            </Form.Item>
            <Form.Item label={strings.assetNumber}>
              {getFieldDecorator("assetNumber", {
                rules: [
                  {
                    required: false
                  }
                ]
              })}
              {editInfoContent.AssetNo
                ? editInfoContent.AssetNo
                : strings.noData}
            </Form.Item>
            <Form.Item
              label={
                <span>
                  {strings.calInterval}&nbsp;{strings.months}
                </span>
              }
            >
              {getFieldDecorator("CalibrationInterval", {
                rules: [
                  {
                    required: false
                  }
                ]
              })}
              {editInfoContent.CalibrationInterval < 0
                ? strings.noData
                : editInfoContent.CalibrationInterval}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.serviceAgreement}>
              {getFieldDecorator("serviceAgreement", {
                rules: [
                  {
                    required: false
                  }
                ]
              })(
                <Input
                  placeholder={strings.serviceAgreementPlaceHolder}
                  onChange={this.props.editInfoFieldsChange}
                />
              )}
            </Form.Item>
            <Form.Item label={strings.paymentMethod}>
              {getFieldDecorator("paymentMethod", {
                rules: [
                  {
                    required: false
                  }
                ]
              })(
                <Select
                  dropdownClassName="paymentMethodDropDown"
                  style={{ width: "70%" }}
                  placeholder={strings.paymentMethodPlaceHolder}
                  onChange={this.handlePaymentMethodChange}
                >
                  {srPaymentMethods.map(dropdown => (
                    <Option key={dropdown.id}>{dropdown.description}</Option>
                  ))}
                </Select>
              )}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.purchaseOrderNumber}>
              {getFieldDecorator("orderNumber", {
                rules: [
                  {
                    required: false
                  }
                ]
              })(
                <Input
                  placeholder={strings.purchaseOrderNumberPlaceHolder}
                  onChange={this.props.editInfoFieldsChange}
                  disabled={newServiceRequestStore.isCreditCardPayment}
                />
              )}
            </Form.Item>
          </Col>
          <Col span={1} />
          <Col span={11}>
            <Form.Item label={strings.requestedService}>
              {getFieldDecorator("requestedService", {
                rules: [
                  {
                    required: true,
                    message: strings.serviceTypeErrorMessage
                  }
                ]
              })(
                <Select
                  dropdownClassName="reqServiceDropDown"
                  style={{ width: 180 }}
                  placeholder={strings.srServiceType}
                  onChange={this.props.editInfoFieldsChange}
                >
                  {dropDownServices.map(dropdown => (
                    <Option key={dropdown.id}>{dropdown.description}</Option>
                  ))}
                </Select>
              )}
            </Form.Item>
            <Form.Item label={strings.preferredDate}>
              {getFieldDecorator("preferredDate", {})(
                <DatePicker
                  className="edit-info-date-picker"
                  format="YYYY-MM-DD"
                  disabledDate={disabledDate}
                  onChange={this.props.editInfoFieldsChange}
                />
              )}
            </Form.Item>
            <Form.Item
              {...formItemLayoutText}
              label={strings.faultDescriptionComments}
            >
              {getFieldDecorator("comments", {
                rules: [{}]
              })(
                <TextArea
                  style={{ width: "257%", backgroundColor: "#FFFFFF" }}
                  rows={4}
                  onChange={this.props.editInfoFieldsChange}
                />
              )}
            </Form.Item>
            <Form.Item label={strings.attachFaultReport}>
              {this.props.getFieldDecorator("calRep", {
                valuePropName: "fileList",
                getValueFromEvent: this.props.uploadFaultReportFile
              })(
                <Upload
                  customRequest={() => {
                    //eslint-disable-next-line
                    console.log("");
                  }}
                  loading={false}
                >
                  <Button>
                    <Icon type="upload" /> {strings.uploadFile}
                  </Button>
                  &nbsp;&nbsp;({strings.maxFileSize})
                  <div>{strings.fileInstructions}</div>
                </Upload>
              )}
            </Form.Item>
            <Form.Item label={strings.attachPurchaseOrder}>
              {getFieldDecorator("purchaseOrderUpload", {
                valuePropName: "fileList",
                getValueFromEvent: this.props.uploadPurchaseOrderFile
              })(
                <Upload
                  customRequest={() => {
                    //eslint-disable-next-line
                    console.log("");
                  }}
                  loading={false}
                >
                  <Button>
                    <Icon type="upload" /> {strings.uploadFile}
                  </Button>
                  &nbsp;&nbsp;({strings.maxFileSize})
                  <div>{strings.fileInstructions}</div>
                </Upload>
              )}
            </Form.Item>
          </Col>
        </Row>
      </Div>
    );
  }
}

export default EditRequestInfoForm;
