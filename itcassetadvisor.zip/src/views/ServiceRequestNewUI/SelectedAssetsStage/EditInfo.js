import React from "react";
import {
  Form,
  Input,
  Row,
  Col,
  Button,
  Icon,
  InputNumber,
  Upload,
  Select,
  DatePicker
} from "antd";
import { Link } from "react-router-dom";
import strings from "../LocalizedText/strings";
import newServiceRequestStore from "src/stores/newServiceRequestStore";
import UIFunctions from "src/helpers/UIFunctions";
import { observer } from "mobx-react";

const Option = Select.Option;
const { TextArea } = Input;
const formItemLayout = {
  labelCol: { span: 20 },
  wrapperCol: { span: 12 }
};
const formItemLayout1 = {
  labelCol: { span: 20 },
  wrapperCol: { span: 16 }
};
const formItemLayout2 = {
  labelCol: { span: 20 },
  wrapperCol: { span: 12 }
};
const formItemLayout3 = {
  labelCol: { span: 20 },
  wrapperCol: { span: 6 }
};

@observer
class editInfo extends React.Component {
  constructor(props) {
    super(props);
  }
  handleSubmit1 = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        values["UniqueID"] = newServiceRequestStore.editInfoData.UniqueID
          ? newServiceRequestStore.editInfoData.UniqueID
          : "";
        newServiceRequestStore.setEditInfoData1(values);
        newServiceRequestStore.setEditInfoOpen(false);
        UIFunctions.Toast("Information Updated Successfully!", "success");
        if (
          newServiceRequestStore.cartItems[
            newServiceRequestStore.editInfoData1.UniqueID
          ]
        ) {
          newServiceRequestStore.setEditInfoCartItems();
        }
      } else {
        UIFunctions.Toast("One or more mandatory fields are empty!", "error");
      }
    });
  };
  normFile = e => {
    const isLt10M = e.file.size / 1024 / 1024 <= 10;
    if (!isLt10M) {
      return UIFunctions.Toast(e.file.name + " is greater than 10MB", "error");
    }
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  normFile1 = e => {
    const isLt10M = e.file.size / 1024 / 1024 <= 10;
    if (!isLt10M) {
      return UIFunctions.Toast(e.file.name + " is greater than 10MB", "error");
    }
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  componentDidMount() {
    const storeData = newServiceRequestStore.editInfoData;
    const newObj = {};
    newObj["manufacturer"] = storeData.Manufacturer
      ? storeData.Manufacturer
      : "";
    newObj["SerialNo"] = storeData.SerialNo ? storeData.SerialNo : "";
    newObj["modelNo"] = storeData.ModelNo ? storeData.ModelNo : "";
    newObj["calInterval"] = storeData.calInterval ? storeData.calInterval : "";
    newObj["serviceAgreement"] = storeData.serviceAgreement
      ? storeData.serviceAgreement
      : "";
    newObj["calReport"] = storeData.calReport ? storeData.calReport : "";
    newObj["assetNumber"] = storeData.assetNumber ? storeData.assetNumber : "";
    newObj["paymentMethod"] = storeData.paymentMethod
      ? storeData.paymentMethod
      : "";
    newObj["orderNumber"] = storeData.orderNumber ? storeData.orderNumber : "";
    newObj["attachPurchaseOrder"] = storeData.attachPurchaseOrder
      ? storeData.attachPurchaseOrder
      : "";
    newObj["preferredDate"] = storeData.preferredDate
      ? storeData.preferredDate
      : "";
    newObj["comments"] = storeData.comments ? storeData.comments : "";

    this.props.form.setFieldsValue(newObj);
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <Form className="edit-info-form">
        <Row gutter={16}>
          <Col span={8}>
            <Form.Item {...formItemLayout1} label={strings.manufacturer}>
              {getFieldDecorator("manufacturer", {
                rules: [{ required: false }]
              })(
                <Input placeholder={strings.manufacturerPlaceHolder} disabled />
              )}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.serialNo}>
              {getFieldDecorator("SerialNo", {
                rules: [{ required: false }]
              })(<Input placeholder={strings.serialNoPlaceHolder} disabled />)}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.modelNo}>
              {getFieldDecorator("modelNo", {
                rules: [{ required: false }]
              })(<Input placeholder={strings.modelNoPlaceHolder} disabled />)}
            </Form.Item>
            <Form.Item
              label={
                <span>
                  {strings.calInterval}
                  <span style={{ color: "blue" }}> {strings.months}</span>
                </span>
              }
            >
              {getFieldDecorator("calInterval", {
                rules: [{ required: false }]
              })(<InputNumber min={0} step={1} defaultValue={0} disabled />)}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.serviceAgreement}>
              {getFieldDecorator("serviceAgreement", {
                rules: [{ required: false }]
              })(<Input placeholder={strings.serviceAgreementPlaceHolder} />)}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.calReport}>
              {getFieldDecorator("calReport", {
                valuePropName: "fileList",
                getValueFromEvent: this.normFile1,
                rules: [{ required: false }]
              })(
                <Upload>
                  <Button style={{ marginTop: "10px" }}>
                    <Icon type="upload" />
                    {strings.uploadFile}
                  </Button>
                </Upload>
              )}
            </Form.Item>
            <Form.Item {...formItemLayout1} label={strings.assetNumber}>
              {getFieldDecorator("assetNumber", {
                rules: [{ required: false }]
              })(
                <Input placeholder={strings.assetNumberPlaceHolder} disabled />
              )}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.paymentMethod}>
              {getFieldDecorator("paymentMethod", {
                rules: [{ required: false }]
              })(<Input placeholder={strings.paymentMethodPlaceHolder} />)}
            </Form.Item>
            <Form.Item {...formItemLayout} label={strings.orderNumber}>
              {getFieldDecorator("orderNumber", {
                rules: [{ required: false }]
              })(<Input placeholder={strings.orderNumberPlaceHolder} />)}
            </Form.Item>
            <Form.Item label={strings.attachPurchaseOrder}>
              {getFieldDecorator("attachPurchaseOrder", {
                valuePropName: "fileList",
                getValueFromEvent: this.normFile,
                rules: [{ required: false }]
              })(
                <Upload>
                  <Button style={{ marginTop: "10px" }}>
                    <Icon type="upload" /> {strings.uploadFile}
                  </Button>
                </Upload>
              )}
            </Form.Item>
          </Col>
          <Col span={16}>
            <Form.Item {...formItemLayout2} label={strings.requestedService}>
              {getFieldDecorator("requestedService", {
                rules: [
                  {
                    required: true,
                    message: "Please Provide Service Type"
                  }
                ]
              })(
                <Select
                  className="service"
                  style={{ width: 180 }}
                  placeholder="Requested Service"
                  onChange={e =>
                    this.props.onChange(e, newServiceRequestStore.editInfoData)
                  }
                  value={this.props.requestedService}
                  allowClear
                >
                  {this.props.services.map(dropdown => (
                    <Option key={dropdown.id}>{dropdown.description}</Option>
                  ))}
                </Select>
              )}
            </Form.Item>
            <Form.Item {...formItemLayout3} label={strings.preferredDate}>
              {getFieldDecorator("preferredDate", {
                rules: [{ required: false }]
              })(<DatePicker format="YYYY-MM-DD" />)}
            </Form.Item>
            <Form.Item {...formItemLayout2} label={strings.comments}>
              {getFieldDecorator("comments", {
                rules: [{ required: false }]
              })(
                <TextArea
                  style={{ width: "100%" }}
                  rows={12}
                  placeholder={strings.commentsPlaceHolder}
                />
              )}
            </Form.Item>
            <Form.Item>
              <div className="cont--button1">
                <Button className="cancel">
                  <Link to="/servicerequest">
                    <Icon type="close" />
                    &nbsp;&nbsp; Cancel
                  </Link>
                </Button>
                &nbsp;&nbsp;
                {/* onclick={this.props.handle} */}
                <Button
                  className="continue"
                  type="submit"
                  htmlType="submit"
                  onClick={this.handleSubmit1}
                >
                  {/* <Link to="/contactShipping"> */}
                  <Icon type="check" />
                  &nbsp;&nbsp; Submit
                  {/* </Link> */}
                </Button>
              </div>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    );
  }
}

const EditInfo = Form.create({ name: "edit" })(editInfo);
export default EditInfo;
