import React from "react";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import { Modal, Button, Form, Popconfirm, Icon } from "antd";
import strings from "../LocalizedText/strings";
import styled from "styled-components";
import EditRequestInfoForm from "./EditRequestInfoForm";
import UIFunctions from "../../../helpers/UIFunctions";
import { observer } from "mobx-react";

const Div = styled.div`
  .previousAsset {
    height: 17px;
    width: 95px;
    font-family: "Open Sans";
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 0.43px;
    line-height: 17px;
    border: 0px solid #ffffff !important;
    background-color: #ffffff !important;
  }
  .nextAsset {
    height: 17px;
    width: 72px;
    font-family: "Open Sans";
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 0.43px;
    line-height: 17px;
    margin-right: 55%;
    border: 0px solid #ffffff !important;
    background-color: #ffffff !important;
  }
  .navDivider {
    box-sizing: border-box;
    height: 22px;
    width: 1px;
    border: 1px solid #dedede;
    margin-left: 1%;
    margin-right: 1%;
  }
`;

function Title({ modelNo, equipmentNo }) {
  return (
    <div className="edit-info-modal-title">
      <span className="edit-info-title">{strings.editRequestInfo}</span>
      <span className="sr-vertical-divider" />
      <p id="edit-info-title-description">
        {modelNo}/{equipmentNo}
      </p>
    </div>
  );
}
@observer
class editRequestInfo extends React.Component {
  constructor(props) {
    super(props);
  }
  uploadFaultReportFile = info => {
    const validFileSize = info.file.size / 1024 / 1024 <= 10;
    if (!validFileSize) {
      return UIFunctions.Toast(
        info.file.name + " is greater than 10MB",
        "info"
      );
    }
    newServiceRequestStore.updateEditInfoFieldsChange(true);
    let fileList = info.fileList;
    if (fileList.length > 1) {
      fileList.shift();
      newServiceRequestStore.updateFaultReportUpload(info);
      return fileList;
    } else {
      newServiceRequestStore.updateFaultReportUpload(info);
      return fileList;
    }
  };
  uploadPurchaseOrderFile = info => {
    const validFileSize = info.file.size / 1024 / 1024 <= 10;
    if (!validFileSize) {
      return UIFunctions.Toast(
        info.file.name + " is greater than 10MB",
        "info"
      );
    }
    newServiceRequestStore.updateEditInfoFieldsChange(true);
    let fileList = info.fileList;
    if (fileList.length > 1) {
      fileList.shift();
      newServiceRequestStore.updatePurchaseOrderUpload(info);
      return fileList;
    } else {
      newServiceRequestStore.updatePurchaseOrderUpload(info);
      return fileList;
    }
  };
  editInfoFormData = () => {
    const { editInfoContent } = newServiceRequestStore;
    newServiceRequestStore.setEditInfoFormValues();
    this.props.form.setFieldsValue(editInfoContent);
  };
  editInfoSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        if (!values.preferredDate) {
          values.preferredDate = "";
        }
        if (
          values.requestedService == "OTHER" &&
          !values.comments.replace(/\s/g, "").length
        ) {
          UIFunctions.Toast(strings.faultDescriptionBlankSpaceCheck, "error");
          return;
        }
        newServiceRequestStore.updateEditInfoFieldsChange(false);
        newServiceRequestStore.parseCartItems(
          newServiceRequestStore.editInfoContent,
          values.requestedServices,
          values
        );

        UIFunctions.Toast(strings.editInfoSuccessMessage, "success");
      } else {
        UIFunctions.Toast(strings.serviceTypeNotSelectedErrorMessage, "error");
      }
    });
  };
  editInfoFieldsChange = () => {
    newServiceRequestStore.updateEditInfoFieldsChange(true);
  };
  handleCancel = () => {
    this.props.setRequestedServices();
    newServiceRequestStore.setEditInfoOpen(false);
  };
  clearFormFields = () => {
    newServiceRequestStore.updateEditInfoFieldsChange(true);
    this.props.form.resetFields();
    newServiceRequestStore.editInfoContent.calRep = [];
    newServiceRequestStore.editInfoContent.purchaseOrderUpload = [];
    newServiceRequestStore.setIsCreditCardPayment(false);
    newServiceRequestStore.updateEditInfoContent(
      newServiceRequestStore.editInfoContent.UniqueID,
      "clear"
    );
    this.props.form.setFieldsValue(newServiceRequestStore.editInfoContent);
    newServiceRequestStore.updateEditInfoFieldsChange(false);
  };
  creditCardPaymentChecking()
  {
    if (newServiceRequestStore.editInfoContent.paymentMethod == "C") {
      newServiceRequestStore.setIsCreditCardPayment(true);
      var orderNumber = "";
      this.props.form.setFieldsValue({
        orderNumber
      });
    }
    else {
      newServiceRequestStore.setIsCreditCardPayment(false);
    }
  }
  nextAsset = () => {
    if (newServiceRequestStore.editInfoFieldsChange) {
      var self = this;
      UIFunctions.Confirm({
        zIndex: 2000,
        title: strings.nextPrevConfirmation,
        okText: strings.yes,
        cancelText: strings.no,
        onOk() {
          newServiceRequestStore.nextAsset();
          newServiceRequestStore.updateEditInfoFieldsChange(false);
          self.editInfoFormData();
        },
        onCancel() {}
      });
    } else {
      newServiceRequestStore.nextAsset();
      this.editInfoFormData();
      this.creditCardPaymentChecking();
    }
  };
  previousAsset = () => {
    if (newServiceRequestStore.editInfoFieldsChange) {
      var self = this;
      UIFunctions.Confirm({
        zIndex: 2000,
        title: strings.nextPrevConfirmation,
        okText: strings.yes,
        cancelText: strings.no,
        onOk() {
          newServiceRequestStore.previousAsset();
          newServiceRequestStore.updateEditInfoFieldsChange(false);
          self.editInfoFormData();
        },
        onCancel() {}
      });
    } else {
      newServiceRequestStore.previousAsset();
      this.editInfoFormData();
      this.creditCardPaymentChecking();
    }
  };
  render() {
    return (
      <Form onSubmit={this.editInfoSubmit}>
        <Modal
          className="selected-assets-edit-info-modal"
          title={
            <Title
              modelNo={newServiceRequestStore.editInfoContent.ModelNo}
              equipmentNo={newServiceRequestStore.editInfoContent.EquipmentNo}
            />
          }
          footer={[
            <Div key="">
              <div className="navButton">
                <Button
                  style={{
                    width: "112px",
                    padding: "2px",
                    cursor: newServiceRequestStore.disablePreviousAssetButton
                      ? "not-allowed !important"
                      : "pointer !important",
                    color: newServiceRequestStore.disablePreviousAssetButton
                      ? "#c2c2c2"
                      : "#3385ff"
                  }}
                  disabled={newServiceRequestStore.disablePreviousAssetButton}
                  className="previousAsset"
                  onClick={this.previousAsset}
                >
                  <Icon type="left" />
                  {strings.previousAsset}
                </Button>
                <span className="navDivider" />
                <Button
                  style={{
                    width: "98px",
                    padding: "2px",
                    cursor: newServiceRequestStore.disableNextAssetButton
                      ? "not-allowed !important"
                      : "pointer !important",
                    color: newServiceRequestStore.disableNextAssetButton
                      ? "#c2c2c2"
                      : "#3385ff"
                  }}
                  disabled={newServiceRequestStore.disableNextAssetButton}
                  className="nextAsset"
                  onClick={this.nextAsset}
                >
                  {strings.nextAsset}
                  <Icon type="right" />
                </Button>
                <Popconfirm
                  title={strings.clearFormFields}
                  okText={strings.yes}
                  cancelText={strings.no}
                  onConfirm={this.clearFormFields}
                  key={""}
                >
                  <Button className="edit-clear" key="back">
                    {strings.clear}
                  </Button>
                </Popconfirm>
                <Button
                  key="submit"
                  className="edit-save"
                  onClick={this.editInfoSubmit}
                  type="primary"
                  htmlType="submit"
                >
                  {strings.save}
                </Button>
              </div>
            </Div>
          ]}
          width="900px"
          visible={true}
          onCancel={this.handleCancel}
          maskClosable={false}
        >
          <EditRequestInfoForm
            getFieldDecorator={this.props.form.getFieldDecorator}
            setFieldsValue={this.props.form.setFieldsValue}
            editInfoFormData={this.editInfoFormData}
            uploadFaultReportFile={this.uploadFaultReportFile}
            uploadPurchaseOrderFile={this.uploadPurchaseOrderFile}
            editInfoFieldsChange={this.editInfoFieldsChange}
          />
        </Modal>
      </Form>
    );
  }
}

const EditRequestInfo = Form.create()(editRequestInfo);
export default EditRequestInfo;
