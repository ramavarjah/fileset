import React from "react";
import { Upload, Button, Icon, Form } from "antd";
import { observer } from "mobx-react";
import strings from "../LocalizedText/strings";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import UIFunctions from "../../../helpers/UIFunctions";
import mobx from "mobx";
import _ from "lodash";

@observer
class FaultReportUpload extends React.Component {
  constructor(props) {
    super(props);
    this.ShowWarning = _.debounce(UIFunctions.ShowWarning, 1000);
  }
  uploadFaultReportFile = info => {
    /*eslint-disable*/
    console.log("upload event", info);
    let fileList = info.fileList;
    let fileListFromStore = mobx.toJS(
      newServiceRequestStore.faultReportUploadFile
    );
    if (fileList.length > 1 && fileList.length != fileListFromStore.length) {
      console.log("if");
      this.ShowWarning({
        zIndex: 2000,
        title: "You cannot upload more than 1 file"
      });
    } else {
      const validFileSize = info.file.size / 1024 / 1024 <= 10;
      if (!validFileSize) {
        return UIFunctions.Toast(
          info.file.name + " is greater than 10MB",
          "info"
        );
      }
      fileList[0] ? (fileList[0].status = "done") : "";
      newServiceRequestStore.addFaultReportUploadFile(fileList);
    }
  };
  removeFaultReportFile = file => {
    newServiceRequestStore.removeFaultReportUpload(file);
  };

  render() {
    return (
      <Form.Item label={strings.attachFaultReport}>
        {this.props.getFieldDecorator("calReport", {
          valuePropName: "fileList",
          getValueFromEvent: this.uploadFaultReportFile,
          rules: [{ required: false }]
        })(
          <Upload
            //eslint-disable-next-line
            customRequest={() => console.log("")}
            loading={false}
            // fileList={newServiceRequestStore.faultReportUploadFile}
            onRemove={this.removeFaultReportFile}
          >
            <Button style={{ marginTop: "10px" }}>
              <Icon type="upload" /> {strings.uploadFile}
            </Button>
          </Upload>
        )}
      </Form.Item>
    );
  }
}

export default FaultReportUpload;
