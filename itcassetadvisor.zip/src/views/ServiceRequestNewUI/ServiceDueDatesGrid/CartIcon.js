import React from "react";
import { Icon } from "antd";
import newServiceRequestStore from "src/stores/newServiceRequestStore";
export default class CartIcon extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      Item : newServiceRequestStore.AddingCartItem
    };
  }
  render() {
    let btn_disabled = false;

    newServiceRequestStore.cartItems &&
    newServiceRequestStore.cartItems[this.props.UniqueID]
      ? (btn_disabled = true)
      : "";
    return (
      <a href="#" onClick={this.props.onIconClick}>
        <Icon
          className="icn"
          type={!btn_disabled ? "shopping-cart" : "minus-circle"}
        />{" "}
      </a>
    );
  }
}
