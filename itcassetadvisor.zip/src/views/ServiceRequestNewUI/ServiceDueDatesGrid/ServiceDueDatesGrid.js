import React from "react";
import { Button, Icon, DatePicker, Table } from "antd";
import DropDown from "./DropDown";
import noDataImage from "../../../../public/img/no-data-placeholder_standard.png";
import { observer } from "mobx-react";
import newServiceRequestStore from "src/stores/newServiceRequestStore";

const { RangePicker } = DatePicker;

@observer
class ServiceDueDatesGrid extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <React.Fragment>
        <div style={{ display: "flex", alignItems: "center", height: 56 }}>
          <span style={this.props.style}>{this.props.dummyText}</span>
          &nbsp;&nbsp;
          <Button
            disabled={!newServiceRequestStore.bgData}
            onClick={this.props.addAllItems}
          >
            <Icon type={this.props.btntype} theme={this.props.btntheme} />
            {this.props.btntext}
          </Button>
          <div className="head-dividerBottom" />
          &nbsp;&nbsp;
          <DropDown
            placeholderText={this.props.dropdowntext}
            styles={this.props.customStyles}
            optionStatus1={this.props.optionStatus1}
            options1={this.props.options1}
            handleSelect1={this.props.handleSelect1}
          />
          &nbsp;&nbsp;
          <RangePicker
            style={this.props.rangePicker}
            allowClear={false}
            onChange={this.props.RangeChange}
            className="calendar"
            value={this.props.dateValue}
            defaultValue={this.props.defaultDateRange}
          />
          <div className="head-dividerBottom" />
          &nbsp;
          <Button
            disabled={this.props.disablePastDue}
            onClick={this.props.pastdueclick}
          >
            <Icon
              type="exclamation-circle"
              style={newServiceRequestStore.PastDue ? { color: "red" } : {}}
            />
            <span
              style={newServiceRequestStore.PastDue ? { color: "red" } : {}}
            >
              {this.props.pastdue}
            </span>
          </Button>
          <br />
        </div>
        <div style={this.props.tableStyle}>
          <Table
            columns={this.props.columns}
            dataSource={this.props.serviceDueDatesData}
            pagination={this.props.pagination}
            loading={this.props.sddGridLoading}
            onChange={this.props.onChange}
            scroll={{ y: true }}
            locale={{
              emptyText: (
                <figure
                  className={
                    newServiceRequestStore.SRDueDateMode == "SR_DD_Max"
                      ? "sddImgMax"
                      : "sddImgMin"
                  }
                >
                  <img
                    src={noDataImage}
                    height="95px"
                    width="115px"
                    align="middle"
                  />
                  <figcaption
                    className={
                      newServiceRequestStore.SRDueDateMode == "SR_DD_Max"
                        ? "sddFigMax"
                        : "sddFigMin"
                    }
                  >
                    {this.props.figCaption}
                  </figcaption>
                </figure>
              )
            }}
          />
        </div>
      </React.Fragment>
    );
  }
}
export default ServiceDueDatesGrid;
