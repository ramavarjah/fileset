import React from "react";
import { Modal, Row, Col, Button } from "antd";
import "./styles.css";
import AssetCard from "src/views/Components/Cards/AssetCard";
import VerticalDivider from "../../../views/LoanPoolNewUI/components/dividers/VerticalDivider";
import moment from "moment";
import newServiceRequestStore from "src/stores/newServiceRequestStore";
import strings from "../LocalizedText/strings";

function Title({ request, date }) {
  return (
    <div>
      <span className="request-details-header">
        {strings.modelNumber}: &nbsp; 
        <span className="model-modal-header">
          {request}
          <span className="vertical-small-divider" />{" "}
          </span>
        <p id="description">
          {strings.dueForService} - {date}
        </p>{" "}
      </span>
    </div>
  );
}
export default class SR_ModalDue extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sddModelVisible: true,
      loading: false
    };
  }
  handleBtnClick = params => {
    this.setState({ loading: true });
    const cartItems = {};
    cartItems[params.UniqueID] = [
      {
        ModelNo: params.ModelNo,
        EquipmentNo: params.EquipmentNo,
        Manufacturer: params.Manufacturer,
        Location: params.Location,
        CalibrationType: params.CalibrationType,
        Organization: params.Organization,
        CalibrationDueDate: params.CalibrationDueDate,
        SerialNo: params.SerialNo,
        UniqueID: params.UniqueID
      }
    ];
    newServiceRequestStore.srAddItemsToCart(cartItems);
    setTimeout(() => {
      this.setState({ loading: false });
    }, 3000);
  };

  render() {
    const ModalArray = this.props.ModalArray;
    let location = ModalArray.Location;
    let temp = location.split(">");
    temp.reverse();
    let newLocation = temp.join(" < ");
    const btnStyle = this.props.btnStyle;
    const btnStyle1 = this.props.btnStyle1;
    let btn_disabled = false;
    newServiceRequestStore.cartItems &&
    newServiceRequestStore.cartItems[ModalArray.UniqueID]
      ? (btn_disabled = true)
      : "";

    return (
      <Modal
        title={
          <Title
            request={ModalArray.ModelNo}
            date={`${moment(ModalArray.CalibrationDueDate).format(
              "YYYY-MM-DD"
            )}`}
          />
        }
        visible={this.state.sddModelVisible}
        onOk={this.props.handleOk}
        onCancel={this.props.handleCancel}
        footer={null}
        bodyStyle={{ height: 550 }}
        style={{top: (window.innerHeight - 650)}}
        width="886px"
        className="bottomGridModal"
      >
        <Row>
          <Col span={10}>
            <div
              className="request-modal-asset-details"
              style={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                height: 450
              }}
            >
              <Button
                key="submit"
                type="primary"
                loading={this.state.loading}
                onClick={this.handleBtnClick.bind(this, ModalArray)}
                disabled={btn_disabled}
                icon="shopping-cart"
                style={btn_disabled ? btnStyle : btnStyle1}
              >
                {btn_disabled ? strings.addedToCart : strings.addToCart}
              </Button>
              <p id="modalDueDescription"> {ModalArray.Description} </p>
              <AssetCard
                modelNo={ModalArray.ModelNo}
                dummyUrl="/img/no-asset-image.png"
                width="257px"
                height="257px"
                hasExternalRequest={false}
              />
            </div>
          </Col>
          <Col span={1}>
            <VerticalDivider height1="505px" />
          </Col>
          <Col span={10}>
            <div className="para">
              <p id="modalDueDetails"> <b>{strings.details}:</b> </p>
              <p id="parain">
                <b>{strings.equipmentNumber}:</b> {ModalArray.EquipmentNo}
              </p>
              <p id="parain">
                <b>{strings.manufacturer}:</b> {ModalArray.Manufacturer}
              </p>
              <p id="parain">
                <b>{strings.organization}:</b> {ModalArray.Organization}
              </p>
              <p id="parain">
                <b>{strings.location}:</b> {newLocation}
              </p>
              <p id="parain">
                <b>{strings.calibrationType}:</b> {ModalArray.CalibrationType}
              </p>
              <p id="parain">
                <b>{strings.serialNumber}:</b> {ModalArray.SerialNo}
              </p>
            </div>
          </Col>
        </Row>
      </Modal>
    );
  }
}
