import React from "react";
import { Select } from "antd";
const Option = Select.Option;

export default class DropDown extends React.Component {
  render() {
    return (
      <Select
        dropdownClassName="serviceDueDatesFilter"
        style={this.props.styles}
        placeholder={this.props.placeholderText}
        onChange={e => this.props.handleSelect1(e)}
        value={this.props.optionStatus1}
      >
        {this.props.options1.map((i, index) => (
          <Option key={index} value={i.value}>
            {i.displayName}
          </Option>
        ))}
      </Select>
    );
  }
}
