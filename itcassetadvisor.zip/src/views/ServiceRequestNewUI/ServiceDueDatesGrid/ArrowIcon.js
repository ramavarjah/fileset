import React from "react";
import { Icon } from "antd";
import newServiceRequestStore from "src/stores/newServiceRequestStore";

export default class ArrowIcon extends React.Component {
  constructor(props) {
    super(props);
  }
  onMenuClicked() {
    if (newServiceRequestStore.SRDueDateMode == "SR_DD_Max") {
      newServiceRequestStore.setSRMode("SR_Min");
      newServiceRequestStore.setSRDueDatesMode("SR_DD_Min");
    } else {
      newServiceRequestStore.setSRMode("HIDE");
      newServiceRequestStore.setSRDueDatesMode("SR_DD_Max");
    }
  }
  render() {
    return (
      <a onClick={this.onMenuClicked.bind(this)}>
        <Icon
          type={
            newServiceRequestStore.SRDueDateMode == "SR_DD_Max"
              ? "shrink"
              : "arrows-alt"
          }
          style={{ color: "#646C72" }}
          theme="outlined"
          onClick={this.props.handleClick}
        />
      </a>
    );
  }
}
