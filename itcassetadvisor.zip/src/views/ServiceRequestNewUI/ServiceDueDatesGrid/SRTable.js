import React from "react";
import "antd/dist/antd.css";
import { Table } from "antd";

export default class SRTable extends React.Component {
  render() {
    return (
      <div>
        <Table
          className={this.props.classname}
          columns={this.props.columns}
          dataSource={this.props.data1}
          pagination={this.props.pagination1}
          style={{ backgroundColor: "#FFFFFF" }}
        />
      </div>
    );
  }
}
