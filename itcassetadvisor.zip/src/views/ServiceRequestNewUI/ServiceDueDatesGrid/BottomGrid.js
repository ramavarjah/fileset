import React from "react";
import "./styles.scss";
import SR_ModalDue from "./SR_ModalDue";
import CartIcon from "./CartIcon";
import ArrowIcon from "./ArrowIcon";
import { Icon, Tooltip } from "antd";
import ServiceDueDatesGrid from "./ServiceDueDatesGrid";
import { observer } from "mobx-react";
import newServiceRequestStore from "src/stores/newServiceRequestStore";
import moment from "moment";
import strings from "../LocalizedText/strings";

const dateValue = (startDate, endDate) => [startDate, endDate];
const options1 = [
  {
    value: "7days",
    displayName: strings.next7Days
  },
  {
    value: "30days",
    displayName: strings.next30Days
  },
  {
    value: "90days",
    displayName: strings.next90Days
  }
];
@observer
export default class BottomGrid extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sddModalShow: false,
      loading: false,
      ModalArray: {}
    };
  }
  columns1 = () => [
    {
      width: "5%",
      render: params => (
        <CartIcon
          UniqueID={params.UniqueID}
          onIconClick={this.handleonIconClick.bind(this, params)}
        />
      )
    },
    {
      width: newServiceRequestStore.bgData ? "13%" : "15%",
      title: strings.dueDate,
      dataIndex: "CalibrationDueDate",
      key: "CalibrationDueDate",
      render: text => {
        return (
          <div style={{ marginLeft: -6 }}>
            <Tooltip title={`${moment(text).format("YYYY-MM-DD")}`}>
              <span> {`${moment(text).format("YYYY-MM-DD")}`} </span>
            </Tooltip>
          </div>
        );
      }
    },
    {
      width: newServiceRequestStore.bgData ? "13%" : "18%",
      title: strings.modelNumberCaps,
      dataIndex: "ModelNo",
      render: (text, record) => (
        <div style={{ marginLeft: -3 }}>
          <Tooltip title={record.ModelNo}>
            <a href="javascript:;" onClick={() => this.sddmodalOpen(record)}>
              {text}
            </a>
          </Tooltip>
        </div>
      ),
      key: "ModelNo"
    },
    {
      width: newServiceRequestStore.bgData ? "15%" : "20%",
      title: "SERIAL NUMBER",
      dataIndex: "SerialNo",
      key: "SerialNo",
      render: (text, record) => (
        <div style={{ marginLeft: -3 }}>
          <Tooltip title={record.SerialNo}>{text}</Tooltip>
        </div>
      )
    },
    {
      width: newServiceRequestStore.bgData ? "40%" : "20%",
      title: strings.locationCaps,
      dataIndex: "Location",
      key: "Location",
      render: (text, record) => {
        let location = record.Location;
        let temp = location.split(">");
        temp.reverse();
        let newLocation = temp.join(" < ");
        return <Tooltip title={newLocation}>{newLocation}</Tooltip>;
      }
    },
    {
      width: newServiceRequestStore.bgData ? "12%" : "20%",
      title: strings.status,
      dataIndex: "Status",
      key: "Status",
      render: text => {
        if (text == "ServiceDue") {
          return (
            <Tooltip title={strings.dueForService}>
              <span style={{ color: "orange" }}>
                <Icon type="tool" />
                &nbsp;
                {strings.dueForService}
              </span>
            </Tooltip>
          );
        } else if (text == "PastDue") {
          return (
            <Tooltip title={strings.pastDue}>
              <span style={{ color: "red" }}>
                <Icon type="exclamation-circle" />
                &nbsp;
                {strings.pastDue}
              </span>
            </Tooltip>
          );
        } else {
          return <span style={{ color: "green" }}> {text} </span>;
        }
      }
    },
    {
      title: <ArrowIcon />
    }
  ];
  handleonIconClick = params => {
    let btn_disabled = false;
    newServiceRequestStore.cartItems &&
    newServiceRequestStore.cartItems[params.UniqueID]
      ? (btn_disabled = true)
      : "";
    if (!btn_disabled) {
      const cartItems = {};
      cartItems[params.UniqueID] = [
        {
          ModelNo: params.ModelNo,
          EquipmentNo: params.EquipmentNo,
          Manufacturer: params.Manufacturer,
          CalibrationType: params.CalibrationType,
          Location: params.Location,
          Organization: params.Organization,
          CalibrationDueDate: params.CalibrationDueDate,
          SerialNo: params.SerialNo,
          UniqueID: params.UniqueID,
          AssetNo: params.AssetNo,
          CalibrationInterval: params.CalibrationInterval
        }
      ];
      newServiceRequestStore.srAddItemsToCart(cartItems);
    } else {
      newServiceRequestStore.srDeleteItemsFromCart(params.UniqueID);
    }
  };
  handleOk = () => {
    this.setState({ loading: true });
    setTimeout(() => {
      this.setState({
        loading: false,
        sddModalShow: !this.state.sddModalShow
      });
    }, 3000);
  };

  sddmodalOpen = record => {
    //eslint-disable-next-line
    this.setState(state => ({
      sddModalShow: !this.state.sddModalShow,
      ModalArray: record
    }));
    newServiceRequestStore.getSRDueDateData = record;
  };

  handleCancel = () => {
    this.setState({
      sddModalShow: false
    });
  };
  handleSelect1 = value => {
    if (value == "90days") {
      newServiceRequestStore.PastDue = false;
      newServiceRequestStore.customSelected = false;
      newServiceRequestStore.sddRequests.startDate = moment().startOf("day");
      newServiceRequestStore.sddRequests.endDate = moment()
        .add(90, "day")
        .endOf("day");
      newServiceRequestStore.sddPagination.current = 1;
      newServiceRequestStore.sddPagination.pageNumber = 1;
      newServiceRequestStore.sddPagination.pageSize = 10;
      newServiceRequestStore.fetchSddRequests(
        newServiceRequestStore.sddRequests.startDate,
        newServiceRequestStore.sddRequests.endDate,
        newServiceRequestStore.sddPagination.pageNumber,
        newServiceRequestStore.sddPagination.pageSize,
        newServiceRequestStore.localSearchValue,
        newServiceRequestStore.PastDue
      );
    } else if (value == "7days") {
      newServiceRequestStore.PastDue = false;
      newServiceRequestStore.customSelected = false;
      newServiceRequestStore.sddRequests.startDate = moment().startOf("day");
      newServiceRequestStore.sddRequests.endDate = moment()
        .add(7, "day")
        .endOf("day");
      newServiceRequestStore.sddPagination.current = 1;
      newServiceRequestStore.sddPagination.pageNumber = 1;
      newServiceRequestStore.sddPagination.pageSize = 10;
      newServiceRequestStore.fetchSddRequests(
        newServiceRequestStore.sddRequests.startDate,
        newServiceRequestStore.sddRequests.endDate,
        newServiceRequestStore.sddPagination.pageNumber,
        newServiceRequestStore.sddPagination.pageSize,
        newServiceRequestStore.localSearchValue,
        newServiceRequestStore.PastDue
      );
    } else if (value == "30days") {
      newServiceRequestStore.PastDue = false;
      newServiceRequestStore.customSelected = false;
      newServiceRequestStore.sddRequests.startDate = moment().startOf("day");
      newServiceRequestStore.sddRequests.endDate = moment()
        .add(30, "day")
        .endOf("day");
      newServiceRequestStore.sddPagination.current = 1;
      newServiceRequestStore.sddPagination.pageNumber = 1;
      newServiceRequestStore.sddPagination.pageSize = 10;
      newServiceRequestStore.fetchSddRequests(
        newServiceRequestStore.sddRequests.startDate,
        newServiceRequestStore.sddRequests.endDate,
        newServiceRequestStore.sddPagination.pageNumber,
        newServiceRequestStore.sddPagination.pageSize,
        newServiceRequestStore.localSearchValue,
        newServiceRequestStore.PastDue
      );
    } else if (value == "custom") {
      newServiceRequestStore.customSelected = true;
      newServiceRequestStore.sddPagination.current = 1;
      newServiceRequestStore.sddPagination.pageNumber = 1;
      newServiceRequestStore.sddPagination.pageSize = 10;
    } else {
      newServiceRequestStore.customSelected = false;
      newServiceRequestStore.sddPagination.current = 1;
      newServiceRequestStore.sddPagination.pageNumber = 1;
      newServiceRequestStore.sddPagination.pageSize = 10;
    }
  };
  componentDidMount() {
    newServiceRequestStore.fetchSddRequests(
      newServiceRequestStore.sddRequests.startDate,
      newServiceRequestStore.sddRequests.endDate,
      newServiceRequestStore.sddPagination.pageNumber,
      newServiceRequestStore.sddPagination.pageSize,
      newServiceRequestStore.localSearchValue,
      newServiceRequestStore.PastDue
    );
  }
  componentWillUnmount() {
    newServiceRequestStore.sddPagination["pageNumber"] = 1;
    newServiceRequestStore.sddPagination["pageSize"] = 10;
  }
  getSelectedOption = dates => {
    const a = dates.startDate;
    const b = dates.endDate;
    const diff = Math.abs(a.diff(b, "days"));

    if (
      diff == 90 &&
      newServiceRequestStore.sddRequests.startDate.format("YYYY-MM-DD") ==
        moment().format("YYYY-MM-DD")
    ) {
      return "90days";
    } else if (
      diff == 7 &&
      newServiceRequestStore.sddRequests.startDate.format("YYYY-MM-DD") ==
        moment().format("YYYY-MM-DD")
    ) {
      return "7days";
    } else if (
      diff == 30 &&
      newServiceRequestStore.sddRequests.startDate.format("YYYY-MM-DD") ==
        moment().format("YYYY-MM-DD")
    ) {
      return "30days";
    } else {
      return "Custom";
    }
  };

  PastDueClick = () => {
    newServiceRequestStore.PastDue = !newServiceRequestStore.PastDue;
    newServiceRequestStore.fetchSddRequests(
      newServiceRequestStore.sddRequests.startDate,
      newServiceRequestStore.sddRequests.endDate,
      newServiceRequestStore.sddPagination.pageNumber,
      newServiceRequestStore.sddPagination.pageSize,
      newServiceRequestStore.localSearchValue,
      newServiceRequestStore.PastDue
    );
  };
  handleTableChange = pagination => {
    const pager = { ...newServiceRequestStore.sddPagination };
    pager.pageNumber = pagination.current;
    pager.current = pagination.current;
    newServiceRequestStore.sddPagination = pager;
    newServiceRequestStore.fetchSddRequests(
      newServiceRequestStore.sddRequests.startDate,
      newServiceRequestStore.sddRequests.endDate,
      newServiceRequestStore.sddPagination.pageNumber,
      newServiceRequestStore.sddPagination.pageSize,
      newServiceRequestStore.localSearchValue,
      newServiceRequestStore.PastDue
    );
  };
  handleAddAllItems = () => {
    newServiceRequestStore.AddAll = !newServiceRequestStore.AddAll;
    newServiceRequestStore.srAddAllItemsToCart(
      newServiceRequestStore.sddRequests.startDate,
      newServiceRequestStore.sddRequests.endDate,
      newServiceRequestStore.localSearchValue,
      newServiceRequestStore.PastDue
    );
  };

  render() {
    const stylesheets = {
      style: {
        position: "relative",
        fontSize: "13px",
        fontFamily: "Open Sans",
        letterSpacing: "0.47px",
        lineHeight: "18px",
        color: "#979797"
      },
      customStyles: {
        width: 150
      },
      tableStyle: {
        height:
          newServiceRequestStore.SRDueDateMode == "SR_DD_Max"
            ? window.innerHeight - 130
            : "100%",
        fontSize: "13px",
        fontWeight: "500px",
        borderColor: "#f2f2f2"
      },
      rangePicker: {
        height: "27px",
        width: "251px",
        borderRadius: "3px",
        backgroundColor: "#FFFFFF"
      },
      btnStyle: {
        width: "198px",
        border: "none",
        color: "rgba(0, 0, 0, 0.25)",
        backgroundColor: "#f7f7f7",
        borderRadius: "0px"
      },
      btnStyle1: {
        height: "32px",
        width: "156px",
        border: "1px solid #2c74E0",
        bordeRadius: "4px"
      }
    };
    const btntype = "shopping-cart";
    const btntheme = "outlined";
    //const btntext = strings.addAll;
    const dummyText = strings.serviceDueDates;
    const dropdowntext = strings.dropdowntext;
    const pastdue = strings.pastDue;
    return newServiceRequestStore.SRDueDateMode == "HIDE" ? (
      " "
    ) : (
      <div className={"sr-bottom-grid"}>
        <ServiceDueDatesGrid
          disablePastDue={
            newServiceRequestStore.sddRequests.startDate >
            moment().subtract(1, "day")
              ? true
              : false
          }
          //addallclick={this.AddAllClick}
          pastdueclick={this.PastDueClick}
          RangeChange={newServiceRequestStore.sddRangeChange}
          defaultDateRange={[
            newServiceRequestStore.sddRequests.startDate,
            newServiceRequestStore.sddRequests.endDate
          ]}
          tableStyle={stylesheets.tableStyle}
          dummyText={dummyText}
          style={stylesheets.style}
          serviceDueDatesData={newServiceRequestStore.sddData}
          btntype={btntype}
          dateValue={dateValue(
            newServiceRequestStore.sddRequests.startDate,
            newServiceRequestStore.sddRequests.endDate
          )}
          btntheme={btntheme}
          btntext={"Add All"}
          handleSelect1={this.handleSelect1}
          options1={options1}
          optionStatus1={
            newServiceRequestStore.customSelected
              ? "Custom"
              : this.getSelectedOption(newServiceRequestStore.sddRequests)
          }
          customStyles={stylesheets.customStyles}
          dropdowntext={dropdowntext}
          pastdue={pastdue}
          columns={this.columns1()}
          pagination={newServiceRequestStore.sddPagination}
          sddGridLoading={newServiceRequestStore.sddGridLoading}
          onChange={this.handleTableChange}
          addAllItems={this.handleAddAllItems}
          rangePicker={stylesheets.rangePicker}
          figCaption={strings.figCaption}
        />

        {this.state.sddModalShow ? (
          <SR_ModalDue
            handleOk={this.handleOk}
            loading={this.state.loading}
            handleCancel={this.handleCancel.bind(this)}
            ModalArray={this.state.ModalArray}
            btnStyle={stylesheets.btnStyle}
            btnStyle1={stylesheets.btnStyle1}
          />
        ) : (
          " "
        )}
      </div>
    );
  }
}
