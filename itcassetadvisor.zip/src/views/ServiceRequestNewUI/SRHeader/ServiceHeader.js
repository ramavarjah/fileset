import React from "react";
import CustomSearch from "./CustomSearch";
import CustomRequestCart from "./CustomRequestCart";
import { Layout } from "antd";
import SR_ModalHeader from "./SR_ModalHeader";
import "./SRHeader.scss";
import "antd/dist/antd.css";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import addAssetsStore from "../../../stores/addAssetsStore";
import { observer } from "mobx-react";
import moment from "moment";
import strings from "../LocalizedText/strings";
import { Link } from "react-router-dom";
import UIFunctions from "src/helpers/UIFunctions";
import _ from "lodash";
import userStore from "../../../stores/userStore";
const { Header } = Layout;

@observer
export default class ServiceHeader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "",
      visible: false,
      suggestions: []
    };
  }
  onSuggestionsFetchRequested = ({ value }) => {
    newServiceRequestStore.LocalSearchValue(value);
  };
  searchOnClick = () => {
    newServiceRequestStore.LoadingState(true);
    newServiceRequestStore.fetchSRequests(
      newServiceRequestStore.srOptionStatus,
      newServiceRequestStore.middleGridPagination.defaultPageSize,
      newServiceRequestStore.middleGridPagination.defaultPageNumber,
      moment(),
      newServiceRequestStore.localSearchValue
    );
    newServiceRequestStore.fetchSddRequests(
      newServiceRequestStore.sddRequests.startDate,
      newServiceRequestStore.sddRequests.endDate,
      newServiceRequestStore.sddPagination.pageNumber,
      newServiceRequestStore.sddPagination.pageSize,
      newServiceRequestStore.localSearchValue,
      newServiceRequestStore.PastDue
    );
  };
  _handleKeyPress = e => {
    if (e.key === "Enter") {
      newServiceRequestStore.LoadingState(true);
      newServiceRequestStore.fetchSRequests(
        newServiceRequestStore.srOptionStatus,
        newServiceRequestStore.middleGridPagination.defaultPageSize,
        newServiceRequestStore.middleGridPagination.defaultPageNumber,
        moment(),
        newServiceRequestStore.localSearchValue
      );
      newServiceRequestStore.fetchSddRequests(
        newServiceRequestStore.sddRequests.startDate,
        newServiceRequestStore.sddRequests.endDate,
        newServiceRequestStore.sddPagination.pageNumber,
        newServiceRequestStore.sddPagination.pageSize,
        newServiceRequestStore.localSearchValue,
        newServiceRequestStore.PastDue
      );
    }
  };
  handleQuickSearchChange = (event, { newValue }) => {
    this.setState({
      value: newValue
    });
    newServiceRequestStore.LocalSearchValue(newValue);
  };
  customOnClick = () => {
    this.setState({
      visible: !this.state.visible
    });
  };
  handleOk = () => {
    this.setState({
      visible: false
    });
  };
  handleCancel = () => {
    this.setState({
      visible: false
    });
  };
  onHomeButton = () => {
    this.setState({ value: "" });
    newServiceRequestStore.OnHomeButton();
    newServiceRequestStore.fetchSRequests(
      newServiceRequestStore.srOptionStatus,
      newServiceRequestStore.middleGridPagination.pageSize,
      newServiceRequestStore.middleGridPagination.pageNumber,
      moment(),
      newServiceRequestStore.localSearchValue
    );
    newServiceRequestStore.fetchSddRequests(
      newServiceRequestStore.sddRequests.startDate,
      newServiceRequestStore.sddRequests.endDate,
      newServiceRequestStore.sddPagination.pageNumber,
      newServiceRequestStore.sddPagination.pageSize,
      newServiceRequestStore.localSearchValue,
      newServiceRequestStore.PastDue
    );
    newServiceRequestStore.clearNewReq_basepayload();
  };
  componentDidMount() {
    newServiceRequestStore.setProceedCheckout(false);
    if (newServiceRequestStore.rowSelectedAssetsData.length > 0) {
      let cartArray = {};
      newServiceRequestStore.rowSelectedAssetsData.map(params => {
        let cartItems = [];
        let location = params.Location;
        let temp = location.split(">");
        temp.reverse();
        let newLocation = temp.join(" < ");
        let Organization = params.Organization;
        let temp1 = Organization.split(">");
        temp1.reverse();
        let newOrganization = temp.join(" < ");
        cartItems = [
          {
            ModelNo: params.ModelNo,
            EquipmentNo: params.EquipmentNo,
            Manufacturer: params.Manufacturer,
            CalibrationType: params.CalibrationType,
            Location: newLocation,
            Organization: newOrganization,
            CalibrationDueDate: params.CalibrationDueDate,
            SerialNo: params.SerialNo,
            UniqueID: params.UniqueID,
            AssetNo: params.AssetNo,
            CalibrationInterval: params.CalibrationInterval
          }
        ];
        newServiceRequestStore.cartItems &&
        newServiceRequestStore.cartItems[params.UniqueID]
          ? ""
          : (cartArray[params.UniqueID] = cartItems);
      });
      newServiceRequestStore.srAddItemsToCart(cartArray).then(() => {
        this.setState({
          visible: !this.state.visible
        });
      });
    }
  }
  componentWillUnmount() {
    newServiceRequestStore.OnHomeButton();
    addAssetsStore.dashboardAddCheck([]);
    newServiceRequestStore.serviceRequestNewAddCheck([]);
  }

  isCode() {
    if (userStore.userDetails) {
      const isocode = userStore.userDetails.Country
        ? userStore.userDetails.Country
        : "US";
      return _.find(userStore.userDetails.CountryCodes, {
        CountryCode: isocode
      });
    }
    return false;
  }
  checkCountry() {
    if (!this.isCode()) {
      return "";
    }
    return "/selectedassets";
  }
  isValidIsoCode() {
    if (!this.isCode()) {
      UIFunctions.Toast(strings.wrongCountryCodeErrorMessage, "warn");
    }
  }
  render() {
    const { suggestions, value } = this.state;
    const inputProps = {
      placeholder: strings.quickSearch,
      value,
      onChange: this.handleQuickSearchChange,
      disabled: newServiceRequestStore.proceedCheckout
    };

    const stylesheets = {
      searchstyle: {
        backgroundColor: value ? " #3385FF" : "#EEEEEE",
        color: value ? "#FFFFFF" : "#646C72",
        top: "16px"
      }
    };
    const requestCart = strings.requestCart;
    const badgeNumber =
      (newServiceRequestStore.cartItems &&
        Object.keys(newServiceRequestStore.cartItems).length) ||
      0;
    return (
      <div>
        <Header className="whitebg">
          <div className="header-same-class">
            <CustomSearch
              enterPressed={this._handleKeyPress.bind(this)}
              suggestions={suggestions}
              onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
              type={newServiceRequestStore.loadingIcon ? "loading" : "search"}
              searchstyle={stylesheets.searchstyle}
              inputProps={inputProps}
              onClick={this.searchOnClick}
            />
            {newServiceRequestStore.proceedCheckout ? (
              ""
            ) : (
              <div className="header-divider" />
            )}
            <div className="header-cart">
              <CustomRequestCart
                requestCart={requestCart}
                badgeNumber={badgeNumber}
                onClick={this.customOnClick}
              />
            </div>
          </div>
          <div
            className="header-same-class"
            style={{
              justifyContent: "flex-end",
              width: "auto"
            }}
          >
            <div className="header-common-class" />
            <div className="header-divider" />
            <span className="lp-title nowrap  header-common-class">
              <Link to={{ pathname: "/servicerequest" }}>
                <a onClick={this.onHomeButton.bind(this)}>
                  <span> {strings.serviceRequest} </span>
                </a>
              </Link>
            </span>
          </div>
        </Header>

        {this.state.visible ? (
          <SR_ModalHeader
            handleOk={this.handleOk}
            handleCancel={this.handleCancel}
            pathname={this.checkCountry.bind(this)}
            isValidIsoCode={this.isValidIsoCode.bind(this)}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}
