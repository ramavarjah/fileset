import React from "react";
import { Modal, Icon, Row, Col, Button, Table, Popconfirm } from "antd";
import AssetCard from "src/views/Components/Cards/AssetCard";
import newServiceRequestStore from "src/stores/newServiceRequestStore";
import strings from "../LocalizedText/strings";
import _ from "lodash";
import { observer } from "mobx-react";
import { Link } from "react-router-dom";

function Title({ removeAllCartItems, pathname, isValidIsoCode }) {
  return (
    <div>
      <span className="request-cart-header">
        <Icon
          className="shoppingcart-icon"
          type="shopping-cart"
          theme="outlined"
        />
        {strings.serviceRequestCart}

        <span className="vertical-small-divider" />
      </span>
      {!_.isEmpty(newServiceRequestStore.cartItems) ? (
        <div>
          <div
            className="proceed-checkout"
            style={{ justifyContent: "center", alignItems: "center" }}
          >
            <Link to={{ pathname: pathname() }}>
              <a className="proceed-checkout" onClick={isValidIsoCode}>
                <Icon type="arrow-right" theme="outlined" />
                {strings.proceedToCheckout}
              </a>
            </Link>
          </div>
          <div className="popConfirm">
            <Popconfirm
              title="Are you sure you want to delete all assets from this request?"
              okText="Yes"
              cancelText="No"
              onConfirm={removeAllCartItems}
            >
              <span className="remove-all">
                <Button disabled={newServiceRequestStore.removeAllButton}>
                  <Icon type="cross" theme="outlined" />
                  {strings.removeAll}
                </Button>
              </span>
            </Popconfirm>
          </div>
        </div>
      ) : (
        ""
      )}
    </div>
  );
}

const contentStyles = {
  color: "rgba(12,34,45)",
  fontWeight: "500",
  maxHeight: 450,
  overflow: "auto",
  padding: 16
};
const columns = [
  {
    dataIndex: "",
    title: "",
    width: "100%"
  }
];
@observer
export default class SR_ModalHeader extends React.Component {
  constructor() {
    super();
    this.state = {
      visible: true,
      removeCartLoading: false,
      iconClickedData: {}
    };
  }
  removeAllCartItems = () => {
    this.setState({ removeCartLoading: true });
    newServiceRequestStore.removeAllCartItems();
    setTimeout(() => {
      this.setState({ removeCartLoading: false });
    }, 3000);
  };
  onDeleteItem = UniqueID => {
    this.setState({ removeCartLoading: true, iconClickedData: UniqueID });
    newServiceRequestStore.srDeleteItemsFromCart(UniqueID);
    setTimeout(() => {
      this.setState({ removeCartLoading: false });
    }, 3000);
  };
  getAllCartItems = cartItems => {
    return cartItems
      .slice(0)
      .reverse()
      .map((item, index) => (
        <div key={index}>
          <Row>
            <Row gutter={24}>
              <Col xs={24} sm={6} md={8} lg={8} xl={8} />{" "}
              {/* to get empty space */}
            </Row>
            <Row gutter={24}>
              <Col xs={24} sm={8} md={8} lg={8} xl={8}>
                <div
                  className="request-modal-asset-details"
                  style={{
                    marginTop: 60,
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center"
                  }}
                >
                  <AssetCard
                    modelNo={item.ModelNo}
                    dummyUrl="/img/no-asset-image.png"
                    width="150px"
                    height="150px"
                    hasExternalRequest={false}
                  />
                </div>
              </Col>
              <Col xs={18} sm={14} md={14} lg={14} xl={14}>
                <div className="request-cart-details">
                  <p
                    className="request-cart-results"
                    style={{ color: "#3385FF", fontWeight: "800" }}
                  >
                    {item.Description == "undefined" ? "" : item.Description}
                  </p>
                  <p
                    className="request-cart-results"
                    style={{ color: "#686a6f", fontWeight: "600" }}
                  >
                    Details:
                  </p>
                  <p id="request-details">
                    <b>{strings.equipmentNumber}:</b>{" "}
                    <span className="request-cart-results">
                      {item.EquipmentNo == "undefined" ? "" : item.EquipmentNo}
                    </span>
                  </p>
                  <p id="request-details">
                    <b>{strings.modelNumber}:</b>{" "}
                    <span className="request-cart-results">
                      {item.ModelNo == "undefined" ? "" : item.ModelNo}
                    </span>
                  </p>
                  <p id="request-details">
                    <b>{strings.manufacturer}:</b>{" "}
                    <span className="request-cart-results">
                      {item.Manufacturer == "undefined"
                        ? ""
                        : item.Manufacturer}
                    </span>
                  </p>
                  <p id="request-details">
                    <b>{strings.organization}:</b>{" "}
                    <span className="request-cart-results">
                      {item.Organization == "undefined"
                        ? ""
                        : item.Organization}
                    </span>
                  </p>
                  <p id="request-details">
                    <b>{strings.location}:</b>{" "}
                    <span className="request-cart-results">
                      {item.Location == "undefined" ? "" : item.Location}
                    </span>
                  </p>
                </div>
              </Col>
              <Col xs={2} sm={2} md={2} lg={2} xl={2}>
                <div
                  className="request-modal-asset-details"
                  style={{ marginTop: 75 }}
                >
                  <div>
                    <Button
                      shape="circle"
                      icon="close-circle-o"
                      className="delete-item-icon"
                      loading={
                        this.state.removeCartLoading
                          ? item.UniqueID == this.state.iconClickedData.UniqueID
                            ? true
                            : false
                          : false
                      }
                      disabled={this.state.removeCartLoading ? true : false}
                      onClick={() => this.onDeleteItem(item.UniqueID)}
                    />
                  </div>
                </div>
              </Col>
            </Row>
          </Row>
          <br />
        </div>
      ));
  };

  render() {
    const cartItems = [];
    if (newServiceRequestStore.cartItems) {
      const keys = Object.keys(newServiceRequestStore.cartItems);
      keys.map(e => cartItems.push(...newServiceRequestStore.cartItems[e]));
    }
    return (
      <div>
        <Modal
          className="headerModal"
          title={
            <Title
              removeAllCartItems={this.removeAllCartItems}
              pathname={this.props.pathname}
              isValidIsoCode={this.props.isValidIsoCode}
            />
          }
          visible={this.state.visible}
          onOk={this.props.handleOk}
          onCancel={this.props.handleCancel}
          width="886px"
          bodyStyle={contentStyles}
          footer={null}
        >
          {cartItems.length > 0 ? (
            <Table
              dataSource={this.getAllCartItems(cartItems)}
              columns={columns}
            />
          ) : (
            <div>
              <p className="emptyCart-message" style={{ textAlign: "center" }}>
                <Icon type="shopping-cart" style={{ fontSize: 60 }} />
                <br />
                {strings.emptyCart}
              </p>
            </div>
          )}
        </Modal>
      </div>
    );
  }
}
