import React from "react";
import { Icon, Button } from "antd";
import newServiceRequestStore from "src/stores/newServiceRequestStore";
//import { observer } from "mobx-react";

const CustomArrow = () => {
  return newServiceRequestStore.navigationArrows ? (
    <div>
      <Button
        style={{ border: 0, backgroundColor: "white", padding: 0 }}
        disabled={newServiceRequestStore.navigationArrows}
      >
        <Icon
          type="left"
          theme="outlined"
          style={
            newServiceRequestStore.navigationArrows
              ? { color: "#ccd0d8", cursor: "pointer" }
              : { color: "#646C72", cursor: "pointer" }
          }
          className="header-arrow-icons "
        />
      </Button>
      <Button
        style={{ border: 0, backgroundColor: "white", padding: 0 }}
        disabled={newServiceRequestStore.navigationArrows}
      >
        <Icon
          type="right"
          theme="outlined"
          style={
            newServiceRequestStore.navigationArrows
              ? { color: "#ccd0d8", cursor: "pointer" }
              : { color: "#646C72", cursor: "pointer" }
          }
          className="header-arrow-icons "
        />
      </Button>
    </div>
  ) : (
    ""
  );
};
export default CustomArrow;
