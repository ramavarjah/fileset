import React from "react";
import { Icon, Button } from "antd";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import strings from "../LocalizedText/strings";

const CustomRequestCart = ({ badgeNumber, onClick, requestCart }) => {
  return newServiceRequestStore.proceedCheckout ? (
    newServiceRequestStore.serviceRequestConfirmation ? (
      ""
    ) : (
      <div className="header-common-class header-same-class header-search-wrapper">
        <span className="selected-assets">{strings.selectedAssets}</span>
        <span className={badgeNumber == 0 ? "default-badge" : "custom-badge"}>
          <span className="custom-badge-count">{badgeNumber}</span>
        </span>
      </div>
    )
  ) : (
    <div className="header-common-class header-same-class header-search-wrapper">
      <span className={badgeNumber == 0 ? "default-badge" : "custom-badge"}>
        <span className="custom-badge-count">{badgeNumber}</span>
      </span>
      <Button id="SRcart" onClick={onClick}>
        <Icon type="shopping-cart" theme="outlined" />
        <span>{requestCart}</span>
      </Button>
    </div>
  );
};

export default CustomRequestCart;
