import React from "react";
import Autosuggest from "react-autosuggest";
import { Icon } from "antd";
import newServiceRequestStore from "src/stores/newServiceRequestStore";

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = (suggestion, customRenderSuggestionStyle) => (
  <div style={customRenderSuggestionStyle}>{suggestion.name}</div>
);
const CustomSearch = ({
  suggestions,
  onSuggestionsFetchRequested,
  inputProps,
  searchstyle,
  onClick,
  type,
  enterPressed
}) => {
  return (
    <div>
      {newServiceRequestStore.proceedCheckout ? (
        ""
      ) : (
        <div
          className="header-common-class header-same-class header-search-wrapper"
          onKeyPress={enterPressed}
        >
          <Autosuggest
            suggestions={suggestions}
            onSuggestionsFetchRequested={onSuggestionsFetchRequested}
            getSuggestionValue={getSuggestionValue}
            renderSuggestion={suggestion => renderSuggestion(suggestion)}
            inputProps={inputProps}
          />
          <div className="header-searchbox-icon" style={searchstyle}>
            <Icon
              type={type}
              style={{ color: "inherit", cursor: "pointer" }}
              onClick={onClick}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomSearch;
