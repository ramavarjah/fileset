import React from "react";
import {
  Form,
  Input,
  Row,
  Col,
  Upload,
  Button,
  Icon,
  Select,
  DatePicker
} from "antd";

const { TextArea } = Input;
const Option = Select.Option;
const formItemLayoutText = {
  labelCol: { span: 24 },
  wrapperCol: { span: 24 }
};
const formItemLayoutService = {
  labelCol: { span: 20 },
  wrapperCol: { span: 16 }
};
const formItemLayout = {
  labelCol: { span: 17 },
  wrapperCol: { span: 12 }
};
const formItemLayoutCal = {
  labelCol: { span: 17 },
  wrapperCol: { span: 8 }
};
const formItemLayoutManf = {
  labelCol: { span: 17 },
  wrapperCol: { span: 16 }
};
const formItemLayoutPD = {
  labelCol: { span: 22 },
  wrapperCol: { span: 8 }
};

class editInfo extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <div className="edit--info">
        <Row>
          <Col span={1} />
          <Col span={11}>
            <Form className="form--style">
              <Form.Item {...formItemLayoutManf} label="Manufacturer">
                {getFieldDecorator("manf-name", {
                  rules: [
                    {
                      required: false
                    }
                  ]
                })(<Input placeholder="Keysight Technologies" />)}
              </Form.Item>
              <Form.Item {...formItemLayout} label="Serial No">
                {getFieldDecorator("srl-no", {
                  rules: [
                    {
                      required: false
                    }
                  ]
                })(<Input placeholder="1100393494884" />)}
              </Form.Item>
              <Form.Item {...formItemLayout} label="Model No">
                {getFieldDecorator("mdl-no", {
                  rules: [
                    {
                      required: false
                    }
                  ]
                })(<Input placeholder="MMFJKD943" />)}
              </Form.Item>
              <Form.Item
                {...formItemLayoutCal}
                label={
                  <span>
                    {" "}
                    Calibration Interval{" "}
                    <span style={{ color: "blue" }}> (Months)</span>
                  </span>
                }
              >
                {getFieldDecorator("cal-intr", {
                  rules: [
                    {
                      required: false
                    }
                  ]
                })(<Input placeholder="0" />)}
              </Form.Item>
              <Form.Item {...formItemLayout} label="Service Agreement">
                {getFieldDecorator("servc-agrm", {
                  rules: [
                    {
                      required: false
                    }
                  ]
                })(<Input placeholder="" />)}
              </Form.Item>
              <Form.Item {...formItemLayout} label="Attach Fault Cal Report">
                {getFieldDecorator("cal-rprt", {
                  rules: [
                    {
                      required: false
                    }
                  ]
                })(<Input placeholder="" />)}
                <Upload>
                  <Button style={{ marginTop: "10px" }}>
                    <Icon type="upload" /> Upload File
                  </Button>
                </Upload>
              </Form.Item>
            </Form>
          </Col>
          <Col span={11}>
            <Form.Item {...formItemLayoutService} label="Requested Service">
              {getFieldDecorator("requestedService", {
                color: "red",
                initialValue: "Keysight Calibration",
                rules: [
                  {
                    required: true,
                    message: "Requested Service Is Required"
                  }
                ]
              })(
                <Select
                  style={{
                    width: "75%",
                    color: "#979797"
                  }}
                  className="req--service"
                  onChange={e => this.props.bqHandleSelect(e)}
                  value={this.props.bqOptionStatus}
                >
                  {this.props.options.map((i, index) => (
                    <Option key={index} value={i.value}>
                      {i.bqDisplayName}
                    </Option>
                  ))}
                </Select>
              )}
            </Form.Item>
            <Form.Item {...formItemLayoutPD} label="Preferred Date">
              {getFieldDecorator("date", {})(
                <DatePicker className="date--picker" format="YYYY-MM-DD" />
              )}
            </Form.Item>
            <Form.Item
              {...formItemLayoutText}
              label="Fault Description Comments"
            >
              {getFieldDecorator("fault", {
                rules: [{}]
              })(
                <TextArea
                  style={{ width: "257%", backgroundColor: "#EEEEEE" }}
                  rows={12}
                />
              )}
            </Form.Item>
          </Col>
        </Row>
      </div>
    );
  }
}

const EditInfo = Form.create({ name: "edit" })(editInfo);
export default EditInfo;
