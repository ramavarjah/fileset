/*eslint-disable*/
import React from "react";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import { observer } from "mobx-react";
import SrCreationStage from "../SelectedAssetsStage/SrCreationStage";
import "./bqStyles.scss";
import {
  Table,
  Button,
  Icon,
  Form,
  Switch,
  Popconfirm,
  Tooltip,
  Row,
  Col
} from "antd";
import AssetCard from "src/views/Components/Cards/AssetCard";
import SRSelectedAssets2 from "../SelectedAssetsStage/SelectedAssetsForm";
import UIFunctions from "src/helpers/UIFunctions";
import { Redirect } from "react-router-dom";
import strings from "../LocalizedText/strings";
import { createBrowserHistory } from "history";
import Functions from "../../../api/Functions";
const history = createBrowserHistory();

const parseText = (text = "") =>
  text.length > 16 ? text.substring(0, 17) + "..." : text;

@observer
class SRBudgetaryQuoteForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      bqOptionStatus: "cal",
      bqModalOpen: false,
      goToLandingPage: false,
      tableLoading: false,
      serviceTypeError: false,
      requestedService: {},
      continueLoading: false,

      pagination: {
        showSizeChanger: true,
        onShowSizeChange: this.onShowSizeChange,
        current: 1,
        pageNumber: 1,
        defaultPageNumber: 1,
        pageSize: 10,
        defaultPageSize: 10
      }
    };
    this.columns = (isImageEnabled, dropDownServices) => {
      let ret = [];
      if (isImageEnabled)
        ret.push({
          title: "",
          dataIndex: "",
          width: isImageEnabled ? 150 : 350,
          height: 150,
          render: record => (
            <AssetCard
              modelNo={record.modelno}
              dummyUrl="/img/no-asset-image.png"
              width="150px"
              height="150px"
              hasExternalRequest={false}
            />
          )
        });

      return [
        ...ret,

        {
          title: strings.serialNoCaps,
          dataIndex: "serialno",
          width: isImageEnabled ? "12%" : "14%",
          render: text => <Tooltip title={text}>{text}</Tooltip>
        },
        {
          title: strings.modelNoCaps,
          dataIndex: "modelno",
          width: isImageEnabled ? "12%" : "14%",
          render: text => (
            <div style={{ marginLeft: 2 }}>
              <Tooltip title={text}>{text}</Tooltip>
            </div>
          )
        },
        {
          title: strings.manufacturerCaps,
          dataIndex: "manufacturer",
          width: isImageEnabled ? "11%" : "14%",
          render: text => (
            <div style={{ marginLeft: 4 }}>
              <Tooltip title={text}>{parseText(text)}</Tooltip>
            </div>
          )
        },
        {
          title: strings.coverageCaps,
          dataIndex: "quoteditems",
          width: isImageEnabled ? "13%" : "15%",
          key: "coverage",
          render: record => (
            <div style={{ marginLeft: 6 }}>
              <Tooltip title={record[0].coverage}>
                {parseText(record[0].coverage)}
              </Tooltip>
            </div>
          )
        },
        {
          title: strings.requestedServiceCaps,
          width: isImageEnabled ? "17%" : "18%",
          dataIndex: "requestedservice",
          render: (text, record) => {
            return (
              <div style={{ marginTop: 20 }}>
                <SRSelectedAssets2
                  getFieldDecorator={this.props.form.getFieldDecorator}
                  eqNo={record.EquipmentNo}
                  onChange={e => this.onSelectChange(e, record)}
                  services={newServiceRequestStore.dropDownServices}
                  requestedService={text}
                />
              </div>
            );
          }
        },
        {
          width: "220px",
          title: strings.priceCaps,
          dataIndex: "quoteditems",
          key: "price",
          render: record => (
            <div style={{ marginLeft: 10, color: "#3ABF72" }}>
              <Tooltip title={record[0].currency + " " + record[0].price}>
                {record[0].currency + " " + record[0].price}
              </Tooltip>
            </div>
          )
        },
        {
          title: "",
          width: 50,
          dataIndex: "editInfo",
          render: (text, record) => (
            <span>
              <Icon
                type="cross"
                className="delete-item-icon"
                onClick={e => this.onDeleteItem(e, record, "selectedassets")}
                style={{ fontSize: "16px" }}
              />
            </span>
          )
        }
      ];
    };
  }

  setRequestedServices = () => {
    let cartItems = newServiceRequestStore.InfolineResponse.result.sritems
      ? newServiceRequestStore.InfolineResponse.result.sritems
      : [];
    var Obj = {};
    cartItems.map(i => {
      if (i.requestedservice)
        Obj["service" + i.modelno + i.serialno] = i.requestedservice;
    });
    this.props.form.setFieldsValue(Obj);
  };

  handleBack = e => {
    e.preventDefault();
    return this.props.form.validateFields(err => {
      if (!err) {
        history.go(-1);
      }
    });
  };

  serviceConfirmation() {
    this.setState({ continueLoading: true });
    let params = {};
    params.permissionkey = "hydraxtest";
    params.csrid = newServiceRequestStore.InfolineResponse.result.csrid
      ? newServiceRequestStore.InfolineResponse.result.csrid
      : "";
    newServiceRequestStore.clearNewReq_basepayload();
    Functions.serviceRequest(params, "SRCreateRequest").then(result => {
      if (result.data.details.result) {
        Functions.RemoveAllCartItems().then(resp => {
          newServiceRequestStore.setCartItems(resp.data.cartItems);
        });
        var payload = result.data.details;
        newServiceRequestStore.setInfolineResponse(payload);
        this.props.history.push("/requestConfirmation");
        newServiceRequestStore.updateServieRequestStatus("step4");
        this.setState({ continueLoading: false });
      } else {
        this.setState({ continueLoading: false });
        UIFunctions.Toast(strings.somethingWentWrong, "warn");
      }
    });
  }

  onSelectChange = (e, record) => {
    /*eslint-disable*/
    this.setState({ tableLoading: true });
    newServiceRequestStore.setRequestedService(record, e);
    const values = record;
    record.requestedservice = e;
    newServiceRequestStore.updateSritems(record).then(resp => {
      this.setState({ continueLoading: false });
      let updateVal = {};
      updateVal["requestedservice"] = record.requestedservice;
      updateVal["modelno"] = record.modelno;
      updateVal["serialno"] = record.serialno;
      newServiceRequestStore.updateInfoCartItems(updateVal);
      console.log("cc", newServiceRequestStore.cartItems);
      this.setState(({ requestedService }) => {
        requestedService[record.UniqueID] = e;
        return {
          requestedService
        };
      });
      if (resp) {
        this.setState({
          tableLoading: false,
          serviceTypeError: false
        });
      } else {
        this.setState({
          tableLoading: false,
          continueLoading: true,
          serviceTypeError: true
        });
        UIFunctions.Toast(strings.faultEmpty, "error");
      }
    });
  };

  onDeleteItem = (e, record, mode) => {
    let self = this;
    e.preventDefault();
    var UniqueId = "";
    if (newServiceRequestStore.InfolineResponse.result.sritems.length == 1) {
      UIFunctions.Confirm({
        zIndex: 2000,
        title: strings.srDeleteLastAssetMsg,
        okText: strings.okCaps,
        cancelText: strings.cancelCaps,
        onOk() {
          self.setState({ removeCartLoading: true, iconClickedData: record });
          return newServiceRequestStore
            .srDeleteItemsFromCart(
              UniqueId,
              record.modelno,
              record.serialno,
              mode
            )
            .then(success => {
              self.setState(
                {
                  goToLandingPage: true,
                  removeCartLoading: false
                },
                () => self.setRequestedServices()
              );
            });
        },
        onCancel() {}
      });
    } else {
      this.setState({ tableLoading: true });
      return newServiceRequestStore
        .srDeleteItemsFromCart(UniqueId, record.modelno, record.serialno, mode)
        .then(() => {
          newServiceRequestStore
            .updateSritems(record, "delete")
            .then(success => {
              self.setState({ tableLoading: false });
              self.setRequestedServices();
            });
        });
    }
  };
  confirm = () => {
    this.props.history.push("/servicerequest");
  };

  bqModalShow = () => {
    this.setState({
      bqModalOpen: !this.state.bqModalOpen
    });
  };
  bqHandleModalClose = () => {
    this.setState({
      bqModalOpen: false
    });
  };
  removeAllCartItems = () => {
    Functions.RemoveAllCartItems().then(resp => {
      if (resp.data.success == true) {
        newServiceRequestStore.setCartItems(resp.data.cartItems);
        UIFunctions.Toast(strings.srAssetsRemoveAllSuccessMsg, "success");
        this.props.history.push("/servicerequest");
      } else {
        ("");
      }
    });
  };
  componentDidMount() {
    newServiceRequestStore.updateServieRequestStatus("step3");
    newServiceRequestStore.setProceedCheckout(true);
    this.props.form.setFieldsValue(newServiceRequestStore.NewReq_basepayload);
    this.setRequestedServices();
  }
  bqHandleSelect = value => {
    this.setState({ bqOptionStatus: value });
  };
  showImage = () => {
    newServiceRequestStore.setShowImage(!newServiceRequestStore.showImage);
  };
  onPaginationChange = pagination => {
    this.setState({ pagination });
  };
  onShowSizeChange = (current, pageSize) => {
    this.setState(({ pagination }) => {
      pagination.pageSize = pageSize;
      return { pagination };
    });
  };
  render() {
    const { goToLandingPage, pagination } = this.state;
    return goToLandingPage ? (
      <Redirect to="/servicerequest" />
    ) : (
      <React.Fragment>
        <div className="bq--page">
          <SrCreationStage
            currentSrStep={newServiceRequestStore.currentSrStep}
          />
          <Form onSubmit={this.handleFormData} className="bqForm">
            <div className="bq--form">
              <span className="toggleSwitchBqPage">Show Images</span>
              <Switch
                checkedChildren={strings.onCaps}
                unCheckedChildren={strings.offCaps}
                onClick={this.showImage}
                defaultChecked={newServiceRequestStore.showImage}
              />
              <Table
                style={{
                  maxHeight: "100%",
                  marginLeft: "6%",
                  marginRight: "4%",
                  marginTop: "1%"
                }}
                pagination={pagination}
                onChange={this.onPaginationChange}
                columns={this.columns(
                  newServiceRequestStore.showImage,
                  newServiceRequestStore.dropDownServices
                )}
                dataSource={
                  newServiceRequestStore.InfolineResponse.result.sritems
                }
                scroll={{ y: true }}
                loading={this.state.tableLoading}
              />
              <Row className="bq-bottom">
                <Col span={14} push={10} className="bq-btns">
                  <div className="bqCont--button">
                    <Popconfirm
                      title={strings.srAssetsRemoveAllWarningMsg}
                      okText={strings.yes}
                      cancelText={strings.no}
                      onConfirm={this.removeAllCartItems}
                    >
                      <span className="bqRemove-all">
                        <Button>
                          <Icon type="cross" theme="outlined" />
                          {strings.removeAll}
                        </Button>
                      </span>
                    </Popconfirm>
                    <div className="bqVr"> &nbsp; </div>
                    <Popconfirm
                      title={strings.srAssetsCancelRequest}
                      onConfirm={this.confirm}
                      okText={strings.yes}
                      cancelText={strings.no}
                    >
                      <Button className="bqCancel">
                        <Icon type="close" />
                        &nbsp;&nbsp;{strings.cancel}
                      </Button>
                    </Popconfirm>
                    &nbsp;&nbsp;
                    <Button className="bqCancel" onClick={this.handleBack}>
                      <Icon type="arrow-left" />
                      &nbsp;&nbsp;{strings.back}
                    </Button>
                    &nbsp;&nbsp;
                    <Button
                      className="bqContinue"
                      disabled={this.state.continueLoading ? true : false}
                      onClick={this.serviceConfirmation.bind(this)}
                    >
                      <Icon
                        type={
                          this.state.continueLoading
                            ? this.state.serviceTypeError
                              ? "arrow-right"
                              : "loading"
                            : "arrow-right"
                        }
                      />
                      {strings.continue}
                    </Button>
                  </div>
                </Col>
                <Col span={10} pull={14} className="bq-msg">
                  <span>
                    {strings.coverageMsgPart1} <br />
                    {strings.coverageMsgPart2}
                  </span>
                </Col>
              </Row>
            </div>
          </Form>
        </div>
      </React.Fragment>
    );
  }
}

const SRBudgetaryQuote = Form.create()(SRBudgetaryQuoteForm);
export default SRBudgetaryQuote;
