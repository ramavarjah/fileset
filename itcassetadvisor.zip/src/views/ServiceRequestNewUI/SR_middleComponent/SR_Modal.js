import React from "react";
import { Modal, Col, Row, Tooltip, Progress, Steps } from "antd";
import AssetCard from "src/views/Components/Cards/AssetCard";
import VerticalDivider from "../../../views/LoanPoolNewUI/components/dividers/VerticalDivider";
import "./styles.css";
import moment from "moment";
import strings from "../LocalizedText/strings";

const Step = Steps.Step;
const parseText = (text = "") =>
  text.length > 27 ? text.substring(0, 27) + "..." : text;

function Title({ request, requestedService }) {
  return (
    <span className="request-details-header">
      {strings.request}: &nbsp;
      <span className="model-modal-header">
        {request}
        <span className="vertical-small-divider" />
        <span className="inside-text">
          <Tooltip title={requestedService}>
            {parseText(requestedService)}
          </Tooltip>
        </span>
      </span>
    </span>
  );
}
const getStatusText = status => {
  switch (status) {
    case "finish":
      return strings.statusFinish;
    case "process":
      return strings.statusProcess;
    case "wait":
      return strings.statusWait;
    case "Delayed":
      return strings.statusDelayed;
  }
};
const customDot = (dot, { status }) => (
  <Tooltip
    title={
      <span>
        {strings.statusTitle} :{" "}
        <span
          className={
            status == "Delayed" ? "steps-status-delayed" : "step-tooltip-status"
          }
        >
          {getStatusText(status)}{" "}
        </span>
      </span>
    }
  >
    <span>{dot}</span>
  </Tooltip>
);
const CustomSteps = ({ percent, stepStatus }) => (
  <div>
    <div
      style={{
        width: 272,
        margin: "35px auto",
        color: "#108ee9"
      }}
    >
      <Progress percent={percent} strokeWidth={12} className="test" />
    </div>
    <div
      className="request-approval-stage-steps"
      style={{
        margin: "35px auto"
      }}
    >
      <Steps progressDot={customDot}>
        <Step
          title={strings.requestCreated}
          status={stepStatus.requestCreated}
          data-status={stepStatus.requestCreated}
        />
        <Step
          title={strings.requestConfirmed}
          status={stepStatus.requestConfirmed}
          data-status={stepStatus.requestConfirmed}
        />
        <Step
          title={strings.assetReceived}
          status={stepStatus.assetReceived}
          data-status={stepStatus.assetReceived}
        />
        <Step
          title={strings.serviceInProgress}
          status={stepStatus.serviceInProgress}
          data-status={stepStatus.serviceInProgress}
        />
        <Step
          title={strings.serviceCompleted}
          status={stepStatus.serviceCompleted}
          data-status={stepStatus.serviceCompleted}
        />
        <Step
          title={strings.shippedReturned}
          status={stepStatus.shippedReturned}
          data-status={stepStatus.shippedReturned}
        />
      </Steps>
    </div>
  </div>
);
// let delaydata = newServiceRequestStore.delaydata
export default class SR_Modal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      srModelVisible: true,
      loading: false
    };
  }
  getStatus = ({ requestStatus: percent, serviceStatus }) => {
    if (percent == "0") {
      return {
        requestCreated: "finish",
        requestConfirmed: "process",
        assetReceived: "wait",
        serviceInProgress: "wait",
        serviceCompleted: "wait",
        shippedReturned: "wait"
      };
    } else if (percent == "20") {
      return {
        requestCreated: "finish",
        requestConfirmed: "finish",
        assetReceived: "process",
        serviceInProgress: "wait",
        serviceCompleted: "wait",
        shippedReturned: "wait"
      };
    } else if (percent == "40") {
      return {
        requestCreated: "finish",
        requestConfirmed: "finish",
        assetReceived: "finish",
        serviceInProgress:
          serviceStatus.indexOf("Delay") >= 0 ? "Delayed" : "process",
        serviceCompleted: "wait",
        shippedReturned: "wait"
      };
    } else if (percent == "60") {
      return {
        requestCreated: "finish",
        requestConfirmed: "finish",
        assetReceived: "finish",
        serviceInProgress:
          serviceStatus.indexOf("Delay") >= 0 ? "Delayed" : "finish",
        serviceCompleted: "process",
        shippedReturned: "wait"
      };
    } else if (percent == "80") {
      return {
        requestCreated: "finish",
        requestConfirmed: "finish",
        assetReceived: "finish",
        serviceInProgress: "finish",
        serviceCompleted: "finish",
        shippedReturned: "process"
      };
    } else if (percent == "100") {
      return {
        requestCreated: "finish",
        requestConfirmed: "finish",
        assetReceived: "finish",
        serviceInProgress: "finish",
        serviceCompleted: "finish",
        shippedReturned: "finish"
      };
    } else {
      return "";
    }
  };
  render() {
    const ModalData = this.props.ModalData;
    const stepStatus = this.getStatus(ModalData);
    return (
      <Modal
        className="upperGridModal"
        title={
          <Title
            request={ModalData.serviceOrderId}
            requestedService={ModalData.RequestedService}
          />
        }
        visible={this.state.srModelVisible}
        onOk={this.props.lgHandleOk}
        onCancel={this.props.handleCancel}
        footer={null}
        centered
        style={this.props.modalTop}
        width="927px"
      >
        <CustomSteps
          percent={ModalData.requestStatus}
          stepStatus={stepStatus}
        />
        <hr style={{ borderColor: "#C3C3C3", marginBottom: 25 }} />
        <Row gutter={16}>
          <Col span={9}>
            <div
              className="request-modal-asset-details"
              style={this.props.imgStyle}
            >
              <AssetCard
                modelNo={ModalData.modelNo}
                dummyUrl="/img/no-asset-image.png"
                width="150px"
                height="150px"
                hasExternalRequest={false}
              />
            </div>
          </Col>
          <Col span={1}>
            <VerticalDivider height="860px" />
          </Col>
          <Col span={10}>
            <div className="custom">
              <p id="srModal">
                {strings.modelNumber}: {ModalData.modelNo}
              </p>
              <p id="para">
                <b>{strings.serviceRequestID}:</b> {ModalData.ServiceRequestID}
              </p>
              <p id="para">
                <b>{strings.serviceOrderID}:</b> {ModalData.serviceOrderId}
              </p>
              <p id="para">
                <b>{strings.serviceStatus}:</b> {ModalData.serviceStatus}
              </p>
              <p id="para">
                <b>{strings.serviceEventStatus}:</b> {ModalData.eventStatus}
              </p>
              <p id="para">
                <b>{strings.submittedBy}:</b> {ModalData.SubmittedBy}
              </p>
              <hr style={{ borderColor: "#C3C3C3", marginBottom: 25 }} />
              <p id="para">
                <b>{strings.equipmentNumber}:</b> {ModalData.equipmentNo}
              </p>
              <p id="para">
                <b>{strings.manufacturer}:</b> {ModalData.manufacturer}
              </p>
              <p id="para">
                <b>{strings.serialNumber}:</b> {ModalData.serialNo}
              </p>
              <p id="para">
                <b>{strings.description}:</b> {ModalData.description}
              </p>

              <p id="para">
                <b>{strings.organization}:</b> {ModalData.organization}
              </p>
              <p id="para">
                <b>{strings.location}:</b> {ModalData.location}
              </p>
              <p id="para">
                <b>{strings.Coordinator}:</b> {ModalData.coordinator}
              </p>
              <p id="para">
                <b>{strings.User}:</b> {ModalData.user}
              </p>
              <hr style={{ borderColor: "#C3C3C3", marginBottom: 25 }} />
              <p id="para">
                <b>{strings.calibrationType}:</b> {ModalData.CalibrationType}
              </p>
              <p id="para">
                <b>{strings.shipDate}:</b>{" "}
                {moment(ModalData.shipDate).format("YYYY-MM-DD") <= "1970-01-01"
                  ? ""
                  : moment(ModalData.shipDate).format("YYYY-MM-DD")}
              </p>
              <p id="para">
                <b>{strings.serviceOrderUpdate}:</b>{" "}
                {moment(ModalData.serviceOrderUpdate).format("YYYY-MM-DD") <=
                "1970-01-01"
                  ? ""
                  : moment(ModalData.serviceOrderUpdate).format("YYYY-MM-DD")}
              </p>
              <p id="para">
                <b>{strings.srcomments}:</b> {ModalData.comments}
              </p>
              <p id="para">
                <b>{strings.calCertdocument}:</b>{" "}
                {ModalData.DocumentURL ? (
                  <a href={ModalData.DocumentURL}>Download</a>
                ) : (
                  ""
                )}
              </p>
              <hr style={{ borderColor: "#C3C3C3", marginBottom: 25 }} />
              <p id="para">
                <b>{strings.quoteAmount}:</b> {ModalData.quoteAmount}
              </p>
              <p id="para">
                <b>{strings.quoteDate}:</b>{" "}
                {moment(ModalData.quoteDate).format("YYYY-MM-DD") <=
                "1970-01-01"
                  ? ""
                  : moment(ModalData.quoteDate).format("YYYY-MM-DD")}
              </p>
              <p id="para">
                <b>{strings.pickUpDate}:</b>{" "}
                {moment(ModalData.pickUpDate).format("YYYY-MM-DD") <=
                "1970-01-01"
                  ? ""
                  : moment(ModalData.pickUpDate).format("YYYY-MM-DD")}
              </p>
              <p id="para">
                <b>{strings.receivedDate}:</b>{" "}
                {moment(ModalData.receivedDate).format("YYYY-MM-DD") <=
                "1970-01-01"
                  ? ""
                  : moment(ModalData.receivedDate).format("YYYY-MM-DD")}
              </p>
              <p id="para">
                <b>{strings.receivedCondition}:</b>{" "}
                {ModalData.receivedCondition}
              </p>
              <hr style={{ borderColor: "#C3C3C3", marginBottom: 25 }} />
              <p id="para">
                <b>{strings.serviceDate}:</b>{" "}
                {moment(ModalData.serviceDate).format("YYYY-MM-DD") <=
                "1970-01-01"
                  ? ""
                  : moment(ModalData.serviceDate).format("YYYY-MM-DD")}
              </p>
              <p id="para">
                <b>{strings.servicePerformed}:</b> {ModalData.servicePerformed}
              </p>
              <p id="para">
                <b>{strings.returnedCondition}:</b>{" "}
                {ModalData.returnedCondition}
              </p>
              <p id="para">
                <b>{strings.deliveryDate}:</b>{" "}
                {moment(ModalData.deliveryDate).format("YYYY-MM-DD") <=
                "1970-01-01"
                  ? ""
                  : moment(ModalData.deliveryDate).format("YYYY-MM-DD")}
              </p>
              <p id="para">
                <b>{strings.closedDate}:</b>{" "}
                {moment(ModalData.closedDate).format("YYYY-MM-DD") <=
                "1970-01-01"
                  ? ""
                  : moment(ModalData.closedDate).format("YYYY-MM-DD")}
              </p>
            </div>
          </Col>
        </Row>
      </Modal>
    );
  }
}
