import React from "react";
import SR_Comp from "./SR_Component";
import SR_Modal from "./SR_Modal";
import ArrowIcon from "./ArrowIcon";
import { Progress, Tooltip } from "antd";
import "./styles.scss";
import { observer } from "mobx-react";
import moment from "moment";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import strings from "../LocalizedText/strings";

const options = [
  { value: "open", displayName: strings.openRequest },
  { value: "past7", displayName: strings.past7 },
  { value: "past30", displayName: strings.past30 },
  { value: "past90", displayName: strings.past90 }
];
const parseText = (text = "") =>
  text.length > 16 ? text.substring(0, 17) + "..." : text;
const isDelayed = isDelayed => isDelayed.indexOf("Delay") >= 0
@observer
class SR_MiddleGrid extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      modalOpen: false,
      lgLoading: false,
      ModalData: {}
    };
  }
  ServiceRequestColumns = () => [
    {
      title: "",
      dataIndex: "",
      width: "1%"
    },
    {
      title: strings.serviceOrderId,
      dataIndex: "serviceOrderId",
      width: "15%",
      render: (text, record) => (
        <div style={{ marginLeft: -6 }}>
          <Tooltip title={record.serviceOrderId}>
            <a href="javascript:;" onClick={() => this.modalShow(record)}>
              {parseText(text)}
            </a>
          </Tooltip>
        </div>
      )
    },
    {
      title: strings.modelNumberCaps,
      dataIndex: "modelNo",
      width: "15%",
      render: (text, record) => (
        <div style={{ marginLeft: -2 }}>
          <Tooltip title={record.modelNo}>{text}</Tooltip>
        </div>
      )
    },
    {
      title: strings.serviceType,
      dataIndex: "RequestedService",
      width: "15%",
      render: (text, record) => (
        <div style={{ marginLeft: -2 }}>
          <Tooltip title={record.RequestedService}>{parseText(text)}</Tooltip>
        </div>
      )
    },
    {
      title: strings.manufacturerCaps,
      dataIndex: "manufacturer",
      width: "15%",
      render: (text, record) => (
        <div style={{ marginLeft: 1 }}>
          <Tooltip title={record.manufacturer}>{parseText(text)}</Tooltip>
        </div>
      )
    },

    {
      title: strings.status,
      dataIndex: "requestStatus",
      width: "18%",
      render: (text, record) => {
       
        let delayed = isDelayed(record.serviceStatus)
        if (text == "0") {
          return (
            <Tooltip title={strings.requestCreated}>
              <span className={delayed&&"delayed"} style={{ width: 150, color: "#3385FF" }}>
                <Progress percent={text} size="small" />
              </span>
            </Tooltip>
          );
        } else if (text == "20") {
          return (
            <Tooltip title={strings.requestConfirmed}>
              <span className={delayed&&"delayed"} style={{ width: 150, color: "#3385FF" }}>
                <Progress percent={text} size="small" />
              </span>
            </Tooltip>
          );
        } else if (text == "40") {
          return (
            <Tooltip title={delayed ? (<span> {strings.assetReceived} {" "}{"-"} {""}<span style={{ color: "red" }} >Delayed</span></span>) : strings.assetReceived}>
              <span className={delayed&&"delayed"} style={{ width: 150, color: "#3385FF" }}>
                <Progress percent={text} size="small" />
              </span>
            </Tooltip>
          );
        } else if (text == "60") {
          return (
            <Tooltip title={delayed ? (<span> {strings.serviceInProgress} {" "}{"-"} {""}<span style={{ color: "red" }} >Delayed</span></span>) : strings.serviceInProgress}>
              <span className={delayed&&"delayed"} style={{ width: 150, color: "#3385FF" }}>
                <Progress percent={text} size="small" />
              </span>
            </Tooltip>
          );
        } else if (text == "80") {
          return (
            <Tooltip title={delayed ? (<span> {strings.serviceCompleted} {" "}{"-"} {""}<span style={{ color: "red" }} >Delayed</span></span>) : strings.serviceCompleted}>
              <span className={delayed&&"delayed"} style={{ width: 150, color: "#3385FF" }}>
                <Progress percent={text} size="small" />
              </span>
            </Tooltip>
          );
        } else if (text == "100") {
          return (
            <Tooltip title={ delayed ? (<span> {strings.shippedReturned} {" "}{"-"} {""}<span style={{ color: "red" }} >Delayed</span></span>) : strings.shippedReturned}>
              <span className={delayed&&"delayed"} style={{ width: 150, color: "#3385FF" }}>
                <Progress percent={text} size="small" />
              </span>
            </Tooltip>
          );
        } else {
          return (
            <span className={delayed&&"delayed"} style={{ width: 150, color: "#3385FF" }}>
              <Progress percent={text} size="small" />
            </span>
          );
        }
      }
    },
    {
      title: strings.calCertDocument,
      dataIndex: "DocumentURL",
      width: "15%",
      render: (text, record) => {
        if(record.DocumentURL){
          return(
            <div>
            <Tooltip title="Download Cal Cert">
             <a href={record.DocumentURL}>Download</a>
            </Tooltip>
          </div>
          )
        }
      }
    },
    {
      dataIndex: "",
      width: "3%",
      title: <ArrowIcon />
    }
  ];
  lgHandleOk = () => {
    this.setState({ lgLoading: true });
    setTimeout(() => {
      this.setState({
        lgLoading: false,
        sddModalShow: !this.state.sddModalShow
      });
    }, 3000);
  };
  modalShow = record => {
    this.setState({
      modalOpen: !this.state.modalOpen,
      ModalData: record
    });
  };
  handleSelect = value => {
    newServiceRequestStore.middleGridPagination.pageNumber = 1;
    newServiceRequestStore.middleGridPagination.current = 1;
    newServiceRequestStore.middleGridPagination.pageSize = 10;
    newServiceRequestStore.SrOptionStatus(value);
    newServiceRequestStore.fetchSRequests(
      value,
      newServiceRequestStore.middleGridPagination.pageSize,
      newServiceRequestStore.middleGridPagination.pageNumber,
      moment(),
      newServiceRequestStore.localSearchValue
    );
  };
  componentDidMount() {
    newServiceRequestStore.fetchSRequests(
      newServiceRequestStore.srOptionStatus,
      newServiceRequestStore.middleGridPagination.pageSize,
      newServiceRequestStore.middleGridPagination.pageNumber,
      moment(),
      newServiceRequestStore.localSearchValue
    );
  }
  componentWillUnmount() {
    newServiceRequestStore.middleGridPagination["pageSize"] = 10;
    newServiceRequestStore.middleGridPagination["pageNumber"] = 1;
  }
  handleTableChange = pagination => {
    const pager = { ...newServiceRequestStore.middleGridPagination };
    pager.pageNumber = pagination.current;
    pager.current = pagination.current;
    newServiceRequestStore.middleGridPagination = pager;
    newServiceRequestStore.fetchSRequests(
      newServiceRequestStore.srOptionStatus,
      newServiceRequestStore.middleGridPagination.pageSize,
      newServiceRequestStore.middleGridPagination.pageNumber,
      moment(),
      newServiceRequestStore.localSearchValue
    );
  };
  handleModalClose = () => {
    this.setState({
      modalOpen: false
    });
  };

  render() {
    const stylesheets = {
      srCompStyle: {
        position: "relative",
        top: "0px",
        left: "-30px",
        fontSize: "13px",
        fontFamily: "Open Sans",
        letterSpacing: "0.47px",
        lineHeight: "18px",
        color: "#979797",
        margin: 15
      },
      srCompStyleSelect: {
        position: "absolute",
        top: "-4px",
        left: "12%",
        border: "1px solid #E5E5E5",
        borderRadius: "3px",
        backgroundColor: " #FFFFFF",
        width: "176px",
        height: "27px",
        color: "#979797"
      },
      tableStyle: {
        height:
          newServiceRequestStore.SRMode == "SR_Max"
            ? window.innerHeight - 130
            : "100%",
        fontSize: 13,
        fontWeight: "500",
        borderColor: "#f2f2f2"
      },
      modalTop: {
        top: (window.innerHeight - 650),
        padding: 0,
      
      },
      imgStyle: {
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        height: 412
      }
    };
    const headername = strings.serviceRequest;
    const srCompDefaultValue = strings.openRequest;
    return newServiceRequestStore.SRMode == "HIDE" ? (
      ""
    ) : (
        <div className={"sr--middle-grid"}>
          <SR_Comp
            tableStyle={stylesheets.tableStyle}
            columnsprops={this.ServiceRequestColumns()}
            headername={headername}
            handleSelectChange={this.handleSelect}
            srGridMode={this.props.mode}
            handleSelect={this.handleSelect}
            optionStatus={newServiceRequestStore.srOptionStatus}
            options={options}
            pagination={newServiceRequestStore.middleGridPagination}
            onChange={this.handleTableChange}
            serviceRequestData={newServiceRequestStore.sRequests}
            srGridLoading={newServiceRequestStore.srGridLoading}
            style1={stylesheets.srCompStyle}
            style2={stylesheets.srCompStyleSelect}
            defaultValue={srCompDefaultValue}
            figCaption={strings.figCaption}
          />
          {this.state.modalOpen ? (
            <SR_Modal
              ModalData={this.state.ModalData}
              handleCancel={this.handleModalClose}
              lgLoading={this.state.loading}
              lgHandleOk={this.lgHandleOk}
              modalTop={stylesheets.modalTop}
              imgStyle={stylesheets.imgStyle}
            />
          ) : (
              " "
            )}
        </div>
      );
  }
}

export default SR_MiddleGrid;
