import React from "react";
import { Icon } from "antd";
import newServiceRequestStore from "src/stores/newServiceRequestStore";

export default class ArrowIcon extends React.Component {
  constructor(props) {
    super(props);
  }
  onMenuClicked() {
    if (newServiceRequestStore.SRMode == "SR_Max") {
      newServiceRequestStore.setSRMode("SR_Min");
      newServiceRequestStore.setSRDueDatesMode("SR_DD_Min");
    } else {
      newServiceRequestStore.setSRMode("SR_Max");
      newServiceRequestStore.setSRDueDatesMode("HIDE");
    }
  }
  render() {
    return (
      <a onClick={this.onMenuClicked.bind(this)}>
        <Icon
          type={
            newServiceRequestStore.SRMode == "SR_Max" ? "shrink" : "arrows-alt"
          }
          style={{ color: "#646C72" }}
          theme="outlined"
          onClick={this.props.handleClick}
        />
      </a>
    );
  }
}
