import React from "react";
import { Table, Select } from "antd";
const Option = Select.Option;
import noDataImage from "../../../../public/img/no-data-placeholder_standard.png";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";

export default class SR_Comp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isToogle: true
    };
  }
  showModal = () => {
    this.setState({
      visible: true
    });
  };
  render() {
    return (
      <React.Fragment>
        <div style={{ margin: 15 }}>
          <span style={this.props.style1}>{this.props.headername}</span>
          <Select
            dropdownClassName="serviceRequestGridDropdown"
            style={this.props.style2}
            defaultValue={this.props.defaultValue}
            onChange={e => this.props.handleSelect(e)}
            value={this.props.optionStatus}
          >
            {this.props.options.map((i, index) => (
              <Option key={index} value={i.value}>
                {i.displayName}
              </Option>
            ))}
          </Select>
        </div>
        <div style={this.props.tableStyle}>
          <Table
            columns={this.props.columnsprops}
            dataSource={this.props.serviceRequestData}
            pagination={this.props.pagination}
            scroll={{ y: true }}
            onChange={this.props.onChange}
            loading={this.props.srGridLoading}
            locale={{
              emptyText: (
                <figure
                  className={
                    newServiceRequestStore.SRMode == "SR_Max"
                      ? "srImgMax"
                      : "srImgMin"
                  }
                >
                  <img
                    src={noDataImage}
                    height="150px"
                    width="180px"
                    align="middle"
                  />
                  <figcaption
                    className={
                      newServiceRequestStore.SRMode == "SR_Max"
                        ? "srFigMax"
                        : "srFigMin"
                    }
                  >
                    {this.props.figCaption}
                  </figcaption>
                </figure>
              )
            }}
          />
        </div>
      </React.Fragment>
    );
  }
}
