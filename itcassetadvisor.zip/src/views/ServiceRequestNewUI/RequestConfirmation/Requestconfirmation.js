import React from "react";
import { Tooltip, Table, Row, Col, Icon, Button, Switch } from "antd";
import AssetCard from "src/views/Components/Cards/AssetCard";
import "./styles.css";
import "./styles.scss";
import SrCreationStage from "../SelectedAssetsStage/SrCreationStage";
import { Link } from "react-router-dom";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import { observer } from "mobx-react";
import moment from "moment";
import _ from "lodash";

let resp = {};
function printDiv(divName) {
  var printContents = document.getElementById(divName).innerHTML;
  var root = document.getElementById("root");
  root.style.display = "none";
  var print = document.getElementById("printcontent");
  print.innerHTML = printContents;
  print.style.display = "";
  window.print();
  print.style.display = "none";
  print.innerHTML = "";
  root.style.display = "";
}

import strings from "../LocalizedText/strings";

const parseText = (text = "") =>
  text.length > 16 ? text.substring(0, 17) + "..." : text;

@observer
class Requestconfirmation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        showSizeChanger: true,
        onShowSizeChange: this.onShowSizeChange,
        current: 1,
        pageNumber: 1,
        defaultPageNumber: 1,
        pageSize: 10,
        defaultPageSize: 10
      }
    };
  }

  columns = isImageEnabled => {
    let ret = [];
    if (isImageEnabled)
      ret.push({
        title: "",
        width: isImageEnabled ? "14%" : 350,
        dataIndex: "",
        render: record => (
          <AssetCard
            modelNo={record.modelno}
            dummyUrl="/img/no-asset-image.png"
            width="150px"
            height="150px"
            hasExternalRequest={false}
          />
        )
      });
    return [
      ...ret,
      {
        title: strings.serialNoCaps,
        dataIndex: "serialno",
        width: isImageEnabled ? "12%" : "14%",
        render: (text, record) => (
          <Tooltip title={record.serialno}>{text}</Tooltip>
        )
      },
      {
        title: strings.modelNoCaps,
        dataIndex: "modelno",
        width: isImageEnabled ? "12%" : "14%",
        render: (text, record) => (
          <div style={{ marginLeft: 2 }}>
            <Tooltip title={record.modelno}>{text}</Tooltip>
          </div>
        )
      },
      {
        title: strings.manufacturerCaps,
        dataIndex: "manufacturer",
        width: isImageEnabled ? "11%" : "14%",
        render: (text, record) => (
          <div style={{ marginLeft: 4 }}>
            <Tooltip title={record.manufacturer}>{parseText(text)}</Tooltip>
          </div>
        )
      },
      {
        title: strings.coverageCaps,
        dataIndex: "quoteditems",
        width: isImageEnabled ? "13%" : "15%",
        key: "coverage",
        render: record => (
          <div style={{ marginLeft: 6 }}>
            <Tooltip title={record[0].coverage}>
              {parseText(record[0].coverage)}
            </Tooltip>
          </div>
        )
      },
      {
        title: strings.requestedServiceCaps,
        dataIndex: "requestedService",
        width: isImageEnabled ? "17%" : "17%",
        className: "confirmation-requested-service",
        render: (text, record) => (
          <div style={{ marginLeft: 8 }}>
            <Tooltip title={record.requestedservice}>
              {parseText(record.requestedservice)}
            </Tooltip>
          </div>
        )
      },
      {
        title: strings.priceCaps,
        dataIndex: "quoteditems",
        key: "price",
        render: record => (
          <div style={{ marginLeft: 10, color: "#3ABF72" }}>
            <Tooltip title={record[0].currency + " " + record[0].price}>
              {record[0].currency + " " + record[0].price}
            </Tooltip>
          </div>
        )
      }
    ];
  };

  printCloumn = () => [
    {
      title: "Manufacturer",
      width: "12%",
      dataIndex: "manufacturer"
    },
    {
      title: "Model Number",
      width: "13%",
      dataIndex: "modelno"
    },
    {
      title: "Serial Number",
      width: "12%",
      dataIndex: "serialno",
      render: (text, record) => (
        <div style={{ whiteSpace: "normal" }}>{record.serialno}</div>
      )
    },
    {
      title: "Asset Number",
      width: "12%",
      dataIndex: "custassetno"
    },
    {
      title: "Requested Service",
      dataIndex: "requestedService",
      width: "15%",
      className: "confirmation-requested-service",
      render: (text, record) => (
        <div style={{ whiteSpace: "normal" }}>{record.requestedservice}</div>
      )
    },
    {
      title: "Preferred Date",
      width: "11%",
      dataIndex: "preferreddate",
      key: "coverage",
      render: (text, record) => <div>{record.preferreddate}</div>
    },
    {
      title: "Coverage",
      width: "11%",
      dataIndex: "quoteditems",
      key: "coverage",
      render: record => <div>{record[0].coverage}</div>
    },
    {
      title: "Purchase Order Number",
      width: "13%",
      dataIndex: "purchaseorderno",
      render: (text, record) => (
        <div style={{ whiteSpace: "normal" }}>{record.purchaseorderno}</div>
      )
    }
  ];

  componentWillUnmount() {
    newServiceRequestStore.updateServiceRequestConfirmation(false);
    newServiceRequestStore.setShowImage(false);
  }
  showImage = () => {
    newServiceRequestStore.setShowImage(!newServiceRequestStore.showImage);
  };

  componentDidMount() {
    newServiceRequestStore.updateServieRequestStatus("step4");
    newServiceRequestStore.setProceedCheckout(true);
    newServiceRequestStore.updateServiceRequestConfirmation(true);
  }
  onPaginationChange = pagination => {
    this.setState({ pagination });
  };
  onShowSizeChange = (current, pageSize) => {
    this.setState(({ pagination }) => {
      pagination.pageSize = pageSize;
      return { pagination };
    });
  };
  render() {
    if (!_.isEmpty(newServiceRequestStore.cartItems)) {
      resp = newServiceRequestStore.InfolineResponse.result.sritems;
      let keys = Object.keys(newServiceRequestStore.cartItems);
      resp.map(
        (e, i) => (
          (e.purchaseorderno =
            newServiceRequestStore.cartItems[keys[i]][0].orderNumber),
          (e.preferreddate = newServiceRequestStore.cartItems[keys[i]][0]
            .preferredDate
            ? newServiceRequestStore.cartItems[keys[i]][0].preferredDate.format(
                "YYYY-MM-DD"
              )
            : "")
        )
      );
    }
    const { pagination } = this.state;
    return (
      <div className="req-comp">
        <SrCreationStage currentSrStep={newServiceRequestStore.currentSrStep} />
        <div className="tablecss">
          <span className="toggleSwitchBqPage">Show Images</span>
          <Switch
            checkedChildren={strings.onCaps}
            unCheckedChildren={strings.offCaps}
            onClick={this.showImage}
            defaultChecked={newServiceRequestStore.showImage}
          />
          <Table
            style={{
              maxHeight: 200,
              marginLeft: 100,
              marginRight: 50,
              marginTop: 80
            }}
            scroll={{ y: true }}
            pagination={pagination}
            onChange={this.onPaginationChange}
            columns={this.columns(newServiceRequestStore.showImage)}
            dataSource={newServiceRequestStore.InfolineResponse.result.sritems}
          />
        </div>
        <div
          className="gutter-example"
          style={{
            position: "relative",
            left: "103px",
            height: "63vh"
          }}
        >
          <Row gutter={16}>
            <Col span={4}>
              <div className="iconCss">
                <Icon
                  type="check-circle-o"
                  style={{
                    fontSize: "129px",
                    position: "relative",
                    top: "86px",
                    left: "171px",
                    color: "#42DA81"
                  }}
                />
                 </div>
                </Col> 
                <Col span={4}>
                <span className="thank-you">
                  {strings.requestConfirmationPart1}
                </span>
                <Button className="btTanks">
                  <Link to="/servicerequest">
                    <Icon type="arrow-right" />
                    &nbsp; {strings.backToDashboard}
                  </Link>
                </Button>            
            </Col>
            <Col span={1}>
              <div className="rc-horizontal" />
              </Col>
              <Col className="printButoon" span={2}>            
                <Button onClick={() => printDiv("printTemplate")}>
                  <Icon type="printer" /> {strings.print}
                </Button>             
            </Col>
            <Col className="thankyoucss" span={12}>             
                <span className="you-have-successfull">
                  {strings.requestSubmittedMessage}
                </span>             
            </Col>
          </Row>
        </div>
        <div id="printTemplate" style={{ display: "none" }}>
          <h3 className="printHeader"> {strings.ServiceRequest} </h3>
          <br />
          <h4> {strings.CompanyInformation} </h4>

          <Row>
            <Col span={9}>
              <span>
                <b>Company Name:</b>
              </span>
              <br />
              <span>
                <b>First Name:</b>
              </span>
              <br />
              <span>
                <b>Last Name:</b>
              </span>
              <br />
              <span>
                <b>Phone Number:</b>
              </span>
              <br />
              <span>
                <b>Fax Number:</b>
              </span>
              <br />
              <span>
                <b>Email Address:</b>
              </span>
              <br />
            </Col>
            <Col span={12}>
              <span>
                {
                  newServiceRequestStore.InfolineResponse.result
                    .biladdresscompanyname
                }
              </span>
              <br />
              <span>
                {newServiceRequestStore.InfolineResponse.result.reqfirstname}
              </span>
              <br />
              <span>
                {newServiceRequestStore.InfolineResponse.result.reqlastname}
              </span>
              <br />
              <span>
                {newServiceRequestStore.InfolineResponse.result.reqphone}
              </span>
              <br />
              <span>
                {newServiceRequestStore.InfolineResponse.result.reqfax}
              </span>
              <br />
              <span>
                {newServiceRequestStore.InfolineResponse.result.reqemail}
              </span>
              <br />
            </Col>
          </Row>
          <br />
          <br />
          <h3>Service request details</h3>
          <Row>
            <Col span={9}>
              <span>
                <b>Submit Date:</b>
              </span>
            </Col>
            <Col span={12}>
              <span>{moment().format("YYYY-MM-DD")}</span>
            </Col>
          </Row>
          <div>
            <Table
              style={{
                wordBreak: "break-all",
                maxHeight: 200,
                marginLeft: -8,
                marginRight: -16,
                marginTop: 15
              }}
              pagination={false}
              columns={this.printCloumn()}
              dataSource={resp}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default Requestconfirmation;
