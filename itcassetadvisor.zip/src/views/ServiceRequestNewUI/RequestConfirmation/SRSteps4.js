import React from "react";
import { Steps } from "antd";

const Step = Steps.Step;
// const getStatusText = status => {
//   switch (status) {
//     case "finish":
//       return "Finished";
//     case "wait":
//       return "Yet To Start";
//     case "process":
//       return "In-Progress";
//   }
// };
const customDot = dot => <span>{dot}</span>;
const CustomSteps = () => (
  <div
    className="request-approval-stage-steps"
    style={{
      margin: "35px auto"
    }}
  >
    <Steps progressDot={customDot}>
      <Step title="Selected Assets" status="finish" data-status="finish" />
      <Step title="Contact & Shipping" status="finish" data-status="finish" />
      <Step title="Budgetary Quote" status="finish" data-status="finish" />
      <Step title="Confirmation" status="finish" data-status="finish" />
    </Steps>
  </div>
);

export default class SRSteps4 extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return <CustomSteps />;
  }
}
