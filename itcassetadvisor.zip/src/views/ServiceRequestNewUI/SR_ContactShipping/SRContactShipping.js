import React from "react";
import {
  Row,
  Col,
  Form,
  Radio,
  Input,
  Button,
  Icon,
  Popconfirm,
  Select,
  Tooltip
} from "antd";
import "./style.scss";
import "antd/dist/antd.css";
import strings from "../LocalizedText/strings";
import mobx from "mobx";
import { createBrowserHistory } from "history";
import UIFunctions from "../../../helpers/UIFunctions";
import SrCreationStage from "../SelectedAssetsStage/SrCreationStage";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import userStore from "../../../stores/userStore";
import { observer } from "mobx-react";

function isEmpty(userName) {
  if (!userName) return true;
  if (!userName.replace(/\s/g, "")) return true;
  return false;
}
function invalidUserName(userName) {
  var mailFormat = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
  if (mailFormat.test(userName)) return false;
  else return true;
}
const parseText = (text = "") =>
  text.length > 27 ? text.substring(0, 28) + "..." : text;
const Option = Select.Option;
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const formItemLayout = {
  labelCol: { span: 15 },
  wrapperCol: { span: 10 }
};
const formItem = {
  labelCol: { span: 6 },
  wrapperCol: { span: 12 }
};
const formItemLayout1 = {
  labelCol: { span: 15 },
  wrapperCol: { span: 10 }
};
const radioItemLayout = {
  wrapperCol: { span: 24 },
  labelCol: { span: 4 }
};
const radioStyle = {
  display: "block",
  height: "30px",
  lineHeight: "30px"
};
const history = createBrowserHistory();
const getCountryName = (countryCodes, countryCode) => {
  let country = countryCodes.find(i => i.CountryCode == countryCode);
  return country ? country.Country : "Invalid Country";
};

@observer
class SRContactForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      confirmLoading: false
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  confirm = () => {
    this.props.history.push("/servicerequest");
  };
  resize() {
    let heightOutput = window.innerHeight - 500;
    let heightOutputInfo = window.innerHeight - 310;
    newServiceRequestStore.updateDynamicContactDetails(heightOutput);
    newServiceRequestStore.updateDynamicInfoDetails(heightOutputInfo);
  }
  getRequiredUserDetails() {
    var details = {
      reqlastname: userStore.userDetails.lastName,
      reqfirstname: userStore.userDetails.firstName,
      reqemail: userStore.userDetails.infolineUserName,
      reqphone: userStore.userDetails.phoneNo,
      reqline1: userStore.userDetails.AddressLine1,
      reqcompanyname: userStore.userDetails.Organization,
      reqcity: userStore.userDetails.City,
      reqpostalcode: "11253", //contactAddress[2],
      reqstate: userStore.userDetails.State,
      reqcountry: "US", //contactAddress[5],   userStore.userDetails.country,

      biladdresscontact:
        userStore.userDetails.lastName + userStore.userDetails.firstName,
      biladdressphone: userStore.userDetails.phoneNo,
      biladdresscompanyname: userStore.userDetails.Organization,
      biladdressline1: userStore.userDetails.AddressLine1,
      biladdressline2: userStore.userDetails.AddressLine2,
      biladdressline3: userStore.userDetails.AddressLine3,

      biladdresscity: userStore.userDetails.City,
      biladdresspostalcode: "11253", //contactAddress[2],
      biladdressstate: "",
      biladdresscountry: "US", //contactAddress[5],
      biladdressvatid: ""
    };

    return details;
  }
  handleBack = e => {
    e.preventDefault();
    return this.props.form.validateFields((err, values) => {
      var basepayload = mobx.toJS(newServiceRequestStore.NewReq_basepayload);
      var payload = Object.assign(
        basepayload,
        values,
        this.getRequiredUserDetails()
      );
      newServiceRequestStore.setNewReq_basepayload(payload);
      history.go(-1);
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      let myKeysightUserName = userStore.baseUserDetails.infolineUserName;
      if (isEmpty(myKeysightUserName) || invalidUserName(myKeysightUserName)) {
        err = true;
        UIFunctions.Toast(strings.invalidUserNameErrorMessage, "error");
      }
      if (!err) {
        this.setState({
          confirmLoading: true
        });
        setTimeout(() => {
          if (userStore.userDetails.infolineUserName) {
            var basepayload = mobx.toJS(
              newServiceRequestStore.NewReq_basepayload
            );
            var payload = Object.assign(
              basepayload,
              values,
              this.getRequiredUserDetails()
            );
            payload.sritems = newServiceRequestStore.parseSRItems();
            let error = false;
            payload.sritems.forEach(function(key) {
              if (key.calcycle < 0) {
                error = true;
              }
            });
            if (!error) {
              newServiceRequestStore.setNewReq_basepayload(payload);
              newServiceRequestStore
                .getShippingDetails(payload)
                .then(result => {
                  if (
                    result.error == "501 Err missing billing address contact"
                  ) {
                    UIFunctions.Toast(
                      strings.missingDetailsErrorMessage,
                      "error"
                    );
                    this.setState({
                      confirmLoading: false
                    });
                  } else if (result.result) {
                    newServiceRequestStore.setInfolineResponse(result);
                    this.props.history.push("/budgetaryquote");
                    this.setState({
                      confirmLoading: false
                    });
                  } else {
                    UIFunctions.Toast(
                      strings.srValidateRequestMessage,
                      "error"
                    );
                    this.setState({
                      confirmLoading: false
                    });
                  }
                });
            } else {
              this.setState({
                confirmLoading: false
              });
              return UIFunctions.Toast(strings.calCycleErrorMessage, "error");
            }
          } else {
            UIFunctions.Toast(
              strings.updateKeysightAccountErrorMessage,
              "error"
            );
            userStore.setWaitForRequest(false);
            return;
          }
        }, 2000);
      }
    });
  };

  radioOptionChanged(value, e) {
    var basepayload = mobx.toJS(newServiceRequestStore.NewReq_basepayload);
    basepayload.pickupcountry = userStore.userDetails.Country;
    basepayload.returncountry = userStore.userDetails.Country;
    var fieldvalues = this.props.form.getFieldsValue();
    fieldvalues[value] = e.target.value;
    var payload = Object.assign(
      basepayload,
      fieldvalues,
      this.getRequiredUserDetails()
    );

    newServiceRequestStore.setNewReq_basepayload(payload);
    var self = this;
    setTimeout(() => {
      self.props.form.setFieldsValue(payload);
    }, 100);
  }
  componentDidMount() {
    newServiceRequestStore.setProceedCheckout(true);
    newServiceRequestStore.updateServieRequestStatus("step2");
    this.props.form.setFieldsValue(newServiceRequestStore.NewReq_basepayload);
    this.resize();
  }
  componentWillUnmount() {
    newServiceRequestStore.updateServieRequestStatus("step3");
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    window.addEventListener("resize", this.resize);
    return (
      <React.Fragment>
        <div className="sr-contact-shipping">
          <SrCreationStage
            currentSrStep={newServiceRequestStore.currentSrStep}
          />
          <div className="steps-divider" />
          <Form onSubmit={this.handleSubmit}>
            <div className="SR_view">
              <Row>
                <Col style={{ width: "31%" }} span={7}>
                  <div className="shippingToKeysight">
                    <span className="Shopping-heading-to-Keysight">
                      <Tooltip
                        title={strings.shippingInfo + strings.shippingInfo1}
                      >
                        {strings.shippingInfo}

                        <span style={{ color: "#3385FF" }}>
                          {strings.shippingInfo1}
                        </span>
                      </Tooltip>
                    </span>
                    <div>
                      <FormItem
                        className="serviceInputStyle"
                        {...radioItemLayout}
                      >
                        {getFieldDecorator("pickupoption", {
                          rules: [
                            {
                              required: true,
                              message: strings.selectOptionErrorMessage
                            }
                          ]
                        })(
                          <RadioGroup
                            name="pickupoption"
                            onChange={e =>
                              this.radioOptionChanged("pickupoption", e)
                            }
                          >
                            {strings.shipKeysight.length > 35 ? (
                              <Tooltip title={strings.shipKeysight}>
                                <Radio
                                  style={radioStyle}
                                  value={"0"}
                                  className="serviceInputStyle"
                                >
                                  {strings.shipKeysight}
                                </Radio>
                              </Tooltip>
                            ) : (
                              <Radio
                                style={radioStyle}
                                value={"0"}
                                className="serviceInputStyle"
                              >
                                {strings.shipKeysight}
                              </Radio>
                            )}
                            {strings.pickingAddress.length > 35 ? (
                              <Tooltip title={strings.pickingAddress}>
                                <Radio
                                  style={radioStyle}
                                  value={"1"}
                                  className="serviceInputStyle"
                                >
                                  {strings.pickingAddress}
                                </Radio>
                              </Tooltip>
                            ) : (
                              <Radio
                                style={radioStyle}
                                value={"1"}
                                className="serviceInputStyle"
                              >
                                {strings.pickingAddress}
                              </Radio>
                            )}
                            {strings.mailingAddress.length > 35 ? (
                              <Tooltip title={strings.mailingAddress}>
                                <Radio
                                  style={radioStyle}
                                  value={"3"}
                                  className="serviceInputStyle"
                                >
                                  {strings.mailingAddress}
                                </Radio>
                              </Tooltip>
                            ) : (
                              <Radio
                                style={radioStyle}
                                value={"3"}
                                className="serviceInputStyle"
                              >
                                {strings.mailingAddress}
                              </Radio>
                            )}
                          </RadioGroup>
                        )}
                      </FormItem>
                    </div>
                  </div>
                </Col>
                <Col style={{ width: "31%" }} span={7}>
                  <div className="shippingInstructure">
                    <span className="Shopping-heading-to-Keysight">
                      <Tooltip
                        title={strings.shippingInfo + strings.fromKeysight}
                      >
                        {strings.shippingInfo}
                        <span style={{ color: "#3385FF" }}>
                          {strings.fromKeysight}
                        </span>
                      </Tooltip>
                    </span>
                    <div>
                      <FormItem
                        className="serviceInputStyle"
                        {...radioItemLayout}
                      >
                        {getFieldDecorator("returnoption", {
                          rules: [
                            {
                              required: true,
                              message: strings.selectOptionErrorMessage
                            }
                          ]
                        })(
                          <RadioGroup
                            name="returnoption"
                            onChange={e =>
                              this.radioOptionChanged("returnoption", e)
                            }
                          >
                            {" "}
                            {strings.pickKeysight.length > 35 ? (
                              <Tooltip title={strings.pickKeysight}>
                                <Radio
                                  style={radioStyle}
                                  value={"0"}
                                  className="serviceInputStyle"
                                >
                                  {strings.pickKeysight}
                                </Radio>
                              </Tooltip>
                            ) : (
                              <Radio
                                style={radioStyle}
                                value={"0"}
                                className="serviceInputStyle"
                              >
                                {strings.pickKeysight}
                              </Radio>
                            )}
                            {strings.returnAddress.length > 35 ? (
                              <Tooltip title={strings.returnAddress}>
                                <Radio
                                  style={radioStyle}
                                  value={"1"}
                                  className="serviceInputStyle"
                                >
                                  {strings.returnAddress}
                                </Radio>
                              </Tooltip>
                            ) : (
                              <Radio
                                style={radioStyle}
                                value={"1"}
                                className="serviceInputStyle"
                              >
                                {strings.returnAddress}
                              </Radio>
                            )}
                            {strings.returnMailAddress.length > 35 ? (
                              <Tooltip title={strings.returnMailAddress}>
                                <Radio
                                  style={radioStyle}
                                  value={"3"}
                                  className="serviceInputStyle"
                                >
                                  {strings.returnMailAddress}
                                </Radio>
                              </Tooltip>
                            ) : (
                              <Radio
                                style={radioStyle}
                                value={"3"}
                                className="serviceInputStyle"
                              >
                                {strings.returnMailAddress}
                              </Radio>
                            )}
                          </RadioGroup>
                        )}
                      </FormItem>
                    </div>
                  </div>
                </Col>
                <Col span={8}>
                  <div className="contact-divider">
                    <div
                      className="contact-information"
                      style={{
                        position: "absolute",
                        left: "38px",
                        top: "-24px"
                      }}
                    >
                      <span className="Contactheading">
                        {"Contact Information"}
                      </span>
                      <div
                        className="Contact-body-copy"
                        style={{
                          height: newServiceRequestStore.dynamicInfoDetails
                        }}
                      >
                        <FormItem {...formItem} label={strings.lastName}>
                          <span className="sr-form-data">
                            {userStore.userDetails
                              ? userStore.userDetails.lastName
                              : ""}
                          </span>
                        </FormItem>
                        <Form.Item {...formItem} label={strings.firstName}>
                          <span className="sr-form-data">
                            {userStore.userDetails
                              ? userStore.userDetails.firstName
                              : ""}
                          </span>
                        </Form.Item>
                        <Form.Item {...formItem} label={strings.companyName}>
                          <span className="sr-form-data">
                            {userStore.userDetails
                              ? userStore.userDetails.CustomerName
                              : ""}
                          </span>
                        </Form.Item>
                        <Form.Item {...formItem} label={strings.mailingAdd}>
                          <span className="sr-form-data">
                            <p>
                              {userStore.userDetails
                                ? userStore.userDetails.AddressLine1
                                : ""}
                            </p>
                            <p>
                              {userStore.userDetails
                                ? userStore.userDetails.AddressLine2
                                : ""}{" "}
                            </p>
                            <p>
                              {userStore.userDetails
                                ? userStore.userDetails.AddressLine3
                                : ""}
                            </p>
                            <p>
                              {userStore.userDetails
                                ? userStore.userDetails.City
                                : ""}
                            </p>
                            <p>
                              {userStore.userDetails
                                ? userStore.userDetails.State
                                : ""}
                            </p>
                            <p>
                              {userStore.userDetails
                                ? getCountryName(
                                    userStore.userDetails.CountryCodes,
                                    userStore.userDetails.Country
                                  )
                                : ""}
                            </p>
                          </span>
                        </Form.Item>
                        <Form.Item {...formItem} label={strings.emailAddress}>
                          <span className="sr-form-data">
                            {userStore.userDetails ? (
                              userStore.userDetails.infolineUserName.length >
                              27 ? (
                                <Tooltip
                                  title={userStore.userDetails.infolineUserName}
                                >
                                  {parseText(
                                    userStore.userDetails.infolineUserName
                                  )}
                                </Tooltip>
                              ) : (
                                userStore.userDetails.infolineUserName
                              )
                            ) : (
                              ""
                            )}
                          </span>
                        </Form.Item>
                        <Form.Item {...formItem} label={strings.phoneNum}>
                          <span className="sr-form-data">
                            {userStore.userDetails
                              ? userStore.userDetails.phoneNo
                              : ""}
                          </span>
                        </Form.Item>
                        <Form.Item {...formItem} label={strings.mobile}>
                          <span className="sr-form-data">
                            {userStore.userDetails
                              ? userStore.userDetails.mobilePhone
                              : ""}
                          </span>
                        </Form.Item>
                      </div>
                    </div>
                  </div>
                  <Row />
                </Col>
              </Row>
              <Row
                type="flex"
                className="details-on-Select"
                style={{ height: newServiceRequestStore.dynamicContactDetails }}
              >
                <Col span={8} order={1}>
                  {newServiceRequestStore.NewReq_basepayload.pickupoption ==
                  "1" ? (
                    <div id="height">
                      <FormItem {...formItemLayout1} label={strings.contact}>
                        {getFieldDecorator("pickupcontact", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterContactName
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout1} label={strings.phoneNum}>
                        {getFieldDecorator("pickupphone", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterPhoneNumber
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout1} label={strings.mobile}>
                        {getFieldDecorator("toKeySightMobile", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterMobileNumber
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout1} label={strings.company}>
                        {getFieldDecorator("pickupcompanyname", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterCompName
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout1} label={strings.address}>
                        {getFieldDecorator("pickupline1", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterAddress
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout1} label={strings.city}>
                        {getFieldDecorator("pickupcity", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterCity
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout1} label={strings.postalCode}>
                        {getFieldDecorator("pickuppostalcode", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterPostalCode
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout1} label={strings.pickState}>
                        {getFieldDecorator("pickupstate", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterState
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.country}>
                        {getFieldDecorator("pickupcountry", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterCountry
                            }
                          ]
                        })(
                          <Select
                            dropdownClassName="countryDropDown"
                            showSearch
                            style={{ width: 200 }}
                            optionFilterProp="children"
                            filterOption={(input, option) =>
                              option.props.children
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                          >
                            {userStore.userDetails.CountryCodes.map(e => {
                              return (
                                <Option value={e.CountryCode} key={e.Country}>
                                  {e.Country}
                                </Option>
                              );
                            })}
                          </Select>
                        )}
                      </FormItem>
                    </div>
                  ) : null}
                </Col>
                <Col
                  span={8}
                  order={2}
                  style={{
                    position: "relative",
                    left: "22%"
                  }}
                >
                  {newServiceRequestStore.NewReq_basepayload.returnoption ==
                  "1" ? (
                    <div>
                      <FormItem {...formItemLayout} label={strings.contact}>
                        {getFieldDecorator("returncontact", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterContactName
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>

                      <FormItem {...formItemLayout} label={strings.phoneNum}>
                        {getFieldDecorator("returnphone", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterPhoneNumber
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.mobile}>
                        {getFieldDecorator("fromKeySightMobile", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterMobileNumber
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.company}>
                        {getFieldDecorator("returncompanyname", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterCompName
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.address}>
                        {getFieldDecorator("returnline1", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterAddress
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.city}>
                        {getFieldDecorator("returncity", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterCity
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.postalCode}>
                        {getFieldDecorator("returnpostalcode", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterPostalCode
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.pickState}>
                        {getFieldDecorator("returnstate", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterState
                            }
                          ]
                        })(<Input type="text" />)}
                      </FormItem>
                      <FormItem {...formItemLayout} label={strings.country}>
                        {getFieldDecorator("returncountry", {
                          rules: [
                            {
                              required: true,
                              message: strings.enterCountry
                            }
                          ]
                        })(
                          <Select
                            dropdownClassName="countryDropDown"
                            showSearch
                            style={{ width: 200 }}
                            optionFilterProp="children"
                            filterOption={(input, option) =>
                              option.props.children
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                          >
                            {userStore.userDetails.CountryCodes.map(e => {
                              return (
                                <Option value={e.CountryCode} key={e.Country}>
                                  {e.Country}
                                </Option>
                              );
                            })}
                          </Select>
                        )}
                      </FormItem>
                    </div>
                  ) : null}
                </Col>
              </Row>
              <Col span={8}>
                <div className="cont--buttons">
                  <Popconfirm
                    title={strings.srAssetsCancelRequest}
                    onConfirm={this.confirm}
                    okText={strings.yes}
                    cancelText={strings.no}
                  >
                    <Button className="cancel">
                      <Icon type="close" />
                      &nbsp;&nbsp;{strings.cancel}
                    </Button>
                  </Popconfirm>
                  &nbsp;&nbsp;
                  <Button className="cancel" onClick={this.handleBack}>
                    <Icon type="arrow-left" />
                    &nbsp;&nbsp; {strings.back}
                  </Button>
                  &nbsp;&nbsp;
                  <Button
                    className="continue"
                    htmlType="submit"
                    disabled={this.state.confirmLoading ? true : false}
                  >
                    <Icon
                      type={
                        this.state.confirmLoading ? "loading" : "arrow-right"
                      }
                    />
                    &nbsp;&nbsp; {strings.continue}
                  </Button>
                </div>
              </Col>
            </div>
          </Form>
        </div>
      </React.Fragment>
    );
  }
}

const SRContactShipping = Form.create()(SRContactForm);

export default SRContactShipping;
