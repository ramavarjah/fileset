import React, { Component } from "react";
import Sidebar from "src/components/Sidebar/Sidebar";
import Footer from "src/components/Footer/Footer";
import BottomGrid from "../ServiceDueDatesGrid";
import ServiceHeader from "../SRHeader";
import SR_MiddleGrid from "../SR_middleComponent";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";
import { observer } from "mobx-react";
import "../SRNewUI.scss";
import tabModelStore from "../../../stores/tabModelStore";
import addAssetsStore from "../../../stores/addAssetsStore";

@observer
class SRLandingPage extends Component {
  componentDidMount() {
    newServiceRequestStore.updateServiceRequestConfirmation(false);
    newServiceRequestStore.setShowImage(false);
    newServiceRequestStore.AddAll = true;
    tabModelStore.setIsAssetListView(false);
    tabModelStore.setIsChartView(false);
    newServiceRequestStore.setIsServiceRequest(true);
    newServiceRequestStore.updateEditInfoFieldsChange(false);
    if (newServiceRequestStore.rowSelectedAssetsData.length < 1) {
      newServiceRequestStore.srGetAllCartItems();
    }
  }
  componentWillUnmount = () => {
    newServiceRequestStore.setIsServiceRequest(false);
    addAssetsStore.setIsDashboardSelected(false);
  };
  render() {
    return (
      <React.Fragment>
        <Sidebar />
        <ServiceHeader />
        <div className="sr__landingPage">
          <SR_MiddleGrid loading={true} />
          <BottomGrid />
        </div>
        <Footer />
      </React.Fragment>
    );
  }
}

export default SRLandingPage;
