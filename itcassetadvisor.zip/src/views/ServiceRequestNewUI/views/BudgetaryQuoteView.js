import React from "react";
import ServiceHeader from "../SRHeader/ServiceHeader";
import Sidebar from "src/components/Sidebar/Sidebar";
import Footer from "src/components/Footer/Footer";
import SRBudgetaryQuote from "src/views/ServiceRequestNewUI/SRBudgetaryQuote/SRBudgetaryQuote";

export default class BudgetaryQuoteView extends React.Component {
  constructor(props){
    super(props)
  }
  render() {
    return (
      <React.Fragment>
        <Sidebar />
        <ServiceHeader />
        <SRBudgetaryQuote {...this.props} />
        <Footer />
      </React.Fragment>
    );
  }
}
