import React from "react";
import ServiceHeader from "../SRHeader/ServiceHeader";
import Sidebar from "src/components/Sidebar/Sidebar";
import Footer from "src/components/Footer/Footer";
import SRContactShipping from "src/views/ServiceRequestNewUI/SR_ContactShipping/SRContactShipping";

export default class ContactShipping extends React.Component {
  constructor(props){
    super(props)
  }
  render() {
    return (
      <React.Fragment>
        <Sidebar />
        <ServiceHeader />
        <SRContactShipping {...this.props}/>
        <Footer />
      </React.Fragment>
    );
  }
}
