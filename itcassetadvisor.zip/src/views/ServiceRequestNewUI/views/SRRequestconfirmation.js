import React from "react";
import ServiceHeader from "../SRHeader/ServiceHeader";
import Sidebar from "src/components/Sidebar/Sidebar";
import Footer from "src/components/Footer/Footer";
import Requestconfirmation from "../RequestConfirmation/Requestconfirmation";

export default class SRRequestconfirmation extends React.Component {
  render() {
    return (
      <React.Fragment>
        <Sidebar />
        <ServiceHeader />
        <Requestconfirmation />
        <Footer />
      </React.Fragment>
    );
  }
}
