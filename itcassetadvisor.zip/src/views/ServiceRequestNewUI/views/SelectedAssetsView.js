import React from "react";
import ServiceHeader from "../SRHeader/ServiceHeader";
import Sidebar from "src/components/Sidebar/Sidebar";
import Footer from "src/components/Footer/Footer";
import SRSelectedAssets from "src/views/ServiceRequestNewUI/SelectedAssetsStage/SRSelectedAssets";
import { observer } from "mobx-react";
import newServiceRequestStore from "../../../stores/newServiceRequestStore";

@observer
export default class SelectedAssestsView extends React.Component {
  render() {
    return (
      <React.Fragment>
        <Sidebar />
        <ServiceHeader />
        <SRSelectedAssets requestedService={newServiceRequestStore.requestedService} {...this.props} />
        <Footer />
      </React.Fragment>
    );
  }
}
