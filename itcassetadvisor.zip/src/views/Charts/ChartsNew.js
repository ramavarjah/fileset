//ImplementedChart

import React, { Component } from "react";
import "amcharts3";
import "amcharts3/amcharts/serial";
import AmCharts from "@amcharts/amcharts3-react";
import tabModelStore from "../../stores/tabModelStore";
import permissionStore from "../../stores/permissionStore";
import chartConfig from "./chartConfig";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";
import ChartFooter from "./ChartFooter";
import ServiceDueDate from "./ServiceDueDate";
import { Row, Button, Col, Spin, Alert, Switch, Tooltip } from "antd";
import AssetDetails from "./AssetDetails";
import _ from "lodash";
import "../../helpers/Antd/antd.css"; // new line of code
import mobx from "mobx";

class Charts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartDetailstoggle: false,
      valueProp: "",
      dataProvider: "",
      timer: null,
      categoryId: null,
      breadcrumb: "",
      CustomerId: "",
      detailsMode: false,
      width: 0,
      height: 0,
      graphObj: [],
      graphObject: null,
      activeChartId: 0,
      footerHeight: 120,
      mainHeight: 834,
      btnToglIndx: 0
    };
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this);
    this.showAll = this.showAll.bind(this);
    this.hideAll = this.hideAll.bind(this);
    this.hideAllLegends = this.hideAllLegends.bind(this);
    this.drillDown = _.debounce(this.drillDown.bind(this));
    this.drillDownHealthWithApiCall = _.debounce(
      this.drillDownHealthWithApiCall.bind(this)
    );
    this.drillDownAssetCountBySublocation = _.debounce(
      this.drillDownAssetCountBySublocation.bind(this)
    );
    this.drillDownAssetCountBySubOrganization = _.debounce(
      this.drillDownAssetCountBySubOrganization.bind(this)
    );
  }

  componentWillUnmount() {
    tabModelStore.setOnChartActive(false);
    tabModelStore.setOnTabActive(false);
    window.removeEventListener("resize", this.updateWindowDimensions);
  }

  updateWindowDimensions() {
    var footerHeight = document.getElementById("footer")
      ? document.getElementById("footer").clientHeight + 63
      : 120;
    var mainHeight = window.innerHeight - 27 - footerHeight;

    this.setState({
      width: window.innerWidth,
      height: window.innerHeight,
      footerHeight,
      mainHeight
    });
  }

  componentWillMount() {
    tabModelStore.setIsAssetListView(false);
    tabModelStore.setIsChartView(true);
    tabModelStore.setIsVisible(false);
    tabModelStore.setShowToolTip(true);
    this.updateWindowDimensions();
    window.addEventListener("resize", this.updateWindowDimensions);
    var dataProvider = JSON.stringify(tabModelStore.chartConfig);

    dataProvider = JSON.parse(dataProvider);
    this.setState({
      dataProvider: dataProvider
    });
  }
  healthCount() {
    tabModelStore.setIsHealthCount(true);
    var currentDataProvider = JSON.parse(
      JSON.stringify(tabModelStore.chartConfig)
    );
    let config;
    if (tabModelStore.getIsSubLevel === false) {
      config = chartConfig.assetHealthByCount;
    } else {
      config = chartConfig.assetHealthByCountDrillDown;
    }
    config.dataProvider = currentDataProvider.dataProvider;
    tabModelStore.setChartConfig(config);
    this.setState({ btnToglIndx: 0 });
  }
  healthPercent() {
    tabModelStore.setIsHealthCount(false);
    var currentDataProvider = JSON.parse(
      JSON.stringify(tabModelStore.chartConfig)
    );
    let config;
    if (tabModelStore.getIsSubLevel === false) {
      config = chartConfig.assetHealthByPercent;
    } else {
      config = chartConfig.assetHealthByPercentDrillDown;
    }
    config.dataProvider = currentDataProvider.dataProvider;
    tabModelStore.setChartConfig(config);
    this.setState({ btnToglIndx: 1 });
  }
  drillUp() {
    setTimeout(() => {
      tabModelStore.setIsSubLevel(false);
      var previousConfig = tabModelStore.previousChartConfig;
      var arrLength = previousConfig.length;

      if (arrLength > 0) {
        tabModelStore.setBackButtonVisibility(true);
        var config = tabModelStore.previousChartConfig[arrLength - 1];
        tabModelStore.drillUpPreviousChartConfig();
        tabModelStore.setChartConfig(config);
      }
      if (arrLength == 1) {
        tabModelStore.setBackButtonVisibility(false);
        tabModelStore.clearPreviousChartConfig();
      }
    }, 100);
  }

  componentDidMount() {
    tabModelStore.setOnChartActive(true);
    this.setState({
      chartViewData: tabModelStore.chartViewData
    });
    var categoryId = tabModelStore.getActiveChartCategory;
    this.setState({
      categoryId: categoryId
    });
    // because Object.keys(new Date()).length === 0;
    // we have to do some additional check
    const isEmpty = mobx.toJS(tabModelStore.chartConfig);
    if (
      Object.keys(isEmpty).length === 0 &&
      (isEmpty.constructor === Object) == true
    ) {
      UIFunctions.setPreset(tabModelStore.getActiveTab.DatePreset);
    }
    if (tabModelStore.onTabActive) {
      this.loaded = false;
      tabModelStore.setDataLoaded(false);
      UIFunctions.ReRenderChart().then(() => {
        this.loaded = true;
        tabModelStore.setDataLoaded(true);
        //console.log("respChart", resp)
      });
    }
  }

  // HIDE AND SHOW LEGEND ITEMS
  hideOtherss(e) {
    var currentGraph = e.dataItem;
    var hidden = true;
    // console.log("hello", e);

    if (this.state.chartDetailstoggle) {
      if (e.dataItem.id == "all") this.setState({ detailsMode: false });
      else
        this.setState({
          detailsMode:
            e.type == "showItem" || e.type == "hideItem" ? true : false
        });

      if (e.type == "showItem" || e.type == "hideItem") {
        this.setState({
          valueProp: e.dataItem.legendTextReal
        });
        // console.log("showitem", e.type);
        // console.log("setItem", e.dataItem.legendTextReal);
      }
      if (e.dataItem.id == "all") {
        for (let i1 in e.chart.graphs) {
          if (e.chart.graphs[i1].id != "all") {
            e.chart[e.dataItem.hidden ? "hideGraph" : "showGraph"](
              e.chart.graphs[i1]
            );
          }
        }
      }
      if (e.dataItem.id == "showAll") {
        for (let i1 in e.chart.graphs) {
          if (e.chart.graphs[i1].id != "showAll") {
            e.chart["showGraph"](e.chart.graphs[i1]);
          }
        }
      }
      if (e.dataItem.id == "hideAll") {
        for (let i1 in e.chart.graphs) {
          if (e.chart.graphs[i1].id != "hideAll") {
            e.chart["hideGraph"](e.chart.graphs[i1]);
          }
        }
      }
      //check if we clicked on this graph before and if all the other graphs are visible.
      // if we clicked on this graph before and the other graphs are invisible,
      // make them visible, otherwise default to previous behavior
      if (
        e.chart.lastClicked == currentGraph.id &&
        e.chart.allVisible == false
      ) {
        hidden = false;
        e.chart.allVisible = true;
      } else {
        e.chart.allVisible = false;
      }
      e.chart.lastClicked = currentGraph.id; //keep track of the current one we clicked

      currentGraph.hidden = false; //force clicked graph to stay visible
      _.forEach(e.chart.graphs, function(graph) {
        if (graph.id !== currentGraph.id) {
          graph.hidden = hidden; //set the other graph's visibility based on the rules above
        }
      });
      // update the chart with newly set hidden values
      e.chart.validateNow();
    }
  }
  toggleDetails = () => {
    // console.log("state");
    this.setState({ chartDetailstoggle: !this.state.chartDetailstoggle });
    this.setState({ valueProp: null });
    var self = this;
    function handleLegendClick(graph) {
      // console.log("graph", graph);
      var chart = graph.chart;
      for (var i = 0; i < chart.graphs.length; i++) {
        if (graph.id == chart.graphs[i].id) {
          self.setLegendOpacity(chart.graphs[i], 1);
          self.setOpacity(chart.graphs[i], 1);
          // chart.showGraph(chart.graphs[i]);
        } else {
          self.setLegendOpacity(chart.graphs[i], 0.1);
          self.setOpacity(chart.graphs[i], 0.1);
          // chart.hideGraph(chart.graphs[i]);
        }
      }
      // return false so that default action is canceled
      return false;
    }
    setTimeout(() => {
      //ui will take sometime to finish toggling, after that we set the selection view
      // console.log("clickinglegend", this.state.graphObj)

      this.setState({ graphObj: [] });
      handleLegendClick(this.state.graphObject);
    }, 300);
  };

  /* toggleDetails1 = e => {
      console.log("state");
      this.setState({ chartDetailstoggle:true }, {overlayOpen:false} );
      var self = this;
      function handleLegendClick(graph) {
        // console.log("graph", graph);
        var chart = graph.chart;
        for (var i = 0; i < chart.graphs.length; i++) {
          if (graph.id == chart.graphs[i].id) {
            self.setLegendOpacity(chart.graphs[i], 1);
            self.setOpacity(chart.graphs[i], 1);
            // chart.showGraph(chart.graphs[i]);
          } else {
            self.setLegendOpacity(chart.graphs[i], 0.1);
            self.setOpacity(chart.graphs[i], 0.1);
            // chart.hideGraph(chart.graphs[i]);
          }
        }
        // return false so that default action is canceled
        return false;
      }
      setTimeout(() => {
        //ui will take sometime to finish toggling, after that we set the selection view
        // console.log("clickinglegend", this.state.graphObj)
        handleLegendClick(this.state.graphObj);
      }, 300);
    };*/

  showAll() {
    this.setState({
      valueProp: null,
      graphObj: []
    });
    var self = this;
    if (!this.state.graphObject) return;
    var graph = this.state.graphObject;
    var chart = graph.chart;
    var newGraphstate = [];
    for (var i = 0; i < chart.graphs.length; i++) {
      // self.setLegendOpacity(chart.graphs[i], 1)
      // self.setOpacity(chart.graphs[i], 1)
      newGraphstate.push(chart.graphs[i]);
    }
    self.setState({ graphObj: newGraphstate });
    return false;
  }
  setOpacity(graph, opacity) {
    var container = graph.chart.div;
    var className = "amcharts-graph-" + graph.id;
    let items;
    if (UIFunctions.isIE() != false)
      items = container.querySelectorAll("." + className);
    else items = container.getElementsByClassName(className);
    if (undefined === items) return;
    for (var x in items) {
      if ("object" !== typeof items[x]) continue;
      var path = items[x].getElementsByTagName("path")[0];
      if (undefined !== path) {
        // set line opacity
        path.style.strokeOpacity = opacity;
      }
      // set bullet opacity
      let bullets;
      if (UIFunctions.isIE() != false)
        bullets = items[x].querySelectorAll("." + "amcharts-graph-bullet");
      else bullets = items[x].getElementsByClassName("amcharts-graph-bullet");
      for (var y in bullets) {
        if ("object" !== typeof bullets[y]) continue;
        bullets[y].style.fillOpacity = opacity;
      }
      // set label opacity
      let labels;
      if (UIFunctions.isIE() != false)
        labels = items[x].querySelectorAll("." + "amcharts-graph-label");
      else labels = items[x].getElementsByClassName("amcharts-graph-label");
      for (let y in labels) {
        if ("object" !== typeof labels[y]) continue;
        labels[y].style.opacity = opacity == 1 ? 1 : 0;
      }
    }
  }
  setLegendOpacity(graph, opacity) {
    var container = graph.chart.div;
    // console.log(container)
    // console.log("opacity", opacity)
    var className = "amcharts-legend-item-" + graph.id;
    let items;
    if (UIFunctions.isIE() != false)
      items = container.querySelectorAll("." + className);
    else items = container.getElementsByClassName(className);
    // console.log(items)
    if (undefined === items) return;
    for (var x in items) {
      if ("object" !== typeof items[x]) continue;
      var path = items[x].getElementsByTagName("path")[0];
      if (undefined !== path) {
        // set legend opacity
        path.style.fillOpacity = opacity;
      }
      // set label opacity
      let labels;
      if (UIFunctions.isIE() != false)
        labels = items[x].querySelectorAll("." + "amcharts-legend-label");
      else labels = items[x].getElementsByClassName("amcharts-legend-label");
      for (var y in labels) {
        if ("object" !== typeof labels[y]) continue;
        labels[y].style.opacity = opacity;
      }
    }
  }
  hideAll() {
    this.setState({
      valueProp: null,
      graphObj: []
    });
  }
  hideAllLegends() {
    var self = this;
    // console.log("hideAllLegends", self.state);
    if (!this.state.graphObject) return;
    // console.log("hideAllLegends");
    var graph = this.state.graphObject;
    var chart = graph.chart;
    for (var i = 0; i < chart.graphs.length; i++) {
      // console.log("hideAllLegends_for");
      self.setLegendOpacity(chart.graphs[i], 0.1);
      self.setOpacity(chart.graphs[i], 0.1);
    }
    return false;
  }
  componentDidUpdate() {
    // console.log("componentDidUpdate", prevProps, prevState, snapshot);
    // console.log("componentDidUpdate", this.state);
    if (this.state.graphObj.length < 1) return this.hideAllLegends();
    var graph = this.state.graphObj[0];
    var chart = graph.chart;
    for (var i = 0; i < chart.graphs.length; i++) {
      var found = this.state.graphObj.find(
        item => item.id == chart.graphs[i].id
      );
      if (found) {
        this.setLegendOpacity(chart.graphs[i], 1);
        this.setOpacity(chart.graphs[i], 1);
      } else {
        this.setLegendOpacity(chart.graphs[i], 0.1);
        this.setOpacity(chart.graphs[i], 0.1);
      }
    }
    this.setLegentDivWidth();
  }
  setLegentDivWidth() {
    let element;
    if (UIFunctions.isIE() != false)
      element = document.querySelectorAll("." + "amcharts-legend-div");
    else element = document.getElementsByClassName("amcharts-legend-div");
    if (element.length) {
      var width = element[0].clientWidth;
      // console.log("width", width);
      if (UIFunctions.isIE() != false)
        document.querySelectorAll(".button-showall")[0].style.width =
          width + 40 + "px";
      else
        document.getElementsByClassName("button-showall")[0].style.width =
          width + 40 + "px";
    }
  }

  drillDown(event) {
    if (!event) {
      tabModelStore.setBackButtonVisibility(true);
      UIFunctions.Toast("No further levels defined", "info");
      return;
    }
    tabModelStore.setBackButtonVisibility(true);
    var dataProvider = event.item.dataContext.subnodes;
    var config = chartConfig.assetHealthByCount;
    config.dataProvider = dataProvider;
    tabModelStore.addToPrevConfig();
    tabModelStore.setChartConfig(config);
  }
  drillDownHealthWithApiCall(event, chartConfig, type, tabId) {
    tabModelStore.setBackButtonVisibility(true);
    permissionStore.setChartLoading(true);
    Functions.GetAssetHealthDrillDown(
      tabId,
      type,
      event.item.dataContext.propertyName,
      tabModelStore.chartBucketType
    ).then(resp => {
      var dataProvider = resp.data.data;
      //console.log("dataProvider===========",dataProvider);
      let config;
      if (tabModelStore.isHealthCount === true) {
        config = chartConfig.assetHealthByCountDrillDown;
      } else {
        config = chartConfig.assetHealthByPercentDrillDown;
      }
      config.dataProvider = dataProvider;
      config.dataDateFormat = ""; //resp.data.DateFormat;
      config.categoryAxis.minPeriod = resp.data.minPeriod;
      var previousConfig = tabModelStore.previousChartConfig;
      previousConfig.push(tabModelStore.chartConfig);
      tabModelStore.setPreviousChartConfig(previousConfig);
      tabModelStore.setChartConfig(config);
      tabModelStore.setIsSubLevel(true);
      permissionStore.setChartLoading(false);
    });
  }
  drillDownAssetCountBySublocation(event, chartConfig) {
    // console.log(tabModelStore.chartId)

    if (tabModelStore.chartId !== "1") return;

    // console.log(event.item.dataContext.subnodes);
    if (!event || event.item.dataContext.subnodes.length == 0) {
      tabModelStore.setBackButtonVisibility(true);
      UIFunctions.Toast("No further levels defined", "info");
      return;
    }
    tabModelStore.setBackButtonVisibility(true);
    var dataProvider = event.item.dataContext.subnodes;
    var config = chartConfig.assetCountByLoc;
    config.dataProvider = dataProvider;
    var previousConfig = tabModelStore.previousChartConfig;
    previousConfig.push(tabModelStore.chartConfig);
    tabModelStore.setPreviousChartConfig(previousConfig);
    tabModelStore.setChartConfig(config);
    return;
  }

  drillDownAssetCountBySubOrganization(event, chartConfig) {
    // console.log(event.item.dataContext.subnodes);
    if (tabModelStore.chartId !== "3") return;
    if (!event || event.item.dataContext.subnodes.length == 0) {
      tabModelStore.setBackButtonVisibility(true);
      UIFunctions.Toast("No further levels defined", "info");
      return;
    }
    tabModelStore.setBackButtonVisibility(true);
    var dataProvider = event.item.dataContext.subnodes;
    var config = chartConfig.assetCountByOrganization;
    config.dataProvider = dataProvider;
    var previousConfig = tabModelStore.previousChartConfig;
    previousConfig.push(tabModelStore.chartConfig);
    tabModelStore.setPreviousChartConfig(previousConfig);
    tabModelStore.setChartConfig(config);
    return;
  }

  render() {
    const AmChartsHealth = props => {
      return (
        <div>
          <Row
            type="flex"
            justify="start"
            align="left"
            style={{ paddingTop: "6px" }}
          >
            <Col span={4} style={{ paddingLeft: "6px" }}>
              <Button.Group>
                <Button
                  style={
                    this.state.btnToglIndx === 0
                      ? { ...onStyle }
                      : { ...offStyle }
                  }
                  onClick={this.healthCount.bind(this)}
                >
                  #
                </Button>
                <Button
                  style={
                    this.state.btnToglIndx === 1
                      ? { ...onStyle }
                      : { ...offStyle }
                  }
                  onClick={this.healthPercent.bind(this)}
                >
                  %
                </Button>
              </Button.Group>
            </Col>
          </Row>
          <AmCharts.React
            style={{ width: "100%", height: this.state.height * 0.55 }}
            options={props.config}
          />
        </div>
      );
    };
    var config; //= JSON.parse(JSON.stringify(tabModelStore.chartConfig));
    config = JSON.parse(JSON.stringify(tabModelStore.chartConfig));
    var chartCategory = tabModelStore.chartViewData;
    var tabId = tabModelStore.activeTab.TabId;
    tabModelStore.setHealthVsTimeContext(false);
    var activeChartId = "";
    var activeCategoryId = tabModelStore.activeCategoryId;
    for (var index = 0; index < chartCategory.length; index++) {
      var element = chartCategory[index];
      if (element.Active === true) {
        activeCategoryId = element.CategoryId;
      }
    }
    activeChartId = tabModelStore.chartId;
    let listeners;
    if (activeCategoryId === "2" && activeChartId === "5") {
      //Health charts
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (event.item.dataContext.subnodes.length > 0) {
              self.drillDown(event);
            } else {
              self.drillDown(null);
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "2" && activeChartId === "6") {
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (
              event.item.dataContext.propertyName != undefined &&
              event.item.dataContext.propertyName != null
            ) {
              self.drillDownHealthWithApiCall(
                event,
                chartConfig,
                "ModelNo",
                tabId
              );
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "2" && activeChartId === "7") {
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (event.item.dataContext.subnodes.length > 0) {
              self.drillDown(event);
            } else {
              self.drillDown(null);
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "2" && activeChartId === "8") {
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (
              event.item.dataContext.propertyName != undefined &&
              event.item.dataContext.propertyName != null
            ) {
              self.drillDownHealthWithApiCall(
                event,
                chartConfig,
                "SerialNo",
                tabId
              );
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "2" && activeChartId === "19") {
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (
              event.item.dataContext.propertyName != undefined &&
              event.item.dataContext.propertyName != null
            ) {
              self.drillDownHealthWithApiCall(
                event,
                chartConfig,
                "EquipmentNo",
                tabId
              );
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "2" && activeChartId === "20") {
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (
              event.item.dataContext.propertyName != undefined &&
              event.item.dataContext.propertyName != null
            ) {
              self.drillDownHealthWithApiCall(
                event,
                chartConfig,
                "AssetNo",
                tabId
              );
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "1" && activeChartId === "1") {
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (
              event.item.dataContext !== undefined &&
              event.item.dataContext != null
            ) {
              self.drillDownAssetCountBySublocation(event, chartConfig, tabId);
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "1" && activeChartId === "3") {
      listeners = [
        {
          event: "clickGraphItem",
          method: function(event) {
            if (
              event.item.dataContext !== undefined &&
              event.item.dataContext != null
            ) {
              self.drillDownAssetCountBySubOrganization(
                event,
                chartConfig,
                tabId
              );
            }
          }
        }
      ];
      config.listeners = listeners;
    } else if (activeCategoryId === "3") {
      listeners = [];
      config.listeners = [
        {
          event: "rendered",
          method: setgraphObj
        }
      ];
      if (config.legend) {
        config.legend.listeners = listeners;
        config.legend.clickMarker = handleLegendClick;
        config.legend.clickLabel = handleLegendClick;
      }
    }
    var self = this;
    function setgraphObj(graph) {
      function setVals() {
        self.setState({
          graphObj: graph.chart.graphs,
          graphObject: graph,
          activeChartId: activeChartId
        });
      }
      if (!self.state.graphObject) return setVals();
      if (!self.state.activeChartId) return setVals();
      if (activeChartId != self.state.activeChartId) return setVals();
    }
    function addLegendSelection(graph) {
      setLegendOpacity(graph, 1);
      setOpacity(graph, 1);

      var list = self.state.graphObj;
      list.push(graph);
      var newState = { graphObj: list };
      if (list.length == 1) newState.valueProp = list[0].legendTextReal;
      else newState.valueProp = null;
      self.setState(newState);
      return false;
    }
    function removeLegendSelection(graph) {
      var list = self.state.graphObj;
      if (list.length > 1) {
        var length = list.length;
        for (var i = 0; i < length; i++) {
          if (list[i] && list[i].id === graph.id) list.splice(i, 1);
        }
      } else {
        list = [];
      }
      var newState = { graphObj: list };
      if (list.length == 1) newState.valueProp = list[0].legendTextReal;
      if (list.length == 0) newState.valueProp = null;
      self.setState(newState);
      return false;
    }
    function handleLegendClick(graph) {
      // console.log("graphObj_beforeFind", self.state.graphObj)
      for (var i = 0; i < self.state.graphObj.length; i++) {
        var oldGraph = self.state.graphObj[i];
        if (oldGraph.id == graph.id) {
          // console.log("newgraph", graph.id);
          // console.log("oldgraph", oldGraph);
          return removeLegendSelection(graph);
        }
      }
      return addLegendSelection(graph);
    }
    function setOpacity(graph, opacity) {
      var container = graph.chart.div;
      var className = "amcharts-graph-" + graph.id;
      let items;
      UIFunctions.isIE() != false
        ? (items = container.querySelectorAll("." + className))
        : (items = container.getElementsByClassName(className));
      if (undefined === items) return;
      for (var x in items) {
        if ("object" !== typeof items[x]) continue;
        var path = items[x].getElementsByTagName("path")[0];
        if (undefined !== path) {
          // set line opacity
          path.style.strokeOpacity = opacity;
        }

        // set bullet opacity
        let bullets;
        if (UIFunctions.isIE() != false)
          bullets = items[x].querySelectorAll("." + "amcharts-graph-bullet");
        else bullets = items[x].getElementsByClassName("amcharts-graph-bullet");
        for (var y in bullets) {
          if ("object" !== typeof bullets[y]) continue;
          bullets[y].style.fillOpacity = opacity;
        }

        // set label opacity
        let labels;
        UIFunctions.isIE() != false
          ? (labels = items[x].querySelectorAll("." + "amcharts-graph-label"))
          : (labels = items[x].getElementsByClassName("amcharts-graph-label"));
        for (let y in labels) {
          if ("object" !== typeof labels[y]) continue;
          labels[y].style.opacity = opacity == 1 ? 1 : 0;
        }
      }
    }
    function setLegendOpacity(graph, opacity) {
      var container = graph.chart.div;
      var className = "amcharts-legend-item-" + graph.id;
      let items;
      UIFunctions.isIE() != false
        ? (items = container.querySelectorAll("." + className))
        : (items = container.getElementsByClassName(className));
      if (undefined === items) return;
      for (var x in items) {
        if ("object" !== typeof items[x]) continue;
        var path = items[x].getElementsByTagName("path")[0];
        if (undefined !== path) {
          // set legend opacity
          path.style.fillOpacity = opacity;
        }
        // set label opacity
        let labels;
        UIFunctions.isIE() != false
          ? (labels = items[x].querySelectorAll("." + "amcharts-legend-label"))
          : (labels = items[x].getElementsByClassName("amcharts-legend-label"));
        for (var y in labels) {
          if ("object" !== typeof labels[y]) continue;
          labels[y].style.opacity = opacity;
        }
      }
    }
    // console.log(activeCategoryId + "-----Active-----" + `activeChartId`);

    const onStyle = {
      color: "#306ec9",
      fontSize: 20,
      padding: "0px 14px"
    };
    const offStyle = {
      color: "#8E9193",
      fontSize: 20,
      padding: "0px 14px"
    };
    function getExportFields(chartId) {
      let exportFields = [];
      if (chartId == 4) {
        exportFields.push("Manufacturer");
        exportFields.push("Count");
      } else if (chartId == 3) {
        exportFields.push("breadcrumb");
        exportFields.push("count");
      } else if (chartId == 2) {
        exportFields.push("ModelNo");
        exportFields.push("Count");
      } else if (chartId == 1) {
        // exportFields.push("location");
        exportFields.push("breadcrumb");
        exportFields.push("count");
        // exportFields.push("location");
      }

      return exportFields;
    }
    function getColumnNames(chartId) {
      let obj = {};
      if (chartId == 4) {
        obj.Count = "Number of Assets";
        obj.breadcrumb = "Manufacturer";
        obj.Manufacturer = "Manufacturer";
      } else if (chartId == 3) {
        obj.count = "Number of Assets";
        obj.breadcrumb = "Organization";
        // obj.OU = "Organization";
      } else if (chartId == 2) {
        obj.Count = "Number of Assets";
        obj.breadcrumb = "ModelNo";
        obj.ModelNo = "Model Number";
      } else if (chartId == 1) {
        obj.count = "Number of Assets";
        obj.breadcrumb = "Location";
        //  obj.location = "Lowest location unit";
      }
      return obj;
    }
    function getExportFieldsHealth(chartId) {
      let exportFields = [];
      if (chartId == 8) {
        exportFields.push("propertyName");
        exportFields.push("GREEN");
        exportFields.push("YELLOW");
        exportFields.push("RED");
        exportFields.push("percentageGREEN");
        exportFields.push("percentageYELLOW");
        exportFields.push("percentageRED");
      }
      if (chartId == 7) {
        exportFields.push("propertyName");
        exportFields.push("GREEN");
        exportFields.push("YELLOW");
        exportFields.push("RED");
        exportFields.push("percentageGREEN");
        exportFields.push("percentageYELLOW");
        exportFields.push("percentageRED");
      }
      if (chartId == 6) {
        exportFields.push("propertyName");
        exportFields.push("GREEN");
        exportFields.push("YELLOW");
        exportFields.push("RED");
        exportFields.push("percentageGREEN");
        exportFields.push("percentageYELLOW");
        exportFields.push("percentageRED");
      }
      if (chartId == 5) {
        exportFields.push("propertyName");
        exportFields.push("GREEN");
        exportFields.push("YELLOW");
        exportFields.push("RED");
        exportFields.push("percentageGREEN");
        exportFields.push("percentageYELLOW");
        exportFields.push("percentageRED");
      }
      if (chartId == 20) {
        exportFields.push("propertyName");
        exportFields.push("GREEN");
        exportFields.push("YELLOW");
        exportFields.push("RED");
        exportFields.push("percentageGREEN");
        exportFields.push("percentageYELLOW");
        exportFields.push("percentageRED");
      }
      if (chartId == 19) {
        exportFields.push("propertyName");
        exportFields.push("GREEN");
        exportFields.push("YELLOW");
        exportFields.push("RED");
        exportFields.push("percentageGREEN");
        exportFields.push("percentageYELLOW");
        exportFields.push("percentageRED");
      }

      return exportFields;
    }
    function getColumnNamesHealth(chartId) {
      let obj = {};
      if (chartId == 8) {
        obj.propertyName = "Serial Number";
        //obj.AssetName = "Serial Number";
        obj.GREEN = "Number of Green Indicators";
        obj.RED = "Number of Red Indicators";
        obj.YELLOW = "Number of Yellow Indicators";
        obj.percentageGREEN = " Percentage of Green Indicators";
        obj.percentageRED = "Percentage of Red Indicators";
        obj.percentageYELLOW = "Percentage of Yellow Indicators";
      }
      if (chartId == 7) {
        obj.propertyName = "Organization";
        obj.GREEN = "Number of Green Indicators";
        obj.RED = "Number of Red Indicators";
        obj.YELLOW = "Number of Yellow Indicators";
        obj.percentageGREEN = " Percentage of Green Indicators";
        obj.percentageRED = "Percentage of Red Indicators";
        obj.percentageYELLOW = "Percentage of Yellow Indicators";
      }
      if (chartId == 6) {
        obj.propertyName = "Model Number";
        //obj.AssetName = "Model Number";
        obj.GREEN = "Number of Green Indicators";
        obj.RED = "Number of Red Indicators";
        obj.YELLOW = "Number of Yellow Indicators";
        obj.percentageGREEN = " Percentage of Green Indicators";
        obj.percentageRED = "Percentage of Red Indicators";
        obj.percentageYELLOW = "Percentage of Yellow Indicators";
      }
      if (chartId == 5) {
        obj.propertyName = "Location";
        obj.GREEN = "Number of Green Indicators";
        obj.RED = "Number of Red Indicators";
        obj.YELLOW = "Number of Yellow Indicators";
        obj.percentageGREEN = " Percentage of Green Indicators";
        obj.percentageRED = "Percentage of Red Indicators";
        obj.percentageYELLOW = "Percentage of Yellow Indicators";
      }
      if (chartId == 20) {
        obj.propertyName = "Asset Number";
        obj.GREEN = "Number of Green Indicators";
        obj.RED = "Number of Red Indicators";
        obj.YELLOW = "Number of Yellow Indicators";
        obj.percentageGREEN = " Percentage of Green Indicators";
        obj.percentageRED = "Percentage of Red Indicators";
        obj.percentageYELLOW = "Percentage of Yellow Indicators";
      }
      if (chartId == 19) {
        obj.propertyName = "Equipment Number";
        obj.GREEN = "Number of Green Indicators";
        obj.RED = "Number of Red Indicators";
        obj.YELLOW = "Number of Yellow Indicators";
        obj.percentageGREEN = " Percentage of Green Indicators";
        obj.percentageRED = "Percentage of Red Indicators";
        obj.percentageYELLOW = "Percentage of Yellow Indicators";
      }

      return obj;
    }
    function isShowAllDisabled() {
      if (!self.state.graphObject) return true;
      if (!self.state.graphObj) return true;
      var allGraphs = self.state.graphObject.chart.graphs.length;
      var selection = self.state.graphObj.length;
      //console.log("isShowAllDisabled", allGraphs, selection);
      if (allGraphs > selection) return false;
      return true;
    }
    function isHideAllDisabled() {
      if (!self.state.graphObject) return true;
      if (!self.state.graphObj) return true;
      var selection = self.state.graphObj.length;
      //console.log("isHideAllDisabled", allGraphs, selection);
      if (0 < selection) return false;
      return true;
    }
    config.export = {
      enabled: true,

      processData: function(data) {
        return data;
      },

      backgroundColor: "#000",
      fallback: false,
      menu: [
        {
          class:
            activeCategoryId == 1
              ? "export-main amcharts-export-custom"
              : "export-main amcharts-export-custom-utilization",
          menu: ["PNG", "JPG", "CSV", "PDF"]
        }
      ]
    };
    if (activeCategoryId == 1) {
      config.export.columnNames = getColumnNames(activeChartId);
      config.export.exportFields = getExportFields(activeChartId);
    }
    if (activeCategoryId == 2) {
      config.export.columnNames = getColumnNamesHealth(activeChartId);
      config.export.exportFields = getExportFieldsHealth(activeChartId);
    }
    // if (activeCategoryId == 3) {
    //   console.log(activeCategoryId + "-----activeCategoryId-----");
    //   console.log(activeChartId + "-----activeChartId-----");
    //   config.export.columnNames = getColumnNamesUtilization(
    //     activeChartId,
    //     config
    //   );
    //   config.export.exportFields = getExportFieldsUtilization(
    //     activeChartId,
    //     config
    //   );
    // }
    if (Object.keys(config).length < 3) {
      //filter out invalid configs
      config = undefined;
    }
    return (
      <div
        className="container utilization"
        id="utilization-chart-wrapper"
        style={{ background: "#EEE", borderRadius: "3px" }}
      >
        <div className="chartFooter">
          <ChartFooter
            chartViewData={tabModelStore.chartViewData}
            chartCategoryData={tabModelStore.chartCategoryData}
            activeTab={tabModelStore.activeTab}
          />
        </div>
        {activeCategoryId == "4" ? (
          <ServiceDueDate />
        ) : (
          <div>
            <Spin spinning={permissionStore.chartLoading}>
              {config && tabModelStore.dataLoaded ? (
                <div className="chartBg">
                  {activeCategoryId == 3 &&
                  config.dataProvider &&
                  config.dataProvider.length == 0 &&
                  tabModelStore.chartMessage ? (
                    <div className="row">
                      <div
                        className="col-md-2 col-md-offset-5"
                        style={{ margin: "auto" }}
                      >
                        <Alert
                          message={tabModelStore.chartMessage}
                          type="warning"
                        />
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 1 && activeChartId == 4 ? (
                    <div>
                      <AmCharts.React
                        style={{
                          width: "100%",
                          height: this.state.height * 0.8 - 50
                        }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 1 && activeChartId == 3 ? (
                    <div>
                      <AmCharts.React
                        style={{
                          width: "100%",
                          height: this.state.height * 0.8 - 50
                        }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 1 && activeChartId == 2 ? (
                    <div>
                      <AmCharts.React
                        style={{
                          width: "100%",
                          height: this.state.height * 0.8 - 50
                        }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 1 && activeChartId == 1 ? (
                    <div>
                      <AmCharts.React
                        style={{
                          width: "100%",
                          height: this.state.height * 0.8 - 50
                        }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 2 ? (
                    <AmChartsHealth config={config} />
                  ) : (
                    ""
                  )}
                  {/* {activeCategoryId == 3 && config.dataProvider && config.dataProvider.length
                                        ? <AmCharts.React style={{ width: "100%", height:this.state.mainHeight }} options={config} />
                                        : ''
                                    } */}
                  {/* made for assetdetails in utilization chart Sooraj  */}
                  {activeCategoryId == 3 &&
                  activeChartId == 9 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <AmCharts.React
                        style={{ width: "100%", height: this.state.mainHeight }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 3 &&
                  activeChartId == 12 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <AmCharts.React
                        style={{ width: "100%", height: this.state.mainHeight }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 3 &&
                  activeChartId == 13 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <AmCharts.React
                        style={{ width: "100%", height: this.state.mainHeight }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 3 &&
                  activeChartId == 14 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <div
                        className="amcharts-div"
                        style={{
                          position: "relative",
                          width: "100%",
                          height: this.state.chartDetailstoggle
                            ? this.state.height * 0.63
                            : this.state.mainHeight
                        }}
                      >
                        <AmCharts.React
                          style={{
                            width: "100%",
                            height: this.state.chartDetailstoggle
                              ? this.state.height * 0.63
                              : this.state.mainHeight
                          }}
                          options={config}
                        />
                      </div>
                      <AssetDetails
                        height={this.state.height * 0.2}
                        type={activeChartId}
                        value={this.state.valueProp}
                        chartDetailstoggle={this.state.chartDetailstoggle}
                        time={new Date()}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 3 &&
                  activeChartId == 15 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <div
                        className="amcharts-div"
                        style={{
                          position: "relative",
                          width: "100%",
                          height: this.state.chartDetailstoggle
                            ? this.state.height * 0.63
                            : this.state.mainHeight
                        }}
                      >
                        <AmCharts.React
                          style={{
                            width: "100%",
                            height: this.state.chartDetailstoggle
                              ? this.state.height * 0.63
                              : this.state.mainHeight
                          }}
                          options={config}
                        />
                      </div>
                      <AssetDetails
                        height={this.state.height * 0.2}
                        type={activeChartId}
                        value={this.state.valueProp}
                        chartDetailstoggle={this.state.chartDetailstoggle}
                        time={new Date()}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 3 &&
                  activeChartId == 16 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <div
                        className="amcharts-div"
                        style={{
                          position: "relative",
                          width: "100%",
                          height: this.state.chartDetailstoggle
                            ? this.state.height * 0.63
                            : this.state.mainHeight
                        }}
                      >
                        <AmCharts.React
                          style={{
                            width: "100%",
                            height: this.state.chartDetailstoggle
                              ? this.state.height * 0.63
                              : this.state.mainHeight
                          }}
                          options={config}
                        />
                      </div>
                      <AssetDetails
                        height={this.state.height * 0.2}
                        type={activeChartId}
                        value={this.state.valueProp}
                        chartDetailstoggle={this.state.chartDetailstoggle}
                        time={new Date()}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 3 &&
                  activeChartId == 17 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <AmCharts.React
                        style={{ width: "100%", height: this.state.mainHeight }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}
                  {activeCategoryId == 3 &&
                  activeChartId == 18 &&
                  config.dataProvider &&
                  config.dataProvider.length ? (
                    <div>
                      <AmCharts.React
                        style={{ width: "100%", height: this.state.mainHeight }}
                        options={config}
                      />
                    </div>
                  ) : (
                    ""
                  )}

                  {tabModelStore.previousChartConfig.length ? (
                    <Button onClick={this.drillUp.bind(this)}>Go Back </Button>
                  ) : (
                    ""
                  )}
                </div>
              ) : (
                <Spin tip="Loading..." delay={500}>
                  <div style={{ padding: "40%" }} />
                </Spin>
              )}
            </Spin>
          </div>
        )}
        {tabModelStore.dataLoaded &&
        ((activeCategoryId == 3 && activeChartId == 9) ||
          (activeCategoryId == 3 && activeChartId == 12) ||
          (activeCategoryId == 3 && activeChartId == 13) ||
          (activeCategoryId == 3 && activeChartId == 17) ||
          (activeCategoryId == 3 && activeChartId == 18)) ? (
          <div
            className="button-showall"
            style={{
              position: "fixed",
              //top: this.state.mainHeight - 60,
              top: this.state.mainHeight - 70,
              right: "-5px",
              zIndex: "1000",
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "center",
              paddingTop: "10px",
              backgroundColor: permissionStore.chartLoading ? "" : "#2e3439"
            }}
          >
            <Button
              size="small"
              onClick={this.showAll}
              disabled={isShowAllDisabled()}
            >
              Show All
            </Button>
            <Button
              size="small"
              onClick={this.hideAll}
              disabled={isHideAllDisabled()}
            >
              Hide All
            </Button>
          </div>
        ) : (
          ""
        )}
        {tabModelStore.dataLoaded &&
        ((activeCategoryId == 3 && activeChartId == 14) ||
          (activeCategoryId == 3 && activeChartId == 15) ||
          (activeCategoryId == 3 && activeChartId == 16)) ? (
          <div>
            <div
              style={{
                position: "fixed",
                bottom: this.state.footerHeight - 8,
                right: "46px",
                marginTop: 3,
                zIndex: "1000",
                display: "flex",
                justifyContent: "flex-end",
                alignItems: "center"
              }}
            >
              <Tooltip
                placement="bottom"
                title={
                  this.state.chartDetailstoggle ? (
                    <span>Disable details mode</span>
                  ) : (
                    <span>Enable details mode</span>
                  )
                }
              >
                <Switch
                  checkedChildren="ON"
                  unCheckedChildren="OFF"
                  checked={this.state.chartDetailstoggle}
                  onClick={this.toggleDetails}
                  onChange={this.hideAll}
                />
              </Tooltip>
              <i
                className="icon-book-open"
                style={this.state.chartDetailstoggle ? onStyle : offStyle}
              />
            </div>
            <div
              className="button-showall"
              style={{
                position: "fixed",
                top: this.state.chartDetailstoggle
                  ? this.state.mainHeight * 0.65 + 20
                  : this.state.mainHeight - 70,
                right: "-5px",
                zIndex: "1000",
                display: "flex",
                justifyContent: "flex-end",
                alignItems: "center",
                paddingTop: "10px",
                backgroundColor: permissionStore.chartLoading ? "" : "#2e3439"
              }}
            >
              <Button
                size="small"
                onClick={this.showAll}
                disabled={isShowAllDisabled()}
              >
                Show All
              </Button>
              <Button
                size="small"
                onClick={this.hideAll}
                disabled={isHideAllDisabled()}
              >
                Hide All
              </Button>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    );
  }
}

export default Charts;
