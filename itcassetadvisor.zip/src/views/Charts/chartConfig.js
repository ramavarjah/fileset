import tabModelStore from "../../stores/tabModelStore";

// HIDE AND SHOW LEGEND ITEMS
function hideOthers(e) {
  var currentGraph = e.dataItem;
  var hidden = true;
  //check if we clicked on this graph before and if all the other graphs are visible.
  // if we clicked on this graph before and the other graphs are invisible,
  // make them visible, otherwise default to previous behavior
  if (e.chart.lastClicked == currentGraph.id && e.chart.allVisible == false) {
    hidden = false;
    e.chart.allVisible = true;
  } else {
    e.chart.allVisible = false;
  }
  e.chart.lastClicked = currentGraph.id; //keep track of the current one we clicked

  currentGraph.hidden = false; //force clicked graph to stay visible
  e.chart.graphs.forEach(function(graph) {
    if (graph.id !== currentGraph.id) {
      graph.hidden = hidden; //set the other graph's visibility based on the rules above
    }
  });
  // update the chart with newly set hidden values
  e.chart.validateNow();
}

//======================================
const CHART_CONFIG = {
  //assetCountByManucaturer
  barChart: {
    hideCredits: true,
    type: "serial",
    categoryField: "Manufacturer",
    columnWidth: 0.4,
    marginBottom: 5,
    marginLeft: 5,
    marginRight: 10,
    marginTop: 5,
    sequencedAnimation: false,
    startDuration: 0,
    startEffect: "easeInSine",
    color: "#E7E7E7",
    fontFamily: "Open Sans", //---cos
    theme: "light",
    categoryAxis: {
      autoWrap: true,
      gridPosition: "start",
      title: ""
    },
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    valueScrollbar: {
      enabled: true,
      graph: "AmGraph-1",
      graphType: "column"
    },
    /*
        "chartCursor": {
            "enabled": true,
            "categoryBalloonEnabled": false,
            "categoryBalloonText": "[[category]]",
            "cursorColor": "#FFFFFF",
            "valueLineBalloonColor": "#FFFFFF",
            "legendColor": "#FFFFFF",
            "oneBalloonOnly": true
        },
        */
    chartScrollbar: {
      enabled: true
    },
    trendLines: [],
    graphs: [
      {
        //"accessibleLabel": "[[title]] [[Manufacturer]] [[value]]",
        accessibleLabel: "[[title]] [[value]] [[Manufacturer]]",
        //"balloonText": "Unit: [[Manufacturer]]\nAsset Count: [[Count]]",
        balloonText:
          "<span><b>Asset Count: [[Count]]</b>\n [[Manufacturer]]</span>",
        fillAlphas: 0.7, //--cos
        fillColors: "#00ff9c",
        //"fillColors": "#33ffbc",
        //"fillColors": "#8cb5fc",
        lineColor: "#00ff9c",
        //"lineColor": "#33ffbc",
        //"lineColor": "#8CB5FC",
        showHandOnHover: true,
        id: "AmGraph-1",
        labelText: "",
        title: "graph 1",
        type: "column",
        valueField: "Count"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        integersOnly: true,
        minimum: 0,
        title: "Asset Count"
      }
    ],
    allLabels: [],
    balloon: {
      disableMouseEvents: false,
      //-------------------------------------------COS
      adjustBorderColor: true,
      borderAlpha: 0,
      fillAlphas: 1,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      fillColor: "#ffffff",
      verticalPadding: 10,
      horizontalPadding: 12,
      fontSize: 13,
      textAlign: "left"
    },

    chartCursor: {
      valueLineEnabled: true,
      valueLineBalloonEnabled: true,
      cursorColor: "#f1f1f1",
      color: "#000000"
    },
    //-------------------------------------------END
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  /*
    lineChart: {
        "hideCredits":true,
        "type": "serial",
        "theme": "light", //---COS
        "categoryField": "date",
        "dataDateFormat": "YYYY-MM-DD",
        "mouseWheelScrollEnabled": true,
        "color": "#E7E7E7",
        "fontFamily": "Open Sans", //---COS
        "export": {
            "enabled": true,
            "menu": [],
            "backgroundColor": "#2b2c33"
        },
        "categoryAxis": {
            "minPeriod": "DD",
            "parseDates": true
        },
        "trendLines": [],
        "graphs": [],
        "guides": [],
        "valueAxes": [{
            "id": "ValueAxis-1",
            "title": "Events", //---COS
            "includeHidden": true //---COS
        }],
        "allLabels": [],
        "balloon": {
            "adjustBorderColor": false,
            "borderAlpha": 0,
            "borderThickness": 0,
            "pointerOrientation": "down",
            "color": "#000000",
            "cornerRadius": 3,
            "verticalPadding": 10,
            "horizontalPadding": 12,
            "fontSize": 13,
            "textAlign": "left"
        },
        "legend": {
            "enabled": true,
            "useGraphSettings": false,
            "switchable": true,
            "rollOverGraphAlpha": 0.35,
            "horizontalGap": 3,
            "valueText": "",
            "markerLabelGap": 7,
            "color": "#FFFFFF",
            "fontSize": 13,
            "markerType": "square",
            "position": "right",
            "marginBottom": 130,
            "labelWidth": 130,
            "markerSize": 12,
            "listeners": [{
                "event": "showItem",
                // "method": hideOthers
            }, {
                "event": "hideItem",
                // "method": hideOthers
            }]
        },
       
        "chartScrollbar": {
            "graph": "ValueAxis-1",
            "oppositeAxis": true,
            "offset": 10,
            "scrollbarHeight": 30,
            "backgroundAlpha": 0,
            "selectedBackgroundAlpha": 0.1,
            "selectedBackgroundColor": "#888888",
            "graphFillAlpha": 0,
            "graphLineAlpha": 0.5,
            "selectedGraphFillAlpha": 0,
            "selectedGraphLineAlpha": 1,
            "autoGridCount": true,
            "color": "#AAAAAA"
        "titles": [{
            "id": "Title-1",
            "size": 15,
            "text": ""
        }],
        "dataProvider": []
    },*/
  //==================================
  // ASSET COUNT > LOCATION ++++++++++
  //==================================
  assetCountByLoc: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    categoryField: "location",
    columnWidth: 0.4,
    marginBottom: 5,
    marginLeft: 5,
    marginRight: 10,
    marginTop: 5,
    sequencedAnimation: false,
    startDuration: 0,
    startEffect: "easeInSine",
    color: "#E7E7E7",
    fontFamily: "Open Sans",

    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    categoryAxis: {
      autoWrap: true,
      gridPosition: "start",
      title: ""
    },
    valueScrollbar: {
      //"enabled": false,
      //"graph": "AmGraph-1",
      //"graphType": "column"
    },
    chartScrollbar: {
      //"enabled": true,
    },
    trendLines: [],
    graphs: [
      {
        accessibleLabel: "[[title]] [[value]] [[location]]",
        balloonText:
          "<span><b>Asset Count: [[count]]</b>\n [[breadcrumb]]</span>",
        fillAlphas: 0.7,
        fillColors: "#00ff9c",
        lineColor: "#00ff9c",
        showHandOnHover: true,
        id: "AmGraph-1",
        labelText: "",
        title: "graph 1",
        type: "column",
        valueField: "count"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        integersOnly: true,
        minimum: 0,
        title: "Asset Count"
      }
    ],
    allLabels: [],
    balloon: {
      disableMouseEvents: false,
      adjustBorderColor: true,
      borderAlpha: 0,
      fillAlphas: 1,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      fillColor: "#ffffff",
      //"shadowAlpha": 1,
      //"shadowColor": "#000000",
      //"cornerRadius": 3,
      verticalPadding: 10,
      fontSize: 13,
      textAlign: "left"
    },
    chartCursor: {
      valueLineEnabled: true,
      valueLineBalloonEnabled: true,
      cursorColor: "#f1f1f1",
      color: "#000000"
    },
    titles: [
      {
        bold: true,
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  assetCountByModelNo: {
    hideCredits: true,
    type: "serial",
    categoryField: "ModelNo",
    columnWidth: 0.4,
    marginBottom: 5,
    marginLeft: 5,
    marginRight: 10,
    marginTop: 5,
    sequencedAnimation: false,
    startDuration: 0,
    startEffect: "easeInSine",
    color: "#E7E7E7",
    fontFamily: "Open Sans", //--cos
    //"fontFamily": "Roboto",
    theme: "light",
    categoryAxis: {
      autoWrap: true,
      gridPosition: "start",
      title: ""
    },
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    valueScrollbar: {
      enabled: true,
      graph: "AmGraph-1",
      graphType: "column"
    },
    chartCursor: {
      enabled: true,
      categoryBalloonEnabled: false,
      categoryBalloonText: "[[category]]",
      cursorColor: "#FFFFFF",
      valueLineBalloonColor: "#FFFFFF",
      legendColor: "#FFFFFF",
      oneBalloonOnly: true
    },
    chartScrollbar: {
      enabled: true
    },
    trendLines: [],
    graphs: [
      {
        //"accessibleLabel": "[[title]] [[value]] [[ModelNo]]",
        accessibleLabel: "[[value]] [[title]] [[ModelNo]]",
        //"balloonText": "Asset Count: [[Count]]",
        balloonText: "<span><b>Asset Count: [[Count]]</b>\n [[ModelNo]]</span>",
        fillAlphas: 0.7, //--cos
        fillColors: "#00ff9c",
        //"fillColors": "#33ffbc",
        //"fillColors": "#8cb5fc",
        lineColor: "#00ff9c",
        //"lineColor": "#33ffbc",
        //"lineColor": "#8CB5FC",
        showHandOnHover: true,
        id: "AmGraph-1",
        labelText: "",
        title: "graph 1",
        type: "column",
        valueField: "Count"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        integersOnly: true,
        minimum: 0,
        title: "Asset Count"
      }
    ],
    allLabels: [],
    balloon: {
      disableMouseEvents: false,
      //-------------------------------------------COS
      adjustBorderColor: true,
      borderAlpha: 0,
      fillAlphas: 1,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      fillColor: "#ffffff",
      //"shadowAlpha": 1,
      //"shadowColor": "#000000",
      //"cornerRadius": 3,
      verticalPadding: 10,
      fontSize: 13,
      textAlign: "left"
    },
    /*
        "legend": {
           "enabled": true,
           "useGraphSettings": false,
           "switchable": true,
           "markerLabelGap": 1,
           "color": "#FFFFFF",
           "fontSize": 13,
           "markerType": "square",
           "position": "right",
           "marginTop": 0,
           "divId": "count-legend-div",
           "labelText": "",
           "markerSize": 12
        },
        */

    //-------------------------------------------END
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  assetCountByOrganization: {
    hideCredits: true,
    type: "serial",
    categoryField: "OU",
    columnWidth: 0.4,
    marginBottom: 5,
    marginLeft: 5,
    marginRight: 10,
    marginTop: 5,
    sequencedAnimation: false,
    startDuration: 0,
    startEffect: "easeInSine",
    color: "#E7E7E7",
    //"fontFamily": "Roboto",
    fontFamily: "Open Sans", //---cos
    theme: "light",
    categoryAxis: {
      autoWrap: true,
      gridPosition: "start",
      title: ""
    },

    listeners: [
      {
        event: "clickGraphItem",
        method: function() {
          // tabModelStore.setDataContext(event.item.dataContext);
          //tabModelStore.setDataContextState("step2");
        }
      }
    ],
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    valueScrollbar: {
      enabled: true,
      graph: "AmGraph-1",
      graphType: "column"
    },
    chartCursor: {
      enabled: true,
      categoryBalloonEnabled: false,
      categoryBalloonText: "[[category]]",
      cursorColor: "#FFFFFF",
      valueLineBalloonColor: "#FFFFFF",
      oneBalloonOnly: true
    },
    chartScrollbar: {
      enabled: true
    },
    /*
        "legend": {
           "enabled": true,
           "useGraphSettings": false,
           "switchable": true,
           "markerLabelGap": 1,
           "color": "#FFFFFF",
           "fontSize": 13,
           "markerType": "square",
           "position": "right",
           "marginTop": 0,
           "divId": "count-legend-div",
           "labelText": "",
           "markerSize": 12
        },
        */
    trendLines: [],
    graphs: [
      {
        //"accessibleLabel": "[[title]] [[OU]] [[value]]",
        accessibleLabel: "[[value]] [[title]] [[OU]]",
        //"balloonText": "Unit: [[breadcrumb]]\nAsset Count: [[count]]",
        balloonText:
          "<span><b>Asset Count: [[count]]</b>\n [[breadcrumb]]</span>",
        fillAlphas: 0.7, //---cos
        fillColors: "#00ff9c",
        //"fillColors": "#33ffbc",
        //"fillColors": "#8cb5fc",
        lineColor: "#00ff9c",
        //"lineColor": "#33ffbc",
        //"lineColor": "#8CB5FC",
        showHandOnHover: true,
        id: "AmGraph-1",
        labelText: "",
        title: "graph 1",
        type: "column",
        valueField: "count"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        integersOnly: true,
        minimum: 0,
        title: "Asset Count"
      }
    ],
    allLabels: [],
    balloon: {
      disableMouseEvents: false,
      //-------------------------------------------COS
      adjustBorderColor: true,
      borderAlpha: 0,
      fillAlphas: 1,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      fillColor: "#ffffff",
      shadowAlpha: 1,
      shadowColor: "#000000",
      cornerRadius: 0,
      verticalPadding: 10,
      fontSize: 13,
      textAlign: "left"
      //-------------------------------------------END
    },
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  assetHealthBylocation: {
    hideCredits: true,
    type: "serial",
    categoryField: "location",
    startDuration: 0,
    color: "#E7E7E7",
    categoryAxis: {
      gridPosition: "start"
    },

    // "listeners": [{
    //     "event": "clickGraphItem",
    //     "method": clickmethod
    // }],
    chartScrollbar: {
      enabled: true
    },
    trendLines: [],
    graphs: [
      {
        fillAlphas: 0.8,
        id: "AmGraph-1",
        title: "graph 1",
        type: "column",
        fillColors: "#6ae69b",
        lineThickness: 0,
        valueField: "GREEN"
      },
      {
        fillAlphas: 0.8,
        id: "AmGraph-2",
        title: "graph 2",
        type: "column",
        lineThickness: 0,
        fillColors: "#ffe345",
        valueField: "YELLOW"
      },
      {
        fillAlphas: 0.8,
        id: "AmGraph-3",
        title: "graph 3",
        type: "column",
        lineThickness: 0,
        fillColors: "#ff4545",
        valueField: "RED"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        stackType: "regular",
        title: "Axis title"
      }
    ],
    allLabels: [],
    balloon: {},
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],

    dataProvider: []
  },
  assetHealthByCount: {
    hideCredits: true,
    type: "serial",
    categoryField: "propertyName",
    startDuration: 0,
    color: "#E7E7E7",
    categoryAxis: {
      gridPosition: "start"
    },
    // "chartScrollbar": {
    //     "enabled": true
    // },
    trendLines: [],
    graphs: [
      {
        fillAlphas: 1,
        balloonText: "[[title]] of [[category]]:[[value]]",
        id: "AmGraph-1",
        title: "Green indicators",
        type: "column",
        lineColor: "#6ae69b",
        fillColors: "#6ae69b",
        lineThickness: 0,
        valueField: "GREEN"
      },
      {
        fillAlphas: 1,
        balloonText: "[[title]] of [[category]]:[[value]]",
        id: "AmGraph-2",
        title: "Yellow indicators",
        type: "column",
        lineThickness: 0,
        lineColor: "#ffe345",
        fillColors: "#ffe345",
        valueField: "YELLOW"
      },
      {
        fillAlphas: 1,
        balloonText: "[[title]] of [[category]]:[[value]]",
        id: "AmGraph-3",
        title: "Red indicators",
        type: "column",
        lineThickness: 0,
        lineColor: "#ff4545",
        fillColors: "#ff4545",
        valueField: "RED"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        stackType: "regular",
        title: "Health Indicators"
      }
    ],
    allLabels: [],
    balloon: {},
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    // "listeners": [{
    //     "event": "clickGraphItem",
    //     "method": function(event){
    // // tabModelStore.setDataContext(event.item.dataContext);
    //  //tabModelStore.setDataContextState("step2");
    //     }
    // }],
    dataProvider: []
  },
  assetHealthByCountDrillDown: {
    hideCredits: true,
    type: "serial",
    categoryField: "date",
    dataDateFormat: "YYYY-MM-DD",
    startDuration: 0,
    color: "#E7E7E7",
    categoryAxis: {
      minPeriod: "DD",
      parseDates: true
    },
    chartScrollbar: {
      enabled: true
    },
    trendLines: [],
    graphs: [
      {
        fillAlphas: 1,
        balloonText: "[[title]] on [[category]]:[[value]]",
        id: "AmGraph-1",
        title: "Green indicators",
        type: "column",
        lineColor: "#6ae69b",
        fillColors: "#6ae69b",
        lineThickness: 0,
        valueField: "GREEN"
      },
      {
        fillAlphas: 1,
        balloonText: "[[title]] on [[category]]:[[value]]",
        id: "AmGraph-2",
        title: "Yellow indicators",
        type: "column",
        lineThickness: 0,
        lineColor: "#ffe345",
        fillColors: "#ffe345",
        valueField: "YELLOW"
      },
      {
        fillAlphas: 1,
        balloonText: "[[title]] on [[category]]:[[value]]",
        id: "AmGraph-3",
        title: "Red indicators",
        type: "column",
        lineThickness: 0,
        lineColor: "#ff4545",
        fillColors: "#ff4545",
        valueField: "RED"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        stackType: "regular",
        title: "Health Indicators"
      }
    ],
    allLabels: [],
    balloon: {},
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    listeners: [
      {
        event: "clickGraphItem",
        method: function() {
          // tabModelStore.setDataContext(event.item.dataContext);
          //tabModelStore.setDataContextState("step2");
        }
      }
    ],
    dataProvider: []
  },
  assetHealthByPercent: {
    hideCredits: true,
    type: "serial",
    categoryField: "propertyName",
    startDuration: 0,
    color: "#E7E7E7",
    categoryAxis: {
      gridPosition: "start"
    },
    trendLines: [],
    graphs: [
      {
        balloonText: "[[title]] of [[category]]:[[percents]]%",
        fillAlphas: 1,
        id: "AmGraph-1",
        title: "Green indicators",
        type: "column",
        lineColor: "#6ae69b",
        fillColors: "#6ae69b",
        valueField: "GREEN"
      },
      {
        balloonText: "[[title]] of [[category]]:[[percents]]%",
        fillAlphas: 1,
        id: "AmGraph-2",
        title: "Yellow indicators",
        type: "column",
        lineColor: "#ffe345",
        fillColors: "#ffe345",
        valueField: "YELLOW"
      },
      {
        balloonText: "[[title]] of [[category]]:[[percents]]%",
        fillAlphas: 1,
        id: "AmGraph-3",
        title: "Red indicators",
        type: "column",
        lineColor: "#ff4545",
        fillColors: "#ff4545",
        valueField: "RED"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        stackType: "100%",
        title: "Health Indicators(%)"
      }
    ],
    allLabels: [],
    balloon: {},
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  // assetHealthByPercent:{
  //     "type": "serial",
  //     "theme": "light",
  //     "color": "#E7E7E7",
  //     "legend": {
  //       "autoMargins": false,
  //       "borderAlpha": 0.2,
  //       "equalWidths": false,
  //       "horizontalGap": 10,
  //       "markerSize": 10,
  //     //   "useGraphSettings": true,
  //       "valueAlign": "left",
  //       "valueWidth": 0
  //     },
  //     "dataProvider": [],
  //     "valueAxes": [
  //       {
  //         "stackType": "100%",
  //         "axisAlpha": 0,
  //         "gridAlpha": 0,
  //         // "labelsEnabled": false,
  //         "position": "left"
  //       }
  //     ],
  //     "graphs": [
  //       {
  //         // "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
  //         "fillAlphas": 0.9,
  //         "fontSize": 11,
  //         "labelText": "[[percents]]%",
  //         "lineAlpha": 0.5,
  //         "fillColors": "#ff4545",
  //         "fillColors": "#6ae69b",
  //         "valueField": "GREEN"

  //       },
  //       {
  //         // "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
  //         "fillAlphas": 0.9,
  //         "fontSize": 11,
  //         "labelText": "[[percents]]%",
  //         "lineAlpha": 0.5,
  //         "type": "column",
  //         "fillColors": "#ffe345",
  //         "valueField": "YELLOW"
  //       },
  //       {
  //         // "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
  //         "fillAlphas": 0.9,
  //         "fontSize": 11,
  //         "labelText": "[[percents]]%",
  //         "lineAlpha": 0.5,
  //         "type": "column",
  //         "type": "column",
  //         "fillColors": "#ff4545",
  //         "valueField": "RED"
  //       }
  //     ],
  //     "marginTop": 30,
  //     "marginRight": 0,
  //     "marginLeft": 0,
  //     "marginBottom": 40,
  //     "autoMargins": false,
  //     "categoryField": "propertyName",
  //     "chartScrollbar": {
  //         "enabled": true
  //     },
  //     "trendLines": [],
  //     "categoryAxis": {
  //       "gridPosition": "start",
  //       "axisAlpha": 0,
  //       "gridAlpha": 0
  //     },
  //     "listeners": [{
  //         "event": "clickGraphItem",
  //         "method": function(event){}
  //     }],
  //     "export": {
  //       "enabled": true
  //     }
  // },
  assetHealthByPercentDrillDown: {
    hideCredits: true,
    type: "serial",
    categoryField: "date",
    dataDateFormat: "YYYY-MM-DD",
    startDuration: 0,
    color: "#E7E7E7",
    categoryAxis: {
      minPeriod: "DD",
      parseDates: true
    },

    trendLines: [],
    graphs: [
      {
        balloonText: "[[title]] on [[category]]:[[percents]]%",
        fillAlphas: 1,
        id: "AmGraph-1",
        title: "Green indicators",
        type: "column",
        lineColor: "#6ae69b",
        fillColors: "#6ae69b",
        valueField: "GREEN"
      },
      {
        balloonText: "[[title]] on [[category]]:[[percents]]%",
        fillAlphas: 1,
        id: "AmGraph-2",
        title: "Yellow indicators",
        type: "column",
        lineColor: "#ffe345",
        fillColors: "#ffe345",
        valueField: "YELLOW"
      },
      {
        balloonText: "[[title]] on [[category]]:[[percents]]%",
        fillAlphas: 1,
        id: "AmGraph-3",
        title: "Red indicators",
        type: "column",
        lineColor: "#ff4545",
        fillColors: "#ff4545",
        valueField: "RED"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        stackType: "100%",
        title: "Health Indicators(%)"
      }
    ],
    allLabels: [],
    balloon: {},
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  // assetHealthByPercentDrillDown:{
  //     "type": "serial",
  //     "theme": "light",
  //     "legend": {
  //       "autoMargins": false,
  //       "borderAlpha": 0.2,
  //       "equalWidths": false,
  //       "horizontalGap": 10,
  //       "markerSize": 10,
  //       "useGraphSettings": true,
  //       "valueAlign": "left",
  //       "valueWidth": 0
  //     },
  //     "dataProvider": [],
  //     "valueAxes": [
  //       {
  //         "stackType": "100%",
  //         "axisAlpha": 0,
  //         "gridAlpha": 0,
  //         "labelsEnabled": false,
  //         "position": "left"
  //       }
  //     ],
  //     "color": "#E7E7E7",
  //     "graphs": [
  //       {
  //         "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
  //         "fillAlphas": 0.9,
  //         "fontSize": 11,
  //         "labelText": "[[percents]]%",
  //         "lineAlpha": 0.5,
  //         "fillColors": "#ff4545",
  //         "fillColors": "#6ae69b",
  //         "valueField": "GREEN"

  //       },
  //       {
  //         "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
  //         "fillAlphas": 0.9,
  //         "fontSize": 11,
  //         "labelText": "[[percents]]%",
  //         "lineAlpha": 0.5,
  //         "type": "column",
  //         "fillColors": "#ffe345",
  //         "valueField": "YELLOW"
  //       },
  //       {
  //         "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
  //         "fillAlphas": 0.9,
  //         "fontSize": 11,
  //         "labelText": "[[percents]]%",
  //         "lineAlpha": 0.5,
  //         "type": "column",
  //         "type": "column",
  //         "fillColors": "#ff4545",
  //         "valueField": "RED"
  //       }
  //     ],
  //     "marginTop": 30,
  //     "marginRight": 0,
  //     "marginLeft": 0,
  //     "marginBottom": 40,
  //     "autoMargins": false,
  //     "categoryField": "date",
  //     "dataDateFormat": "YYYY-MM-DD",
  //     "categoryAxis": {
  //       "gridPosition": "start",
  //       "minPeriod": "DD",
  //       "parseDates": true
  //     },
  //     "chartScrollbar": {
  //         "enabled": true
  //     },
  //     "trendLines": [],
  //     "listeners": [{
  //         "event": "clickGraphItem",
  //         "method": function(event){}
  //     }],
  //     "export": {
  //       "enabled": true
  //     }
  // },
  assetHealthByOrganization: {
    hideCredits: true,
    type: "serial",
    categoryField: "organization",
    startDuration: 0,
    categoryAxis: {
      gridPosition: "start"
    },
    chartScrollbar: {
      enabled: true
    },
    trendLines: [],
    graphs: [
      {
        fillAlphas: 0.8,
        id: "AmGraph-1",
        title: "graph 1",
        type: "column",
        fillColors: "#6ae69b",
        lineThickness: 0,
        valueField: "GREEN"
      },
      {
        fillAlphas: 0.8,
        id: "AmGraph-2",
        title: "graph 2",
        type: "column",
        lineThickness: 0,
        fillColors: "#ffe345",
        valueField: "YELLOW"
      },
      {
        fillAlphas: 0.8,
        id: "AmGraph-3",
        title: "graph 3",
        type: "column",
        lineThickness: 0,
        fillColors: "#ff4545",
        valueField: "RED"
      }
    ],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        stackType: "regular",
        title: "Axis title"
      }
    ],
    allLabels: [],
    balloon: {},
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  assetHealthBySerial: {
    type: "serial",
    theme: "light", //---COS
    categoryField: "date",
    dataDateFormat: "YYYY-MM-DD",
    mouseWheelScrollEnabled: true,
    color: "#E7E7E7",
    fontFamily: "Open Sans", //---COS
    //"fontFamily": "Roboto",
    //"startEffect": "easeInSine",
    //"startDuration": 0,
    //"sequencedAnimation": false,
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    categoryAxis: {
      minPeriod: "DD",
      parseDates: true
    },

    trendLines: [],
    /*
        "chartCursor": {
               "enabled": true,
               "oneBalloonOnly": true
           },
           "chartScrollbar": {
               "enabled": true,
               "backgroundColor": "#2B2B2B",
               "selectedBackgroundColor": "#5D5D5D"
           },
        */
    graphs: [],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        title: "Events", //---COS
        includeHidden: true //---COS
      }
    ],
    allLabels: [],
    balloon: {
      //-------------------------------------------COS
      adjustBorderColor: false,
      borderAlpha: 0,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      cornerRadius: 3,
      verticalPadding: 10,
      fontSize: 13,
      textAlign: "left"
    },
    legend: {
      enabled: true,
      useGraphSettings: false,
      switchable: true,
      rollOverGraphAlpha: 0.1,
      horizontalGap: 3,
      valueText: "",
      //"spacing": 10,
      //"width": 50,
      markerLabelGap: 7,
      //"showEntries": false,
      color: "#FFFFFF",
      fontSize: 13,
      markerType: "square",
      position: "right",
      marginBottom: 130,
      labelWidth: 130,
      //"labelText": "",
      markerSize: 12,
      listeners: [
        {
          event: "showItem",
          method: hideOthers
        },
        {
          event: "hideItem",
          method: hideOthers
        }
      ]
    },
    chartCursor: {
      valueLineEnabled: true,
      valueLineBalloonEnabled: true,
      cursorColor: "#f1f1f1",
      color: "#000000"
    },
    chartScrollbar: {
      graph: "ValueAxis-1",
      oppositeAxis: true,
      offset: 10,
      scrollbarHeight: 30,
      backgroundAlpha: 0,
      selectedBackgroundAlpha: 0.1,
      selectedBackgroundColor: "#888888",
      graphFillAlpha: 0,
      graphLineAlpha: 0.5,
      selectedGraphFillAlpha: 0,
      selectedGraphLineAlpha: 1,
      autoGridCount: true,
      color: "#AAAAAA"
    },
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  //==================================
  // Utilization > Location ++++++++++
  //==================================
  assetUtilizationByLoc: {
    type: "serial",
    theme: "light",
    addClassNames: true,
    allVisible: true,
    categoryField: "date",
    dataDateFormat: "",
    mouseWheelScrollEnabled: true,
    color: "#E7E7E7",
    colors: [
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C",
      "#FFEA00",
      "#37E2FF",
      "#FF64FF",
      "#3CFF86",
      "#FF0065",
      "#3385ff",
      "#ff9000",
      "#8840FF",
      "#FF8C7A",
      "#00B595",
      "#FF5722",
      "#E3FF8C"
    ],
    fontFamily: "Open Sans",
    hideCredits: true,
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    graphs: [
      {
        labelPosition: "middle"
      }
    ],
    categoryAxis: {
      minPeriod: "DD",
      parseDates: true,
      markPeriodChange: false,
      centerLabels: false,
      axisColor: "#7f848f",
      gridColor: "#C9CEDA",
      dashLength: 5
    },
    valueAxes: [
      {
        id: "ValueAxis-1",
        title: "Utilization Percentage (%)",
        axisColor: "#7f848f",
        gridColor: "#C9CEDA",
        dashLength: 5
      }
    ],
    balloon: {
      adjustBorderColor: false,
      borderAlpha: 0,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      cornerRadius: 3,
      verticalPadding: 10,
      horizontalPadding: 12,
      fontSize: 13,
      textAlign: "left"
    },
    legend: {
      enabled: true,
      useGraphSettings: false,
      switchable: true,
      rollOverGraphAlpha: 0.1,
      horizontalGap: 3,
      valueText: "",
      //"spacing": 10,
      //"width": 50,
      markerLabelGap: 7,
      color: "#FFFFFF",
      fontSize: 13,
      markerType: "square",
      position: "right",
      marginBottom: 130,
      labelWidth: 140,
      markerSize: 12
    },
    chartCursor: {
      oneBalloonOnly: true,
      valueLineEnabled: true,
      valueLineBalloonEnabled: true,
      cursorColor: "#B0BEC5",
      color: "#000000"
    },
    chartScrollbar: {
      oppositeAxis: true,
      offset: 10,
      scrollbarHeight: 30,
      backgroundAlpha: 0,
      selectedBackgroundAlpha: 0.1,
      selectedBackgroundColor: "#888888",
      graphFillAlpha: 0,
      graphLineAlpha: 0.5,
      selectedGraphFillAlpha: 0,
      selectedGraphLineAlpha: 1,
      autoGridCount: true,
      color: "#AAAAAA"
    },
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    allLabels: [],
    trendLines: [],
    guides: [],
    dataProvider: []
  },
  //==================================
  // Utilization > Model Number ++++++
  //==================================
  assetUtilizationByModelNo: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    categoryField: "date",
    dataDateFormat: "YYYY-MM-DD",
    mouseWheelScrollEnabled: true,
    allVisible: true,
    color: "#E7E7E7",
    fontFamily: "Open Sans",
    //"startEffect": "easeInSine",
    //"startDuration": 0,
    //"sequencedAnimation": false,
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    categoryAxis: {
      minPeriod: "DD",
      parseDates: true
    },
    /*
        "chartCursor": {
            "enabled": true,
            "oneBalloonOnly": true
        },
        "chartScrollbar": {
           "enabled": true,
           "backgroundColor": "#2B2B2B",
           "selectedBackgroundColor": "#5D5D5D"
        },
        */
    chartScrollbar: {
      enabled: true
    },
    trendLines: [],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        title: "Utilization Percentage (%)",
        includeHidden: true
      }
    ],
    allLabels: [],
    balloon: {
      adjustBorderColor: false,
      borderAlpha: 0,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      cornerRadius: 3,
      verticalPadding: 10,
      fontSize: 13,
      textAlign: "left"
    },
    legend: {
      enabled: true,
      useGraphSettings: false,
      switchable: true,
      rollOverGraphAlpha: 0.1,
      horizontalGap: 3,
      valueText: "",
      //"spacing": 10,
      //"width": 50,
      markerLabelGap: 7,
      //"showEntries": false,
      color: "#FFFFFF",
      fontSize: 13,
      markerType: "square",
      position: "right",
      marginBottom: 130,
      labelWidth: 130,
      //"labelText": "",
      markerSize: 12,
      listeners: [
        {
          event: "showItem",
          method: hideOthers
        },
        {
          event: "hideItem",
          method: hideOthers
        }
      ]
    },
    chartCursor: {
      valueLineEnabled: true,
      valueLineBalloonEnabled: true,
      cursorColor: "#B0BEC5",
      color: "#000000"
    },

    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  //==================================
  // Utilization > Org +++++++++++++++
  //==================================
  assetUtilizationByOrganization: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    categoryField: "date",
    dataDateFormat: "YYYY-MM-DD",
    mouseWheelScrollEnabled: true,
    allVisible: true,
    color: "#E7E7E7",
    fontFamily: "Open Sans",
    //"startEffect": "easeInSine",
    //"startDuration": 0,
    //"sequencedAnimation": false,
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    categoryAxis: {
      minPeriod: "DD",
      parseDates: true
    },
    /*
        "chartCursor": {
            "enabled": true,
            "oneBalloonOnly": true
        },
        "chartScrollbar": {
           "enabled": true,
           "backgroundColor": "#2B2B2B",
           "selectedBackgroundColor": "#5D5D5D"
        },
        */
    trendLines: [],
    graphs: [],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        title: "Utilization Percentage (%)",
        includeHidden: true
      }
    ],
    allLabels: [],
    balloon: {
      adjustBorderColor: false,
      borderAlpha: 0,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      cornerRadius: 3,
      verticalPadding: 10,
      fontSize: 13,
      textAlign: "left"
    },
    legend: {
      enabled: true,
      useGraphSettings: false,
      switchable: true,
      rollOverGraphAlpha: 0.1,
      horizontalGap: 3,
      valueText: "",
      //"spacing": 10,
      //"width": 50,
      markerLabelGap: 7,
      //"showEntries": false,
      color: "#FFFFFF",
      fontSize: 13,
      markerType: "square",
      position: "right",
      labelWidth: 140,
      marginBottom: 130,
      //"labelText": "",
      markerSize: 12,
      listeners: [
        {
          event: "showItem",
          method: hideOthers
        },
        {
          event: "hideItem",
          method: hideOthers
        }
      ]
    },
    chartCursor: {
      valueLineEnabled: true,
      valueLineBalloonEnabled: true,
      cursorColor: "#B0BEC5",
      color: "#000000"
    },
    chartScrollbar: {
      graph: "ValueAxis-1",
      oppositeAxis: true,
      offset: 10,
      scrollbarHeight: 30,
      backgroundAlpha: 0,
      selectedBackgroundAlpha: 0.1,
      selectedBackgroundColor: "#888888",
      graphFillAlpha: 0,
      graphLineAlpha: 0.5,
      selectedGraphFillAlpha: 0,
      selectedGraphLineAlpha: 1,
      autoGridCount: true,
      color: "#AAAAAA"
    },
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  //==================================
  // Utilization > Serial Number +++++
  //==================================
  assetUtilizationBySerial: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    categoryField: "date",
    dataDateFormat: "YYYY-MM-DD",
    mouseWheelScrollEnabled: true,
    allVisible: true,
    color: "#E7E7E7",
    fontFamily: "Open Sans",
    //"startEffect": "easeInSine",
    //"startDuration": 0,
    //"sequencedAnimation": false,
    export: {
      enabled: true,
      menu: [],
      backgroundColor: "#2b2c33"
    },
    categoryAxis: {
      minPeriod: "DD",
      parseDates: true
    },
    /*
        "chartCursor": {
               "enabled": true,
               "oneBalloonOnly": true
           },
           "chartScrollbar": {
               "enabled": true,
               "backgroundColor": "#2B2B2B",
               "selectedBackgroundColor": "#5D5D5D"
           },
        */
    trendLines: [],
    graphs: [],
    guides: [],
    valueAxes: [
      {
        id: "ValueAxis-1",
        title: "Utilization Percentage (%)",
        includeHidden: true
      }
    ],
    allLabels: [],
    balloon: {
      adjustBorderColor: false,
      borderAlpha: 0,
      borderThickness: 0,
      pointerOrientation: "down",
      color: "#000000",
      cornerRadius: 3,
      verticalPadding: 10,
      fontSize: 13,
      textAlign: "left"
    },
    legend: {
      enabled: true,
      useGraphSettings: false,
      switchable: true,
      rollOverGraphAlpha: 0.1,
      horizontalGap: 3,
      valueText: "",
      //"spacing": 10,
      //"width": 50,
      markerLabelGap: 7,
      //"showEntries": false,
      color: "#FFFFFF",
      fontSize: 13,
      markerType: "square",
      position: "right",
      marginBottom: 130,
      labelWidth: 130,
      //"labelText": "",
      markerSize: 12,
      listeners: [
        {
          event: "showItem",
          method: hideOthers
        },
        {
          event: "hideItem",
          method: hideOthers
        }
      ]
    },
    chartCursor: {
      valueLineEnabled: true,
      valueLineBalloonEnabled: true,
      cursorColor: "#B0BEC5",
      color: "#000000"
    },
    chartScrollbar: {
      graph: "ValueAxis-1",
      oppositeAxis: true,
      offset: 10,
      scrollbarHeight: 30,
      backgroundAlpha: 0,
      selectedBackgroundAlpha: 0.1,
      selectedBackgroundColor: "#888888",
      graphFillAlpha: 0,
      graphLineAlpha: 0.5,
      selectedGraphFillAlpha: 0,
      selectedGraphLineAlpha: 1,
      autoGridCount: true,
      color: "#AAAAAA"
    },
    titles: [
      {
        id: "Title-1",
        size: 15,
        text: ""
      }
    ],
    dataProvider: []
  },
  //==================================
  // Asset Health > Min ++++++++++++++
  //==================================
  assethealthchartmin: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    color: "#C6C5CE",
    sequencedAnimation: false,
    autoMargins: false,
    marginBottom: 40,
    marginLeft: 10,
    marginRight: 10,
    marginTop: 40,
    startEffect: "easeInSine",
    dataProvider: [],
    valueAxes: [
      {
        stackType: "regular",
        strictMinMax: true,
        gridAlpha: 0,
        color: "#C6C5CE",
        axisColor: "#616370",
        titleBold: true,
        guides: [
          {
            value: 1,
            lineAlpha: 2,
            above: true,
            lineThickness: 5,
            lineColor: "#4578FF"
          },
          {
            value: 1,
            lineAlpha: 1,
            above: true,
            lineThickness: 5,
            lineColor: "#4578FF"
          }
        ]
      }
    ],
    graphs: [
      {
        fillAlphas: 1,
        //"lineColor": "#D76B50",
        //"showBalloon": true,
        balloonText: "[[ChartMinValue]]" + "-" + "[[RED]]",
        type: "column",
        openField: "ChartMinValue",
        closeField: "RED",
        lineAlpha: 0,
        fillColors: ["#FFC0BC", "#FF7674", "#ff4546"]
      },
      {
        fillAlphas: 1,
        //"lineColor": "#FFE769",
        //"showBalloon": true,
        balloonText: "[[RED]]" + "-" + "[[YELLOW]]",
        type: "column",
        openField: "RED",
        closeField: "YELLOW",
        //"valueField": "YELLOW"
        lineAlpha: 0,
        fillColors: ["#ffe588", "#FFE769", "#ffc754"]
      },
      {
        fillAlphas: 1,
        //"lineColor": "#3BC98A",
        showBalloon: true,
        balloonText: "[[YELLOW]]" + "-" + "[[GREEN]]",
        type: "column",
        openField: "YELLOW",
        closeField: "GREEN",
        //"valueField": "RED"
        lineAlpha: 0,
        fillColors: ["#C5FFDB", "#00FF6E", "#00B34A"]
      },
      {
        bullet: "square",
        columnWidth: 1.0,
        fillAlphas: 0.0,
        lineColor: "#000000",
        lineThickness: 5,
        behindColumns: false,
        //"showBalloon": true,
        noStepRisers: true,
        stackable: false,
        type: "step",
        valueField: "bullet"
      }
    ],
    rotate: true,
    columnWidth: 1,
    categoryField: "category",
    balloon: {
      enabled: true,
      balloonText: "[[bullet]]",
      fixedPosition: false,
      adjustBorderColor: true,
      borderAlpha: 0,
      animationDuration: 0.1,
      fillAlpha: 1,
      fillColor: "#F5F5F5",
      color: "#000000",
      fontSize: 13
    },
    categoryAxis: {
      gridAlpha: 0,
      position: "left",
      autoWrap: true,
      labelsEnabled: false
    },
    listeners: [
      {
        event: "clickGraphItem",
        method: function(event) {
          tabModelStore.setDataContext(event.item.dataContext);
          tabModelStore.setDataContextState("step2");

          // //console.log('******'+tabModelStore.getDataContext());
        }
      }
    ]
  },
  //==================================
  // Asset Health > Max ++++++++++++++
  //==================================
  assethealthchartmax: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    color: "#C6C5CE",
    sequencedAnimation: false,
    autoMargins: false,
    marginBottom: 40,
    marginLeft: 10,
    marginRight: 10,
    marginTop: 40,
    startEffect: "easeInSine",
    dataProvider: [],
    valueAxes: [
      {
        stackType: "regular",
        strictMinMax: true,
        gridAlpha: 0,
        color: "#C6C5CE",
        axisColor: "#616370",
        titleBold: true,
        guides: [
          {
            value: 1,
            lineAlpha: 2,
            above: true,
            lineThickness: 5,
            lineColor: "#4578FF"
          },
          {
            value: 1,
            lineAlpha: 1,
            above: true,
            lineThickness: 5,
            lineColor: "#4578FF"
          }
        ]
      }
    ],
    graphs: [
      {
        fillAlphas: 1,
        columnWidth: 1,
        //"lineColor": "#3BC98A",
        showBalloon: true,
        balloonText: "[[ChartMinValue]]" + "-" + "[[GREEN]]",
        type: "column",
        openField: "ChartMinValue",
        closeField: "GREEN",
        lineAlpha: 0,
        fillColors: ["#C5FFDB", "#00FF6E", "#00B34A"]
      },
      {
        fillAlphas: 1,
        //"lineColor": "#FFE769",
        //"showBalloon": true,
        balloonText: "[[GREEN]]" + "-" + "[[YELLOW]]",
        type: "column",
        openField: "GREEN",
        closeField: "YELLOW",
        //"valueField": "YELLOW"
        lineAlpha: 0,
        fillColors: ["#FBFFB1", "#F8C100"]
      },
      {
        fillAlphas: 1,
        balloonText: "[[YELLOW]]" + "-" + "[[RED]]",
        type: "column",
        openField: "YELLOW",
        closeField: "RED",
        //"valueField": "RED"
        lineAlpha: 0,
        fillColors: ["#FFC0BC", "#FF7674", "#ff4546"]
      },
      {
        bullet: "circle",
        bulletColor: "#ffffff",
        bulletSize: 12,
        bulletBorderThickness: 3,
        bulletBorderColor: "#000000",
        bulletBorderAlpha: 1.0,
        columnWidth: 1.0,
        fillAlphas: 0.0,
        lineColor: "#000000",
        lineThickness: 3,
        behindColumns: false,
        //"showBalloon": true,
        noStepRisers: true,
        stackable: false,
        type: "step",
        valueField: "bullet"
      }
    ],
    rotate: true,
    columnWidth: 1,
    categoryField: "category",
    balloon: {
      enabled: true,
      balloonText: "[[bullet]]",
      fixedPosition: false,
      adjustBorderColor: true,
      borderAlpha: 0,
      animationDuration: 0.1,
      fillAlpha: 1,
      fillColor: "#F5F5F5",
      color: "#000000",
      fontSize: 13
    },
    categoryAxis: {
      gridAlpha: 0.5,
      position: "left",
      autoWrap: true,
      labelsEnabled: false
    },
    listeners: [
      {
        event: "clickGraphItem",
        method: function(event) {
          tabModelStore.setDataContext(event.item.dataContext);
          tabModelStore.setDataContextState("step2");
          //   //console.log('******'+ tabModelStore.getDataContext());
        }
      }
    ]
  },
  //==================================
  // Asset Health > Min & Max ++++++++
  //==================================
  assethealthchartmin_max: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    color: "#C6C5CE",
    sequencedAnimation: false,
    autoMargins: false,
    marginBottom: 40,
    marginLeft: 10,
    marginRight: 10,
    marginTop: 40,
    startEffect: "easeInSine",
    dataProvider: [],
    valueAxes: [
      {
        stackType: "regular",
        strictMinMax: true,
        gridAlpha: 0,
        color: "#C6C5CE",
        axisColor: "#616370",
        titleBold: true,
        guides: [
          {
            value: 1,
            lineAlpha: 2,
            above: true,
            lineThickness: 5,
            lineColor: "#4578FF"
          },
          {
            value: 1,
            lineAlpha: 1,
            above: true,
            lineThickness: 5,
            lineColor: "#4578FF"
          }
        ]
      }
    ],
    graphs: [
      {
        fillAlphas: 1,
        //"showBalloon": true,
        balloonText: "[[ChartMinValue]]" + "-" + "[[REDN]]",
        type: "column",
        openField: "ChartMinValue",
        closeField: "REDN",
        lineAlpha: 0,
        fillColors: ["#FFC0BC", "#FF7674", "#ff4546"]
      },
      {
        fillAlphas: 1,
        //"showBalloon": true,
        balloonText: "[[REDN]]" + "-" + "[[YELLOWN]]",
        type: "column",
        openField: "REDN",
        closeField: "YELLOWN",
        //"valueField": "YELLOW"
        lineAlpha: 0,
        fillColors: ["#FBFFB1", "#F8C100"]
      },
      {
        fillAlphas: 1,
        //"showBalloon": true,
        balloonText: "[[YELLOWN]]" + "-" + "[[GREEN]]",
        type: "column",
        openField: "YELLOWN",
        closeField: "GREEN",
        lineAlpha: 0,
        fillColors: ["#C5FFDB", "#00FF6E", "#00B34A"]
      },
      {
        fillAlphas: 1,
        //"showBalloon": true,
        balloonText: "[[GREEN]]" + "-" + "[[YELLOWP]]",
        type: "column",
        openField: "GREEN",
        closeField: "YELLOWP",
        //"valueField": "YELLOW"
        lineAlpha: 0,
        fillColors: ["#FBFFB1", "#F8C100"]
      },
      {
        fillAlphas: 1,
        balloonText: "[[YELLOWP]]" + "-" + "[[REDP]]",
        type: "column",
        openField: "YELLOWP",
        closeField: "REDP",
        //"valueField": "RED"
        lineAlpha: 0,
        fillColors: ["#FFC0BC", "#FF7674", "#ff4546"]
      },
      {
        bullet: "circle",
        bulletColor: "#ffffff",
        bulletSize: 12,
        bulletBorderThickness: 3,
        bulletBorderColor: "#000000",
        bulletBorderAlpha: 1.0,
        columnWidth: 1.0,
        fillAlphas: 0.0,
        lineColor: "#000000",
        lineThickness: 3,
        behindColumns: false,
        showBalloon: true,
        noStepRisers: true,
        stackable: false,
        type: "step",
        valueField: "bullet"
      }
    ],
    rotate: true,
    columnWidth: 1,
    categoryField: "category",
    balloon: {
      enabled: true,
      balloonText: "[[bullet]]",
      fixedPosition: false,
      adjustBorderColor: true,
      borderAlpha: 0,
      animationDuration: 0.1,
      fillAlpha: 1,
      fillColor: "#F5F5F5",
      color: "#000000",
      fontSize: 13
    },
    categoryAxis: {
      gridAlpha: 0,
      position: "left",
      autoWrap: true,
      labelsEnabled: false
    },
    listeners: [
      {
        event: "clickGraphItem",
        method: function(event) {
          tabModelStore.setDataContext(event.item.dataContext);
          tabModelStore.setDataContextState("step2");
          ////console.log('******'+ tabModelStore.getDataContext());
        }
      }
    ]
  },
  //==================================
  // Asset Health > None +++++++++++++
  //==================================
  assethealthchartnone: {
    hideCredits: true,
    type: "serial",
    theme: "light",
    color: "#C6C5CE",
    autoMargins: false,
    marginBottom: 40,
    marginLeft: 10,
    marginRight: 10,
    marginTop: 40,
    dataProvider: [],
    valueAxes: [
      {
        axisColor: "#34343B",
        axisThickness: 0,
        gridColor: "#34343B",
        labelsEnabled: false,
        guides: [
          {
            value: 10,
            lineAlpha: 2,
            above: true,
            lineColor: "red"
          },
          {
            value: 16,
            lineAlpha: 1,
            above: true,
            lineColor: "skyblue"
          }
        ]
      }
    ],
    graphs: [
      {
        showBalloon: false,
        lineColor: "#34343B",
        type: "column",
        valueField: "tmp"
      }
    ],
    allLabels: [
      {
        text: "",
        bold: true,
        x: 180,
        y: 16
      }
    ],
    rotate: true,
    columnWidth: 1,
    categoryField: "category",
    categoryAxis: {
      gridAlpha: 0,
      position: "left",
      autoWrap: true,
      labelsEnabled: false
    },
    listeners: [
      {
        event: "clickGraphItem",
        method: function(event) {
          tabModelStore.setDataContext(event.item.dataContext);
          tabModelStore.setDataContextState("step2");
          //  //console.log('******'+tabModelStore.getDataContext());
        }
      }
    ]
  }
};
export default CHART_CONFIG;
