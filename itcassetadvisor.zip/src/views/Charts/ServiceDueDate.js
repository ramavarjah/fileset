import React, { Component } from "react";
import { observer } from "mobx-react";
import { Spin, Form, Row, Col } from "antd";
const FormItem = Form.Item;
import { AgGridReact } from "../../../libs/ag-grid-react";
import tabModelStore from "../../stores/tabModelStore";
import addAssetsStore from "../../stores/addAssetsStore";

@observer
class ServiceDueDate extends Component {
    constructor(props) {
        super(props);
        this._columns = [
            { key: "id", name: "ID" },
            { key: "title", name: "Equipment Number" },
            { key: "manufacturer", name: "Manufacturer" },
            { key: "serial", name: "Serial Number" },
            { key: "count", name: "Count" }
        ];
        this.state = {
            selecting: false,
            bottomFooterHeight: 157,
            rowSelection: "multiple"
        };
        this.onRowSelected = this.onRowSelected.bind(this);
    }
  createRows = () => {
      let rows = [];
      for (let i = 1; i < 100; i++) {
          rows.push({
              "12-10-2016": i
          });
      }
      return rows;
  };
  componentDidMount() {
      window.addEventListener("resize", this.onWinResize.bind(this));
      tabModelStore.setServiceDueChartLoading(true);
      tabModelStore.generateDateColumns();
      tabModelStore.fetchServiceDueDateData();
      this.onWinResize();
  }
  onGridReady = params => {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;

      params.api.sizeColumnsToFit();
      params.api.sizeColumnsToFit();
      var allColumnIds = [];
      this.gridColumnApi.getAllColumns().forEach(function(column) {
          allColumnIds.push(column.colId);
      });
      this.gridColumnApi.resetColumnState();
  };
  onSelectionChanged = () => {
      var selection = this.gridApi.getSelectedRows();
      if (selection.length <= 0) {
          return;
      }
      var self = this;
      if (self.state.selecting) return;
      let p1 = new Promise(resolve => {
          self.setState({ selecting: true });
          addAssetsStore.dashBoardAddCheckByKey(
              tabModelStore.gridOptions.api.getSelectedRows()
          );
          resolve("success");
      });
      p1.then(() => {
          self.setState({ selecting: false });
      });
  };
  handleDateChange(date) {
      tabModelStore.setServiceDueDateRangesAndReRender(date);
  }
  onRowSelected() {
      var self = this;
      if (self.state.selecting) return;
      let p1 = new Promise(resolve => {
          self.setState({ selecting: true });
          addAssetsStore.dashBoardAddCheckByKey(
              tabModelStore.gridOptions.api.getSelectedRows()
          );
          resolve("success");
      });
      p1.then(() => {
          self.setState({ selecting: false });
          //loop through the ks grid and filters out is the row selected or not in the grid
          var isTrue = false;
          //sets the dashboard is selected or not in the store
          isTrue
              ? addAssetsStore.setIsServiceChartDashboardSelected(true)
              : addAssetsStore.setIsServiceChartDashboardSelected(false);
      });
  }
  onWinResize() {
      var gridElem = document.getElementById("ksgridContainer");
      if (gridElem) {
          var footerElem = document.getElementById("footer");
          var mainFooter = document.getElementById("mainFooter");
          var appHeader = document.getElementById("app-header");
          var legendsRow = document.getElementById("legendsRow");
          var footerPlusBottomElemHeight =
        footerElem.clientHeight +
        mainFooter.clientHeight +
        appHeader.clientHeight +
        legendsRow.clientHeight -
        10;
          this.setState({ bottomFooterHeight: footerPlusBottomElemHeight });
      }
  }

  render() {
      tabModelStore.generateDateColumns();
      return (
          <FormItem>
              <Spin spinning={tabModelStore.serviceLoading} delay={500}>
                  <div
                      id="ksgridContainer"
                      style={{
                          height: window.innerHeight - this.state.bottomFooterHeight,
                          width: "100%",
                          paddingBottom: 4,
                          paddingTop: 10,
                          paddingLeft: 9
                      }}
                      className="ag-fresh service-due-date-grid serviceDueDateContainer"
                  >
                      {tabModelStore.serviceDataArray.map(a => a) ? (
                          <AgGridReact
                              id="ootGrid"
                              rowSelection="multiple"
                              suppressRowClickSelection
                              onSelectionChanged={this.onSelectionChanged.bind(this)}
                              suppressDragLeaveHidesColumns={true}
                              gridOptions={tabModelStore.gridOptions}
                              columnDefs={tabModelStore.columnDefs}
                              suppressCellSelection={true}
                              onRowSelected={this.onRowSelected}
                              onGridReady={this.onGridReady.bind(this)}
                          />
                      ) : (
                          ""
                      )}
                  </div>
                  <Row id="legendsRow" style={{ paddingBottom: 3 }}>
                      <Col span={12} />
                      <Col span={3}>
                          <Row>
                              <Col span={6}>
                                  <div
                                      style={{
                                          margin: 6,
                                          height: 15,
                                          width: 15,
                                          backgroundColor: "#FF325C"
                                      }}
                                  />
                              </Col>
                              <Col span={18}>Past Due</Col>
                          </Row>
                      </Col>
                      <Col span={3}>
                          <Row>
                              <Col span={6}>
                                  <div
                                      style={{
                                          margin: 6,
                                          height: 15,
                                          width: 15,
                                          backgroundColor: "#666666"
                                      }}
                                  />
                              </Col>
                              <Col span={18}>Due For Service</Col>
                          </Row>
                      </Col>
                      <Col span={3}>
                          <Row>
                              <Col span={6}>
                                  <div
                                      style={{
                                          margin: 6,
                                          height: 15,
                                          width: 15,
                                          backgroundColor: "#2CB0C7"
                                      }}
                                  />
                              </Col>
                              <Col span={18}>Out For Service</Col>
                          </Row>
                      </Col>
                  </Row>
              </Spin>
          </FormItem>
      );
  }
}

export default ServiceDueDate;
