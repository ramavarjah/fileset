import React, { Component } from "react";
import { observer } from "mobx-react";
import { Form, Row, Col } from "antd";
import tabModelStore from "../../stores/tabModelStore";

@observer
class AssetDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            overlayOpen: false,
            details: {
                EquipmentNo: "",
                ModelNo: "",
                SerialNo: "",
                AssetNo: ""
            },
            loading: true,
            assetDetails: {
                EquipmentNo: "",
                Manufacturer: "",
                AltManufacturerName: "",
                ModelNo: "",
                SerialNo: "",
                AssetNo: "",
                Description: "",
                ProductCategory: "",
                StickyNotes: ""
            }
        };
    }
    getTypeFromChartId(chartId) {
        var rtn = "EquipmentNo";
        if (chartId == "16") rtn = "EquipmentNo";
        else if (chartId == "15") rtn = "AssetNo";
        else if (chartId == "14") rtn = "SerialNo";
        return rtn;
    }
    _handleSameProps(props) {
        if (props.chartDetailstoggle && props.value) {
            return this.setState(() =>
                this.setState({ overlayOpen: !this.state.overlayOpen })
            );
        } else {
            this.setState({ overlayOpen: this.state.overlayOpen });
        }
    }

    componentWillReceiveProps(nextProps) {
        var props = nextProps;
        if (props.value == undefined)
            return this.setState({
                overlayOpen: false,
                details: {
                    EquipmentNo: "",
                    ModelNo: "",
                    SerialNo: "",
                    AssetNo: ""
                }
            });
        else if (props.value == "ALL ASSETS")
            return this.setState({ overlayOpen: false });
        var type = this.getTypeFromChartId(props.type);
        if (this.state.details[type] == props.value)
            return this._handleSameProps(props); //if it is same props dont proceed
        var details = {};
        tabModelStore.currentScreenDataArray.map(item => {
            if (item[type] == props.value) details = JSON.parse(JSON.stringify(item));
        });
        if (details.EquipmentNo)
            return this.setState({
                details,
                assetDetails: details,
                overlayOpen: true
            });
    }

    render() {
        const wrapperStyle = {
            boxSizing: "border-box",
            color: "#959595",
            paddingTop: 15,
            paddingRight: 0,
            paddingBottom: 15,
            paddingLeft: 15,
            margin: 0,
            border: "none",
            outline: "none",
            background: "transparent",
            fontWeight: "500",
            letterSpacing: 1,
            fontSize: 16,
            borderRadius: 3,
            position: "relative"
        };
        return this.props.chartDetailstoggle ? (
            <div className="assestWrapper">
                <div style={wrapperStyle} className="assestWrapper">
                    {this.props.chartDetailstoggle && this.state.overlayOpen ? (
                        <div
                            style={{
                                position: "relative",
                                overflow: "auto",
                                border: "none",
                                outline: "none",
                                overflowX: "hidden",
                                height: this.props.height,
                                padding: 0
                            }}
                        >
                            <Row>
                                <h5
                                    style={{
                                        padding: 16,
                                        borderBottom: "solid 1px #3e4245",
                                        color: "#969897"
                                    }}
                                >
                                    {" "}
                  Asset Details - IDENTIFICATION /{" "}
                                    <span style={{ color: "#3285ff" }}>
                                        {" "}
                                        {this.state.assetDetails.EquipmentNo}{" "}
                                    </span>{" "}
                                </h5>
                            </Row>
                            <Row gutter={48}>
                                <Col xs={8} sm={8} md={8} lg={8} xl={8}>
                                    <p className="assestTitle">
                    Equipment Number:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.EquipmentNo}
                                        </span>
                                    </p>
                                    <p className="assestTitle">
                    Manufacturer:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.Manufacturer}{" "}
                                        </span>
                                    </p>
                                    <p className="assestTitle">
                    Alt Manufacturer:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.AltManufacturerName}{" "}
                                        </span>
                                    </p>
                                    <p className="assestTitle">
                    Model Number:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.ModelNo}{" "}
                                        </span>
                                    </p>
                                </Col>
                                <Col xs={8} sm={8} md={8} lg={8} xl={8}>
                                    <p className="assestTitle">
                    Serial Number:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.SerialNo}{" "}
                                        </span>
                                    </p>
                                    <p className="assestTitle">
                    Asset Number:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.AssetNo}{" "}
                                        </span>
                                    </p>
                                    <p className="assestTitle">
                    Description:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.Description}{" "}
                                        </span>
                                    </p>
                                </Col>
                                <Col xs={8} sm={8} md={8} lg={8} xl={8}>
                                    <p className="assestTitle">
                    Product Category:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.ProductCategory}{" "}
                                        </span>
                                    </p>
                                    <p className="assestTitle">
                    Sticky Notes:
                                        <span className="assestTitleResponse">
                                            {" "}
                                            {this.state.assetDetails.StickyNotes}{" "}
                                        </span>
                                    </p>
                                </Col>
                            </Row>
                        </div>
                    ) : (
                        <div
                            style={{
                                height: this.props.height,
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center"
                            }}
                        >
                            <h4>
                Select a single asset in the legend to view its identification
                details
                            </h4>
                        </div>
                    )}
                </div>
            </div>
        ) : (
            <div style={{ display: "none" }} />
        );
    }
}
const WrappedRegistrationForm = Form.create()(AssetDetails);

export default WrappedRegistrationForm;
import PropTypes from "prop-types";
AssetDetails.propTypes = {
    value: PropTypes.String,
    type: PropTypes.String,
    chartDetailstoggle: PropTypes.String,
    height: PropTypes.String
};
