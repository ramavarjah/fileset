import React, { Component } from "react";
import { observer } from "mobx-react";
import "./chartStyle.css";
import tabModelStore from "../../stores/tabModelStore";
import permissionStore from "../../stores/permissionStore";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";
import QueryHelper from "../../helpers/QueryHelper";
import PropTypes from "prop-types";
import WarningQuery from "./WarningQuery";
import { DatePicker, Select, InputNumber, Tooltip } from "antd";
import moment from "moment";
const RangePicker = DatePicker.RangePicker;
const Option = Select.Option; // Cos
const ChartCategoryIdExceptions = ["1", "2", "4"];
@observer
class ChartFooter extends Component {
	constructor(props) {
		super(props);
		// var config = { "type": "serial", "categoryField": "Manufacturer", "columnWidth": 0.4, "marginBottom": 5, "marginLeft": 5, "marginRight": 10, "marginTop": 5, "sequencedAnimation": false, "startDuration": 1, "startEffect": "easeInSine", "color": "#E7E7E7", "fontFamily": "Open Sans", "theme": "dark", "categoryAxis": { "autoWrap": true, "gridPosition": "start", "title": "" }, "export": { "enabled": true, "menu": [], "backgroundColor": "#2b2c33" }, "valueScrollbar": { "enabled": true, "graph": "AmGraph-1", "graphType": "column" }, "chartScrollbar": { "enabled": true }, "trendLines": [], "graphs": [{ "accessibleLabel": "[[title]] [[value]] [[Manufacturer]]", "balloonText": "<span><b>Asset Count: [[Count]]</b>\n [[Manufacturer]]</span>", "fillAlphas": 0.7, "fillColors": "#00ff9c", "lineColor": "#00ff9c", "showHandOnHover": true, "id": "AmGraph-1", "labelText": "", "title": "graph 1", "type": "column", "valueField": "Count" }], "guides": [], "valueAxes": [{ "id": "ValueAxis-1", "integersOnly": true, "minimum": 0, "title": "Asset Count" }], "allLabels": [], "balloon": { "disableMouseEvents": false, "adjustBorderColor": true, "borderAlpha": 0, "fillAlphas": 1, "borderThickness": 0, "pointerOrientation": "down", "color": "#000000", "fillColor": "#ffffff", "verticalPadding": 10, "horizontalPadding": 12, "fontSize": 13, "textAlign": "left" }, "chartCursor": { "valueLineEnabled": true, "valueLineBalloonEnabled": true, "cursorColor": "#f1f1f1", "color": "#000000" }, "titles": [{ "id": "Title-1", "size": 15, "text": "" }], "dataProvider": [{ "Manufacturer": "Keysight", "Count": 23 }, { "Manufacturer": "Anritsu", "Count": 10 }, { "Manufacturer": "R&S", "Count": 4 }, { "Manufacturer": "Sprient", "Count": 2 }, { "Manufacturer": "Keysight Technologies", "Count": 1 }] }
		this.state = {
			dataProvider: "",
			timer: null,
			categoryId: "",
			chartViewData: "",
			chartId: "",
			preset: "",
			warningMode: false,
			dataPoints: {
				dataPoints: "",
				validAssetCount: "",
				activeBucketType: "",
				totalDays: ""
			}
		};
		this.handleChartIdChangeForced = this.handleChartIdChangeForced.bind(this);
	}
	getOffset() {
		const offsetBy = this.props.chartCategoryData.filter(item => item.ViewName)
			.length;
		if (offsetBy === 1) return offsetBy * 50;
		else if (offsetBy === 2) return offsetBy * 48;
		else if (offsetBy === 3) return offsetBy * 43;
		else return offsetBy * 41.5;
	}
	componentDidMount() {

		this.setState({
			chartViewData: tabModelStore.chartViewData
		});
		var categoryId = tabModelStore.getActiveTab.ChartCategoryId;
		this.setState({
			categoryId: categoryId
		});
	}
	handleChartIdChange(value) {
		//bypass check if bucket is already View By Hours

		var inputVal, dataPoints;
		if (
			tabModelStore.chartBucketType != "View By Hours" ||
			ChartCategoryIdExceptions.indexOf(tabModelStore.activeCategoryId) > -1
		)
			return this.handleChartIdChangeForced(value);
		inputVal = {
			type: "chartId",
			value: value
		};
		dataPoints = QueryHelper.getDatapoints(value, null, null, null, inputVal);
		if (dataPoints.dataPoints > 3000) {
			this.setState({
				warningMode: true,
				dataPoints: dataPoints
			});
			return;
		}
		this.handleChartIdChangeForced(value);
	}
	handleChartIdChangeForced(value) {
		//this will not check for query or data points, called after check point

		tabModelStore.setHealthVsTimeContext(false);
		permissionStore.setChartLoading(true);
		tabModelStore.setBackButtonVisibility(false);
		this.setState({
			chartId: value
		});
		var ChartViewId = value;
		//if (!ChartViewId)
		//	ChartViewId = 0;
		var tabId = tabModelStore.activeTab.TabId;
		tabModelStore.setChartId(ChartViewId);
		var previousConfig = [];
		tabModelStore.setPreviousChartConfig(previousConfig);
		Functions.SetChartId(tabId, ChartViewId).then(() => {
			var activeTab = this.props.activeTab;
			UIFunctions.switchChart(
				activeTab.CategoryId ? activeTab.CategoryId : activeTab.ChartCategoryId,
				ChartViewId,
				tabId
			);
		});
	}
	handleCategoryChange(value) {
		tabModelStore.setHealthVsTimeContext(false);
		permissionStore.setChartLoading(true);
		tabModelStore.setServiceDueChartLoading(true);
		tabModelStore.setBackButtonVisibility(false);
		this.setState({
			categoryId: value
		});
		var categoryId = value;
		var activeTab = tabModelStore.getActiveTab;
		var tabId = tabModelStore.activeTab.TabId;
		activeTab.CategoryId = categoryId;
		tabModelStore.setActiveTab(activeTab);
		// var ChartViewId = 0; // activeTab.ChartViewId;

		Functions.SetCategoryId(tabId, categoryId).then(() => {
			tabModelStore.setActiveCategoryId(categoryId);

			Functions.GetSubViewOptions(
				tabModelStore.getActiveTab.TabId,
				categoryId
			).then(resp => {
				var activeChartId = "";
				if (resp.data.data) {
					tabModelStore.setChartViewData(JSON.stringify(resp.data.data));
					// tabModelStore.setActiveCategoryId(categoryId);
					var chartDataToSet = resp.data.data;
					for (var index = 0; index < chartDataToSet.length; index++) {
						var element = chartDataToSet[index];
						if (element.Active === true) {
							activeChartId = element.ChartId;
							// activeCategotyId = element.CategoryId;
							// activeChart = element.PropertyName;
						}
					}
					tabModelStore.setChartId(activeChartId);
					var previousConfig = [];
					tabModelStore.setPreviousChartConfig(previousConfig);
					this.setState({
						chartViewData: resp.data.data
					});
				}
				UIFunctions.switchChart(categoryId, activeChartId, tabId);
			});
		});
	}
	handleWorkingHours(val) {
		var tabId = tabModelStore.activeTab.TabId;
		var activeChartId = tabModelStore.getChartId;
		var activeCategoryId = tabModelStore.getActiveCategoryId;
		var hours = val; //e.target.value;
		if (hours) {
			Functions.SetWorkingHours(tabId, hours).then(() => {
				tabModelStore.setWorkingHours(hours);
				UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
			});
		}
	}
	handleRefresh() {
		permissionStore.setChartLoading(true);
		var tabId = tabModelStore.activeTab.TabId;
		var activeChartId = tabModelStore.getChartId;
		var activeCategoryId = tabModelStore.getActiveCategoryId;
		UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
	}
	handlePreset(value) {
		//bypass check if bucket is already View By Hours

		if (
			tabModelStore.chartBucketType != "View By Hours" ||
			ChartCategoryIdExceptions.indexOf(tabModelStore.activeCategoryId) > -1
		)
			return this.handlePresetForced(value);
		var startDate, endDate;
		var dataPoints, inputVal;
		if (value === "Today") {
			startDate = moment()
				.startOf("day")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Last Week") {
			startDate = moment()
				.subtract(1, "weeks")
				.startOf("week")
				.toISOString();
			endDate = moment()
				.subtract(1, "weeks")
				.endOf("week")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Last Month") {
			startDate = moment()
				.subtract(1, "month")
				.startOf("month")
				.toISOString();
			endDate = moment()
				.subtract(1, "month")
				.endOf("month")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Yesterday") {
			startDate = moment()
				.subtract(1, "days")
				.startOf("day")
				.toISOString();
			endDate = moment()
				.subtract(1, "days")
				.endOf("day")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "This Week-to-date") {
			startDate = moment()
				.startOf("week")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "This Month-to-date") {
			startDate = moment()
				.startOf("month")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Last Week-to-date") {
			startDate = moment()
				.subtract(1, "weeks")
				.startOf("week")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Last Month-to-date") {
			startDate = moment()
				.subtract(1, "months")
				.startOf("month")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "This Month") {
			startDate = moment()
				.startOf("month")
				.toISOString();
			endDate = moment()
				.endOf("month")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "This Quarter") {
			startDate = moment()
				.startOf("quarter")
				.toISOString();
			endDate = moment()
				.endOf("quarter")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "This Quarter-to-date") {
			startDate = moment()
				.startOf("quarter")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "This Year") {
			startDate = moment()
				.startOf("year")
				.toISOString();
			endDate = moment()
				.endOf("year")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Next Month") {
			startDate = moment()
				.add(1, "months")
				.startOf("month")
				.toISOString();
			endDate = moment()
				.add(1, "months")
				.endOf("month")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Next Quarter") {
			startDate = moment()
				.add(1, "quarters")
				.startOf("quarter")
				.toISOString();
			endDate = moment()
				.add(1, "quarters")
				.endOf("quarter")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		} else if (value === "Next Year") {
			startDate = moment()
				.add(1, "years")
				.startOf("year")
				.toISOString();
			endDate = moment()
				.add(1, "years")
				.endOf("year")
				.toISOString();
			inputVal = {
				type: "preset",
				value: value
			};
			dataPoints = QueryHelper.getDatapoints(
				null,
				moment(startDate),
				moment(endDate),
				null,
				inputVal
			);
			if (dataPoints.dataPoints > 3000) {
				this.setState({
					warningMode: true,
					dataPoints: dataPoints
				});
				return;
			}
			this.handlePresetForced(value);
		}
	}
	handlePresetForced(value) {
		var datePreset = value;
		if (datePreset == "Custom") {
			this.setState({
				preset: datePreset
			});
			Functions.SetDatePreset(tabId, datePreset).then(() => {
				// tabModelStore.setPreset(datePreset);
			});
			return tabModelStore.setPreset(datePreset);
		}
		permissionStore.setChartLoading(true);
		tabModelStore.setServiceDueChartLoading(true);
		this.setState({
			preset: datePreset
		});
		var tabId = tabModelStore.activeTab.TabId;
		var activeChartId = tabModelStore.getChartId;
		var activeCategoryId = tabModelStore.getActiveCategoryId;

		Functions.SetDatePreset(tabId, datePreset).then(() => {
			tabModelStore.setPreset(datePreset);
		});
		var startDate, endDate;

		if (value === "Today") {
			startDate = moment()
				.startOf("day")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Last Week") {
			startDate = moment()
				.subtract(1, "weeks")
				.startOf("week")
				.toISOString();
			endDate = moment()
				.subtract(1, "weeks")
				.endOf("week")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Last Month") {
			startDate = moment()
				.subtract(1, "month")
				.startOf("month")
				.toISOString();
			endDate = moment()
				.subtract(1, "month")
				.endOf("month")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Yesterday") {
			startDate = moment()
				.subtract(1, "days")
				.startOf("day")
				.toISOString();
			endDate = moment()
				.subtract(1, "days")
				.endOf("day")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "This Week-to-date") {
			startDate = moment()
				.startOf("week")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "This Month-to-date") {
			startDate = moment()
				.startOf("month")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Last Week-to-date") {
			startDate = moment()
				.subtract(1, "weeks")
				.startOf("week")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Last Month-to-date") {
			startDate = moment()
				.subtract(1, "months")
				.startOf("month")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "This Month") {
			startDate = moment()
				.startOf("month")
				.toISOString();
			endDate = moment()
				.endOf("month")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "This Quarter") {
			startDate = moment()
				.startOf("quarter")
				.toISOString();
			endDate = moment()
				.endOf("quarter")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "This Quarter-to-date") {
			startDate = moment()
				.startOf("quarter")
				.toISOString();
			endDate = moment()
				.endOf("day")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "This Year") {
			startDate = moment()
				.startOf("year")
				.toISOString();
			endDate = moment()
				.endOf("year")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Next Month") {
			startDate = moment()
				.add(1, "months")
				.startOf("month")
				.toISOString();
			endDate = moment()
				.add(1, "months")
				.endOf("month")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Next Quarter") {
			startDate = moment()
				.add(1, "quarters")
				.startOf("quarter")
				.toISOString();
			endDate = moment()
				.add(1, "quarters")
				.endOf("quarter")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		} else if (value === "Next Year") {
			startDate = moment()
				.add(1, "years")
				.startOf("year")
				.toISOString();
			endDate = moment()
				.add(1, "years")
				.endOf("year")
				.toISOString();
			tabModelStore.setTabStartDate(moment(startDate));
			tabModelStore.setTabEndDate(moment(endDate));
			Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
				if (resp.data.success) {
					UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
				}
			});
		}
	}
	handleChartBucketType(value) {
		var inputVal, dataPoints;
		if (ChartCategoryIdExceptions.indexOf(tabModelStore.activeCategoryId) > -1)
			return this.handleChartBucketTypeForced(value);
		inputVal = {
			type: "bucketType",
			value: value
		};
		dataPoints =
			value == "View By Hours"
				? QueryHelper.getDatapoints(null, null, null, value, inputVal)
				: { datapoints: 0 }; //if not view by hours direct render
		if (dataPoints.dataPoints > 3000) {
			this.setState({
				warningMode: true,
				dataPoints: dataPoints
			});
			return;
		}
		this.handleChartBucketTypeForced(value);
	}
	handleChartBucketTypeForced(value) {
		permissionStore.setChartLoading(true);
		var tabId = tabModelStore.activeTab.TabId;
		var activeChartId = tabModelStore.getChartId;
		var activeCategoryId = tabModelStore.getActiveCategoryId;
		var bucketType = value;
		if (bucketType === "View By Hours") {
			tabModelStore.setChartBucketType("View By Hours");
		} else if (bucketType === "View By Days") {
			tabModelStore.setChartBucketType("View By Days");
		} else {
			tabModelStore.setChartBucketType("View By Months");
		}
		UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
	}
	handleDateChange(date) {
		//bypass check if bucket is already View By Hours
		var inputVal, dataPoints;
		if (
			tabModelStore.chartBucketType != "View By Hours" ||
			ChartCategoryIdExceptions.indexOf(tabModelStore.activeCategoryId) > -1
		)
			return this.handleDateChangeForced(date);

		inputVal = {
			type: "date",
			value: date
		};
		var startDate = date[0].startOf("day").toISOString();
		var endDate = date[1].endOf("day").toISOString();
		dataPoints = QueryHelper.getDatapoints(
			null,
			moment(startDate),
			moment(endDate),
			null,
			inputVal
		);
		if (dataPoints.dataPoints > 3000) {
			this.setState({
				warningMode: true,
				dataPoints: dataPoints
			});
			return;
		}
		this.handleDateChangeForced(date);
	}
	handleDateChangeForced(date) {
		permissionStore.setChartLoading(true);
		tabModelStore.setServiceDueChartLoading(true);
		var startDate = moment(date[0])
			.startOf("day")
			.toISOString();
		var endDate = moment(date[1])
			.endOf("day")
			.toISOString();
		tabModelStore.setTabStartDate(moment(startDate));
		tabModelStore.setTabEndDate(moment(endDate));
		var tabId = tabModelStore.activeTab.TabId;
		var activeChartId = tabModelStore.getChartId;
		var activeCategoryId = tabModelStore.getActiveCategoryId;
		this.setState({
			preset: "Custom"
		});
		Functions.SetDatePreset(tabId, "Custom");
		tabModelStore.setPreset("Custom");
		Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
			if (resp.data.success) {
				UIFunctions.switchChart(activeCategoryId, activeChartId, tabId);
			}
		});
	}
	handleWarningModalButton(data) {
		switch (data) {
			case "cancel":
				this.setState({
					warningMode: false,
					dataPoints: {
						dataPoints: "",
						validAssetCount: "",
						activeBucketType: "",
						totalDays: "",
						inputVal: {
							type: null,
							value: null
						}
					}
				});
				break;
			case "proceed":
				this.handleModalWarningProceed();
				break;
			case "ByDates":
				this.handleWarningBydates();
				break;
		}
	}
	handleModalWarningProceed() {
		var switchObj = this.state.dataPoints.inputVal;
		switch (switchObj.type) {
			case "chartId":
				this.handleChartIdChangeForced(switchObj.value);
				break;
			case "bucketType":
				this.handleChartBucketTypeForced(switchObj.value);
				break;
			case "date":
				this.handleDateChangeForced(switchObj.value);
				break;
			case "preset":
				this.handlePresetForced(switchObj.value);
				break;
		}
		//close modal and clear the data
		this.setState({
			warningMode: false,
			dataPoints: {
				dataPoints: "",
				validAssetCount: "",
				activeBucketType: "",
				totalDays: "",
				inputVal: {
					type: null,
					value: null
				}
			}
		});
	}
	handleWarningBydates() {
		var switchObj = this.state.dataPoints.inputVal;
		if (
			switchObj.type == "bucketType" &&
			tabModelStore.chartBucketType == "View By Days"
		)
			return this.setState({
				//prevent unnecessary rerender if bucket type is already view by days and when user tries to change the bucket type to hours but after warning, he decided to keep view by days
				warningMode: false,
				dataPoints: {
					dataPoints: "",
					validAssetCount: "",
					activeBucketType: "",
					totalDays: "",
					inputVal: {
						type: null,
						value: null
					}
				}
			});

		tabModelStore.setChartBucketType("View By Days");
		this.handleModalWarningProceed();
	}
	render() {
		let offset = 0;
		var activeTab = this.props.activeTab.CategoryId
			? this.props.activeTab.CategoryId
			: this.props.activeTab.ChartCategoryId;
		if (activeTab == 2) {
			offset = -230;
		} else if (activeTab == 1) {
			{
				offset = -165;
			}
		} else if (activeTab == 3) {
			{
				offset = -210;
			}
		}
		var activechart = tabModelStore.chartId;
		var activechartExist = false;
		const chartsOptions = this.props.chartViewData
			? this.props.chartViewData.map(item => {
					if (item.ChartId == activechart) activechartExist = true;
					return (
						<Option
							className="chartFooterSelectBoxOption chartFooterViewSelectBoxOption"
							key={item.ChartId}
							value={item.ChartId}
						>
							{item.value}
						</Option>
					);
			  })
			: "";
		const chartsSelect = (
			<Select
				dropdownAlign={{
					offset: [0, offset]
				}}
				className="chartFooterSelectBox chartFooterViewSelectBox"
				style={{ width: "178px" }}
				value={activechartExist ? activechart : "Loading..."}
				onChange={this.handleChartIdChange.bind(this)}
			>
				{chartsOptions}
			</Select>
		);
		const chartsCategoryOptions = this.props.chartCategoryData
			? this.props.chartCategoryData.map(
					item =>
						item.CategoryId && (
							<Option
								className="chartFooterSelectBoxOption chartFooterCategorySelectBoxOption"
								hidden={!item.CategoryId}
								key={item.CategoryId}
								value={item.CategoryId}
							>
								{item.ViewName}
							</Option>
						)
			  )
			: "";
		let getOffset = this.getOffset();
		const chartsCategorySelect = (
			<Select
				dropdownAlign={{ offset: [0, -getOffset] }}
				className="chartFooterSelectBox chartFooterCategorySelectBox"
				style={{ width: "155px" }}
				defaultValue={tabModelStore.getActiveTab.ChartCategoryId}
				value={tabModelStore.activeCategoryId}
				onChange={this.handleCategoryChange.bind(this)}
			>
				{chartsCategoryOptions}
			</Select>
		);

		return (
			<div id="footer" className="dashboardChartFooter">
				{this.state.warningMode ? (
					<WarningQuery
						data={this.state.dataPoints}
						handleButton={this.handleWarningModalButton.bind(this)}
					/>
				) : (
					""
				)}
				<nav className="navbar navbar-dark bg-dark paginationBar">
					{/*'Chart Controls Containing Row'*/}
					<div className="row chart-controls">
						{/* 'Chart Type Dropup' */}
						<div
							className="dropup textDropdown selectDropdown"
							id="chart-type-dropup"
						>
							<div
								className="dropdown dropdown-neww"
								style={{ backgroundColor: "#0000" }}
							>
								{chartsCategorySelect}
							</div>
						</div>
						{/* 'Chart View Type Dropup' */}
						{tabModelStore.chartViewData.map(e => e).length > 1 ? (
							<div
								className="dropup textDropdown selectDropdown"
								id="chart-view-dropup"
							>
								<div
									className="dropdown dropdown-neww"
									style={{ backgroundColor: "#0000" }}
								>
									{/*antd Select */}
									{chartsSelect}
								</div>
							</div>
						) : (
							""
						)}

						{tabModelStore.activeCategoryId != "1" && (
							<div
								className="dropup textDropdown selectDropdownToday tooltipcss"
								id="chart-view-dropup"
								style={{ borderRight: "none" }}
							>
								<div
									className="dropdown dropdown-neww dropdownHoursandMonth"
									style={{ backgroundColor: "#0000", width: "175px" }}
								>
									{/*antd Select */}
									<Select
										className="chartFooterSelectBox chartFooterDatePresetSelectBox"
										style={{ width: "100%" }}
										defaultValue={tabModelStore.getActiveTab.DatePreset}
										value={tabModelStore.getPreset}
										//disabled={tabModelStore.activeCategoryId == "2" && tabModelStore.isHealthVsTime}
										onChange={this.handlePreset.bind(this)}
									>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Today"
										>
											Today
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="This Week-to-date"
										>
											This Week-to-date
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="This Month-to-date"
										>
											This Month-to-date
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Yesterday"
										>
											Yesterday
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Last Week"
										>
											Last Week
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Last Week-to-date"
										>
											Last Week-to-date
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Last Month"
										>
											Last Month
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Last Month-to-date"
										>
											Last Month-to-date
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="This Month"
										>
											This Month
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="This Quarter"
										>
											This Quarter
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="This Quarter-to-date"
										>
											This Quarter-to-date
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="This Year"
										>
											This Year
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Next Month"
										>
											Next Month
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Next Quarter"
										>
											Next Quarter
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Next Year"
										>
											Next Year
										</Option>
										<Option
											className="chartFooterSelectBoxOption chartFooterDatePresetSelectBoxOption"
											key="Custom"
										>
											Custom
										</Option>
									</Select>
								</div>
								<span className="footertooltiptext">Select range</span>
							</div>
						)}
						{tabModelStore.activeCategoryId != "1" && (
							<div
								className="rangePickerModel tooltipcss"
								style={{ width: "260px" }}
							>
								<RangePicker
									ranges={{
										Today: [moment(), moment()],
										"This Month": [moment(), moment().endOf("month")]
									}}
									defaultValue={[
										moment(tabModelStore.activeTab.ChartStartDate),
										moment(tabModelStore.activeTab.ChartEndDate)
									]}
									value={[
										moment(tabModelStore.tabStartDate),
										moment(tabModelStore.tabEndDate)
									]}
									//disabled={tabModelStore.activeCategoryId == "2" && !tabModelStore.isHealthVsTime}
									allowClear={false}
									onChange={this.handleDateChange.bind(this)}
									//disabled={tabModelStore.preset !== "Custom"}
								/>
								<span className="footertooltiptext">Select date range</span>
							</div>
						)}
						{(tabModelStore.activeCategoryId == "3" ||
							tabModelStore.activeCategoryId == "2") && (
							<div className="chartFooterLastCoulmn">
								<div
									className="dropup textDropdown selectDropdownToday"
									style={{ borderRight: "none" }}
								>
									<div
										className="dropdown dropdown-neww dropdownHoursandMonth"
										style={{ backgroundColor: "#0000" }}
									>
										{/*antd Select */}
										<Select
											dropdownAlign={{
												offset: [0, -137]
											}}
											className="chartFooterSelectBox chartFooterBucketTypeSelectBox"
											style={{ width: "142px" }}
											//disabled={tabModelStore.activeCategoryId == "2" && !tabModelStore.isHealthVsTime}
											value={tabModelStore.chartBucketType}
											onChange={this.handleChartBucketType.bind(this)}
										>
											<Option
												className="chartFooterSelectBoxOption chartFooterBucketTypeSelectBoxOption"
												key="View By Hours"
											>
												View By Hours
											</Option>
											<Option
												className="chartFooterSelectBoxOption chartFooterBucketTypeSelectBoxOption"
												key="View By Days"
											>
												View By Days
											</Option>
											<Option
												className="chartFooterSelectBoxOption chartFooterBucketTypeSelectBoxOption"
												key="View By Months"
											>
												View By Months
											</Option>
										</Select>
									</div>
								</div>
								{tabModelStore.activeCategoryId == "3" && (
									<div
										className=" working-hours"
										style={{ color: "#afafaf", padding: "0px 0px 0px 8px" }}
									>
										<Tooltip
											placement="top"
											title={
												<span>
													Number of hours an asset may be in use per day
												</span>
											}
										>
											<span className="workingHoursText">Hours in a Day</span>
											<InputNumber
												min={1}
												max={24}
												defaultValue={8}
												value={tabModelStore.workingHours}
												disabled={
													tabModelStore.chartBucketType == "View By Hours"
												}
												className={
													tabModelStore.chartBucketType == "View By Hours"
														? "changeOpacity"
														: ""
												}
												onChange={this.handleWorkingHours.bind(this)}
												style={{ marginLeft: "8px" }}
											/>
											{/* <input id="working-hours-input" type="text" value="08" style={{ color: '#40444D' }} /> */}
										</Tooltip>
									</div>
								)}
							</div>
						)}
						{/*'Reset Button'*/}
						<div className="row reset-utilization-settings">
							{/*<button className="aa-sml-bar-btn" type="button" name="button">Reset</button>*/}
							<i
								className="icon-refresh tooltipcss"
								onClick={this.handleRefresh.bind(this)}
							>
								<span className="footertooltiptext">Refresh</span>
							</i>
						</div>
					</div>
				</nav>
			</div>
		);
	}
}
export default ChartFooter;

ChartFooter.propTypes = {
	chartCategoryData: PropTypes.array,
	activeTab: PropTypes.object,
	chartViewData: PropTypes.array,
	visible: PropTypes.bool
};
