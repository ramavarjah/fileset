//Original chart
import React, { Component } from "react";

// import 'amcharts3';
// import 'amcharts3/amcharts/serial';
import AmCharts from "@amcharts/amcharts3-react";

import tabModelStore from "../../stores/tabModelStore";
import { observer } from "mobx-react";
import { observable } from "mobx";

// Component which contains the dynamic state for the chart
@observer
class Charts extends Component {
  @observable
  config;
  constructor(props) {
    super(props);
    this.config;
  }

  componentDidMount() {
    var data = tabModelStore.getChartConfig;
    //console.log('chart', data);
    var config = {
      type: "serial",
      categoryField: "Manufacturer",
      columnWidth: 0.4,
      marginBottom: 5,
      marginLeft: 5,
      marginRight: 10,
      marginTop: 5,
      sequencedAnimation: false,
      startDuration: 1,
      startEffect: "easeInSine",
      color: "#E7E7E7",
      fontFamily: "Open Sans", //---cos
      theme: "dark",
      categoryAxis: {
        autoWrap: true,
        gridPosition: "start",
        title: ""
      },
      export: {
        enabled: true,
        menu: [],
        backgroundColor: "#2b2c33"
      },
      valueScrollbar: {
        enabled: true,
        graph: "AmGraph-1",
        graphType: "column"
      },
      /*
                  "chartCursor": {
                      "enabled": true,
                      "categoryBalloonEnabled": false,
                      "categoryBalloonText": "[[category]]",
                      "cursorColor": "#FFFFFF",
                      "valueLineBalloonColor": "#FFFFFF",
                      "legendColor": "#FFFFFF",
                      "oneBalloonOnly": true
                  },
      */
      chartScrollbar: {
        enabled: true
      },
      trendLines: [],
      graphs: [
        {
          //"accessibleLabel": "[[title]] [[Manufacturer]] [[value]]",
          accessibleLabel: "[[title]] [[value]] [[Manufacturer]]",
          //"balloonText": "Unit: [[Manufacturer]]\nAsset Count: [[Count]]",
          balloonText:
            "<span><b>Asset Count: [[Count]]</b>\n [[Manufacturer]]</span>",
          fillAlphas: 0.7, //--cos
          fillColors: "#00ff9c",
          //"fillColors": "#33ffbc",
          //"fillColors": "#8cb5fc",
          lineColor: "#00ff9c",
          //"lineColor": "#33ffbc",
          //"lineColor": "#8CB5FC",
          showHandOnHover: true,
          id: "AmGraph-1",
          labelText: "",
          title: "graph 1",
          type: "column",
          valueField: "Count"
        }
      ],
      guides: [],
      valueAxes: [
        {
          id: "ValueAxis-1",
          integersOnly: true,
          minimum: 0,
          title: "Asset Count"
        }
      ],
      allLabels: [],
      balloon: {
        disableMouseEvents: false,
        //-------------------------------------------COS
        adjustBorderColor: true,
        borderAlpha: 0,
        fillAlphas: 1,
        borderThickness: 0,
        pointerOrientation: "down",
        color: "#000000",
        fillColor: "#ffffff",
        verticalPadding: 10,
        horizontalPadding: 12,
        fontSize: 13,
        textAlign: "left"
      },

      chartCursor: {
        valueLineEnabled: true,
        valueLineBalloonEnabled: true,
        cursorColor: "#f1f1f1",
        color: "#000000"
      },
      //-------------------------------------------END
      titles: [
        {
          id: "Title-1",
          size: 15,
          text: ""
        }
      ],
      dataProvider: []
    };

    config.dataProvider = JSON.parse(data);
    this.config = config;
    //console.log("Chart Config : ", JSON.stringify(config));
  }

  render() {
    return (
      <div className="app">
        <div className="app-body">
          {/*****'Asset Group Menu'*****/}
          <div className="col-sm-2">
            <div className="flex-row">
              {/* <div className="dropdown col-sm-2">
                <select id="categorySelect" value={tabModelStore.getActiveTab.ChartCategoryId} onChange={(value, label) => { this.setState({ CategoryId: value }) }} >
                  {tabModelStore.getChartCategoryData.map((item) =>
                    <option key={item.CategoryId} value={item.CategoryId}>{item.ViewName}</option>)}
                </select>
              </div>
              <div className="dropdown col-sm-2">
                <select id="chartSelect" value={tabModelStore.getActiveTab.ChartViewId} onChange={(value, label) => { this.setState({ ChartId: value }) }} >
                  {tabModelStore.getChartViewData.map((item) =>
                    <option key={item.ChartId} value={item.ChartId}>{item.value}</option>)}
                </select>
              </div> */}
            </div>
          </div>
          <br />
          <div className="col-lg-12">
            {tabModelStore.dataLoaded ? (
              <AmCharts.React
                style={{ width: "90%", height: "400px" }}
                options={this.config}
              />
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default Charts;
