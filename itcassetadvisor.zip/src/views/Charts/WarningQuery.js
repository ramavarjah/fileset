import React, { Component } from "react";
import { observer } from "mobx-react";
import { Modal } from "reactstrap";
import userStore from "../../stores/userStore";
import PropTypes from "prop-types";
const header = {
    fontSize: 28,
    letterSpacing: 2,
    lineHeight: 2,
    color: "#737474",
    margin: 0,
    marginLeft: "-5px",
    fontWeight: "700"
};
const btn = {
    padding: "1px 20px",
    border: "1px solid #979797",
    background: "#f4f4f4",
    color: "#979797",
    fontSize: 17,
    lineHeight: 1.8,
    marginRight: 13,
    borderRadius: 5,
    cursor: "pointer",
    marginBottom: 5
};
const container = {
    backgroundColor: "#fff",
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%,-50%)",
    transition: "all .35s ease-in-out"
};
const wrapper = {
    backgroundColor: "#fff",
    // padding:40,
    // minWidth:400,
    // paddingLeft: 25,
    // paddingBottom: 25,
    // paddingRight: 25,
    // paddingTop: 10,
    padding: "15px 14px 25px 25px"
};
const para = {
    fontSize: 16.5,
    color: "#7a8186",
    margin: 0,
    fontWeight: "300",
    lineHeight: 1.8,
    letterSpacing: 1.2
};

@observer
class WarningQuery extends Component {
    constructor(props) {
        super(props);
        // var config = { "type": "serial", "categoryField": "Manufacturer", "columnWidth": 0.4, "marginBottom": 5, "marginLeft": 5, "marginRight": 10, "marginTop": 5, "sequencedAnimation": false, "startDuration": 1, "startEffect": "easeInSine", "color": "#E7E7E7", "fontFamily": "Open Sans", "theme": "dark", "categoryAxis": { "autoWrap": true, "gridPosition": "start", "title": "" }, "export": { "enabled": true, "menu": [], "backgroundColor": "#2b2c33" }, "valueScrollbar": { "enabled": true, "graph": "AmGraph-1", "graphType": "column" }, "chartScrollbar": { "enabled": true }, "trendLines": [], "graphs": [{ "accessibleLabel": "[[title]] [[value]] [[Manufacturer]]", "balloonText": "<span><b>Asset Count: [[Count]]</b>\n [[Manufacturer]]</span>", "fillAlphas": 0.7, "fillColors": "#00ff9c", "lineColor": "#00ff9c", "showHandOnHover": true, "id": "AmGraph-1", "labelText": "", "title": "graph 1", "type": "column", "valueField": "Count" }], "guides": [], "valueAxes": [{ "id": "ValueAxis-1", "integersOnly": true, "minimum": 0, "title": "Asset Count" }], "allLabels": [], "balloon": { "disableMouseEvents": false, "adjustBorderColor": true, "borderAlpha": 0, "fillAlphas": 1, "borderThickness": 0, "pointerOrientation": "down", "color": "#000000", "fillColor": "#ffffff", "verticalPadding": 10, "horizontalPadding": 12, "fontSize": 13, "textAlign": "left" }, "chartCursor": { "valueLineEnabled": true, "valueLineBalloonEnabled": true, "cursorColor": "#f1f1f1", "color": "#000000" }, "titles": [{ "id": "Title-1", "size": 15, "text": "" }], "dataProvider": [{ "Manufacturer": "Keysight", "Count": 23 }, { "Manufacturer": "Anritsu", "Count": 10 }, { "Manufacturer": "R&S", "Count": 4 }, { "Manufacturer": "Sprient", "Count": 2 }, { "Manufacturer": "Keysight Technologies", "Count": 1 }] }
        this.state = {
            dataProvider: "",
            localModalOpen: false
        };
    }
    componentDidMount() {
        var queryMode = userStore.getQueryMode;
        if (queryMode == "proceed") {
            this.props.handleButton("proceed");
        } else
            this.setState({
                localModalOpen: true
            });
    }

    render() {
        var assets = this.props.data.validAssetCount
            ? this.props.data.validAssetCount
            : "";
        var totalDays = this.props.data.totalDays ? this.props.data.totalDays : "";
        return (
            <div>
                <Modal
                    isOpen={this.state.localModalOpen}
                    className="modal-dialog modal-lg"
                    style={container}
                    id="createAssetModal"
                >
                    <section style={wrapper}>
                        <h1 style={header}>Warning</h1>
                        <main style={{ marginTop: 5 }}>
                            <p style={para}>Based on your settings:</p>
                            <p style={para}>
                                <span style={{ color: "#3385ff" }}>
                                    {assets} assets | {totalDays} days | View By Hours,
                                </span>
                            </p>
                            <p style={para}>this query will take time to complete.</p>
                        </main>
                        <div style={{ marginTop: 25, marginBottom: 25 }}>
                            <p style={para}>Would you like to:</p>
                        </div>
                        <footer>
                            <div style={{ margin: 3 }}>
                                <span
                                    style={{ marginLeft: 28, color: "#a49b9b", fontSize: 13 }}
                                >
                  (<em>Recommended</em>)
                                </span>
                            </div>
                            <button
                                onClick={() => {
                                    this.props.handleButton("ByDates");
                                }}
                                style={btn}
                            >
                View by Days
                            </button>
                            <button
                                onClick={() => {
                                    userStore.setWarningQuery("proceed");
                                    this.props.handleButton("proceed");
                                }}
                                style={btn}
                            >
                Proceed
                            </button>
                            <button
                                onClick={() => this.props.handleButton("cancel")}
                                style={btn}
                            >
                Cancel
                            </button>
                        </footer>
                    </section>
                </Modal>
            </div>
        );
    }
}
export default WarningQuery;
WarningQuery.propTypes = {
    handleButton: PropTypes.func,
    data: PropTypes.object
};
