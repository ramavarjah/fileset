import React, { Component } from "react";
import { observer } from "mobx-react";
import "./style.css";
import userStore from "../../stores/userStore";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";
import { ListGroup, ListGroupItem } from "reactstrap";

import {
    Form,
    InputNumber,
    Button,
    Checkbox,
    Select,
    Card,
    Cascader
} from "antd";
const FormItem = Form.Item;
const Option = Select.Option;

var rr, locTree;

@observer
class UserPreferences1 extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orgTreeData: [],
            locTreeData: []
        };
        this.setLocOrgTree = this.setLocOrgTree.bind(this);
        this.savePreferences = this.savePreferences.bind(this);
        this.handleClose = this.props.handleClose.bind(this);
        this.handleEdit = this.handleEdit.bind(this);
    }
  handleEdit = () => {
      userStore.seteditFlag(false);
  };

  savePreferences() {
      var NotificationAssetGroups = userStore.preferences.NotificationAssetGroups;

      //changing one item from boolean to string

      const newValues = this.props.form.getFieldsValue();

      newValues["assetHealthCheckbox"] = newValues[
          "assetHealthCheckbox"
      ].toString();
      userStore.setPreferences(newValues);
      userStore.addToPreference({
          NotificationAssetGroups: NotificationAssetGroups
      });
      Functions.UpdateUserPreference({ Input: userStore.preferences }).then(
          response => {
              if (response.data.success) {
                  UIFunctions.Toast("Preferences Saved", "success");
                  userStore.setbasePreferences(userStore.preferences);
                  userStore.setEditing(false);
                  userStore.seteditFlag(true);
                  userStore.setUserDetailsModalopen(false);
              } else {
                  UIFunctions.Toast(
                      "There was an error in saving the preferences",
                      "error"
                  );
              }
          }
      );
  }
  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll(() => {});
  };

  createFrequencySelectItems = () => {
      let opts = ["Weekly", "Monthly", "Yearly"];
      let items = [];
      for (let i = 0; i < opts.length; i++) {
          items.push(
              <Option key={i} value={opts[i].toString()}>
                  {opts[i].toString()}
              </Option>
          );
      }
      return items;
  };
  process(json, tag, pos, currentValue) {
      var currentVal = currentValue;

      if (json.text) {
          var toadd =
        '{"label":"' +
        json.text +
        '",' +
        '"key":"' +
        tag +
        "-" +
        pos +
        '",' +
        '"value":"' +
        json.text +
        '",';
          if (currentVal) {
              toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          currentVal +
          " > " +
          json.text +
          '",';
              currentVal = currentVal + " > " + json.text;
          } else {
              currentVal = json.text;
          }
          if (rr) {
              rr = rr + toadd;
          } else {
              rr = toadd;
          }
      }
      if (json.expanded) {
          if (json.text) {
              let toadd = '"children":[';
              rr = rr + toadd;
          }

          json.children.map((item, index) => {
              var poss = index + 1;
              this.process(item, tag + "-" + pos, poss, currentVal);
              var toadd = ",";
              rr = rr + toadd;
          });
          rr = rr.slice(0, -1);
          if (json.text) {
              let toadd = "]";
              rr = rr + toadd;
          }
      } else {
          rr = rr.slice(0, -1);
      }
      if (json.text) {
          let toadd = "}";
          rr = rr + toadd;
      }

      return true;
  }
  processLocTree(json, tag, pos, currentValue) {
      var currentVal = currentValue;

      if (json.text) {
          var toadd =
        '{"label":"' +
        json.text +
        '",' +
        '"key":"' +
        tag +
        "-" +
        pos +
        '",' +
        '"value":"' +
        json.text +
        '",';
          if (currentVal) {
              toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          currentVal +
          " > " +
          json.text +
          '",';
              currentVal = currentVal + " > " + json.text;
          } else {
              currentVal = json.text;
          }
          if (locTree) {
              locTree = locTree + toadd;
          } else {
              locTree = toadd;
          }
      }
      if (json.expanded) {
          if (json.text) {
              let toadd = '"children":[';
              locTree = locTree + toadd;
          }

          json.children.map((item, index) => {
              var poss = index + 1;
              this.processLocTree(item, tag + "-" + pos, poss, currentVal);
              var toadd = ",";
              locTree = locTree + toadd;
          });
          locTree = locTree.slice(0, -1);
          if (json.text) {
              let toadd = "]";
              locTree = locTree + toadd;
          }
      } else {
          locTree = locTree.slice(0, -1);
      }
      if (json.text) {
          let toadd = "}";
          locTree = locTree + toadd;
      }

      return true;
  }

  componentDidMount() {
      var customerId = userStore.userDetails.CustomerId;

      Functions.GetOrganizationTree(customerId).then(resp => {
          var json = resp.data.tree;
          rr = null;
          this.process(json, "0", "0", false);
          var dta = "[" + rr + "]";
          var tdta = JSON.parse(dta);
          this.setState({ orgTreeData: tdta });

          Functions.GetLocationTree(customerId).then(resp => {
              locTree = null;
              this.processLocTree(resp.data.tree, "0", "0", false);
              var dta = "[" + locTree + "]";
              var tdta = JSON.parse(dta);
              this.setState({ locTreeData: tdta });
              const newValues = userStore.preferences;
              newValues["assetHealthCheckbox"] =
          newValues["assetHealthCheckbox"] == "true";
              this.props.form.setFieldsValue(newValues);
          });
      });
  }
  setLocOrgTree(val) {
      var ss = this.props.form.getFieldValue(val);
      var loc = val.substring(0, 3) + " : " + ss[ss.length - 1];
      userStore.changeAssetGroups(loc, "add");
  }
  render() {
      const { getFieldDecorator } = this.props.form;
      const formItemLayout = {
          labelCol: { span: 4 },
          wrapperCol: { span: 6 }
      };
      const formItemCheckLayout = {
          labelCol: { span: 24 },
          wrapperCol: { span: 24 }
      };
      const formItemSelLayout = {
          labelCol: { span: 24 },
          wrapperCol: { span: 24 }
      };
      const formItemDaysLayout = {
          labelCol: { span: 24 },
          wrapperCol: { span: 24 }
      };

      return (
          <div className="userSettingsContainer userSettingsNotification">
              {!userStore.preferences ? (
                  <Card loading />
              ) : (
                  <div className="userSettingsFormWrapper">
                      <Form onSubmit={this.handleSubmit} style={{ width: "100%" }}>
                          <div
                              style={{
                                  height: window.innerHeight - 290,
                                  overflow: "auto",
                                  padding: "0px 30px 60px 30px"
                              }}
                          >
                              <div className="userSettingsFormFieldset">
                                  <div
                                      className="settingsRow userSettingsFormHeader"
                                      style={{ marginTop: "0px" }}
                                  >
                                      <h5>General Settings</h5>
                                  </div>
                                  <div className="row">
                                      <div className="col-md-12">
                                          <FormItem
                                              {...formItemLayout}
                                              label="Language"
                                              hasFeedback
                                          >
                                              {getFieldDecorator("Language", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select language!"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Select a Language"
                                                  >
                                                      <Option value="The Kings Speech">English</Option>
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-12">
                                          <FormItem {...formItemCheckLayout}>
                                              {getFieldDecorator("DND", {
                                                  valuePropName: "checked"
                                              })(
                                                  <Checkbox
                                                      //  disabled={userStore.editFlag}
                                                      onChange={() => userStore.setEditing(true)}
                                                  >
                            Do not send any emails
                                                  </Checkbox>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-12">
                                          <FormItem {...formItemCheckLayout}>
                                              {getFieldDecorator("GroupAlerts", {
                                                  valuePropName: "checked"
                                              })(
                                                  <Checkbox onChange={() => userStore.setEditing(true)}>
                            Group alerts with same frequency in single email
                                                  </Checkbox>
                                              )}
                                          </FormItem>
                                      </div>
                                  </div>
                              </div>{" "}
                              <div className="clear" />
                              <div className="userSettingsFormFieldset">
                                  <div className="settingsRow userSettingsFormHeader">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <h5>Email Alert Options</h5>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <h5>Frequency</h5>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <h5>Alert Days Prior</h5>
                                      </div>
                                      <div className="clear" />
                                  </div>

                                  {/* warranty alert */}
                                  <div className="settingsRow">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <label className="formLabel">
                          End of Warranty or Support Agreement
                                              </label>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemSelLayout} hasFeedback>
                                              {getFieldDecorator("EndofWarrantySupport", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select frequency"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      placeholder="Select a Frequency"
                                                      onChange={() => userStore.setEditing(true)}
                                                  >
                                                      {this.createFrequencySelectItems()}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemDaysLayout} label="" hasFeedback>
                                              {getFieldDecorator("EndOfWarrantyDaysPrior", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please input alert days prior"
                                                      }
                                                  ]
                                              })(
                                                  <InputNumber
                                                      min={1}
                                                      max={100}
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Alert Days Prior"
                                                  />
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="clear" />
                                  </div>

                                  {/* service due alert */}
                                  <div className="settingsRow">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <label className="formLabel">Service Due Alert</label>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemSelLayout} hasFeedback>
                                              {getFieldDecorator("ServiceDueAlert", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select frequency"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Select a Frequency"
                                                  >
                                                      {this.createFrequencySelectItems()}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemDaysLayout} label="" hasFeedback>
                                              {getFieldDecorator("ServiceDueAlertDaysPrior", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please input alert days prior"
                                                      }
                                                  ]
                                              })(
                                                  <InputNumber
                                                      min={1}
                                                      max={100}
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Alert Days Prior"
                                                  />
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="clear" />
                                  </div>

                                  {/* service order status alert */}
                                  <div className="settingsRow">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <label className="formLabel">
                          Service Order Status Update
                                                  <br />{" "}
                                                  <span>
                            (open orders, received, shipped, OOT, delay, etc)
                                                  </span>
                                              </label>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemSelLayout} hasFeedback>
                                              {getFieldDecorator("ServiceOrderAlert", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select frequency"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Select a Frequency"
                                                  >
                                                      {this.createFrequencySelectItems()}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-3 pull-left" />
                                      <div className="clear" />
                                  </div>

                                  {/* product safety alert */}
                                  <div className="settingsRow">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <label className="formLabel">
                          Product Safety, Firmware Updates, Discontinuance
                          Alerts
                                              </label>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemSelLayout} hasFeedback>
                                              {getFieldDecorator("ProductSafetyFirmwareAlert", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select frequency"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      placeholder="Select a Frequency"
                                                      onChange={() => userStore.setEditing(true)}
                                                  >
                                                      {this.createFrequencySelectItems()}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-3 pull-left" />
                                      <div className="clear" />
                                  </div>

                                  {/* service request alert */}
                                  <div className="settingsRow">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <label className="formLabel">
                          Service Request Acknowledgement
                                              </label>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemSelLayout} hasFeedback>
                                              {getFieldDecorator("ServiceRequestAcknowledgeAlert", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select frequency"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Select a Frequency"
                                                  >
                                                      {this.createFrequencySelectItems()}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-3 pull-left" />
                                      <div className="clear" />
                                  </div>

                                  {/* asset health alert */}
                                  <div className="settingsRow">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <label className="formLabel">Asset Health Status</label>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemSelLayout} hasFeedback>
                                              {getFieldDecorator("AssetHealthStatus", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select frequency"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Select a Frequency"
                                                  >
                                                      {this.createFrequencySelectItems()}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-3 pull-left asset-health-checkbox">
                                          <FormItem {...formItemDaysLayout} label="" hasFeedback>
                                              {getFieldDecorator("assetHealthCheckbox", {
                                                  valuePropName: "checked",
                                                  initialValue: false
                                              })(<Checkbox>Subscribe for immediate alerts</Checkbox>)}
                                          </FormItem>
                                      </div>
                                      <div className="clear" />
                                  </div>

                                  {/* oot alert */}
                                  <div className="settingsRow">
                                      <div className="col-md-6 pull-left">
                                          <div className="row">
                                              <label className="formLabel">
                          Out of Tolerance event
                                              </label>
                                          </div>
                                      </div>
                                      <div className="col-md-3 pull-left">
                                          <FormItem {...formItemSelLayout} hasFeedback>
                                              {getFieldDecorator("OutofTolerance", {
                                                  rules: [
                                                      {
                                                          required: true,
                                                          message: "Please select frequency"
                                                      }
                                                  ]
                                              })(
                                                  <Select
                                                      onChange={() => userStore.setEditing(true)}
                                                      placeholder="Select a Frequency"
                                                  >
                                                      {this.createFrequencySelectItems()}
                                                  </Select>
                                              )}
                                          </FormItem>
                                      </div>
                                      <div className="col-md-3 pull-left" />
                                      <div className="clear" />
                                  </div>
                              </div>{" "}
                              {/* end of Email Alert Settings */}
                              <div className="clear" />
                              <div className="userSettingsFormFieldset userSettingAssets">
                                  <div className="settingsRow userSettingsFormHeader">
                                      <div className="col-md-12 pull-left">
                                          <div className="row">
                                              <h5>Assets | Get Alerts for</h5>
                                          </div>
                                      </div>
                                      <div className="clear" />
                                  </div>
                                  <div className="assetsSettingsContainer">
                                      <div className="col-md-5 pull-left">
                                          <div className="assetsButtonContainer">
                                              <FormItem>
                                                  <Button
                                                      onClick={() =>
                                                          userStore.changeAssetGroups("Coordinator", "add")
                                                      }
                                                      className="assetsUserButton"
                                                      type="button"
                                                      style={{ marginLeft: 8 }}
                                                  >
                            Coordinator
                                                  </Button>
                                              </FormItem>
                                          </div>
                                          <div className="assetsButtonContainer">
                                              <FormItem>
                                                  <Button
                                                      onClick={() =>
                                                          userStore.changeAssetGroups("User", "add")
                                                      }
                                                      className="assetsUserButton"
                                                      type="button"
                                                      style={{ marginLeft: 8 }}
                                                  >
                            User
                                                  </Button>
                                              </FormItem>
                                          </div>
                                          <div className="assetsSelectContainer">
                                              <FormItem
                                                  {...formItemSelLayout}
                                                  hasFeedback
                                                  label="Organization"
                                              >
                                                  {getFieldDecorator("Organization", {})(
                                                      <Cascader
                                                          getPopupContainer={trigger =>
                                                              trigger.parentElement
                                                          }
                                                          options={this.state.orgTreeData}
                                                          changeOnSelect
                                                      />
                                                  )}
                                                  <Button
                                                      onClick={() => this.setLocOrgTree("Organization")}
                                                  >
                                                      {">>"}
                                                  </Button>
                                              </FormItem>
                                          </div>
                                          <div className="assetsSelectContainer">
                                              <FormItem
                                                  {...formItemSelLayout}
                                                  hasFeedback
                                                  label="Location"
                                              >
                                                  {getFieldDecorator("Location", {})(
                                                      <Cascader
                                                          getPopupContainer={trigger =>
                                                              trigger.parentElement
                                                          }
                                                          options={this.state.locTreeData}
                                                          changeOnSelect
                                                      />
                                                  )}
                                                  <Button
                                                      onClick={() => this.setLocOrgTree("Location")}
                                                  >
                                                      {">>"}
                                                  </Button>
                                              </FormItem>
                                          </div>
                                      </div>
                                      <div className="col-md-6 pull-left">
                                          <label className="formLabel userSettingAsset">
                        Asset Groups
                                          </label>
                                          <div
                                              style={{
                                                  height: "300px",
                                                  overflow: "scroll",
                                                  background: "white"
                                              }}
                                          >
                                              <ListGroup>
                                                  {userStore.editFlag
                                                      ? userStore.preferences.NotificationAssetGroups.map(
                                                          (it, index) => (
                                                              <ListGroupItem key={index}>
                                                                  {it}
                                                              </ListGroupItem>
                                                          )
                                                      )
                                                      : userStore.preferences.NotificationAssetGroups.map(
                                                          (it, index) => (
                                                              <ListGroupItem key={index}>
                                                                  {it}
                                                                  <i
                                                                      style={{ color: "black" }}
                                                                      onClick={() =>
                                                                          userStore.changeAssetGroups(
                                                                              it,
                                                                              "delete"
                                                                          )
                                                                      }
                                                                      className="icon-close"
                                                                  />
                                                              </ListGroupItem>
                                                          )
                                                      )}
                                              </ListGroup>
                                          </div>
                                      </div>
                                      <div className="col-md-1 pull-left">
                                          <label className="formLabel">
                                              {" "}
                        Select the type of assets you want to get notifications
                        for*
                                          </label>
                                      </div>
                                      <div className="clear" />
                                  </div>
                              </div>
                              <div className="clear" />
                          </div>
                          {/* end of Assets | Get Alerts for Settings */}

                          <div
                              className="alert alert-info"
                              style={{ "text-align": "center" }}
                          >
                              {" "}
                Notifications Implementation - Work In Progress
                          </div>

                          <div>
                              <div className="userSettingsButton">
                                  <FormItem>
                                      <Button
                                          className="cancelButton"
                                          style={{ marginLeft: 8 }}
                                          onClick={this.handleClose}
                                      >
                      Cancel
                                      </Button>
                                      <Button
                                          className="submitButton"
                                          type="primary"
                                          style={{ marginLeft: 8 }}
                                          onClick={this.savePreferences}
                                      >
                      Submit
                                      </Button>
                                  </FormItem>
                              </div>
                          </div>
                      </Form>
                      <div className="clear" />
                  </div>
              )}
          </div>
      );
  }
}

// export default UserPreferences1;

const UserPreferences = Form.create()(UserPreferences1);
export default UserPreferences;
