import React, { Component } from "react";
import { observer } from "mobx-react";
import userStore from "../../stores/userStore";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";

import { Form, Input, Button } from "antd";
const FormItem = Form.Item;

@observer
class UserPwdDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            oldpassword: "",
            newpassword1: "",
            newpassword2: "",
            editFlag: true,
            userDetails: userStore.userDetails,
            confirmDirty: false,

            isValidLength: "noRule",
            isValidNoName: "noRule",
            isValidUppercase: "noRule",
            isValidLowercase: "noRule",
            isValidNumber: "noRule",
            isValidSpecial: "noRule"
        };
        this.changePassword = this.changePassword.bind(this);
        this.handleReset = this.handleReset.bind(this);
        this.handleClose = this.props.handleClose.bind(this);
    }
  handleReset = (e, directClose) => {
      this.props.form.resetFields();
      this.clearNewPwdRule();
      directClose
          ? userStore.setUserDetailsModalopen(false)
          : this.handleClose(e);
  };
  changePassword = e => {
      this.props.form.validateFields(err => {
          if (!err) {
              Functions.ChangePassword(
                  this.state.oldpassword,
                  this.state.newpassword1,
                  this.state.newpassword2
              ).then(response => {
                  if (response.data.success && response.data.hasChanged) {
                      UIFunctions.Toast("Password Changed", "success");
                  } else {
                      UIFunctions.Toast(response.data.message, "error");
                  }
                  this.handleReset(e, true);
                  userStore.setEditing(false);
              });
          }
      });
  };
  handleConfirmBlur = e => {
      const value = e.target.value;
      this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  };
  checkPassword = (rule, value, callback) => {
      const form = this.props.form;
      if (value && value !== form.getFieldValue("newPassword")) {
          callback("Passwords do not match");
      } else {
          callback();
      }
  };
  checkConfirm = (rule, value, callback) => {
      const form = this.props.form;
      if (value && this.state.confirmDirty) {
          form.validateFields(["confirm"], { force: true });
      }
      callback();
  };

  clearNewPwdRule = () => {
      this.setState({
          isValidLength: "noRule",
          isValidNoName: "noRule",
          isValidUppercase: "noRule",
          isValidLowercase: "noRule",
          isValidNumber: "noRule",
          isValidSpecial: "noRule"
      });
  };

  checkPwd = (rule, value, callback) => {
      if (value == undefined) {
          this.setState({
              isValidLength: "inValid",
              isValidNoName: "inValid",
              isValidUppercase: "inValid",
              isValidLowercase: "inValid",
              isValidNumber: "inValid",
              isValidSpecial: "inValid"
          });
          return callback();
      }

      if ((value && value.length < 8) || value.length == 0) {
          this.setState({
              isValidLength: "inValid"
          });
          callback("Password length should be greater than 8 characters");
      } else {
          this.setState({
              isValidLength: "valid"
          });
      }

      let firstName = userStore.userDetails.firstName;
      let lastName = userStore.userDetails.lastName;
      let userNameTokens = userStore.userDetails.UserName.split(/[\s#,.\-_]+/);
      let emailAddress = userStore.userDetails.emailAddress;
      let token = "";
      let firstNameTokens = [];
      let lastNameTokens = [];
      let emailAddressTokens = [];

      let matchName = 0;
      if (firstName != undefined && firstName.trim() != "") {
          firstNameTokens = firstName.split(/[\s#,.\-_]+/);
      }
      if (lastName != undefined && lastName.trim() != "") {
          lastNameTokens = lastName.split(/[\s#,.\-_]+/);
      }
      if (emailAddress != undefined && emailAddress.trim() != "") {
          emailAddressTokens = emailAddress.split(/[\s#,.\-_]+/);
      }
      for (let x = 0; x < userNameTokens.length; x++) {
          if (
              userNameTokens[x].length > 2 &&
        value.toLowerCase().indexOf(userNameTokens[x].toLowerCase()) != -1
          ) {
              matchName++;
              callback(
                  "Password cannot contain the word " +
            token +
            " present in the username"
              );
          }
      }
      for (let x = 0; x < firstNameTokens.length; x++) {
          if (
              firstNameTokens[x].length > 2 &&
        value.toLowerCase().indexOf(firstNameTokens[x].toLowerCase()) != -1
          ) {
              matchName++;
              callback(
                  "Password cannot contain the word " +
            token +
            " present in the first name"
              );
          }
      }
      for (let x = 0; x < lastNameTokens.length; x++) {
          if (
              lastNameTokens[x].length > 2 &&
        value.toLowerCase().indexOf(lastNameTokens[x].toLowerCase()) != -1
          ) {
              matchName++;
              callback(
                  "Password cannot contain the word " +
            token +
            " present in the last name"
              );
          }
      }
      for (let x = 0; x < emailAddressTokens.length; x++) {
          if (
              emailAddressTokens[x].length > 2 &&
        value.toLowerCase().indexOf(emailAddressTokens[x].toLowerCase()) != -1
          ) {
              matchName++;
              callback(
                  "Password cannot contain the word " +
            token +
            " present in the email address"
              );
          }
      }

      if (matchName == 0) {
          this.setState({
              isValidNoName: "valid"
          });
      } else {
          this.setState({
              isValidNoName: "inValid"
          });
      }

      var reg = /(?=.*[A-Z\u0080-\u024F\u0300-\u04FF\u00C0-\u024F])/g;
      var reg1 = /(?=.*[a-z\u0080-\u024F\u0300-\u04FF\u00C0-\u024F])/g;
      var reg2 = /(?=.*[0-9])/g;
      var reg3 = /(?=.*[\W])/g;

      if (reg.test(value)) {
          this.setState({
              isValidUppercase: "valid"
          });
      } else {
          this.setState({
              isValidUppercase: "inValid"
          });
          callback("Password must contain an uppercase letter");
      }

      if (reg1.test(value)) {
          this.setState({
              isValidLowercase: "valid"
          });
      } else {
          this.setState({
              isValidLowercase: "inValid"
          });
          callback("Password must contain a lowercase letter");
      }

      if (reg2.test(value)) {
          this.setState({
              isValidNumber: "valid"
          });
      } else {
          this.setState({
              isValidNumber: "inValid"
          });
          callback("Password must contain a number");
      }

      if (reg3.test(value)) {
          this.setState({
              isValidSpecial: "valid"
          });
      } else {
          this.setState({
              isValidSpecial: "inValid"
          });
          callback("Password must contain a special character");
      }

      callback();
  };

  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll();
  };

  render() {
      const { getFieldDecorator } = this.props.form;

      const formItemLayout = {
          labelCol: { span: 24 },
          wrapperCol: { span: 24 }
      };
      return (
          <div
              className="bg userSettingsContainer"
              style={{ height: window.innerHeight - 202, overflow: "auto" }}
          >
              <div className="changePasswordContainer moduleContainerWrapper">
                  <Form onSubmit={this.handleSubmit} style={{ width: "100%" }}>
                      <div className="col-md-6 pull-left borderRight">
                          <div>
                              <ul className="passwordRule">
                                  <li>
                                      <label className={this.state.isValidLength}>
                                          {" "}
                      Password should contain minimum 8 characters{" "}
                                      </label>
                                  </li>
                                  <li>
                                      <label className={this.state.isValidNoName}>
                                          {" "}
                      Password should not contain words/strings from First name,
                      Last name and Email{" "}
                                      </label>
                                  </li>
                                  <li>
                                      <label className="passwordsMust">
                                          {" "}
                      Password should contain characters from four of the
                      following categories:{" "}
                                      </label>
                                  </li>
                                  <li>
                                      <label className={this.state.isValidUppercase}>
                                          {" "}
                      At least one uppercase letter (A - Z)
                                      </label>
                                  </li>
                                  <li>
                                      <label className={this.state.isValidLowercase}>
                                          {" "}
                      At least one lowercase letter (a - z)
                                      </label>
                                  </li>
                                  <li>
                                      <label className={this.state.isValidNumber}>
                                          {" "}
                      At least one number (0 - 9)
                                      </label>
                                  </li>
                                  <li>
                                      <label className={this.state.isValidSpecial}>
                                          {" "}
                      At least one special character
                                      </label>
                                  </li>
                              </ul>
                          </div>
                      </div>

                      <div className="col-md-6 pull-left">
                          <FormItem {...formItemLayout} label="Old Password" hasFeedback>
                              {getFieldDecorator("Old password", {
                                  rules: [
                                      {
                                          required: true,
                                          message: "Please input your old password!"
                                      }
                                  ]
                              })(
                                  <Input
                                      type="password"
                                      autoComplete="off"
                                      onChange={e => {
                                          this.setState({ oldpassword: e.target.value });
                                          userStore.setEditing(true);
                                      }}
                                  />
                              )}
                          </FormItem>

                          <FormItem {...formItemLayout} label="New Password" hasFeedback>
                              {getFieldDecorator("newPassword", {
                                  rules: [
                                      {
                                          required: true,
                                          message: "Please input your new password!"
                                      },
                                      {
                                          validator: this.checkPwd
                                      },
                                      {
                                          validator: this.checkConfirm
                                      }
                                  ]
                              })(
                                  <Input
                                      type="password"
                                      autoComplete="off"
                                      onChange={e => {
                                          this.setState({ newpassword1: e.target.value });
                                          userStore.setEditing(true);
                                      }}
                                  />
                              )}
                          </FormItem>
                          <FormItem
                              {...formItemLayout}
                              label="Confirm Password"
                              hasFeedback
                          >
                              {getFieldDecorator("confirm", {
                                  rules: [
                                      {
                                          required: true,
                                          message: "Please confirm your new password!"
                                      },
                                      {
                                          validator: this.checkPassword
                                      }
                                  ]
                              })(
                                  <Input
                                      type="password"
                                      autoComplete="off"
                                      onChange={e => {
                                          this.setState({ newpassword2: e.target.value });
                                          userStore.setEditing(true);
                                      }}
                                      onBlur={this.handleConfirmBlur}
                                  />
                              )}
                          </FormItem>
                      </div>

                      <div className="clear" />

                      <div className="col-md-12 pull-left">
                          <div className="userSettingsButton">
                              <FormItem>
                                  <Button
                                      className="cancelButton"
                                      style={{ marginLeft: 8 }}
                                      onClick={this.handleReset}
                                  >
                    Cancel
                                  </Button>
                                  <Button
                                      className="submitButton"
                                      type="primary"
                                      style={{ marginLeft: 8 }}
                                      onClick={this.changePassword}
                                  >
                    Submit
                                  </Button>
                              </FormItem>
                          </div>
                      </div>
                  </Form>
                  <div className="clear" />
              </div>
          </div>
      );
  }
}

const UserDetails = Form.create()(UserPwdDetails);
export default UserDetails;
