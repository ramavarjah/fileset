import React, { Component } from "react";
import { Modal, ModalHeader, ModalBody } from "reactstrap";
import UserDetailsInput from "./UserDetailsInput";
import UserPreferences from "./UserPreferences";
import ChangePassword from "./ChangePassword";
import InfolineAccount from "./InfolineAccount";
import userStore from "../../stores/userStore";
import UIFunctions from "../../helpers/UIFunctions";
import { Row, Col, Tabs } from "antd";
const TabPane = Tabs.TabPane;
import PropTypes from "prop-types";

class UserDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeTab: "1"
        };

        this.handleClose = this.handleClose.bind(this);
        this.handleTabChange = this.handleTabChange.bind(this);
    }

  handleClose = e => {
      e.preventDefault();
      if (userStore.editing) {
          UIFunctions.ShowConfirm({
              zIndex: 2000,
              title: "Do you want to discard changes?",
              okText: "Yes",
              cancelText: "No",
              onOk() {
                  userStore.setUserDetails(userStore.baseUserDetails);
                  userStore.setPreferences(userStore.basePrefences);
                  userStore.setUserDetailsModalopen(false);
                  userStore.seteditFlag(true);
                  userStore.setEditing(false);
              },
              onCancel() {}
          });
      } else {
          userStore.setUserDetails(userStore.baseUserDetails);
          userStore.setPreferences(userStore.basePrefences);
          userStore.setUserDetailsModalopen(false);
          userStore.seteditFlag(true);
          userStore.setEditing(false);
      }
  };

  handleTabChange = key => {
      var self = this;
      if (userStore.editing) {
          UIFunctions.ShowConfirm({
              zIndex: 2000,
              title: "Do you want to discard changes? ",
              okText: "Yes",
              cancelText: "No",
              // content: 'All the entries will be lost',
              onOk() {
                  self.setState({
                      activeTab: key
                  });
                  userStore.setUserDetails(userStore.baseUserDetails);
                  userStore.setPreferences(userStore.basePrefences);
                  userStore.seteditFlag(true);
                  userStore.setEditing(false);
              },
              onCancel() {}
          });
      } else {
          this.setState({
              activeTab: key
          });
          userStore.seteditFlag(true);
          userStore.setEditing(false);
      }
  };

  render() {
      return (
          <Modal
              isOpen={true}
              className="modal-dialog modal-lg editFiltersModal userSettingsModal"
              id="createAssetModal"
              style={{ maxWidth: 1100 }}
          >
              <ModalHeader
                  className="row modalHeader editFiltersModalHeader"
                  style={{ borderBottom: "1px solid #ccd0d8" }}
              >
                  <span className="createAssetLabel">USER SETTINGS</span>
                  <span onClick={this.handleClose} style={{ cursor: "pointer" }}>
                      <i className="icon-close" />
                  </span>
              </ModalHeader>
              <ModalBody style={{ padding: 0 }}>
                  {/* 'User Details Tabs' */}
                  <Row className="userDetailsTabWrapper">
                      <Col span={24}>
                          <Tabs
                              defaultActiveKey="1"
                              size="small"
                              activeKey={this.state.activeTab}
                              onChange={this.handleTabChange}
                          >
                              <TabPane tab="User Info" key="1" />
                              <TabPane tab="Change Password" key="2" />
                              <TabPane tab="Notification Settings" key="3" />
                              <TabPane tab="myKeysight Account" key="4" />
                              {/*<TabPane tab="Appearance" key="4"/>*/}
                          </Tabs>
                      </Col>
                  </Row>
                  {/* 'Tabs' */}
                  <Row className="userDetailsTabContainer">
                      <Col span={24}>
                          {this.state.activeTab == "1" ? (
                              <UserDetailsInput handleClose={this.handleClose} />
                          ) : (
                              ""
                          )}
                          {this.state.activeTab == "2" ? (
                              <ChangePassword handleClose={this.handleClose} />
                          ) : (
                              ""
                          )}
                          {this.state.activeTab == "3" ? (
                              <UserPreferences handleClose={this.handleClose} />
                          ) : (
                              ""
                          )}
                          {this.state.activeTab == "4" ? (
                              <InfolineAccount handleClose={this.handleClose} />
                          ) : (
                              ""
                          )}
                      </Col>
                  </Row>
              </ModalBody>
          </Modal>
      );
  }
}

export default UserDetails;

UserDetails.propTypes = {
    router: PropTypes.object.isRequired
};
