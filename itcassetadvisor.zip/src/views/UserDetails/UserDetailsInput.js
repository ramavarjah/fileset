import React, { Component } from "react";
import { observer } from "mobx-react";
import Functions from "../../api/Functions";
import URL from "../../api/Urls";
import userStore from "../../stores/userStore";
import UIFunctions from "../../helpers/UIFunctions";

import { Form, Input, Button, Select } from "antd";
import { Upload, Icon, Modal } from "antd";
const FormItem = Form.Item;
const { TextArea } = Input;
const formItemLayout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 15 }
};

const Option = Select.Option;

@observer
class UserDetailsInput1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Base64Image:
        URL.hostUrl +
        "/Thingworx/Users/" +
        userStore.userDetails.UserName +
        "/Avatar?" +
        new Date().getTime(),
      //Base64Image:'',
      previewVisible: false,
      previewImage: "",
      fileList: [
        {
          uid: -1,
          name: userStore.userDetails.UserName,
          status: "done",
          url:
            URL.hostUrl +
            "/Thingworx/Users/" +
            userStore.userDetails.UserName +
            "/Avatar?" +
            new Date().getTime()
        }
      ]
    };
    (this.check = this.check.bind(this)),
      (this.cancel = this.cancel.bind(this)),
      (this.reset = this.reset.bind(this)),
      (this.handleClose = this.props.handleClose.bind(this));
  }

  check = () => {
    this.props.form.validateFields(err => {
      if (!err) {
        Functions.SetUserProfile(userStore.userDetails).then(response => {
          if (response.data.success) {
            UIFunctions.Toast("User Profile Saved", "success");
            userStore.setUserDetails(response.data.userDetails);
            userStore.setbaseUserDetails(response.data.userDetails);
            userStore.seteditFlag(true);
            userStore.setEditing(false);
            userStore.setUserDetailsModalopen(false);
          } else {
            UIFunctions.Toast(
              "There was an error in saving the profile",
              "error"
            );
          }
        });
      }
    });
  };
  edit = () => {
    userStore.seteditFlag(false);
  };
  cancel = () => {
    //history.go(-1);
    userStore.seteditFlag(true);
    //this.handleClose(e);
  };
  reset = () => {
    this.props.form.resetFields();
  };

  handleCancel = () => this.setState({ previewVisible: false });

  handlePreview = file => {
    this.setState({
      previewImage: file.url || file.thumbUrl,
      previewVisible: true
    });
  };

  handleChange = ({ fileList }) => {
    if (fileList.length == 0) {
      var defaultImage = [
        {
          uid: -1,
          name: userStore.userDetails.UserName,
          status: "done",
          url:
            URL.hostUrl +
            "/Thingworx/Things/Keysight.UserProfile/Properties/DefaultAvatar"
        }
      ];

      this.setState({ fileList: defaultImage });
      userStore.setEditing(true);
      // var stateBase64Image = this.state.fileList[0].url;
      userStore.addToUserDetails({ Base64Image: "DefaultAvatar" });
    } else {
      if (!fileList[fileList.length - 1].name.match(/.(jpg|jpeg|png|gif)$/i))
        return UIFunctions.Toast("Upload an Image file", "info");
      var fileSize = fileList[fileList.length - 1].size / 1024 / 1024 >= 10;
      if (fileSize)
        return UIFunctions.Toast(
          fileList[fileList.length - 1].name + " is greater than 10 MB",
          "info"
        );
      var filefromFileList = [];
      filefromFileList.push(fileList[fileList.length - 1]);
      this.setState({ fileList: filefromFileList });
      userStore.setEditing(true);
      var stateBase64Image = this.state.fileList[0].thumbUrl;
      userStore.addToUserDetails({ Base64Image: stateBase64Image });
    }
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll();
  };

  componentDidMount() {
    userStore.addToUserDetailsFromCode({
      Base64Image:
        URL.hostUrl +
        "/Thingworx/Users/" +
        userStore.userDetails.UserName +
        "/Avatar?" +
        new Date().getTime()
    });
    userStore.setUserDetails(userStore.baseUserDetails);
    this.props.form.setFieldsValue(userStore.baseUserDetails);
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    const { previewVisible, previewImage, fileList } = this.state;
    const uploadButton = (
      <div>
        <Icon type="plus-circle-o" />
        <div className="ant-upload-text">Upload New Profile Picture*</div>
      </div>
    );

    return (
      <div className="bg userSettingsContainer">
        {/* <div className={'editButton pull-right ' + editBtnClass} style={{ cursor: 'pointer' }} onClick={this.edit}> Edit <Icon type="edit" style={{ fontWeight: 100 }} /></div> */}

        <div className="col-lg-12 moduleContainerWrapper">
          <Form onSubmit={this.handleSubmit} style={{ width: "100%" }}>
            <div style={{ height: window.innerHeight - 330, overflow: "auto" }}>
            <div className="userSettingUserInfo">
              <div className="col-lg-6 pull-left borderRight">
                <FormItem {...formItemLayout} label="First name" hasFeedback>
                  {getFieldDecorator("firstName", {
                    rules: [
                      {
                        required: true,
                        message: "Please input your first name"
                      }
                    ]
                  })(
                    //<Input disabled={userStore.editFlag} onChange={e => { userStore.addToUserDetails({ firstName: e.target.value }) }} placeholder="Please input your first name" />
                    <Input
                      onChange={e => {
                        userStore.addToUserDetails({
                          firstName: e.target.value
                        });
                      }}
                      placeholder="Please input your first name"
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Last name" hasFeedback>
                  {getFieldDecorator("lastName", {
                    rules: [
                      {
                        required: true,
                        message: "Please input your last name"
                      }
                    ]
                  })(
                    <Input
                      //disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          lastName: e.target.value
                        });
                      }}
                      placeholder="Please input your last name"
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Email" hasFeedback>
                  {getFieldDecorator("emailAddress", {
                    rules: [
                      {
                        type: "email",
                        message: "The input is not valid a email"
                      },
                      {
                        required: true,
                        message: "Please input your email"
                      }
                    ]
                  })(
                    <Input
                      onChange={e => {
                        userStore.addToUserDetails({
                          emailAddress: e.target.value
                        });
                      }}
                      placeholder="Please input your email"
                      disabled
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Phone number" hasFeedback>
                  {getFieldDecorator("phoneNo", {
                    rules: [
                      {
                        required: true,
                        message: "Please input your phone number"
                      }
                    ]
                  })(
                    <Input
                      //disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({ phoneNo: e.target.value });
                      }}
                      placeholder="Please input your phone number"
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Job title">
                  {getFieldDecorator("JobTitle", {
                    rules: [
                      {
                        required: false,
                        message: "Please input your job  title"
                      }
                    ]
                  })(
                    <Input
                      //disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          JobTitle: e.target.value
                        });
                      }}
                      placeholder="Please input your job  title"
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Fax">
                  {getFieldDecorator("Fax", {
                    rules: [
                      {
                        required: false,
                        message: "Please input your fax number"
                      }
                    ]
                  })(
                    <Input
                      //disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({ Fax: e.target.value });
                      }}
                      placeholder="Please input your fax number"
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Organization" hasFeedback>
                  {getFieldDecorator("CustomerName", {
                    rules: [
                      {
                        required: true,
                        message: "Please input your organization"
                      }
                    ]
                  })(
                    <Input
                      onChange={e => {
                        userStore.addToUserDetails({
                          CustomerName: e.target.value
                        });
                      }}
                      placeholder="Please input your organization"
                      disabled
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Mobile">
                  {getFieldDecorator("mobilePhone", {
                    rules: [
                      {
                        required: this.state.mobileNo,
                        message: "Please input your mobile number"
                      }
                    ]
                  })(
                    <Input
                      // disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          mobilePhone: e.target.value
                        });
                      }}
                      placeholder="Please input your mobile number"
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Manager">
                  {getFieldDecorator("manager", {
                    rules: [
                      {
                        required: false,
                        message: "No validation"
                      }
                    ]
                  })(
                    <Input
                      onChange={e => {
                        userStore.addToUserDetails({ manager: e.target.value });
                      }}
                      placeholder=""
                      disabled
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Department">
                  {getFieldDecorator("Department", {
                    rules: [
                      {
                        required: this.state.departmment,
                        message: "Please input your department"
                      }
                    ]
                  })(
                    <Input
                      // disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          Department: e.target.value
                        });
                      }}
                      placeholder="Please input your department"
                    />
                  )}
                </FormItem>
              </div>

              <div className="col-lg-6 pull-left">
                <FormItem
                  {...formItemLayout}
                  label="Address line 1"
                  hasFeedback
                >
                  {getFieldDecorator("AddressLine1", {
                    rules: [
                      {
                        required: true,
                        message: "Please input first line of your address"
                      }
                    ]
                  })(
                    <TextArea
                      rows={4}
                      //disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          AddressLine1: e.target.value
                        });
                      }}
                      placeholder="Address line 1"
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Address line 2">
                  {getFieldDecorator("AddressLine2", {
                    rules: [
                      {
                        required: false,
                        message: "NO validation"
                      }
                    ]
                  })(
                    <TextArea
                      rows={4}
                      //disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          AddressLine2: e.target.value
                        });
                      }}
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="Address line 3">
                  {getFieldDecorator("AddressLine3", {
                    rules: [
                      {
                        required: false,
                        message: "NO validation"
                      }
                    ]
                  })(
                    <TextArea
                      rows={4}
                      // disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          AddressLine3: e.target.value
                        });
                      }}
                    />
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="City" hasFeedback>
                  {getFieldDecorator("City", {
                    rules: [
                      {
                        required: true,
                        message: "Please input city"
                      }
                    ],
                    initialValue: userStore.userDetails.city
                  })(
                    <Input
                      //disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({ City: e.target.value });
                      }}
                      placeholder="Please input your city"
                    />
                  )}
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="State/Province"
                  hasFeedback
                >
                  {getFieldDecorator("State", {
                    rules: [
                      {
                        required: true,
                        message: "Please input state"
                      }
                    ]
                  })(
                    <Input
                      // disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({ State: e.target.value });
                      }}
                      placeholder="Please input your State/Province"
                    />
                  )}
                </FormItem>

                <FormItem
                  {...formItemLayout}
                  label="Zip/Postal code"
                  hasFeedback
                >
                  {getFieldDecorator("PostalCode", {
                    rules: [
                      {
                        required: true,
                        message: "Please input zip code"
                      }
                    ]
                  })(
                    <Input
                      // disabled={userStore.editFlag}
                      onChange={e => {
                        userStore.addToUserDetails({
                          PostalCode: e.target.value
                        });
                      }}
                      placeholder="Please input your Zip or Postal Code"
                    />
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="Country" hasFeedback>
                  {getFieldDecorator("Country", {
                    rules: [
                      {
                        required: true,
                        message: "Please input country"
                      }
                    ]
                  })(
                    <Select
                      showSearch
                      style={{ width: 200, backgroundColor: "#0000" }}
                      placeholder="Please select your country"
                      optionFilterProp="children"
                      onChange={value => {
                        userStore.addToUserDetails({ Country: value });
                      }}
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                    >
                      {userStore.userDetails.CountryCodes.map(e => {
                        return (
                          <Option value={e.CountryCode} key={e.Country}>
                            {e.Country}
                          </Option>
                        );
                      })}
                    </Select>
                  )}
                </FormItem>
              </div>
            </div>
            </div>
            <div className="clear" />

            <div className="col-lg-6 pull-left">
              <div
                className={
                  userStore.editFlag ? "udPicUpload clearfix" : "clearfix"
                }
              >
                <Upload
                  action="//jsonplaceholder.typicode.com/posts/"
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={this.handlePreview}
                  onChange={this.handleChange}
                  multiple={false}
                  // disabled={userStore.editFlag}
                >
                  {uploadButton}
                </Upload>
                <span
                  style={{
                    fontSize: 12,
                    color: "#afb5c5",
                    position: "absolute",
                    top: 50,
                    left: 100,
                    width: 250
                  }}
                >
                  Maximum upload file size : 10MB
                </span>
                <Modal
                  className="userPicModalWindow"
                  visible={previewVisible}
                  footer={null}
                  onCancel={this.handleCancel}
                >
                  <img
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </div>
            </div>
            <div className="col-lg-6 pull-left" style={{ margin: "auto 0" }}>
              <div className="userSettingsButton">
                <FormItem>
                  <Button
                    className="cancelButton"
                    type="primary"
                    onClick={this.handleClose}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="submitButton"
                    type="primary"
                    onClick={this.check}
                    //disabled={userStore.editFlag}
                  >
                    Submit
                  </Button>
                </FormItem>
              </div>
            </div>
            <div className="clear" />
          </Form>
        </div>
      </div>
    );
  }
}
const UserDetailsInput = Form.create()(UserDetailsInput1);
export default UserDetailsInput;
