import React, { Component } from "react";
import { observer } from "mobx-react";
import userStore from "../../stores/userStore";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";

import { Form, Input, Button, Checkbox, Icon, Row, Col } from "antd";

const FormItem = Form.Item;
function invalidUserName(userName) {
  var mailFormat = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
  if (mailFormat.test(userName)) return false;
  else return true;
}

@observer
class InfolineAccount1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      type: "password",
      loading: false
    };
    this.handleClose = this.props.handleClose.bind(this);
    this.show = this.show.bind(this);
  }
  componentDidMount() {
    this.props.form.setFieldsValue(userStore.baseUserDetails);

    if (
      userStore.baseUserDetails.infolineUserName &&
      userStore.baseUserDetails.infolinePassword
    ) {
      this.setState({ resp: true });
    }
    setTimeout(function() {
      userStore.setEditing(false);
    }, 200);
  }

  handleSubmit() {
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (invalidUserName(values.infolineUserName)) {
        err = true;
        UIFunctions.Toast("Please enter a valid username", "error");
      }
      if (!err) {
        this.setState({ loading: true });
        var InfolineCreds = values;
        Functions.SetInfolineCredentials(InfolineCreds).then(resp => {
          this.setState({ resp: resp.data.success });
          userStore.setEditing(false);
          this.setState({ loading: false });

          if (resp.data.success) {
            userStore.addToUserDetailsFromCode(InfolineCreds);
            UIFunctions.Toast(resp.data.message, "success");
          } else {
            UIFunctions.Toast(resp.data.message, "error");
            var values = { infolineUserName: "", infolinePassword: "" };
            userStore.addToUserDetailsFromCode(values);
          }
        });
      }
    });
  }

  show() {
    this.setState({
      type: this.state.type === "password" ? "text" : "password"
    });
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    const formItemLayout = {
      labelCol: { span: 15 },
      wrapperCol: { span: 11 }
    };

    return (
      <Row
        className="userInfolineAccount"
        style={{ height: window.innerHeight - 235 }}
      >
        <Col span={16} offset={8}>
          <Form onSubmit={this.handleSubmit}>
            <h4 className="userInfolineAccountHeader">
              Link Your myKeysight Account to Asset Advisor
            </h4>

            <label style={{ color: "#d8d8d8" }}>Username</label>
            <FormItem {...formItemLayout}>
              {getFieldDecorator("infolineUserName", {
                rules: [
                  {
                    required: true,
                    message: "Please input your username!"
                  }
                ]
              })(
                <Input
                  prefix={
                    <Icon type="user" style={{ color: "rgba(0,0,0,.25)" }} />
                  }
                  onChange={() => userStore.setEditing(true)}
                />
              )}
            </FormItem>
            <label style={{ color: "#d8d8d8" }}>Password</label>
            <div style={{ position: "relative" }}>
              <FormItem {...formItemLayout}>
                {getFieldDecorator("infolinePassword", {
                  rules: [
                    { required: true, message: "Please input your Password!" }
                  ]
                })(
                  <Input
                    prefix={
                      <Icon type="lock" style={{ color: "rgba(0,0,0,.25)" }} />
                    }
                    type={this.state.type}
                    autoComplete="new-password"
                    onChange={() => userStore.setEditing(true)}
                  />
                )}
              </FormItem>

              <Checkbox
                style={{
                  color: "#d5d5d5",
                  position: "absolute",
                  right: "41.5%",
                  top: "20%"
                }}
                onChange={this.show}
              >
                Show
              </Checkbox>
            </div>
            <br />

            <FormItem {...formItemLayout}>
              <Button
                className="submitButton"
                type="primary"
                onClick={this.handleSubmit.bind(this)}
                disabled={!userStore.editing}
              >
                Link Account
              </Button>
            </FormItem>
            <br />

            <FormItem {...formItemLayout}>
              {this.state.loading == true ? (
                <Icon
                  type="loading"
                  style={{
                    fontSize: 130,
                    color: "#3385FF",
                    position: "relative"
                  }}
                  spin
                >
                  <Icon
                    type="loading"
                    style={{
                      fontSize: 110,
                      color: "yellow",
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%,-50%) rotateY(180deg)"
                    }}
                    spin
                  >
                    <Icon
                      type="loading"
                      style={{
                        fontSize: 80,
                        color: "orange",
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%,-50%) rotateY(180deg)"
                      }}
                      spin
                    />
                  </Icon>
                </Icon>
              ) : this.state.resp == true ? (
                <Icon
                  type="check-circle-o"
                  style={{ fontSize: 130, color: "green" }}
                />
              ) : (
                <Icon
                  type="close-circle-o"
                  style={{ fontSize: 130, color: "red" }}
                />
              )}
            </FormItem>
            <br />
            <br />
            <FormItem {...formItemLayout} style={{ fontSize: 14 }}>
              <span>Having trouble linking accounts? </span>
              <br />
              <span>
                Feel free to{" "}
                <a href="#" style={{ color: "#3385FF" }}>
                  Submit An Issue
                </a>{" "}
                to our team
              </span>
            </FormItem>
          </Form>
        </Col>
      </Row>
    );
  }
}

const InfolineAccount = Form.create()(InfolineAccount1);
export default InfolineAccount;
