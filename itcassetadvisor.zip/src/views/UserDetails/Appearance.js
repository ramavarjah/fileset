import React, { Component } from "react";
import { observer } from "mobx-react";
import userStore from "../../stores/userStore";
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";

import { Form, Button, Radio } from "antd";
const FormItem = Form.Item;
const RadioGroup = Radio.Group;

@observer
class UserAppearance extends Component {
    constructor(props) {
        super(props);
        this.state = {
            oldpassword: "",
            newpassword1: "",
            newpassword2: "",
            editFlag: true,
            userDetails: userStore.userDetails,
            confirmDirty: false
        };
        this.changePassword = this.changePassword.bind(this);
        this.handleReset = this.handleReset.bind(this);
        this.handleClose = this.props.handleClose.bind(this);
    }
  handleReset = e => {
      this.props.form.resetFields();
      this.handleClose(e);
  };
  changePassword = () => {
      this.props.form.validateFields(err => {
          if (!err) {
              Functions.ChangePassword(
                  this.state.oldpassword,
                  this.state.newpassword1,
                  this.state.newpassword2
              ).then(response => {
                  if (response.data.success && response.data.hasChanged) {
                      UIFunctions.Toast("Password Changed", "success");
                  } else {
                      UIFunctions.Toast(
                          "There was an error in changing the password",
                          "error"
                      );
                  }
                  this.handleReset();
              });
          }
      });
  };
  handleConfirmBlur = e => {
      const value = e.target.value;
      this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  };
  checkPassword = (rule, value, callback) => {
      const form = this.props.form;
      if (value && value !== form.getFieldValue("newPassword")) {
          callback("Two passwords that you enter is inconsistent!");
      } else {
          callback();
      }
  };
  checkConfirm = (rule, value, callback) => {
      const form = this.props.form;
      if (value && this.state.confirmDirty) {
          form.validateFields(["confirm"], { force: true });
      }
      callback();
  };

  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll();
  };

  render() {
      const { getFieldDecorator } = this.props.form;

      const formItemLayout = {
          labelCol: { span: 24 },
          wrapperCol: { span: 24 }
      };
      return (
          <div className="bg userSettingsContainer">
              <div
                  className="moduleContainerWrapper"
                  style={{ height: window.innerHeight - 252 }}
              >
                  <Form onSubmit={this.handleSubmit} style={{ width: "100%" }}>
                      <div className="col-md-12">
                          <div className="col-md-12">
                              <FormItem
                                  className="userSettingsApplicationFormItem"
                                  {...formItemLayout}
                                  label="Application Theme"
                              >
                                  {getFieldDecorator("radio-group")(
                                      <RadioGroup>
                                          <Radio value="Dark">Dark</Radio>
                                          <Radio value="Light">Light</Radio>
                                      </RadioGroup>
                                  )}
                              </FormItem>
                          </div>
                      </div>

                      <div className="clear" />

                      <div className="userSettingsAppearance">
                          <div className="userSettingsButton">
                              <FormItem>
                                  <Button
                                      className="submitButton"
                                      style={{ marginRight: 8 }}
                                      onClick={this.handleReset}
                                  >
                    Cancel
                                  </Button>
                                  <Button
                                      className="cancelButton"
                                      type="primary"
                                      style={{ marginLeft: 8 }}
                                      onClick={this.changePassword}
                                  >
                    Save
                                  </Button>
                              </FormItem>
                          </div>
                      </div>
                  </Form>
              </div>
          </div>
      );
  }
}

const Appearance = Form.create()(UserAppearance);
export default Appearance;
