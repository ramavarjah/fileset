import React from "react";
import { observer } from "mobx-react";
import { Row, Button, Icon, Tooltip } from "antd";
import Functions from "../../api/Functions";
import loanPoolStore from "../../stores/loanPoolStore";
import moment from "moment";
import UIFunctions from "./../../helpers/UIFunctions";

@observer
class NotificationsCard extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = null;
  }

  approveLoanRequest = () => {
    loanPoolStore.loanPoolNotificationLoading = true;
    loanPoolStore.setSubmittingApprove(true);
    Functions.SetApprovalOnLoanPoolRequest(
      "Approved",
      loanPoolStore.notificationSelected.workFlowId
    ).then(response => {
      if (response.data.success) {
        UIFunctions.Toast("Request approved", "success");
        var row = loanPoolStore.notificationSelected;
        row.status = "Approved";
        loanPoolStore.setNotificationSelected(row);
        Functions.MarkNotificationAsRead("LoanPool", row.workFlowId);
        loanPoolStore.setSubmittingApprove(false);
        setTimeout(() => loanPoolStore.getAllLoanPoolRequests(), 10000);
        loanPoolStore.loanPoolNotificationLoading = false;
      } else {
        UIFunctions.Toast(
          "The approval process could not be completed",
          "error"
        );
        loanPoolStore.loanPoolNotificationLoading = false;
        loanPoolStore.setSubmittingApprove(false);
      }
    });
  };

  disapproveLoanRequest = () => {
    loanPoolStore.loanPoolNotificationLoading = true;
    loanPoolStore.setSubmittingReject(true);
    Functions.SetApprovalOnLoanPoolRequest(
      "Rejected",
      loanPoolStore.notificationSelected.workFlowId
    ).then(response => {
      if (response.data.success) {
        UIFunctions.Toast("Request Rejected", "success");
        var row = loanPoolStore.notificationSelected;
        row.status = "Rejected";
        loanPoolStore.setNotificationSelected(row);
        Functions.MarkNotificationAsRead("LoanPool", row.workFlowId);
        loanPoolStore.setSubmittingReject(false);
        setTimeout(() => loanPoolStore.getAllLoanPoolRequests(), 10000);
      } else {
        UIFunctions.Toast(
          "The Rejection process could not be completed",
          "error"
        );

        loanPoolStore.loanPoolNotificationLoading = false;
        loanPoolStore.setSubmittingReject(false);
      }
    });
  };

  markAsReturned = () => {
    loanPoolStore.loanPoolNotificationLoading = true;
    Functions.MarkLoanedAssetAsReturned(
      loanPoolStore.notificationSelected.workFlowId
    ).then(response => {
      if (response.data.success) {
        UIFunctions.Toast("Asset has been returned", "success");
        var row = loanPoolStore.notificationSelected;
        row.status = "Returned";
        loanPoolStore.setNotificationSelected(row);
        Functions.MarkNotificationAsRead("LoanPool", row.workFlowId);
        setTimeout(() => loanPoolStore.getAllLoanPoolRequests(), 10000);
      } else {
        UIFunctions.Toast("The return process could not be completed", "error");
        loanPoolStore.loanPoolNotificationLoading = false;
      }
    });
  };

  approveEquipmentRequest = () => {
    loanPoolStore.loanPoolNotificationLoading = true;
    Functions.SetEquipmentRequestApproval(
      "Approved",
      loanPoolStore.notificationSelected.StreamId
    ).then(response => {
      if (response.data.success) {
        UIFunctions.Toast("Request approved", "success");
        var row = loanPoolStore.notificationSelected;
        row.status = "Approved";
        loanPoolStore.setNotificationSelected(row);
        Functions.MarkNotificationAsRead("LoanPool", row.workFlowId);
        setTimeout(() => loanPoolStore.getAllLoanPoolRequests(), 10000);
      } else {
        UIFunctions.Toast(
          "The approval process could not be completed",
          "error"
        );
        loanPoolStore.loanPoolNotificationLoading = false;
      }
    });
  };

  disapproveEquipmentRequest = () => {
    loanPoolStore.loanPoolNotificationLoading = true;
    Functions.SetEquipmentRequestApproval(
      "Rejected",
      loanPoolStore.notificationSelected.StreamId
    ).then(response => {
      if (response.data.success) {
        UIFunctions.Toast("Request Rejected", "success");
        var row = loanPoolStore.notificationSelected;
        row.status = "Rejected";
        loanPoolStore.setNotificationSelected(row);
        Functions.MarkNotificationAsRead("LoanPool", row.workFlowId);
        setTimeout(() => loanPoolStore.getAllLoanPoolRequests(), 10000);
      } else {
        UIFunctions.Toast(
          "The disapproval process could not be completed",
          "error"
        );
        loanPoolStore.loanPoolNotificationLoading = false;
      }
    });
  };

  componentDidMount() {}
  render() {
    var infoStyles = {
      clearBoth: {
        clear: "both"
      },
      colRight: {
        height: window.innerHeight - 256,
        backgroundColor: "#fff",
        padding: "20px",
        overflow: "scroll"
      },
      textStyle: {
        color: "#6a7682",
        fontSize: "1.1rem",
        marginBottom: "10px"
      },
      requestMarginBottom: {
        fontSize: "15px",
        marginBottom: "20px"
      },
      requestLeftTextStyle: {
        color: "#707c88",
        fontWeight: "500"
      },
      requestRightTextStyle: {
        color: "#abb2b8",
        fontWeight: "400"
      },
      requestStatusTextStyle: {
        color: "#ff4d4d",
        fontWeight: "400"
      },
      information: {
        height: window.innerHeight - 253,
        backgroundColor: "#e5e5e5",
        textAlign: "center"
      },
      eyeIcon: {
        position: "absolute",
        padding: "31%",
        right: "-5%",
        fontSize: "17rem",
        color: "rgba(72, 107, 130, 0.09019607843137255)"
      },
      informationText: {
        fontSize: "20px",
        color: "#486c82",
        fontStyle: "italic",
        padding: "55% 32%",
        margin: "0px",
        textAlign: "left"
      }
    };

    return (
      <div className="serviceRequestInfo">
        <div className="pull-left" style={infoStyles.textStyle}>
          Request Info
        </div>
        {loanPoolStore.notificationSelected ? (
          <div>
            <div style={infoStyles.clearBoth} />
            <div style={infoStyles.colRight}>
              {!loanPoolStore.notificationSelected.assets &&
              loanPoolStore.notificationSelected.type !=
                "External Asset Request - Submitted By Me" &&
              loanPoolStore.notificationSelected.type !=
                "External Asset Request - Submitted To Me" ? (
                <div>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Equipment number :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.EquipmentNo}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Asset number :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.AssetNo}
                    </span>
                  </Row>

                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Status :
                    </span>{" "}
                    <span style={infoStyles.requestStatusTextStyle}>
                      {loanPoolStore.notificationSelected.status}
                    </span>
                  </Row>
                  {loanPoolStore.notificationSelected.type ==
                    "Submitted To Me" &&
                  loanPoolStore.notificationSelected.status == "Approved" ? (
                    <Row style={infoStyles.requestMarginBottom}>
                      <Button
                        className="markReturnedBtn"
                        type="primary"
                        size="large"
                        onClick={this.markAsReturned}
                      >
                        <Icon type="check" />
                        <span>Mark as Returned</span>
                      </Button>
                    </Row>
                  ) : (
                    ""
                  )}
                  {loanPoolStore.notificationSelected.type ==
                    "Submitted To Me" &&
                  loanPoolStore.notificationSelected.status == "Requested" ? (
                    <Row
                      className="requestInfoButton"
                      style={infoStyles.requestMarginBottom}
                    >
                      {/* APPROVE & REJECT REQUEST BUTTONS */}
                      <Button
                        className="approveButton"
                        size="large"
                        onClick={this.approveLoanRequest}
                        disabled={loanPoolStore.submittingReject}
                        loading={loanPoolStore.submittingApprove}
                      >
                        <Icon type="check-circle-o" className="approveIcon" />
                        <span>Approve</span>
                      </Button>
                      <Button
                        className="disApproveButton"
                        size="large"
                        onClick={this.disapproveLoanRequest}
                        disabled={loanPoolStore.submittingApprove}
                        loading={loanPoolStore.submittingReject}
                      >
                        <Icon type="close-circle-o" className="rejectIcon" />
                        <span>Reject</span>
                      </Button>
                    </Row>
                  ) : (
                    ""
                  )}
                  <Row>
                    <hr />
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Manufacturer :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.Manufacturer}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Model number :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.ModelNo}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Serial number :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.SerialNo}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Description :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.Description}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Options :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.Options}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Accessories :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.Accessories}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Coordinator :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.Coordinator}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>User :</span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.User}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Loan Daily Cost :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.LoanDailyCost}
                    </span>
                  </Row>
                </div>
              ) : (
                <div>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Request number :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.DisplayRequestId}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Request Date :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {moment(
                        loanPoolStore.notificationSelected.requestDate
                      ).format("YYYY-MM-DD")}
                    </span>
                  </Row>

                  {loanPoolStore.notificationSelected.type ==
                    "External Asset Request - Submitted To Me" &&
                  loanPoolStore.notificationSelected.status == "Requested" ? (
                    <Row
                      className="requestInfoButton"
                      style={infoStyles.requestMarginBottom}
                    >
                      <Button
                        className="approveButton"
                        type="primary"
                        size="large"
                        onClick={this.approveEquipmentRequest}
                      >
                        Approve
                      </Button>
                      <Button
                        className="disApproveButton"
                        type="danger"
                        size="large"
                        onClick={this.disapproveEquipmentRequest}
                      >
                        Reject
                      </Button>
                    </Row>
                  ) : (
                    ""
                  )}

                  <Row>
                    <hr />
                  </Row>
                  {loanPoolStore.notificationSelected.type !=
                    "External Asset Request - Submitted By Me" &&
                  loanPoolStore.notificationSelected.type !=
                    "External Asset Request - Submitted To Me" ? (
                    <div>
                      <Row style={infoStyles.requestMarginBottom}>
                        <span style={infoStyles.requestLeftTextStyle}>
                          Total Loan Cost :
                        </span>{" "}
                        <span style={infoStyles.requestRightTextStyle}>
                          {loanPoolStore.notificationSelected.TotalLoanCost}
                        </span>
                      </Row>
                    </div>
                  ) : (
                    ""
                  )}

                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Justification :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.Justification}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Requestor Name :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.RequestorName}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Proposed Use Location :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.Location}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Request Start Date :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {moment(
                        loanPoolStore.notificationSelected.StartDate
                      ).format("YYYY-MM-DD")}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Request End Date :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {moment(
                        loanPoolStore.notificationSelected.EndDate
                      ).format("YYYY-MM-DD")}
                    </span>
                  </Row>
                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Requestor Email Address :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.RequestorEmail}
                    </span>
                  </Row>

                  <Row style={infoStyles.requestMarginBottom}>
                    <span style={infoStyles.requestLeftTextStyle}>
                      Requestor Phone number :
                    </span>{" "}
                    <span style={infoStyles.requestRightTextStyle}>
                      {loanPoolStore.notificationSelected.PhoneNumber}
                    </span>
                  </Row>
                  {loanPoolStore.notificationSelected.type ==
                    "External Asset Request - Submitted By Me" ||
                  loanPoolStore.notificationSelected.type ==
                    "External Asset Request - Submitted To Me" ? (
                    <div>
                      <Row style={infoStyles.requestMarginBottom}>
                        <span style={infoStyles.requestLeftTextStyle}>
                          Model number :
                        </span>{" "}
                        <span style={infoStyles.requestRightTextStyle}>
                          {loanPoolStore.notificationSelected.ModelNo}
                        </span>
                      </Row>
                      <Row style={infoStyles.requestMarginBottom}>
                        <span style={infoStyles.requestLeftTextStyle}>
                          Manufacturer :
                        </span>{" "}
                        <span style={infoStyles.requestRightTextStyle}>
                          {loanPoolStore.notificationSelected.Manufacturer}
                        </span>
                      </Row>
                    </div>
                  ) : (
                    ""
                  )}

                  {loanPoolStore.notificationSelected.type ==
                    "External Asset Request - Submitted By Me" ||
                  loanPoolStore.notificationSelected.type ==
                    "External Asset Request - Submitted By Me" ? (
                    <div>
                      <Row style={infoStyles.requestMarginBottom}>
                        <span style={infoStyles.requestLeftTextStyle}>
                          Notes :
                        </span>{" "}
                        <span style={infoStyles.requestRightTextStyle}>
                          {loanPoolStore.notificationSelected.Notes}
                        </span>
                      </Row>
                      <Row style={infoStyles.requestMarginBottom}>
                        <span style={infoStyles.requestLeftTextStyle}>
                          Description :
                        </span>{" "}
                        <span style={infoStyles.requestRightTextStyle}>
                          {loanPoolStore.notificationSelected.Description}
                        </span>
                      </Row>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div>
            <div style={infoStyles.clearBoth} />
            <div style={infoStyles.information}>
              <Tooltip
                placement="left"
                title="Click an Item to View More Information"
              >
                <i className="icon-eye" style={infoStyles.eyeIcon} />
              </Tooltip>
            </div>
          </div>
        )}
      </div>
    );
  }
}
export default NotificationsCard;
