import React from "react";
import { observer } from "mobx-react";
import { AgGridReact } from "ag-grid-react";
import PropTypes from "prop-types";
import Functions from "../../api/Functions";
import loanPoolStore from "../../stores/loanPoolStore";
import moment from "moment";
import { Spin } from "antd";
import DetailCellRenderer from "./detailCellRenderer";

@observer
class NotificationsGrid extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = {
      table_expandicons: {
        groupExpanded:
          '<i class="fa fa-chevron-down" style="color: #40444d;cursor:pointer"/>',
        groupContracted:
          '<i class="fa fa-chevron-right" style="color: #40444d;cursor:pointer"/>'
      },
      columnDefs: [
        // {
        //   field: "newId",
        //   headerName: "",
        //   width: 25,
        //   cellRenderer: "agGroupCellRenderer",
        //   valueGetter: function emptyValueGetter(params) {
        //     return "";
        //   }
        // },
        //  {
        //    field: "newId",
        //    headerName: "",
        //    cellRenderer: this.actionLinks, width:50, cellStyle: {'text-align': 'center'}
        //   },
        {
          headerName: "",
          field: "expanded",
          cellRenderer: this.expandableCellRenderer,
          width: 35,
          cellStyle: { "text-align": "center" },
          suppressMenu: true,
          suppressMovable: true
          // suppressSizeToFit: true
        },
        {
          headerName: "Request number",
          field: "DisplayRequestId",
          width: 330,
          suppressMenu: true,
          suppressMovable: true
          // suppressSizeToFit: true
        },
        // {
        //   headerName: "Loan status",
        //   field: "status",
        //   cellRenderer: this.loanStatusCellRenderer, width: 145, cellStyle: { 'text-align': 'left' },
        //   suppressSizeToFit: true
        // },
        //  {
        //   field: "notification",
        //   headerName: "",
        //   cellRenderer: this.notificationActionLinks, width:50, cellStyle: {'text-align': 'center'}
        //  },
        {
          headerName: "Request date",
          field: "requestDate",
          valueFormatter: this.dateFormatter,
          width: 180,
          suppressMenu: true,
          suppressMovable: true
          // suppressSizeToFit: true
        },
        {
          headerName: "Requestor Email Address",
          field: "RequestorEmail",
          width: 260,
          suppressMenu: true,
          suppressMovable: true
          // suppressSizeToFit: true
        },
        {
          headerName: "Type",
          field: "type",
          width: 300,
          suppressMenu: true,
          suppressMovable: true
          // suppressSizeToFit: true
        }
        // {
        //   headerName: "Total Loan Cost",
        //   field: "totalLoanCost",
        //   width: 180,
        //   suppressSizeToFit: true

        // },
        // {
        //   headerName: "Justification",
        //   field: "justification",
        //   width: 180,
        //   suppressSizeToFit: true

        // },
        // {
        //   headerName: "Requestor Name",
        //   field: "requestorName",
        //   width: 170,
        //   suppressSizeToFit: true
        // },

        // {
        //   headerName: "Requestor Phone Number",
        //   field: "requestorPhoneNumber",
        //   width: 230,
        //   suppressSizeToFit: true
        // },
        // {
        //   headerName: "Proposed Use Location",
        //   field: "proposedUseLocation",
        //   width: 180,
        //   suppressSizeToFit: true
        // }
      ],
      isRowMaster: function(dataItem) {
        return dataItem
          ? dataItem.type == "External Asset Request - Submitted By Me"
          : false;
      },
      detailCellRenderer: "myDetailCellRenderer",
      frameworkComponents: { myDetailCellRenderer: DetailCellRenderer },
      // detailCellRendererParams: {
      //   detailGridOptions: {

      //     rowHeight: 35,
      //     headerHeight: 35,

      //     suppressCellSelection: true,

      //     columnDefs: [
      //       {
      //         field: "Action",
      //         headerName: "",
      //         width: 25,

      //         valueGetter: function emptyValueGetter(params) {
      //           return "";
      //         }
      //       },

      //       { field: "EquipmentNo", headerName: "Equipment no" },
      //       { field: "status", headerName: "Status", cellRenderer: this.loanStatusCellRenderer, width: 100, cellStyle: { 'text-align': 'left' } },
      //       { field: "Requestor", headerName: "Requestor" },
      //       { field: "Coordinator", headerName: "Coordinator" },
      //     ],
      //     onGridReady: function (params) {
      //       console.log("Param onGridReady -> ", params);
      //       params.api.sizeColumnsToFit();
      //     }
      //   },
      //   getDetailRowData: function (params) {
      //     console.log("Param getDetailRowData -> ", params.data);
      //     //params.successCallback(sampleDetailData);
      //     params.successCallback(params.data.assets);
      //   },
      //   template:
      //     '<div style="height: 100%; background-color: #edf6ff; padding: 0px; box-sizing: border-box;">' +
      //     '  <div class="loanPoolOpenRequestHeader" ref="eDetailGrid" style="height: 100%;"></div>' +
      //     "</div>"
      // },
      rowSelection: "single",
      rowClassRules: {
        "normal-row": function(params) {
          // params.data.read && console.log("params", params.data);
          return params.node.data.read;
        },
        "bold-row": function(params) {
          // !params.node.data.read && console.log("params", params);
          return !params.node.data.read;
        }
      }
    };
    //this.actionLinks = this.actionLinks.bind(this);
    this.onSelectionChanged = this.onSelectionChanged.bind(this);
    this.notificationActionLinks = this.notificationActionLinks.bind(this);
    this.loanStatusCellRenderer = this.loanStatusCellRenderer.bind(this);
  }
  onCellClicked(event) {
    if (event.column.colId != "expanded") return; //prevent all other column click
    if (!event.value) return; //prevent click if value is false (not expandable)

    event.api.forEachNode(function(node) {
      node.data == event.data &&
        node.setDataValue(
          "expanded",
          node.data.expanded == "COLLAPSED" ? "EXPANDED" : "COLLAPSED"
        );
      node.data == event.data &&
        node.setExpanded(node.data.expanded != "COLLAPSED");
    });
  }
  onSelectionChanged = () => {
    var selection = this.gridApi.getSelectedRows();

    this.gridApi.forEachDetailGridInfo(detailGridInfo =>
      detailGridInfo.api.deselectAll()
    );

    var row = null;
    if (selection.length > 0) {
      row = selection[0];
    }

    loanPoolStore.setNotificationSelected(row);
    if (row.assets) return; //if it is a master do nothing just expand

    if (row.read == false) {
      Functions.MarkNotificationAsRead("LoanPool", row.requestId);
      loanPoolStore.markAsReadMasterRow(row);
      this.gridApi.redrawRows();
    }
  };

  onGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    // params.api.setRowData(this.createRows());
    var api = params.api;
    api.sizeColumnsToFit();
    // setTimeout(function () {
    //   var rowCount = 0;
    //   console.log("expanding", params)
    //   api.forEachNode(function (node) {
    //     console.log("node", node)
    //     console.log("nodeExpanded", rowCount++ === 1)
    //     node.setExpanded(rowCount++ === 1);
    //   });
    // }, 5000);
  };

  dateFormatter = params => {
    return moment(params.value).format("YYYY-MM-DD");
  };

  componentDidMount() {
    loanPoolStore.getAllLoanPoolRequests();
  }

  actionLinks = () => {
    let resultElement = document.createElement("span");
    resultElement.className = "link-action-wrap";
    let downLink = document.createElement("i");
    downLink.className = "anticon anticon-down";
    resultElement.appendChild(downLink);
    return resultElement;
  };

  notificationActionLinks = () => {
    let resultElement = document.createElement("span");
    resultElement.className = "link-action-wrap";
    let downLink = document.createElement("i");
    downLink.className = "anticon anticon-check-circle";
    resultElement.appendChild(downLink);
    return resultElement;
  };

  loanStatusCellRenderer = params => {
    // console.log("loanStatusCellRenderer params::", params);
    const status = params.value.toLowerCase();
    let statusCell = document.createElement("div");
    statusCell.innerHTML =
      '<div class="openRequestsStatusColumn ' +
      status +
      '"><label class="' +
      status +
      '"> ' +
      params.value +
      " </label></div>";
    return statusCell;
  };
  expandableCellRenderer = params => {
    // console.log("loanStatusCellRenderer params::", params);
    // const status = params.value.toLowerCase();
    let statusCell = document.createElement("div");
    params.data.expanded
      ? params.data.expanded == "COLLAPSED"
        ? (statusCell.innerHTML =
            '<i class="fa fa-chevron-right" style="color: #40444d;cursor:pointer"/>')
        : (statusCell.innerHTML =
            '<i class="fa fa-chevron-down" style="color: #40444d;cursor:pointer"/>')
      : (statusCell.innerHTML = '<span class="notExpandable"></span>');
    return statusCell;
  };

  getRowHeight = params => {
    // console.log('params', params)
    // return 35
    if (params.node && params.node.detail) {
      var offset = 62;
      var allDetailRowHeight = params.data.assets.length * 35;
      return allDetailRowHeight + offset;
    } else {
      return 35;
    }
  };

  render() {
    var loanStyles = {
      clearBoth: {
        clear: "both"
      },
      colLeft: {
        height: window.innerHeight - 246,
        color: "#666",
        border: "none",
        borderRadius: "0px"
      }
    };
    var gridData = this.props.gridData.map(e => e);
    // console.log("Rendering grid notification");

    return (
      <Spin spinning={loanPoolStore.loanPoolNotificationLoading} delay={500}>
        <div
          style={loanStyles.colLeft}
          className="loanPoolselectedAssetsOpenRowGrid ag-fresh"
        >
          <AgGridReact
            id="notificationsGrid"
            icons={this.state.table_expandicons}
            columnDefs={this.state.columnDefs}
            rowSelection={this.state.rowSelection}
            onCellClicked={this.onCellClicked.bind(this)}
            suppressCellSelection={true}
            onGridReady={this.onGridReady.bind(this)}
            rowClassRules={this.state.rowClassRules}
            enableColResize={true}
            isRowMaster={this.state.isRowMaster}
            detailCellRenderer={this.state.detailCellRenderer}
            frameworkComponents={this.state.frameworkComponents}
            masterDetail={true}
            onRowClicked={this.onSelectionChanged.bind(this)}
            rowData={gridData}
            getRowHeight={this.getRowHeight.bind(this)}
            //rowHeight="35"
            headerHeight="35"
            enableSorting={true}
          />
        </div>
      </Spin>
    );
  }
}
NotificationsGrid.propTypes = {
  gridData: PropTypes.String
};
export default NotificationsGrid;
