import React, { Component } from "react";
import { observer } from "mobx-react";
import Functions from "../../api/Functions";
import loanPoolStore from "../../stores/loanPoolStore";
import tabModelStore from "../../stores/tabModelStore";
import userStore from "../../stores/userStore";
import { Icon } from "antd";
import "./style.css";
import NotificationsGrid from "./NotificationsGrid";
import NotificationsCard from "./NotificationsCard";
import permissionStore from "../../stores/permissionStore";
import PropTypes from "prop-types";

@observer
class LoanPoolNotifications extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentStep: "step1"
        };
    }

    componentDidMount() {
        permissionStore.permissions.icons
            ? permissionStore.permissions.icons.LoanPool
                ? ""
                : this.props.history.push("/dashboard")
            : Functions.GetPermissionBasedColumns().then(response => {
                permissionStore.setPermissions(JSON.stringify(response.data));
                response.data.icons.LoanPool
                    ? ""
                    : this.props.history.push("/dashboard");
            });
        loanPoolStore.dashboardAddCheckFull(null);
        if (userStore.userDetails && userStore.me) return;
        loanPoolStore.getUserDetails();
        permissionStore.permissions.icons.LoanPool
            ? ""
            : this.props.history.push("/dashboard");
    }

    handleClose(e) {
        e.preventDefault();
        loanPoolStore.setNotificationSelected(null);
        this.context.router.history.push("/dashboard");
        Functions.GetGridDataModel(tabModelStore.activeTab.TabId).then(resp => {
            tabModelStore.setCurrentTabColoumns(resp);
        });
        Functions.BadgeCounterForApprover().then(response => {
            tabModelStore.loanPoolNotificationCount =
              response.data.notificationCount;
          });
    }

    render() {
        var loanStyles = {
            clearBoth: {
                clear: "both"
            },
            colLeft: {
                height: window.innerHeight - 330,
                color: "#666"
            }
        };

        return (
            <div id="wizard" className="loanPoolWrapper">
                <div className="loanPoolHeader">
                    <div className="pull-left">
                        <div
                            className="wizardTitle"
                            style={{ color: "rgb(255,255,255)", textTransform: "uppercase" }}
                        >
              Loan Pool
                        </div>
                    </div>
                    <div className="pull-right fr">
                        <Icon
                            type="close-circle-o"
                            style={{
                                color: "rgb(255,255,255)",
                                fontWeight: "100",
                                fontSize: "21px",
                                lineHeight: "normal",
                                paddingRight: "20px",
                                cursor: "pointer"
                            }}
                            onClick={this.handleClose.bind(this)}
                        />
                    </div>
                    <div style={loanStyles.clearBoth} />
                </div>

                <div style={{ paddingTop: "35px" }} />

                <div className="loanPoolComponentWrapper">
                    <div className="col-md-8 pull-left">
                        <div className="selectedAssetsText">Loan Pool Requests</div>
                        <NotificationsGrid gridData={loanPoolStore.allLoanPoolRequests} />
                    </div>

                    <div className="col-md-4 pull-left">
                        <NotificationsCard />
                    </div>

                    <div
                        className="wizardFooter"
                        style={{
                            justifyContent: "center",
                            fontSize: "18px",
                            fontWeight: 600
                        }}
                    >
                        <div>
                            <div
                                className="newRequestBtn"
                                style={{
                                    color: "#79838c",
                                    backgroundColor: "#e5e5e5",
                                    letterSpacing: ".5px",
                                    padding: "5px 12px 5px 14px",
                                    borderRadius: "4px",
                                    border: "1px solid #c3c3c3"
                                }}
                                onClick={() => this.context.router.history.push("/loan-pool")}
                            >
                New Request
                                <Icon
                                    type="plus-circle-o"
                                    style={{
                                        fontWeight: "400",
                                        paddingLeft: "12px"
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default LoanPoolNotifications;

LoanPoolNotifications.contextTypes = {
    router: PropTypes.func.isRequired
};

LoanPoolNotifications.propTypes = {
    history: PropTypes.object
};
