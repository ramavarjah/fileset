import React, { Component } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-enterprise";
import loanPoolStore from "../../stores/loanPoolStore";
import Functions from "../../api/Functions";
import moment from "moment";
import PropTypes from "prop-types";

export default class DetailCellRenderer extends Component {
    constructor(props) {
        super(props);

        this.state = {
            name: props.data.status,
            account: props.data.status,
            colDefs: [
                {
                    field: "Action",
                    headerName: "",
                    width: 25,
                    valueGetter: function emptyValueGetter() {
                        return "";
                    }
                },

                {
                    field: "EquipmentNo",
                    headerName: "Equipment Number",
                    width: 200,
                    suppressSizeToFit: true,
                    suppressMenu: true,
                    suppressMovable: true
                },
                {
                    field: "AssetNo",
                    headerName: "Asset Number",
                    width: 150,
                    suppressSizeToFit: true,
                    suppressMenu: true,
                    suppressMovable: true
                },
                {
                    field: "status",
                    headerName: "Loan Status",
                    cellRenderer: this.loanStatusCellRenderer,
                    cellStyle: { "text-align": "left" },
                    width: 150,
                    suppressSizeToFit: true,
                    suppressMenu: true,
                    suppressMovable: true
                },
                //{ field: "Manufacturer", headerName: "Manufacturer", width: 250, suppressSizeToFit: true,suppressMenu: true,suppressMovable: true },
                {
                    field: "ModelNo",
                    headerName: "Model Number",
                    width: 170,
                    suppressSizeToFit: true,
                    suppressMenu: true,
                    suppressMovable: true
                },
                //{ field: "SerialNo", headerName: "Serial no", width: 250, suppressSizeToFit: true,suppressMenu: true,suppressMovable: true },
                // { field: "Description", headerName: "Description", width: 250, suppressSizeToFit: true,suppressMenu: true,suppressMovable: true },
                //{ field: "Requestor", headerName: "Requestor", width: 250, suppressSizeToFit: true,suppressMenu: true,suppressMovable: true },
                {
                    field: "Coordinator",
                    headerName: "Coordinator",
                    width: 250,
                    suppressSizeToFit: true,
                    suppressMenu: true,
                    suppressMovable: true
                },
                {
                    field: "StartDate",
                    headerName: "Request Start Date",
                    width: 250,
                    suppressSizeToFit: true,
                    suppressMenu: true,
                    suppressMovable: true,
                    valueFormatter: this.dateFormatter
                },
                {
                    field: "EndDate",
                    headerName: "Request End Date",
                    width: 250,
                    suppressSizeToFit: true,
                    suppressMenu: true,
                    suppressMovable: true,
                    valueFormatter: this.dateFormatter
                }
                //{ field: "LoanDailyCost", headerName: "Loan Daily Cost", width: 250, suppressSizeToFit: true,suppressMenu: true,suppressMovable: true },
            ],
            rowData: props.data.assets,
            masterGridApi: props.api,
            rowId: props.node.id,
            rowClassRules: {
                "normal-row": function(params) {
                    //   params.data.read && console.log("params", params.data);
                    return params.node.data.read;
                },
                "bold-row": function(params) {
                    // !params.node.data.read && console.log("params", params);
                    return !params.node.data.read;
                }
            }
        };
    }
  loanStatusCellRenderer = params => {
      const status = params.value.toLowerCase();
      let statusCell = document.createElement("div");
      statusCell.innerHTML =
      '<div class="openRequestsStatusColumn ' +
      status +
      '"><label class="' +
      status +
      '"> ' +
      params.value +
      " </label></div>";
      return statusCell;
  };
  onSelectionChanged = () => {
      var selection = this.gridApi.getSelectedRows();
      var row = null;
      if (selection.length > 0) {
          row = selection[0];
      }
      // var rowValue=row.read;
      // row.read=true;
      loanPoolStore.setNotificationSelected(row);

      if (row.read == false) {
          if (
              row.type == "Submitted By Me" ||
        row.type == "External Asset Request - Submitted By Me"
          ) {
              Functions.MarkNotificationAsRead("LoanPool", row.workFlowId);
              loanPoolStore.markAsRead(row);
              this.gridApi.redrawRows();
          }
      }

      this.state.masterGridApi.deselectAll();
      this.state.masterGridApi.forEachDetailGridInfo(detailGridInfo => {
          if (this.state.rowId !== detailGridInfo.id)
              detailGridInfo.api.deselectAll();
      });
  };

  onGridReady = params => {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;

      const gridInfo = {
          id: this.state.rowId,
          api: params.api,
          columnApi: params.columnApi
      };

      this.state.masterGridApi.addDetailGridInfo(this.state.rowId, gridInfo);

      params.api.sizeColumnsToFit();
  };
  dateFormatter = params => {
      return moment(params.value).format("YYYY-MM-DD");
  };

  render() {
      var loanStyles = {
          clearBoth: {
              clear: "both"
          },
          colLeft: {
              //height: window.innerHeight - 246,
              height:
          this.state.rowData.length > 1
              ? this.state.rowData.length * 35 + 62
              : 97,
              color: "#666",
              overflow: "auto"
          }
      };
      return (
          <div className="full-width-panel">
              <div
                  style={loanStyles.colLeft}
                  className="loanPoolOpenRequestHeader ag-fresh"
              >
                  <AgGridReact
                      id="notificationsGrid"
                      columnDefs={this.state.colDefs}
                      rowData={this.state.rowData}
                      rowSelection="single"
                      enableSorting={false}
                      rowClassRules={this.state.rowClassRules}
                      enableColResize={true}
                      isRowMaster={() => true}
                      onRowClicked={this.onSelectionChanged.bind(this)}
                      onGridReady={this.onGridReady.bind(this)}
                      rowHeight="35"
                      headerHeight="35"
                  />
              </div>
          </div>
      );
  }
}
DetailCellRenderer.propTypes = {
    params: PropTypes.object,
    data: PropTypes.object,
    api: PropTypes.func,
    node: PropTypes.object
};
