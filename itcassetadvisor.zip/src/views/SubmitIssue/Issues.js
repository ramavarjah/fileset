import React, { Component } from "react";
import { observer } from "mobx-react";
import submitIssuesStore from "../../stores/submitIssuesStore";
import { Form, Input, Select, Row, Col } from "antd";
const FormItem = Form.Item;
const { TextArea } = Input;
const Option = Select.Option;
const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 12 }
};

@observer
class Issues extends Component {
    constructor(props) {
        super(props);

        this.state = {
            newIssue: true,
            binaryFiles: { data: "", fileName: "" },
            CustomerId: "",
            CustomerName: "",
            Description: "",
            Implication: "",
            IssueSummary: "",
            SubmittedBy: "",
            attachments: "",
            tab: true,
            _rows: [],
            isUploadFileSelected: false,
            SeverityList: ["High", "Low", "Blocker", "Invalid"],
            CategoryList: ["UAT", "Prod", "internal", "Unit"],
            StatusList: ["Fixed", "Completed", "Invalid", "Reopen", "Open"],
            Status: ""
        };

        this._columns = [
            { key: "downloadLink", name: "Download Link" },
            { key: "name", name: "Name" },
            { key: "lastModifiedDate", name: "Last Modified Date" }
        ];
    }

    componentDidMount() {
    // If data is not present it's a CreateIssue
    // else an UpdateIssue
    //submitIssuesStore.getIsSubmitNewIssue   --> its to check in new issue or submitted issue
    //submitIssuesStore.selectedIssueData     --> if its editing existing issue then we ll get Object or null

        if (
            submitIssuesStore.selectedIssueData == null &&
      !submitIssuesStore.getIsSubmitNewIssue
        ) {
            this.setState({ newIssue: submitIssuesStore.getIsSubmitNewIssue });
        }
    }

    render() {
        const SeverityListOptions = this.state.SeverityList.map(severity => (
            <Option key={severity}>{severity}</Option>
        ));
        const CategoryListOptions = this.state.CategoryList.map(Category => (
            <Option key={Category}>{Category}</Option>
        ));
        const StatusListOptions = this.state.StatusList.map(Status => (
            <Option key={Status}>{Status}</Option>
        ));

        return (
            <Form className="ant-advanced-search-form">
                {/*Below block of code is requied for only for editing an logged issue*/}
                <Row gutter={16}>
                    {this.state.newIssue ? (
                        <Col span={8}>
                            <FormItem {...formItemLayout} label="Customer">
                                {
                                    <Input
                                        placeholder="Please enter Customer name"
                                        value={this.state.CustomerName}
                                        onChange={e =>
                                            this.setState({ CustomerName: e.target.value })
                                        }
                                    />
                                }
                            </FormItem>

                            <FormItem {...formItemLayout} label="Assign to">
                                {
                                    <Input
                                        placeholder="Please enter assignee"
                                        value={this.state.AssignedTo}
                                        onChange={e =>
                                            this.setState({ AssignedTo: e.target.value })
                                        }
                                    />
                                }
                            </FormItem>
                        </Col>
                    ) : (
                        <div>
                            <div className="col-md-6 fl ">
                                <FormItem {...formItemLayout} label="Submited By">
                                    {
                                        <Input
                                            placeholder="Please enter username"
                                            value={this.state.SubmittedBy}
                                        />
                                    }
                                </FormItem>

                                <FormItem {...formItemLayout} label="Severity">
                                    <Select
                                        defaultValue={this.state.Severity}
                                        onChange={value => {
                                            this.setState({ Severity: value });
                                        }}
                                    >
                                        {SeverityListOptions}
                                    </Select>
                                </FormItem>

                                <FormItem {...formItemLayout} label="Category">
                                    <Select
                                        defaultValue={this.state.Severity}
                                        value={this.state.Category}
                                        onChange={value => {
                                            this.setState({ Category: value });
                                        }}
                                    >
                                        {CategoryListOptions}
                                    </Select>
                                </FormItem>

                                <FormItem {...formItemLayout} label="Issue Summary">
                                    {
                                        <Input
                                            placeholder="Please enter username"
                                            defaultValue={
                                                submitIssuesStore.getIsSubmitNewIssue
                                                    ? this.state.IssueSummary
                                                    : "New issue descripation is required"
                                            }
                                            value={this.state.IssueSummary}
                                            onChange={e =>
                                                this.setState({ IssueSummary: e.target.value })
                                            }
                                        />
                                    }
                                </FormItem>
                            </div>
                            <div className="col-md-6 fl">
                                <FormItem {...formItemLayout} label="Customer">
                                    {
                                        <Input
                                            placeholder="Please enter Customer name"
                                            value={this.state.CustomerName}
                                            onChange={e =>
                                                this.setState({ CustomerName: e.target.value })
                                            }
                                        />
                                    }
                                </FormItem>
                                <FormItem {...formItemLayout} label="Assign to">
                                    {
                                        <Input
                                            placeholder="Please enter assignee"
                                            value={this.state.AssignedTo}
                                            onChange={e =>
                                                this.setState({ AssignedTo: e.target.value })
                                            }
                                        />
                                    }
                                </FormItem>
                                <FormItem {...formItemLayout} label="Status">
                                    <Select
                                        defaultValue={this.state.Status}
                                        value={this.state.Status}
                                        onChange={value => {
                                            this.setState({ Status: value });
                                        }}
                                    >
                                        {StatusListOptions}
                                    </Select>
                                </FormItem>
                            </div>
                        </div>
                    )}
                </Row>
                <br />
                {/* Irrespective of new issue or edit issue,below block is required  */}
                <div className="fl">
                    <FormItem {...formItemLayout} label="Issue Summary">
                        {
                            <Input
                                placeholder="Please enter username"
                                defaultValue={
                                    submitIssuesStore.getIsSubmitNewIssue
                                        ? this.state.IssueSummary
                                        : "New issue descripation is required"
                                }
                                value={this.state.IssueSummary}
                                onChange={e => this.setState({ IssueSummary: e.target.value })}
                            />
                        }
                    </FormItem>

                    <div className="clear">
                        <label>Description</label>
                        <TextArea
                            rows={3}
                            type="text"
                            value={this.state.Description}
                            onChange={e => this.setState({ Description: e.target.value })}
                        />
                        <i className="clear">(Include the steps to reproduce)</i>
                    </div>
                    <div className="clear">
                        <label>Implication</label>
                        <TextArea
                            rows={3}
                            type="text"
                            value={this.state.Implication}
                            onChange={e => this.setState({ Implication: e.target.value })}
                        />
                        <i className="clear">(How does this impact your work)</i>
                    </div>
                </div>
            </Form>
        );
    }
}

export default Issues;
