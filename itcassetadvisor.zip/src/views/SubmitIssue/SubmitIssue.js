import React, { Component } from "react";
import { observer } from "mobx-react";
import { Row, Col, Spin } from "antd";
import Issues from "./Issue";
import Functions from "../../api/Functions";
import userStore from "../../stores/userStore";
import submitIssuesStore from "../../stores/submitIssuesStore";
import PropTypes from "prop-types";
import { Tabs } from "antd";
const TabPane = Tabs.TabPane;
import { AgGridReact } from "ag-grid-react";
import { Form, Icon, Button } from "antd";
import UIFunctions from "../../helpers/UIFunctions";
import moment from "moment";
import tabModelStore from "../../stores/tabModelStore";
const FormItem = Form.Item;


@observer
class SubmitIssue extends Component {
    constructor(props) {
        super(props);
        this.handleCloseAfterSubmitIssue = this.handleCloseAfterSubmitIssue.bind(
            this
        );
        this.handleCancel = this.handleCancel.bind(this);
        this.handleSubmitAnIssue = this.handleSubmitAnIssue.bind(this);
        this.updateTabState = this.updateTabState.bind(this);
        this.historyClicked = this.historyClicked.bind(this);

        this.state = {
            tabActive: "assignedToMe",
            tabKey: "1",
            data: [],
            tabColumns: [
                { field: "IssueId", headerName: "Issue ID", width: 170, menuTabs: [] },
                {
                    field: "IssueSummary",
                    headerName: "Issue Summary",
                    width: 220,
                    menuTabs: []
                },
                {
                    field: "DateOpened",
                    headerName: "Date Submitted",
                    width: 220,
                    valueFormatter: this.dateFormatter,
                    menuTabs: []
                },
                {
                    field: "SubmittedBy",
                    headerName: "Submitter Name",
                    width: 170,
                    menuTabs: []
                },
                { field: "Category", headerName: "Category", width: 170, menuTabs: [] },
                { field: "Severity", headerName: "Severity", width: 170, menuTabs: [] },
                {
                    field: "Status",
                    headerName: "Issue Status",
                    width: 170,
                    menuTabs: []
                },
                {
                    field: "AssignedTo",
                    headerName: "Assigned To",
                    width: 220,
                    menuTabs: []
                },
                { field: "Type", headerName: "Type", width: 270, menuTabs: [] }
            ],
            historyColumns: [
                {
                    field: "Timestamp",
                    headerName: "Last Modified",
                    width: 180,
                    menuTabs: []
                },
                {
                    field: "EditedBy",
                    headerName: "Changed By",
                    width: 230,
                    menuTabs: []
                },
                {
                    field: "Description",
                    headerName: "Details Changed",
                    width: 400,
                    menuTabs: []
                }
            ],
            historyView: 0,
            historyDatas: [],
            rowSelection: "single",
            rowClassRules: {
                "normal-row": function(params) {
                    return params.node.data.read;
                },
                "bold-row": function(params) {
                    return !params.node.data.read;
                }
            }
        };
    }

  onSelectionChanged = e => {
      const selection = e.api.getSelectedRows() ? e.api.getSelectedRows() : [];
      var row = null;
      if (selection.length > 0) {
          row = JSON.parse(JSON.stringify(selection[0]));
      }
      submitIssuesStore.setSelectedIssueData(row);

      if (row.read == false) {
          Functions.MarkNotificationAsRead("IssueLog", row.NotificationId);
          submitIssuesStore.markAsReadAssignedToMe(row);
          submitIssuesStore.markAsReadSubmittedByMe(row);
          this.gridApi.redrawRows();
      }
  };
  onGridReady = params => {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
  };

  dateFormatter = params => {
      return moment(params.value).format("YYYY-MM-DD");
  };

  handleSubmitAnIssue() {
      submitIssuesStore.setIsSubmitNewIssue(true);
      submitIssuesStore.toggleOpenIssueForm();
  }
  componentDidMount() {
      userStore.userDetails ? "" : this.props.history.push("/");

      Functions.GetIssuesAssignedToMe().then(resp => {
          var array = resp.data.array;
          submitIssuesStore.setIssuesAssignedToMe(array);
          Functions.GetIssuesSubmittedByMe().then(resp => {
              var array = resp.data.array;
              submitIssuesStore.setIssuesSubmittedByMe(array);
              submitIssuesStore.setSpinFlag(true);
          });
      });

      submitIssuesStore.setSelectedIssueData({});
      submitIssuesStore.setIsSubmittedByMeTabActive(false);
  }

  updateTabState() {
      var tabElem = document.getElementsByClassName("ant-tabs-tab");
      if (this.state.tabKey == 1) {
          tabElem[1].click();
      } else if (this.state.tabKey == 2) {
          tabElem[2].click();
      } else {
          tabElem[0].click();
      }
      window.clearTimeout();
  }
  handleCloseAfterSubmitIssue() {
      submitIssuesStore.setSelectedIssueData({});
      submitIssuesStore.toggleOpenIssueForm();
      submitIssuesStore.setIsSubmitNewIssue(false);
      submitIssuesStore.setEditing(false);
      submitIssuesStore.setSubmitting(false);
      window.setTimeout(this.updateTabState, 300);
  }
  callback(key) {
      submitIssuesStore.setIsSubmittedByMeTabActive(false);
      if (key == 1) this.setState({ tabActive: "assignedToMe", tabKey: "1" });
      else if (key == 2) {
          this.setState({ tabActive: "submittedByMe", tabKey: "2" });
          submitIssuesStore.setIsSubmittedByMeTabActive(true);
      } else if (key == 3) {
          this.setState({ tabActive: "issuesViewAll", tabKey: "3" });
      }
      submitIssuesStore.setSelectedIssueData({});
      this.setState({ historyView: 0 });
  }

  rowDoubleClicked(event) {
      submitIssuesStore.setSelectedIssueData(event.data);
      submitIssuesStore.toggleOpenIssueForm();
  }
  rowClicked() {
      submitIssuesStore.toggleOpenIssueForm();
      this.setState({ historyView: 0 });
  }
  handleCancel() {
      if (submitIssuesStore.editing) {
          UIFunctions.ShowConfirm({
              zIndex: 2000,
              title: "Do you want to discard changes?",
              okText: "Yes",
              cancelText: "No",
              onOk() {
                  submitIssuesStore.setSelectedIssueData({});
                  submitIssuesStore.toggleOpenIssueForm();
                  submitIssuesStore.setEditing(false);
                  submitIssuesStore.setIsSubmitNewIssue(false);
                  //clear update session if user cancel the update issue popup
              },
              onCancel() {}
          });
          //Fix for - Tab button state disappear after closing issue pop up
          window.setTimeout(this.updateTabState, 300);
      } else {
          submitIssuesStore.setSelectedIssueData({});
          submitIssuesStore.toggleOpenIssueForm();
          submitIssuesStore.setEditing(false);
          submitIssuesStore.setIsSubmitNewIssue(false);
      }
  }
  cancelButton() {
      submitIssuesStore.openIssueForm
          ? this.handleCancel()
          : this.props.history.push("/");
      Functions.GetNotificationCount().then(response => {
          tabModelStore.IssueLogNotificationCount =
        response.data.IssueLogNotificationCount;
      });
  }

  historyClicked = () => {
      if (submitIssuesStore.selectedIssueData.History != undefined) {
          var x = JSON.parse(submitIssuesStore.selectedIssueData.History);
          x.forEach(item => {
              item.Timestamp = moment(item.Timestamp).format("YYYY-MM-DD HH:mm:SS");
          });

          this.setState({ historyView: 1, historyDatas: x });
      } else {
          this.setState({ historyView: 1, historyDatas: [] });
      }
  };
  resetHistory = () => {
      this.setState({ historyView: 0 });
  };

  render() {
      var issueStyles = {
          clearBoth: {
              clear: "both"
          },
          textStyle: {
              color: "#6a7682",
              fontSize: "1.1rem",
              marginBottom: "15px"
          },
          colLeft: {
              height: window.innerHeight - 308,
              color: "#666"
          },
          colRight: {
              height: window.innerHeight - 308,
              backgroundColor: "#fff",
              padding: "20px",
              overflow: "scroll"
          },
          requestLeftTextStyle: {
              color: "#707c88",
              fontWeight: "500"
          },
          requestRightTextStyle: {
              color: "#abb2b8",
              fontWeight: "400"
          },
          requestStatusTextStyle: {
              color: "#ff4d4d",
              fontWeight: "400"
          },
          requestMarginBottom: {
              fontSize: "15px",
              marginBottom: "20px"
          },
          information: {
              height: window.innerHeight - 308,
              backgroundColor: "#e5e5e5",
              textAlign: "center"
          },
          informationText: {
              fontSize: "20px",
              color: "#ff5c5f",
              fontStyle: "italic",
              padding: "52% 20%",
              margin: "0px"
          },
          editButtonIssueLog: {
              cursor: "pointer",
              color: "#6a7682",
              fontSize: "1.1rem",
              marginBottom: "15px"
          }
      };

      let displayString = null;
      let infoString = null;
      if (this.state.historyView == 0) {
          displayString = "Open Issues";
          infoString = "Issue Info";
      } else {
          displayString = "Issue History";
          infoString = "Issue Info";
      }
      const allRows = () => {
          var SubmittedId = [];
          var Assigned = JSON.parse(
              JSON.stringify(submitIssuesStore.issuesAssignedToMe)
          );
          submitIssuesStore.issuesSubmittedByMe.map(item =>
              SubmittedId.push(item.IssueId)
          );

          Assigned.map(item => {
              var index = SubmittedId.indexOf(item.IssueId);
              if (index >= 0) {
                  item.Type = "Assigned to Me,Submitted by Me";
                  SubmittedId.splice(index, 1);
              }
          });

          var Submitted = submitIssuesStore.issuesSubmittedByMe.filter(item => {
              return SubmittedId.indexOf(item.IssueId) >= 0;
          });
          return Submitted.concat(Assigned).map(item => item);
      };
      return (
          <div id="submit-an-issue-container">
              <Form onSubmit={this.handleSubmit} className="login-form">
                  <div className="wrapper" style={{ height: window.innerHeight }}>
                      <div
                          className="modalPageheader container-fluid"
                          style={{
                              backgroundColor: "rgb(216, 104, 104)",
                              paddingTop: "10px",
                              paddingBottom: "10px",
                              borderRight: "none",
                              borderBottom: "none"
                          }}
                      >
                          <div className="pull-left">
                              <div
                                  style={{
                                      color: "rgb(255,255,255)",
                                      textTransform: "uppercase",
                                      fontSize: "20px",
                                      fontWeight: "400"
                                  }}
                              >
                  Issue log
                              </div>
                          </div>
                          <div className="btn pull-right ">
                              <Icon
                                  type="close-circle-o"
                                  style={{
                                      color: "rgb(255,255,255)",
                                      fontWeight: "100",
                                      fontSize: "21px",
                                      lineHeight: "normal",
                                      cursor: "pointer"
                                  }}
                                  onClick={() => this.cancelButton()}
                              />
                          </div>
                          <div style={issueStyles.clearBoth} />
                      </div>
                      {!submitIssuesStore.openIssueForm ? (
                          <div className="twoItems container-fluid">
                              <div className="col-md-12">
                                  <FormItem>
                                      <Tabs
                                          defaultActiveKey={this.state.tabKey}
                                          onChange={this.callback.bind(this)}
                                      >
                                          <TabPane tab="View All" key="3" />
                                          <TabPane tab="Assigned to Me" key="1" />
                                          <TabPane tab="Submitted by Me" key="2" />
                                      </Tabs>
                                  </FormItem>
                              </div>
                          </div>
                      ) : (
                          <div />
                      )}
                      {!submitIssuesStore.openIssueForm ? (
                          <div className="container-fluid">
                              <div className="col-lg-8 pull-left">
                                  <div style={issueStyles.textStyle}>{displayString}</div>

                                  {this.state.tabActive === "issuesViewAll" && (
                                      <div className="column1 openRequests issuesViewAll">
                                          <Spin spinning={!submitIssuesStore.SpinFlag}>
                                              <div style={issueStyles.colLeft} className="ag-fresh">
                                                  {submitIssuesStore.issuesAssignedToMe &&
                            this.state.historyView === 0 && (
                                                      <AgGridReact
                                                          rowData={allRows()}
                                                          columnDefs={this.state.tabColumns}
                                                          rowSelection={this.state.rowSelection}
                                                          suppressCellSelection={true}
                                                          onGridReady={this.onGridReady.bind(this)}
                                                          onSelectionChanged={this.onSelectionChanged.bind(
                                                              this
                                                          )}
                                                          rowHeight="35"
                                                          headerHeight="35"
                                                          suppressMovableColumns={true}
                                                          rowClassRules={this.state.rowClassRules}
                                                      />
                                                  )}
                                                  {this.state.historyView === 1 && (
                                                      <AgGridReact
                                                          rowData={this.state.historyDatas}
                                                          columnDefs={this.state.historyColumns}
                                                          suppressCellSelection={true}
                                                          onGridReady={this.onGridReady.bind(this)}
                                                          rowHeight="35"
                                                          headerHeight="35"
                                                          suppressMovableColumns={true}
                                                      />
                                                  )}
                                              </div>
                                          </Spin>
                                      </div>
                                  )}

                                  {this.state.tabActive === "assignedToMe" && (
                                      <div className="column1 openRequests assignedToMe">
                                          <Spin spinning={!submitIssuesStore.SpinFlag}>
                                              <div style={issueStyles.colLeft} className="ag-fresh">
                                                  {submitIssuesStore.issuesAssignedToMe &&
                            this.state.historyView === 0 && (
                                                      <AgGridReact
                                                          rowData={submitIssuesStore.issuesAssignedToMe.map(
                                                              i => i
                                                          )}
                                                          columnDefs={this.state.tabColumns}
                                                          rowSelection={this.state.rowSelection}
                                                          suppressCellSelection={true}
                                                          onGridReady={this.onGridReady.bind(this)}
                                                          onSelectionChanged={this.onSelectionChanged.bind(
                                                              this
                                                          )}
                                                          rowHeight="35"
                                                          headerHeight="35"
                                                          suppressMovableColumns={true}
                                                          rowClassRules={this.state.rowClassRules}
                                                      />
                                                  )}
                                                  {this.state.historyView === 1 && (
                                                      <AgGridReact
                                                          rowData={this.state.historyDatas}
                                                          columnDefs={this.state.historyColumns}
                                                          suppressCellSelection={true}
                                                          onGridReady={this.onGridReady.bind(this)}
                                                          rowHeight="35"
                                                          headerHeight="35"
                                                          suppressMovableColumns={true}
                                                      />
                                                  )}
                                              </div>
                                          </Spin>
                                      </div>
                                  )}

                                  {this.state.tabActive === "submittedByMe" && (
                                      <div className="column1 openRequests submittedByMe">
                                          <Spin spinning={!submitIssuesStore.SpinFlag}>
                                              <div style={issueStyles.colLeft} className="ag-fresh">
                                                  {submitIssuesStore.issuesAssignedToMe &&
                            this.state.historyView === 0 && (
                                                      <AgGridReact
                                                          rowData={submitIssuesStore.issuesSubmittedByMe.map(
                                                              i => i
                                                          )}
                                                          columnDefs={this.state.tabColumns}
                                                          rowSelection={this.state.rowSelection}
                                                          suppressCellSelection={true}
                                                          onGridReady={this.onGridReady.bind(this)}
                                                          onSelectionChanged={this.onSelectionChanged.bind(
                                                              this
                                                          )}
                                                          rowHeight="35"
                                                          headerHeight="35"
                                                          suppressMovableColumns={true}
                                                          rowClassRules={this.state.rowClassRules}
                                                      />
                                                  )}
                                                  {this.state.historyView === 1 && (
                                                      <AgGridReact
                                                          rowData={this.state.historyDatas}
                                                          columnDefs={this.state.historyColumns}
                                                          suppressCellSelection={true}
                                                          onGridReady={this.onGridReady.bind(this)}
                                                          rowHeight="35"
                                                          headerHeight="35"
                                                          suppressMovableColumns={true}
                                                      />
                                                  )}
                                              </div>
                                          </Spin>
                                      </div>
                                  )}
                              </div>
                              <div className="col-lg-4 pull-right">
                                  <div className="pull-left" style={issueStyles.textStyle}>
                                      {infoString}
                                  </div>
                                  {Object.keys(submitIssuesStore.selectedIssueData).length ? (
                                      <div>
                                          <div
                                              className="editissuebutton pull-right"
                                              style={issueStyles.editButtonIssueLog}
                                              onClick={this.rowClicked.bind(this)}
                                          >
                                              {submitIssuesStore.selectedIssueData.Status != "Closed"
                                                  ? "Edit"
                                                  : "View"}{" "}
                                              <Icon
                                                  type={
                                                      submitIssuesStore.selectedIssueData.Status !=
                            "Closed"
                                                          ? "edit"
                                                          : "bars"
                                                  }
                                                  style={{ fontWeight: 100 }}
                                              />
                                          </div>
                                          <div style={issueStyles.clearBoth} />

                                          <div style={issueStyles.colRight}>
                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-5 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Issue ID :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.IssueId}
                                                      </span>
                                                  </Col>
                                                  <Col className="col-lg-7 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Date Submitted :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {moment(
                                                              submitIssuesStore.selectedIssueData.DateOpened
                                                          ).format("YYYY-MM-DD")}
                                                      </span>
                                                  </Col>
                                              </Row>
                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-5 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Issue Status :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestStatusTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.Status}
                                                      </span>
                                                  </Col>
                                                  <Col className="col-lg-7 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Category :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.Category}
                                                      </span>
                                                  </Col>
                                              </Row>
                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-5 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Severity :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.Severity}
                                                      </span>
                                                  </Col>
                                                  <Col className="col-lg-7 pull-left">
                                                      <Button
                                                          className="viewIssueHistoryButton"
                                                          type="button"
                                                          onClick={this.historyClicked.bind(this)}
                                                      >
                                                          <i className="fa fa-book" /> View Issue History
                                                      </Button>
                                                  </Col>
                                              </Row>
                                              <Row>
                                                  <hr />
                                              </Row>
                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-12 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Submitter Name :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.SubmittedBy}
                                                      </span>
                                                  </Col>
                                              </Row>
                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-12 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Assigned To :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.AssignedTo}
                                                      </span>
                                                  </Col>
                                              </Row>
                                              <Row>
                                                  <hr />
                                              </Row>

                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-12 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Issue Summary :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.IssueSummary}
                                                      </span>
                                                  </Col>
                                              </Row>
                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-12 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Description :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.Description}
                                                      </span>
                                                  </Col>
                                              </Row>
                                              <Row style={issueStyles.requestMarginBottom}>
                                                  <Col className="col-lg-12 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Comments/Resolution :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.Comments}
                                                      </span>
                                                  </Col>
                                              </Row>
                                              <Row>
                                                  <Col className="col-lg-12 pull-left">
                                                      <span style={issueStyles.requestLeftTextStyle}>
                              Attachments :
                                                      </span>{" "}
                                                      <span style={issueStyles.requestRightTextStyle}>
                                                          {submitIssuesStore.selectedIssueData.Attachments}
                                                      </span>
                                                  </Col>
                                              </Row>
                                          </div>
                                      </div>
                                  ) : (
                                      <div>
                                          <div style={issueStyles.clearBoth} />{" "}
                                          <div style={issueStyles.information}>
                                              <h1 style={issueStyles.informationText}>
                          Click an Item to View More Information
                                              </h1>
                                          </div>
                                      </div>
                                  )}
                              </div>
                              <div style={issueStyles.clearBoth} />
                          </div>
                      ) : (
                          <Issues
                              tabMenu={this.state.tabActive}
                              handleCloseAfterSubmitIssue={this.handleCloseAfterSubmitIssue}
                              handleCancel={this.handleCancel}
                              createIssue={submitIssuesStore.getIsSubmitNewIssue}
                          />
                      )}
                      {!submitIssuesStore.openIssueForm && (
                          <div
                              className="wizardFooter"
                              style={{ justifyContent: "center" }}
                          >
                              <div>
                                  <FormItem style={{ display: "none" }}>
                                      <Button onClick={this.handleCancel}>Cancel</Button>
                                  </FormItem>
                                  {this.state.historyView === 0 && (
                                      <div
                                          className="newissuebutton"
                                          onClick={this.handleSubmitAnIssue}
                                      >
                                          {" "}
                      New Issue{" "}
                                          <Icon type="plus-circle-o" style={{ fontWeight: 100 }} />
                                      </div>
                                  )}
                                  {this.state.historyView === 1 && (
                                      <div className="newissuebutton" onClick={this.resetHistory}>
                                          {" "}
                                          <Icon
                                              type="left-circle-o"
                                              style={{ fontWeight: 100 }}
                                          />{" "}
                      Back
                                      </div>
                                  )}
                              </div>
                          </div>
                      )}
                  </div>

                  {/* } */}
              </Form>
          </div>
      );
  }
}
export default SubmitIssue;

SubmitIssue.propTypes = {
    router: PropTypes.func.isRequired,
    push: PropTypes.String,
    history: PropTypes.String
};
