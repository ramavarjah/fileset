import React from "react";
import { observer } from "mobx-react";
import moment from "moment";
import Functions from "../../api/Functions";
import Select from "react-select";
import Urls from "../../api/Urls";
import UIFunctions from "../../helpers/UIFunctions";
import userStore from "../../stores/userStore";
import submitIssuesStore from "../../stores/submitIssuesStore";
import { Form, Input, Button, Upload, Card, Col, Row, Spin } from "antd";
const FormItem = Form.Item;
const { TextArea } = Input;
import { AgGridReact } from "ag-grid-react";

@observer
class IssuesPage extends React.Component {
	constructor(props) {
		super(props);
		this.handleSubmit = this.handleSubmit.bind(this);
		this.uploadFile = this.uploadFile.bind(this);
		this.createRows = this.createRows.bind(this);

		this.state = {
			Attachments: false,
			rows: [],
			SeverityList: [],
			CategoryList: [],
			StatusList: [],
			columnsClosedIssues: [
				{
					field: "downloadLink",
					headerName: "Download Link",
					cellRenderer: function(params) {
						return "<a href=" + params.value + "> download </a>";
					}
				},
				{ field: "name", headerName: "Name" },
				{ field: "lastModifiedDate", headerName: "Last Modified Date" }
			],
			columnsOpenIssues: [
				{
					field: "downloadLink",
					headerName: "Download Link",
					cellRenderer: function(params) {
						return "<a href=" + params.value + "> download </a>";
					}
				},
				{ field: "name", headerName: "Name" },
				{ field: "lastModifiedDate", headerName: "Last Modified Date" },
				{
					headerName: "Delete",
					field: "delete",
					cellRenderer: function() {
						return '<Icon class="icon-trash cell-btn-remove" />';
					}
				}
			],
			fileList: []
		};
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
	}

	onRemoveSelected(event) {
		if (event.column.colId == "delete") {
			var selectedData = this.gridApi.getSelectedRows();
			var fileList = this.state.rows;
			this.state.rows.map((item, index) => {
				if (item.name === event.data.name) fileList.splice(index, 1);
			});
			this.setState({ rows: fileList });
			this.gridApi.updateRowData({ remove: selectedData });
			var deletedFiles = submitIssuesStore.selectedIssueData.deletedFiles;
			deletedFiles.push(selectedData[0].name);
			submitIssuesStore.addToSelectedIssueData({ deletedFiles: deletedFiles });
			submitIssuesStore.setEditing(true);
		}
	}

	createRows = data => {
		var temprows = [];
		for (let i = 0; i < data.length; i++) {
			temprows.push({
				downloadLink: data[i].downloadLink,
				name: data[i].name,
				lastModifiedDate: moment(data[i].lastModifiedDate).format(
					"YYYY-MM-DD HH:mm:SS"
				)
			});
		}
		this.setState({ rows: temprows });
		this.setState({ Attachments: true });
	};
	getAttachedFileDetails = reqID => {
		Functions.GetAttachments(reqID)
			.then(resp => {
				if (resp.data.data && resp.data.data.length > 0)
					this.createRows(resp.data.data);
				else {
					this.setState({ Attachments: true });
				}
			})
			.catch(() => {
				UIFunctions.Toast("Something did not work", "warn");
			});
	};

	fileDataChange(info) {
		var newfilelist = this.state.fileList;
		//File Size Check
		const isLt2M = info.file.size / 1024 / 1024 <= 10;
		if (!isLt2M) {
			return UIFunctions.Toast(
				info.file.name + " is greater than 10MB",
				"info"
			);
		}
		info.fileList.forEach((item, i) => {
			var isNewItem = true;
			this.state.fileList.map(fileitem => {
				item.name == fileitem.name ? (isNewItem = false) : "";
			});
			info.fileList[i].status = info.fileList[i].name;
			isNewItem && newfilelist.push(info.fileList[i]);
		});
		this.setState({ fileList: newfilelist });
		submitIssuesStore.setEditing(true);
	}

	OnFileRemove(file) {
		var newFileList = this.state.fileList;
		const index = newFileList.indexOf(file);
		newFileList.splice(index, 1);
		this.setState({ fileList: newFileList });
	}

	uploadFile() {
		var IssueId = submitIssuesStore.selectedIssueData.IssueId;
		var deletedFiles = submitIssuesStore.selectedIssueData.deletedFiles;
		function upload() {
			Functions.UploadIssueFile(
				Urls.baseServiceurl,
				IssueId,
				fileList,
				deletedFiles
			)
				.then(resp => {
					if (resp.data.success) {
						Functions.GetIssuesAssignedToMe().then(resp => {
							var array = resp.data.array;
							submitIssuesStore.setIssuesAssignedToMe(array);

							Functions.GetIssuesSubmittedByMe().then(resp => {
								var array = resp.data.array;
								submitIssuesStore.setIssuesSubmittedByMe(array);
								submitIssuesStore.setSpinFlag(true);
							});
						});
					}
				})
				.catch(() => {
					UIFunctions.Toast("Something did not work", "warn");
				});
		}
		var fileList = [];
		var length = this.state.fileList.length;
		if (length > 0) {
			this.state.fileList.forEach((item, index) => {
				var reader = new FileReader();
				reader.onload = function() {
					fileList.push({
						name: item.name,
						data: reader.result.split(",")[1]
					});
					if (+index + 1 == length) upload();
				};
				reader.readAsDataURL(item.originFileObj);
			});
		} else if (submitIssuesStore.selectedIssueData.deletedFiles.length > 0) {
			upload();
		} else {
			Functions.GetIssuesAssignedToMe().then(resp => {
				var array = resp.data.array;
				submitIssuesStore.setIssuesAssignedToMe(array);
				Functions.GetIssuesSubmittedByMe().then(resp => {
					var array = resp.data.array;
					submitIssuesStore.setIssuesSubmittedByMe(array);
					submitIssuesStore.setSpinFlag(true);
				});
			});
		}
	}

	componentDidMount() {
		if (submitIssuesStore.isSubmitNewIssue) {
			submitIssuesStore.setSelectedIssueData({});
			submitIssuesStore.addToSelectedIssueDataFromCode({
				CustomerId: userStore.userDetails.CustomerId,
				CustomerName: userStore.userDetails.Organization,
				SubmittedBy: userStore.userDetails.UserName,
				deletedFiles: []
			});
			this.props.form.setFieldsValue(submitIssuesStore.selectedIssueData);
		} else {
			submitIssuesStore.addToSelectedIssueDataFromCode({
				NewStatus: submitIssuesStore.selectedIssueData.Status,
				deletedFiles: []
			});
			this.props.form.setFieldsValue(submitIssuesStore.selectedIssueData);

			if (
				submitIssuesStore.selectedIssueData
					? submitIssuesStore.selectedIssueData.Type != "Submitted by Me"
					: false
			) {
				Functions.GetPageWiseDropDownValue("SubmitIssue").then(resp => {
					var optionListCategory = [];
					var optionListSeverity = [];
					var optionListStatus = [];
					//getting Category List
					for (let i = 0; i < resp.data.details[0].DropDownValues.length; i++) {
						optionListCategory.push({
							label: resp.data.details[0].DropDownValues[i],
							value: resp.data.details[0].DropDownValues[i]
						});
					}
					this.setState({
						CategoryList: optionListCategory
					});
					//getting Severity List
					for (let i = 0; i < resp.data.details[1].DropDownValues.length; i++) {
						optionListSeverity.push({
							label: resp.data.details[1].DropDownValues[i],
							value: resp.data.details[1].DropDownValues[i]
						});
					}
					this.setState({
						SeverityList: optionListSeverity
					});
					//getting Status List
					for (let i = 0; i < resp.data.details[2].DropDownValues.length; i++) {
						optionListStatus.push({
							label: resp.data.details[2].DropDownValues[i],
							value: resp.data.details[2].DropDownValues[i]
						});
					}
					this.setState({
						StatusList: optionListStatus
					});
				});
			}
			//end here
		}

		if (!submitIssuesStore.getIsSubmitNewIssue) {
			if (submitIssuesStore.selectedIssueData.IssueId)
				this.getAttachedFileDetails(
					submitIssuesStore.selectedIssueData.IssueId
				);
		}
	}
	handleSubmitValidation() {
		function listFiles(files) {
			return (
				<div>
					{files.map(item => {
						return <div key={item}>{item}</div>;
					})}
				</div>
			);
		}

		function parseValue(input) {
			var ret = input //null check
				? input.value //value check
					? input.value //if object  take .value from obj
					: input
				: "";
			return ret;
		}
		this.props.form.validateFieldsAndScroll((err, values) => {
			if (!err) {
				submitIssuesStore.setSubmitting(true);

				var files = [];
				this.state.fileList.forEach(item => {
					this.state.rows.map(fileitem => {
						item.name == fileitem.name ? files.push(item.name) : "";
					});
				});

				if (files.length > 0) {
					UIFunctions.ShowConfirm({
						zIndex: 2000,
						title:
							"The following file(s) is/are already attached to the issue. Do you want to overwrite?",
						okText: "Yes",
						cancelText: "No",
						content: listFiles(files),
						width: 600,
						onOk() {
							if (!submitIssuesStore.isSubmitNewIssue) {
								values.Category = parseValue(values.Category);
								values.Severity = parseValue(values.Severity);
								values.Status = parseValue(values.Status);
							}
							submitIssuesStore.addToSelectedIssueData(values);
							self.handleSubmit();
						},
						onCancel() {
							submitIssuesStore.setSubmitting(false);
						}
					});
				} else {
					if (!submitIssuesStore.isSubmitNewIssue) {
						values.Category = parseValue(values.Category);
						values.Severity = parseValue(values.Severity);
						values.Status = parseValue(values.Status);
					}
					submitIssuesStore.addToSelectedIssueData(values);
					this.handleSubmit();
				}
			}
		});
	}

	handleSubmit() {
		submitIssuesStore.setSpinFlag(false);
		if (submitIssuesStore.isSubmitNewIssue) {
			Functions.CreateIssue(submitIssuesStore.selectedIssueData)
				.then(resp => {
					if (resp.data.success) {
						submitIssuesStore.addToSelectedIssueDataFromCode({
							IssueId: resp.data.IssueId
						});
						this.uploadFile();
						UIFunctions.Toast(resp.data.message, "success");
					} else {
						UIFunctions.Toast(resp.data.message, "error");
					}
					this.props.handleCloseAfterSubmitIssue();
				})
				.catch(() => {
					UIFunctions.Toast("Something did not work", "warn");
					this.props.handleCloseAfterSubmitIssue();
				});
		} else if (submitIssuesStore.selectedIssueData.Type === "Submitted by Me") {
			Functions.UpdateSubmittedIssue(
				submitIssuesStore.selectedIssueData.Description,
				submitIssuesStore.selectedIssueData.Implication,
				submitIssuesStore.selectedIssueData.IssueSummary,
				submitIssuesStore.selectedIssueData.IssueId
			)
				.then(resp => {
					if (resp.data.success) {
						this.uploadFile();
						UIFunctions.Toast(resp.data.message, "success");
					} else {
						UIFunctions.Toast(resp.data.message, "error");
					}

					this.props.handleCloseAfterSubmitIssue();
				})
				.catch(() => {
					UIFunctions.Toast("Something did not work", "warn");
					this.props.handleCloseAfterSubmitIssue();
				});
		} else {
			Functions.UpdateAssignedIssue(
				submitIssuesStore.selectedIssueData.IssueSummary,
				submitIssuesStore.selectedIssueData.Description,
				submitIssuesStore.selectedIssueData.Implication,
				submitIssuesStore.selectedIssueData.Status,
				submitIssuesStore.selectedIssueData.Severity,
				submitIssuesStore.selectedIssueData.Category,
				submitIssuesStore.selectedIssueData.AssignedTo,
				submitIssuesStore.selectedIssueData.IssueId
			)
				.then(resp => {
					if (resp.data.success) {
						this.uploadFile();
						UIFunctions.Toast(resp.data.message, "success");
					} else {
						UIFunctions.Toast(resp.data.message, "error");
					}
					this.props.handleCloseAfterSubmitIssue();
				})
				.catch(() => {
					UIFunctions.Toast("Something did not work", "warn");
					this.props.handleCloseAfterSubmitIssue();
				});
		}
	}
	render() {
		const { getFieldDecorator } = this.props.form;
		const formItemLayout = {
			labelCol: {
				md: { span: 9 },
				lg: { span: 8 }
			},
			wrapperCol: {
				md: { span: 15 },
				lg: { span: 16 }
			}
		};
		const formItemLayout1 = {};

		var issueStyles = {
			inputStyle: {
				backgroundColor: "#e5e5e5",
				border: "none",
				color: "#737f8b",
				fontSize: "15px",
				fontWeight: "400"
			},
			textareaStyle: {
				height: "100px",
				backgroundColor: "#e5e5e5",
				border: "none",
				color: "#737f8b",
				fontSize: "15px",
				fontWeight: "400"
			}
		};
		return (
			<div id="thisWrapper" className="issueLogForm">
				<Form>
					<Card style={{ overflowY: "auto", height: window.innerHeight - 120 }}>
						{this.props.createIssue ||
						(submitIssuesStore.selectedIssueData
							? submitIssuesStore.selectedIssueData.Type === "Submitted by Me"
							: false) ? (
							<Row>
								<Col className="col-lg-4 pull-left">
									<FormItem {...formItemLayout} label="Submitter Name">
										{
											<Input
												placeholder="Please enter submitter name"
												value={userStore.userDetails.UserName}
												style={issueStyles.inputStyle}
											/>
										}
									</FormItem>
								</Col>
							</Row>
						) : (
							<Row gutter={8}>
								<Row>
									<Col className="col-lg-4 pull-left">
										<FormItem {...formItemLayout} label="Submitted By">
											{getFieldDecorator("SubmittedBy")(
												<Input
													disabled={
														submitIssuesStore.selectedIssueData.Status ==
														"Closed"
													}
													placeholder="Please enter username"
													style={issueStyles.inputStyle}
												/>
											)}
										</FormItem>
									</Col>
								</Row>
								<Row>
									<Col className="col-lg-4 pull-left selectOptions">
										<FormItem {...formItemLayout} label="Severity">
											{getFieldDecorator("Severity")(
												<Select
													disabled={
														submitIssuesStore.selectedIssueData.Status ==
														"Closed"
													}
													clearable={false}
													getPopupContainer={trigger => trigger.parentElement}
													onChange={() => submitIssuesStore.setEditing(true)}
													options={this.state.SeverityList}
													style={issueStyles.inputStyle}
												/>
											)}
										</FormItem>
									</Col>
									<Col className="col-lg-4 pull-left selectOptions">
										<FormItem {...formItemLayout} label="Category">
											{getFieldDecorator("Category")(
												<Select
													disabled={
														submitIssuesStore.selectedIssueData.Status ==
														"Closed"
													}
													clearable={false}
													getPopupContainer={trigger => trigger.parentElement}
													onChange={() => submitIssuesStore.setEditing(true)}
													options={this.state.CategoryList}
													style={issueStyles.inputStyle}
												/>
											)}
										</FormItem>
									</Col>
								</Row>
								<Row>
									<Col className="col-lg-4 pull-left selectOptions">
										<FormItem {...formItemLayout} label="Status">
											{getFieldDecorator("Status")(
												<Select
													disabled={
														submitIssuesStore.selectedIssueData.Status ==
														"Closed"
													}
													clearable={false}
													getPopupContainer={trigger => trigger.parentElement}
													onChange={() => submitIssuesStore.setEditing(true)}
													id="tabStatus"
													options={this.state.StatusList}
													style={issueStyles.inputStyle}
												/>
											)}
										</FormItem>
									</Col>
								</Row>
							</Row>
						)}

						<Row>
							<Col className="col-lg-6 pull-left">
								<FormItem {...formItemLayout1} label="Issue Summary">
									{getFieldDecorator("IssueSummary", {
										rules: [
											{
												required: true,
												message: "Please provide Issue Summary"
											}
										]
									})(
										<TextArea
											style={issueStyles.textareaStyle}
											rows={3}
											type="text"
											placeholder={
												"Please provide Issue Summary (max 120 character)"
											}
											onChange={() => submitIssuesStore.setEditing(true)}
											disabled={
												submitIssuesStore.selectedIssueData.Status == "Closed"
											}
											onPressEnter={e => {
												e.preventDefault();
											}}
											maxLength={120}
										/>
									)}
								</FormItem>
							</Col>
							<Col className="col-lg-6 pull-left">
								<FormItem {...formItemLayout1} label="Description">
									{getFieldDecorator("Description")(
										<TextArea
											rows={3}
											style={issueStyles.textareaStyle}
											type="text"
											disabled={
												submitIssuesStore.selectedIssueData.Status == "Closed"
											}
											onChange={() => submitIssuesStore.setEditing(true)}
										/>
									)}
								</FormItem>
							</Col>
						</Row>
						<Row>
							<Col className="col-lg-6 pull-left">
								<FormItem {...formItemLayout1} label="Implication">
									{getFieldDecorator("Implication")(
										<TextArea
											rows={3}
											type="text"
											style={issueStyles.textareaStyle}
											disabled={
												submitIssuesStore.selectedIssueData.Status == "Closed"
											}
											onChange={() => submitIssuesStore.setEditing(true)}
										/>
									)}
								</FormItem>
							</Col>
							<Col className="col-lg-6 pull-left">
								<FormItem {...formItemLayout1} label="Upload Attachments">
									<div className="row">
										<Col>
											<Row style={{ display: "flex", position: "relative" }}>
												<Upload
													//eslint-disable-next-line
													customRequest={() => console.log("")}
													onChange={this.fileDataChange.bind(this)}
													multiple={true}
													fileList={this.state.fileList}
													onRemove={this.OnFileRemove.bind(this)}
													disabled={
														submitIssuesStore.selectedIssueData.Status ==
														"Closed"
													}
												>
													<Button className="pull-left chooseButton">
														Upload
													</Button>
												</Upload>
												<span
													style={{
														"letter-spacing": "0.5px",
														color: " #79838c",
														position: "absolute",
														left: 75,
														width: 250
													}}
												>
													Maximum upload file size : 10MB
												</span>
											</Row>
										</Col>
									</div>
								</FormItem>
							</Col>
						</Row>
						{!submitIssuesStore.isSubmitNewIssue && (
							<Row>
								<Col className="col-lg-12">
									<FormItem label="Attached Items">
										<Spin spinning={!this.state.Attachments}>
											<div
												className="ag-fresh openRequests"
												style={{
													height: "325px",
													color: "#666",
													backgroundColor: "#e5e5e5"
												}}
											>
												{
													<AgGridReact
														onCellClicked={this.onRemoveSelected.bind(this)}
														onGridReady={this.onGridReady.bind(this)}
														rowSelection="single"
														disabled={
															submitIssuesStore.selectedIssueData.Status ==
															"Closed"
														}
														rowData={this.state.rows}
														columnDefs={
															submitIssuesStore.selectedIssueData.Status ==
															"Closed"
																? this.state.columnsClosedIssues
																: this.state.columnsOpenIssues
														}
														enableSorting={true}
														enableColResize={true}
														rowHeight="35"
														headerHeight="35"
														defaultColDef={this.state.defaultColDef}
													/>
												}
											</div>
										</Spin>
									</FormItem>
								</Col>
							</Row>
						)}
						<Row>
							<Col className="issueLogButton">
								<FormItem>
									<Button
										className="cancelButton"
										onClick={this.props.handleCancel.bind(this)}
									>
										{submitIssuesStore.selectedIssueData.Status != "Closed"
											? "Cancel"
											: "Close"}
									</Button>
									{(submitIssuesStore.selectedIssueData
										? submitIssuesStore.selectedIssueData.Status != "Closed"
										: true) && (
										<Button
											loading={submitIssuesStore.submitting}
											className="submitButton"
											onClick={this.handleSubmitValidation.bind(this)}
										>
											{" "}
											{submitIssuesStore.isSubmitNewIssue
												? "Submit an Issue"
												: "Update Issue"}
										</Button>
									)}
								</FormItem>
							</Col>
						</Row>
					</Card>
				</Form>
			</div>
		);
	}
}

const Issues = Form.create()(IssuesPage);
export default Issues;
