import React, { Component } from "react";
import { DatePicker } from "antd";
import moment from "moment";
import loanPoolStore from "../../stores/loanPoolStore";
const RangePicker = DatePicker.RangePicker;
import dateArray from "moment-array-dates";
import { Card } from "antd";
import { AgGridReact } from "ag-grid-react";
import _ from "lodash";
// Custom Formatter component

class CheckAvailabilty extends Component {
    parseMonth(data) {
        var months = [];
        months = _.groupBy(data, function(b) {
            return b.month;
        });
        var array = [];
        for (var i = 0; i < Object.keys(months).length; i++) {
            var child = {};
            child.headerName = moment(Object.keys(months)[i], "MM").format("MMMM");
            child.children = Object.values(months)[i];
            array.push(child);
        }
        return array;
    }

    generateDateColumns() {
        var columns = [];
        var dates = dateArray.range(
            moment(
                loanPoolStore.startDateCheckAvailability
                    ? loanPoolStore.startDateCheckAvailability
                    : moment()
                        .startOf("day")
                        .toISOString()
            ),
            moment(
                loanPoolStore.endDateCheckAvailability
                    ? loanPoolStore.endDateCheckAvailability
                    : moment()
                        .add(1, "months")
                        .endOf("day")
                        .toISOString()
            ),
            "MM-DD-YYYY",
            true
        );
        for (var dateItem of dates) {
            var item = {};
            var res = dateItem.split("-");
            item.year = res[2];
            item.date = res[1];
            item.month = res[0];
            item.field = dateItem;
            item.headerName = res[1];
            item.width = 50;
            item.minWidth = 50;
            item.maxWidth = 50;
            item.cellStyle = params => {
                return {
                    backgroundColor: params.value,
                    color: params.value
                };
            };
            columns.push(item);
            var years = [];
            years = _.groupBy(columns, function(b) {
                return b.year;
            });
            var array = [];
            array.push({
                field: "EquipmentNo",
                headerName: "Equipment Number",
                width: 200,
                minWidth: 200,
                maxWidth: 200
            });
            array.push({
                headerName: "",
                width: 50,
                minWidth: 50,
                maxWidth: 50,
                headerCheckboxSelection: true,
                checkboxSelection: true,
                menuTabs: []
            });
            for (var i = 0; i < Object.keys(years).length; i++) {
                var child = {};
                child.headerName = Object.keys(years)[i];
                child.width = 30;
                child.minWidth = 30;
                child.children = this.parseMonth(Object.values(years)[i]);
                array.push(child);
            }
        }
        return array;
    }

    setGridItemsSelection() {
        this.gridApi.removeEventListener("selectionChanged", this.onRowSelected);
        this.gridApi.forEachNode(function(node) {
            if (
                loanPoolStore.selectedAssetsFull.find(
                    item => item.EquipmentNo === node.data.EquipmentNo
                )
            ) {
                node.setSelected(true);
            }
        });
        this.gridApi.addEventListener("selectionChanged", this.onRowSelected);
    }

  onGridReady = params => {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;

      params.api.sizeColumnsToFit();
      params.api.sizeColumnsToFit();
      var allColumnIds = [];
      this.gridColumnApi.getAllColumns().forEach(function(column) {
          allColumnIds.push(column.colId);
      });
      this.gridColumnApi.autoSizeColumns(allColumnIds);
      this.setGridItemsSelection();
  };
  onRowSelected(event) {
      {
      /* commented
        */
      }
      let rows = event.api.getSelectedRows();
      let resultant = [];
      for (var row of rows) {
          let result = loanPoolStore.loanableAssetsForCustomerLoanpoolGrid.filter(
              item => {
                  return item.EquipmentNo.match(row.EquipmentNo);
              }
          );
          resultant.push(result[0]);
      }
      loanPoolStore.dashboardAddCheckFull(resultant);
  }
  handleRangeChange(date) {
      loanPoolStore.setRangeCheckAvailability(date).then(e => {
          e && this.gridApi.setRowData(e); //update grid if data is not null
          this.setGridItemsSelection();
      });
  }
  disabledDate(current) {
      return current <= moment().startOf("day");
  }

  componentDidUpdate() {
      if (loanPoolStore.loanableAssetsForCustomer && this.gridApi) {
          this.gridApi.setRowData(loanPoolStore.loanableAssetsForCustomer); //update grid if data is not null
          this.setGridItemsSelection();
      }
  }
  componentDidMount = () => {
      loanPoolStore.generateDateColumns();
  };

  render() {
      let gridStyles = {
          clearBoth: {
              clear: "both"
          },
          windowHeight: {
              height: window.innerHeight - 486,
              color: "#666"
          }
      };
      return (
          <div className="lpAvailability">
              <div>
                  <div className="availabilityTable">
                      <Card bodyStyle={gridStyles.windowHeight} className="ag-fresh">
                          {loanPoolStore.loanableAssetsForCustomerLoanpoolGrid.map(
                              a => a
                          ) ? (
                                  <AgGridReact
                                      id="ootGrid"
                                      rowSelection="multiple"
                                      suppressRowClickSelection
                                      gridOptions={loanPoolStore.gridOptions}
                                      columnDefs={this.generateDateColumns()}
                                      suppressCellSelection={true}
                                      onGridReady={this.onGridReady.bind(this)}
                                      enableColResize={true}
                                      enableCellChangeFlash={true}
                                      rowHeight="35"
                                      headerHeight="35"
                                      suppressScrollOnNewData={true}
                                  />
                              ) : (
                                  ""
                              )}
                      </Card>
                      <div className="datePickerRow">
                          <div className="pull-right">
                              <RangePicker
                                  ranges={{
                                      Today: [moment(), moment()],
                                      "This Month": [moment(), moment().endOf("month")]
                                  }}
                                  style={{ width: 300, marginRight: 20 }}
                                  defaultValue={[
                                      moment(loanPoolStore.startDateCheckAvailability),
                                      moment(loanPoolStore.endDateCheckAvailability)
                                  ]}
                                  onChange={this.handleRangeChange.bind(this)}
                              />
                          </div>
                          <div className="pull-right loanPollRequestedYellow">
                              <span /> Requested
                          </div>
                          <div className="pull-right loanPollNotAvailable">
                              <span /> Loaned/Not Available
                          </div>
                          <div className="pull-right loanPollRequested">
                              <span /> Service
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      );
  }
}

export default CheckAvailabilty;
