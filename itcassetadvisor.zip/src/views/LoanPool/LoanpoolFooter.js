import React, { Component } from "react";
import loanPoolStore from "../../stores/loanPoolStore";

class LoanpoolFooter extends Component {
  handlePageSize(e) {
    var currentLimit = e.target.value;
    loanPoolStore.handlePageSize(currentLimit);
  }
  handleRefresh() {
    loanPoolStore.setDataLoaded(false);
    loanPoolStore.reRenderLoanPool();
  }
  handleNextPage() {
    loanPoolStore.handleNextpage();
  }
  handleLastPage() {
    loanPoolStore.handleLastPage();
  }

  handleFirstPage() {
    loanPoolStore.handleFirstPage();
  }
  handlePrevPage() {
    loanPoolStore.handlePrevPage();
  }
  handleDensityDefault() {
    var elem = document.getElementsByClassName("react-grid-Main");
    elem[0].style.fontSize = "1em";
  }
  handleDensityMedium() {
    var elem = document.getElementsByClassName("react-grid-Main");
    elem[0].style.fontSize = "1.15em";
  }
  handleDensityLarge() {
    var elem = document.getElementsByClassName("react-grid-Main");
    elem[0].style.fontSize = "1.25em";
  }
  render() {
    var totalItems = loanPoolStore.loanableAssetsForCustomerLoanpoolGridTotal;
    var currentPage = loanPoolStore.currentPage;
    var currentLimit = loanPoolStore.currentLimit;

    var totalPages = parseInt(totalItems / currentLimit);
    var remainder = totalItems % currentLimit;
    if (remainder > 0) {
      totalPages = totalPages + 1;
    }
    return (
      <div>
        <nav className="navbar navbar-dark bg-dark">
          <div className="col-sm-3 paginationButtons">
            <ul>
              <li
                className="pageControls"
                onClick={
                  currentPage != 1 ? this.handleFirstPage.bind(this) : ""
                }
              >
                <a href="#">
                  <i className="fa fa-angle-double-left colorChange" />
                </a>
              </li>
              <li
                className="pageControls"
                onClick={currentPage != 1 ? this.handlePrevPage.bind(this) : ""}
              >
                <a href="#">
                  <i className="fa fa-angle-left colorChange" />
                </a>
              </li>
              <li>
                <span className="page colorChange">Page</span>
              </li>
              <li>
                <input
                  className="pageNumberInput colorChange"
                  type="text"
                  name=""
                  value={loanPoolStore.currentPage}
                />
              </li>
              <li>
                <span className="of38 colorChange">of {totalPages}</span>
              </li>
              <li
                className="pageControls"
                onClick={
                  currentPage != totalPages
                    ? this.handleNextPage.bind(this)
                    : ""
                }
              >
                <a href="#">
                  <i className="fa fa-angle-right colorChange" />
                </a>
              </li>
              <li
                className="pageControls"
                onClick={
                  currentPage != totalPages
                    ? this.handleLastPage.bind(this)
                    : ""
                }
              >
                <a href="#">
                  <i className="fa fa-angle-double-right colorChange" />
                </a>
              </li>
              <li
                className="pageControls"
                onClick={this.handleRefresh.bind(this)}
              >
                <a href="#">
                  <i className="icon-refresh " />
                </a>
              </li>
            </ul>
          </div>

          <div className="col-sm-1 pageSize">
            <select
              id="tabSelect"
              className="dashfooterSelect"
              onChange={this.handlePageSize.bind(this)}
            >
              <option key={25}>25</option>
              <option key={50}>50</option>
              <option key={75}>75</option>
              <option key={100}>100</option>
              <option key={150}>150</option>
              <option key={200}>200</option>
              <option key={250}>250</option>
            </select>
          </div>

          {/* <div className="col-sm-2 displayDensity">
						<ul>
							<li className="densityButtons"><span className="displayDensityLabel">Display Density</span></li>
							<li className="densityButtons" onClick={this.handleDensityDefault.bind(this)}><a href="#"><i className="fa fa-th"></i></a></li>
							<li className="densityButtons" onClick={this.handleDensityMedium.bind(this)}><a href="#"><i className="fa fa-th"></i></a></li>
							<li className="densityButtons" onClick={this.handleDensityLarge.bind(this)}><a href="#"><i className="fa fa-th"></i></a></li>
						</ul>
					</div> */}

          {/* <div className="col-sm-1 exportOptions">
						<div className="btn-group dropup">
							<i className="icon-share-alt dropdown-toggle" data-toggle="dropdown" id="exportButton" aria-expanded="false"></i>
							<div className="dropdown-menu">
								<a className="dropdown-item" href="#"><span>Download</span><i className="icon-cloud-download"></i></a>
								<a className="dropdown-item" href="#"><span>Print</span><i className="icon-printer"></i></a>
							</div>
						</div>
					</div> */}

          {/* <div className="col-sm-1 resetSorters">
						<button type="button" id="resetSorters" className="btn btn-primary btn-sm">Reset Sorters</button>
					</div> */}
        </nav>
      </div>
    );
  }
}

export default LoanpoolFooter;
