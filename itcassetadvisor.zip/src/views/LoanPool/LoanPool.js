import React, { Component } from "react";
import { observer } from "mobx-react";
import { createBrowserHistory } from "history";
import { Icon, Row, Col, Button } from "antd";
import moment from "moment";
import NewRequest from "./NewRequest";
import Functions from "../../api/Functions";
import loanPoolStore from "../../stores/loanPoolStore";
import userStore from "../../stores/userStore";
const history = createBrowserHistory();
import "./style.css";
import CheckAvailability from "./CheckAvailability";
import SelectedAssets from "./SelectedAssets";
import AssetsGrid from "./AssetsGrid";
import tabModelStore from "../../stores/tabModelStore";
import dateArray from "moment-array-dates";
import LoadingImage from "../../containers/Full/loading.gif";
import AddExternalRequest from "./AddExternalRequest";
import LoanPoolFilter from "./LoanPoolFilter";
import Autosuggest from "react-autosuggest";
import ReactTooltip from "react-tooltip";
import _ from "lodash";
import PropTypes from "prop-types";

const LoadingView = <img src={LoadingImage} className="loanPoolLoader" />;

const getSuggestionValue = suggestion =>
  suggestion.colName != undefined ? suggestion.searchStr : "";
const renderSuggestion = suggestion => (
  <div
    style={{
      color: "white",
      zIndex: 10000000,
      backgroundColor: "grey",
      marginBottom: 1,
      borderBottomColor: "black",
      cursor: suggestion.colName != undefined ? "pointer" : "cursor"
    }}
  >
    {suggestion.searchStr}
  </div>
);
@observer
class LoanPool extends Component {
  constructor(props) {
    super(props);
    this.createRows();
    this._columns = [{ key: "AssetNo", name: "Equipment Number" }];

    this.state = {
      addNewItemShow: true,
      addRequest: false,
      tabActive: "selectAsset",
      currentStep: "step1",
      AvalibalityColumns: [],
      columns: [{ key: "EquipmentNo", name: "Equipment Number" }],
      columnLength: 0,
      suggestions: [],
      searchText: "",
      value: ""
    };

    this.handle2PageCancel = this.handle2PageCancel.bind(this);
    this.search = _.debounce(this.search.bind(this), 1000);
  }
  componentDidMount() {
    loanPoolStore.initializeData();
    this.generateOneMonthColumns();
    this.setState({ currentStep: "step1" });
    loanPoolStore.setCurrentStep("step1");
    if (userStore.userDetails && userStore.me) return;
    loanPoolStore.getUserDetails();
  }
  componentDidUpdate() {
    if (loanPoolStore.currentStep === "finished") history.go(-1);
  }

  onChange = (event, { newValue }) => {
    this.setState({
      value: newValue
    });
  };

  onSuggestionSelected = (event, { suggestion }) => {
    if (suggestion.colName == undefined) return;
    var FilterData = {};
    FilterData.TabId = 0;
    FilterData.baseQuery = {
      condition: "AND",
      rules: [
        {
          field: suggestion.colName,
          id: suggestion.colName,
          input: "text",
          operator: "equal",
          type: "string",
          value: suggestion.searchValue
        }
      ],
      valid: true
    };
    FilterData.filterQuery = {};
    Functions.SetFilters(FilterData).then(() => {
      loanPoolStore.initializeData();
      loanPoolStore.setLoanPoolFilter(FilterData.baseQuery);
    });
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  search(value) {
    if (value.value.length >= 2) {
      Functions.GetSolrSearchResult(value.value, "LoanPool").then(resp => {
        var srcStr = value.value;
        var response = resp.data.response;
        var data = [];
        if (response && response.numFound > 0) {
          var docs = response.docs;
          var len = docs.length;
          var exist;
          var test = {};
          var displayNames = JSON.parse(
            JSON.stringify(loanPoolStore.gridDataModel)
          );

          for (var j = 0; j < displayNames.length; j++) {
            test[displayNames[j].key] = displayNames[j].name;
          }

          for (var i = 0; i < len; i++) {
            for (var key in docs[i]) {
              if (typeof docs[i][key] != "string") {
                docs[i][key] = "" + docs[i][key];
              }
              if (
                typeof docs[i][key] === "string" &&
                docs[i][key].toLowerCase().indexOf(srcStr.toLowerCase()) >= 0
              ) {
                exist = false;

                for (var index = 0; index < data.length; index++) {
                  var item = data[index];

                  if (
                    item.colName === key &&
                    item.searchValue === docs[i][key]
                  ) {
                    exist = true;
                    exist = true;
                  }
                }

                if (!exist) {
                  data.push({
                    colName: key,
                    searchValue: docs[i][key],
                    searchStr: docs[i][key] + " in " + test[key]
                  });
                }
              }
            }
          }
        } else {
          if (data.length == 0) {
            data.push({
              colName: undefined,
              searchValue: undefined,
              searchStr: "No results found "
            });
          }
        }
        this.setState({ suggestions: data });
      });
    }
  }

  generateOneMonthColumns = () => {
    var columns = [];
    columns.push({ key: "EquipmentNo", name: "Equipment Number" });
    var dates = dateArray.range(
      moment(
        loanPoolStore.startDateCheckAvailability
          ? loanPoolStore.startDateCheckAvailability
          : moment()
              .startOf("day")
              .toISOString()
      ),
      moment(
        loanPoolStore.endDateCheckAvailability
          ? loanPoolStore.endDateCheckAvailability
          : moment()
              .add(1, "months")
              .endOf("day")
              .toISOString()
      ),
      "MM-DD-YYYY",
      true
    );

    for (var dateItem of dates) {
      var item = {};
      item.key = dateItem;
      item.name = dateItem;
      item.width = 200;
      columns.push(item);
    }
    this.setState({
      columns: columns,
      columnLength: columns.length
    });
  };

  static defaultProps = { rowKey: "id" };

  createRows = () => {
    let rows = [];
    for (let i = 1; i < 100; i++) {
      rows.push({
        id: i,
        title: "company " + i,
        manufacturer: "manufacturer " + i,
        serial: i,
        count: i * 100
      });
    }

    this._rows = rows;
  };

  rowGetter = i => {
    var rtn = loanPoolStore.loanableAssetsForCustomerLoanpoolGrid;
    return rtn[i];
  };
  availabilityRowGetter = i => {
    var rtn = loanPoolStore.loanableAssetsForCustomer;
    rtn = JSON.parse(JSON.stringify(rtn[i]));
    return rtn;
  };
  handleClose(e) {
    e.preventDefault();
    this.setState({ currentStep: "step1" });
    loanPoolStore.setCurrentStep("step1");
    history.go(-1);
  }

  handleAddReq() {
    if (this.state.addRequest) {
      this.setState({ addRequest: false });
    } else {
      this.setState({ addRequest: true });
    }
  }

  handleLPbutton(e) {
    this.setState({ tabActive: e.target.id });
  }

  addNewRequest() {
    if (loanPoolStore.selectedAssetsFull.length) {
      this.setState({ currentStep: "step2" });
      loanPoolStore.setCurrentStep("step2");
    }
  }
  addExternalRequest = () => {
    loanPoolStore.setCurrentStep("step3");
    this.setState({ currentStep: "step3" });
  };

  handle2PageCancel() {
    this.setState({ currentStep: "step1" });
    loanPoolStore.setCurrentStep("step1");
  }

  filterClick() {
    if (loanPoolStore.loanPoolfilterModalOpen) {
      loanPoolStore.setLoanPoolFilterModalopen(false);
    } else {
      loanPoolStore.setLoanPoolFilterModalopen(true);
    }
  }
  concatFilterTags(result, i) {
    var filter = result.rules[i],
      retStr = "";
    if (this.operatorLib.hasOwnProperty(filter.operator)) {
      var operatorObj = this.operatorLib[filter.operator];

      if (operatorObj.category == "comparison") {
        retStr =
          filter.field +
          " " +
          operatorObj.symbol +
          " " +
          (filter.value != undefined || filter.value != null
            ? filter.value != "1970/01/01"
              ? JSON.stringify(filter.value + "")
              : ""
            : "");
      } else if (operatorObj.category == "list") {
        var str = JSON.stringify(filter.value);
        retStr = filter.field + " " + operatorObj.symbol + " " + str;
      } else if (operatorObj.category == "range") {
        retStr =
          filter.field +
          " " +
          operatorObj.symbol +
          " ( " +
          filter.value[0] +
          " AND " +
          filter.value[1] +
          " ) ";
      }
    }
    return retStr;
  }
  handleFilterClick() {
    if (tabModelStore.filterModalOpen) {
      tabModelStore.setFilterModalopen(false);
    } else {
      tabModelStore.setFilterModalopen(true);
    }
  }

  handleEmptyRulesClick() {
    loanPoolStore.clearLoanPoolFilter();
    this.setState({ value: "", suggestion: [] });
  }
  formatfilterDate(baseQuery = JSON.parse(JSON.stringify(baseQuery))) {
    var noOfRules = baseQuery.rules ? baseQuery.rules.length : 0;
    if (noOfRules == 1) {
      if (baseQuery.rules[0].type == "date") {
        if (
          baseQuery.rules[0].operator == "between" ||
          baseQuery.rules[0].operator == "not_between"
        ) {
          baseQuery.rules[0].value[0] = moment(
            baseQuery.rules[0].value[0]
          ).format("YYYY/MM/DD");
          baseQuery.rules[0].value[1] = moment(
            baseQuery.rules[0].value[1]
          ).format("YYYY/MM/DD");
        } else {
          baseQuery.rules[0].value = moment(baseQuery.rules[0].value).format(
            "YYYY/MM/DD"
          );
        }
      }
    } else {
      for (var i = 0; i < noOfRules; i++) {
        if (baseQuery.rules[i].rules == undefined) {
          if (baseQuery.rules[i].type == "date") {
            if (
              baseQuery.rules[i].operator == "between" ||
              baseQuery.rules[i].operator == "not_between"
            ) {
              baseQuery.rules[i].value[0] = moment(
                baseQuery.rules[i].value[0]
              ).format("MM/DD/YYY");
              baseQuery.rules[i].value[1] = moment(
                baseQuery.rules[i].value[1]
              ).format("MM/DD/YYY");
            } else {
              baseQuery.rules[i].value = moment(
                baseQuery.rules[i].value
              ).format("MM/DD/YYY");
            }
          }
        } else {
          baseQuery.rules[i] = this.formatfilterDate(baseQuery.rules[i]);
        }
      }
    }
    return baseQuery;
  }
  formatFilterTags(resultt) {
    var result = this.formatfilterDate(resultt);
    var filterTagObj = new Object();
    if (typeof result === "string") result = JSON.parse(result);
    var filterTag = "";
    if (Object.keys(result).length !== 0) {
      for (var i = 0; i < result.rules.length; i++) {
        if (result.rules[i].hasOwnProperty("condition")) {
          for (var ii = 0; ii < result.rules[i].rules.length; ii++) {
            if (result.rules[i].rules[ii].hasOwnProperty("condition")) {
              for (
                var iii = 0;
                iii < result.rules[i].rules[ii].rules.length;
                iii++
              ) {
                if (
                  result.rules[i].rules[ii].rules[iii].hasOwnProperty(
                    "condition"
                  )
                ) {
                  for (
                    var iiii = 0;
                    iiii < result.rules[i].rules[ii].rules[iii].rules.length;
                    iiii++
                  ) {
                    filterTag =
                      filterTag.replace("))", "") +
                      " ( " +
                      this.concatFilterTags(
                        result.rules[i].rules[ii].rules[iii],
                        iiii
                      ) +
                      ") ) )";
                  }
                } else {
                  filterTag =
                    filterTag.replace(")", "") +
                    " ( " +
                    this.concatFilterTags(result.rules[i].rules[ii], iii) +
                    " ) ) " +
                    (iii == result.rules[i].rules[ii].rules.length - 1
                      ? ""
                      : result.rules[i].rules[ii].condition);
                }
              }
            } else {
              filterTag =
                filterTag +
                " ( " +
                this.concatFilterTags(result.rules[i], ii) +
                " ) " +
                (ii == result.rules[i].rules.length - 1
                  ? ""
                  : result.rules[i].condition);
            }
          }
        } else {
          filterTag =
            filterTag +
            " " +
            this.concatFilterTags(result, i) +
            " " +
            (i == result.rules.length - 1 ? "" : result.condition);
        }
      }
    }
    var filterLength = this.state.width / 10 - 70;
    //console.log(filterLength);
    filterTagObj.filterTagAlt = filterTag;
    filterTagObj.filterTag =
      filterTag.length > filterLength
        ? filterTag.substring(0, filterLength) + " ..."
        : filterTag;

    return filterTagObj;
  }
  operatorLib = {
    equal: { type: "EQ", value: "value", category: "comparison", symbol: "=" },
    not_equal: {
      type: "NE",
      value: "value",
      category: "comparison",
      symbol: "!="
    },
    in: { type: "IN", value: "value", category: "list", symbol: "in" },
    less: { type: "LT", value: "value", category: "comparison", symbol: "<" },
    less_or_equal: {
      type: "LE",
      value: "value",
      category: "comparison",
      symbol: "<="
    },
    greater: {
      type: "GT",
      value: "value",
      category: "comparison",
      symbol: ">"
    },
    greater_or_equal: {
      type: "GE",
      value: "value",
      category: "comparison",
      symbol: ">="
    },
    between: {
      type: "Between",
      value: "value",
      category: "range",
      symbol: "Between"
    },
    not_between: {
      type: "NotBetween",
      value: "value",
      category: "range",
      symbol: "Not Between"
    },
    begins_with: {
      type: "LIKE",
      value: "value*",
      category: "comparison",
      symbol: "Begins with"
    },
    not_begins_with: {
      type: "NOTLIKE",
      value: "value*",
      category: "comparison",
      symbol: "Not Begins with"
    },
    contains: {
      type: "LIKE",
      value: "*value*",
      category: "comparison",
      symbol: "Contains"
    },
    not_contains: {
      type: "NOTLIKE",
      value: "*value*",
      category: "comparison",
      symbol: "Not Contains"
    },
    ends_with: {
      type: "LIKE",
      value: "*value",
      category: "comparison",
      symbol: "Ends with"
    },
    not_ends_with: {
      type: "NOTLIKE",
      value: "*value",
      category: "comparison",
      symbol: "Not Ends With"
    },
    is_empty: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsEmpty"
    },
    is_not_empty: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNotEmpty"
    },
    is_null: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNull"
    },
    is_not_null: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNotNull"
    }
  };
  render() {
    var notActive = {
      // Loan Pool Tabs (non-active)
      color: "#67839b",
      fontWeight: 600,
      padding: "6px 14px 6px 14px",
      textTransform: "uppercase",
      border: "none"
    };
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: "Search For Asset...",
      value,
      onChange: this.onChange
    };
    var styleActive = {
      // Loan Pool Tabs (active)
      color: "#ffffff",
      backgroundColor: "#67839b",
      fontWeight: 600,
      padding: "6px 14px 6px 14px",
      textTransform: "uppercase",
      border: "none"
    };
    var loanStyles = {
      clearBoth: {
        clear: "both"
      },
      colLeft: {
        height: window.innerHeight - 330,
        color: "#666"
      },
      windowHeight: {
        height: 170,
        color: "#666"
      }
    };
    loanPoolStore.setEnableEquipmentRequest(
      loanPoolStore.loanPoolFilter &&
      this.formatFilterTags(loanPoolStore.loanPoolFilter).filterTag.length > 0
        ? true
        : false
    );
    const equipmentClass =
      loanPoolStore.enableEquipmentRequest == true
        ? "loanPoolStyleActive"
        : "loanPoolNotActive";
    const availabilityClass = loanPoolStore.selectedAssetsFull.length
      ? "loanPoolAvailabilityActive"
      : "loanPoolAvailabilityNotActive";
    const nextActiveClass = loanPoolStore.selectedAssetsFull.length
      ? "active"
      : "";
    return (
      <div>
        <div id="wizard" className="loanPoolWrapper">
          <div className="loanPoolHeader">
            <div className="pull-left">
              <div
                className="wizardTitle"
                style={{
                  color: "rgb(255,255,255)",
                  textTransform: "uppercase"
                }}
              >
                Loan Pool
              </div>
            </div>
            <div className="pull-right fr">
              <Icon
                type="close-circle-o"
                style={{
                  color: "rgb(255,255,255)",
                  fontWeight: "100",
                  fontSize: "21px",
                  lineHeight: "normal",
                  cursor: "pointer"
                }}
                onClick={this.handleClose.bind(this)}
              />
            </div>
            <div style={loanStyles.clearBoth} />
          </div>

          {loanPoolStore.currentStep == "step2" ? (
            ""
          ) : (
            <div
              style={{
                /*backgroundColor: bgColors.Default*/
              }}
            >
              <section className="lp-section-box loanPoolHeaderTab">
                <Button
                  className={"pull-right " + availabilityClass}
                  size="large"
                  id="checkAvail"
                  onClick={this.handleLPbutton.bind(this)}
                  style={
                    this.state.tabActive == "checkAvail"
                      ? styleActive
                      : notActive
                  }
                >
                  Check availability
                </Button>
                <Button
                  className="pull-right"
                  size="large"
                  id="selectAsset"
                  onClick={this.handleLPbutton.bind(this)}
                  style={
                    this.state.tabActive == "selectAsset"
                      ? styleActive
                      : notActive
                  }
                >
                  Select asset
                </Button>
                <div className="clear" />
              </section>
              {/* <section style={sectionMargin} className="lp-section-box loanPoolHeaderTab" >   */}
              {/* <section className="lp-section-box loanPoolHeaderTab" >
                  <Row gutter={16}>
                    <Col span={2} offset={19}>
                      <Button size='large' id='selectAsset' onClick={this.handleLPbutton.bind(this)} style={this.state.tabActive == 'selectAsset' ? styleActive : notActive}>Select asset</Button>
                    </Col>
                    <Col span={2}>
                      <Button size='large' id='checkAvail' className={availabilityClass} onClick={this.handleLPbutton.bind(this)} style={this.state.tabActive == 'checkAvail' ? styleActive : notActive}>Check availability</Button>
                    </Col>
                    <Col span={1}></Col>
                  </Row>
                </section> */}

              <section className="lp-section-box">
                <Row>
                  <Col className="col-sm-2 pull-left">
                    <div className="row lp-search-wrapper">
                      <Col span={3}>
                        <span style={{ cursor: "pointer" }}>
                          <Icon type="search" />
                        </span>
                      </Col>
                      <Col span={21}>
                        <Autosuggest
                          suggestions={suggestions}
                          onSuggestionsFetchRequested={this.search.bind(this)}
                          onSuggestionsClearRequested={
                            this.onSuggestionsClearRequested
                          }
                          getSuggestionValue={getSuggestionValue}
                          renderSuggestion={renderSuggestion}
                          inputProps={inputProps}
                          onSuggestionSelected={this.onSuggestionSelected}
                        />
                      </Col>
                    </div>
                  </Col>
                  <Col className="col-sm-10 pull-left">
                    <div className="lp-equipment-wrapper pull-left">
                      {/* <Button type="primary" size="large" style={loanPoolStore.enableEquipmentRequest == true ? styleActive : notActive} onClick={this.addExternalRequest.bind(this)}>Equipment Request</Button> */}
                      <Button
                        type="primary"
                        size="large"
                        className={equipmentClass}
                        title="Please search or Filter some asset before raising an Equipment Request"
                        disabled={!loanPoolStore.enableEquipmentRequest}
                        onClick={this.addExternalRequest.bind(this)}
                      >
                        Equipment Request
                      </Button>
                    </div>
                    <div className="lp-filter-wrapper pull-left">
                      {/*<Col className='pull-left filterButton'>
                        <span onClick={this.filterClick.bind(this)} style={{ cursor: 'pointer' }}>
                          <Icon type="filter" data-toggle="modal" data-target=".filtersModal" />
                        </span>
                      </Col>*/}
                      <Col className="pull-left loanPoolFilter">
                        <div className="col-sm-7 filters">
                          <ul className="filters">
                            <a onClick={this.filterClick.bind(this)}>
                              <li className="filterTags ">
                                <i
                                  className="fa fa-filter fa-ant-filter tooltipcss"
                                  data-toggle="modal"
                                  data-target=".filtersModal"
                                >
                                  <span className="headertooltiptext">
                                    Filter
                                  </span>
                                </i>
                              </li>
                            </a>
                            {loanPoolStore.loanPoolFilter &&
                            this.formatFilterTags(loanPoolStore.loanPoolFilter)
                              .filterTag.length > 0 ? (
                              <a href="#">
                                <li className="filterTags">
                                  <span
                                    className="badge badge-pill badge-primary"
                                    data-tip={
                                      this.formatFilterTags(
                                        loanPoolStore.loanPoolFilter
                                      ).filterTagAlt
                                    }
                                    onClick={this.filterClick.bind(this)}
                                  >
                                    {
                                      this.formatFilterTags(
                                        loanPoolStore.loanPoolFilter
                                      ).filterTag
                                    }
                                  </span>
                                  <a href="#">
                                    <i
                                      className="icon-close"
                                      style={{ marginTop: 5 }}
                                      onClick={this.handleEmptyRulesClick.bind(
                                        this
                                      )}
                                    />
                                  </a>
                                </li>
                                <ReactTooltip />
                              </a>
                            ) : (
                              ""
                            )}
                          </ul>
                        </div>
                      </Col>
                    </div>
                  </Col>
                </Row>
              </section>
            </div>
          )}
          <div>
            {/* //here starts initial check */}
            {/* {loanPoolStore.initialized ? */}
            <div>
              {/****** STEP 1 Content ******/}
              <div>
                {loanPoolStore.currentStep == "step1" ||
                loanPoolStore.currentStep == "step3" ? (
                  <div
                    style={{
                      /*backgroundColor: bgColors.Default*/
                    }}
                  >
                    <section className="lp-section-box lpSelectAssets">
                      <Row>
                        <Col span={24}>
                          {this.state.tabActive == "selectAsset" ? ( //if Active tab is selectAsset
                            <AssetsGrid rowGetter={this.rowGetter} />
                          ) : (
                            ""
                          )}
                          {this.state.tabActive == "checkAvail" ? (
                            <CheckAvailability
                              columns={this.state.columns}
                              rowGetter={this.availabilityRowGetter}
                            />
                          ) : (
                            ""
                          )}
                          {!loanPoolStore.dataLoaded ? LoadingView : ""}
                        </Col>
                      </Row>
                    </section>

                    {/* {this.state.tabActive == 'selectAsset' ?  */}
                    <section className="lp-section-box loanPoolSelectedAssets lpSelectAssets">
                      <Row>
                        <Col span={2}>
                          {/* {loanPoolStore.selectedAssetsFull.length? */}
                          <div
                            className="lpBackButton"
                            style={{
                              color: "#afb5c3",
                              textAlign: "left",
                              cursor: "pointer"
                            }}
                            onClick={this.handleClose.bind(this)}
                          >
                            <Icon
                              type="left"
                              style={{ fontWeight: 100 }}
                            />{" "}
                            Back
                          </div>
                        </Col>
                        <Col span={20}>
                          <div className="selectedAssetsTitle">
                            {" "}
                            Selected Assets{" "}
                          </div>

                          <div className="lp-sel-grid-wrapper">
                            <div
                              className="loanPoolselectedAssetsOpenRowGrid ag-fresh"
                              style={loanStyles.windowHeight}
                            >
                              <SelectedAssets isDeleteActionHide={true} />
                            </div>
                          </div>
                        </Col>
                        <Col span={2}>
                          {/* {loanPoolStore.selectedAssetsFull.length? */}
                          <div
                            className={"lpNextButton " + nextActiveClass}
                            style={{
                              color: "#afb5c3",
                              textAlign: "right",
                              cursor: "pointer"
                            }}
                            onClick={this.addNewRequest.bind(this)}
                          >
                            Next{" "}
                            <Icon type="right" style={{ fontWeight: 100 }} />
                          </div>
                        </Col>
                      </Row>
                    </section>
                  </div>
                ) : (
                  ""
                )}
                {loanPoolStore.currentStep == "step2" ? (
                  <NewRequest handle2PageCancel={this.handle2PageCancel} />
                ) : (
                  ""
                )}
              </div>
              {loanPoolStore.currentStep == "step3" ? (
                <AddExternalRequest onCancel={this.handle2PageCancel} />
              ) : (
                ""
              )}
            </div>
            {/* : LoadingView */}
            {/* } */}
            {/* //ends initalized check */}
          </div>
        </div>
        {loanPoolStore.loanPoolfilterModalOpen ? <LoanPoolFilter /> : ""}
      </div>
    );
  }
}

export default LoanPool;

LoanPool.contextTypes = {
  router: PropTypes.func.isRequired
};
