import React, { Component } from "react";
import moment from "moment";
import PropTypes from "prop-types";
import { AgGridReact } from "ag-grid-react";
import loanPoolStore from "../../stores/loanPoolStore";

class SelectedAssets extends Component {
  constructor(props) {
    super(props);
    this.state = {
      columnDefs: [
        {
          field: "",
          headerName: "",
          cellRenderer: this.actionCellRenderer,
          width: 50,
          cellStyle: { "text-align": "center" },
          hide: this.props.isDeleteActionHide
        },

        { field: "EquipmentNo", headerName: "Equipment Number", width: 220 },
        { field: "Manufacturer", headerName: "Manufacturer", width: 220 },
        {
          field: "AltManufacturerName",
          headerName: "Alternative Manufacturer Name",
          width: 330
        },
        { field: "ModelNo", headerName: "Model Number", width: 200 },
        { field: "SerialNo", headerName: "Serial Number", width: 200 },
        { field: "Description", headerName: "Description", width: 278 },
        { field: "Accessories", headerName: "Accessories", width: 200 },
        { field: "Options", headerName: "Options", width: 200 },
        { field: "SystemParent", headerName: "System parent", width: 200 },
        { field: "SystemName", headerName: "System name", width: 200 },
        { field: "SystemChild", headerName: "System child", width: 200 },
        {
          field: "ParentSystemName",
          headerName: "Parent system name",
          width: 250
        },
        {
          field: "CalibrationDate",
          headerName: "Last Calibration Date",
          width: 250,
          valueFormatter: this.dateFormatter
        },
        //{ field: "ServiceDueDate", headerName: "Service Due Date ", width: 200 ,valueFormatter: this.dateFormatter},
        { field: "LoanDailyCost", headerName: "Loan daily cost", width: 200 }
      ],
      rowSelection: "single"
    };
    this.actionCellRenderer = this.actionCellRenderer.bind(this);
  }

  dateFormatter = params => {
    return moment(params.value).format("YYYY-MM-DD");
  };
  componentDidMount() {}

  actionCellRenderer = e => {
    let del = document.createElement("div");
    del.innerHTML =
      '<span><i class="anticon anticon-close-circle" style="color: rgb(216, 104, 104); font-size:20px; cursor:pointer;"/></span>';
    del.addEventListener("click", function() {
      let uid = e.data.UniqueID;
      let filteredRowData = loanPoolStore.selectedAssetsFull.filter(
        r => r.UniqueID != uid
      );
      loanPoolStore.dashboardAddCheckFull(filteredRowData);
    });
    return del;
  };

  render() {
    const gridRowSelAssetsData = JSON.parse(
      JSON.stringify(loanPoolStore.selectedAssetsFull)
    );
    return (
      <AgGridReact
        //onRowSelected={this.onRowSelected}
        rowData={gridRowSelAssetsData}
        columnDefs={this.state.columnDefs}
        rowSelection={this.state.rowSelection}
        suppressRowClickSelection={true}
        suppressCellSelection={true}
        rowHeight="35"
        headerHeight="35"
        enableSorting={true}
        enableColResize={true}
      />
    );
  }
}

export default SelectedAssets;
SelectedAssets.propTypes = {
  isDeleteActionHide: PropTypes.object
};
