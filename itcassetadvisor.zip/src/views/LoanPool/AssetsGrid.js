import React, { Component } from "react";

import { observer } from "mobx-react";
//import ReactDataGrid from 'react-data-grid';
import { AgGridReact } from "ag-grid-react";
import loanPoolStore from "../../stores/loanPoolStore";

import LoadingImage from "../../containers/Full/loading.gif";

const LoadingView1 = <img src={LoadingImage} className="loanPoolLoader" />;

@observer
class AssetsGrid extends Component {
  static defaultProps = { rowKey: "EquipmentNo" };

  constructor(props) {
      super(props);
      this.state = {
          rowSelection: "multiple",
          lastPageFound: false,
          currentLimit: 25,
          totalPages: 0,
          startItem: 1,
          lastItem: 25,
          isDensityApplied: "false",
          currentDensityState: "default",
          currentPage: 1
      };
      this.currentRowHeight = "35";
  }

  setGridItemsSelection() {
      this.api.removeEventListener("selectionChanged", this.onRowSelected);

      this.api.forEachNode(function(node) {
          if (
              loanPoolStore.selectedAssetsFull.find(
                  item => item.EquipmentNo === node.data.EquipmentNo
              )
          ) {
              node.setSelected(true);
          }
      });

      this.api.addEventListener("selectionChanged", this.onRowSelected);
  }
  rowGetter = i => {
      var rtn = loanPoolStore.loanableAssetsForCustomerLoanpoolGrid[i];
      // console.log('getter',rtn);
      return rtn;
  };

  // onRowsSelected = rows => {
  //     // loanPoolStore.dashboardAddCheck(rows);
  //     loanPoolStore.dashboardAddCheckFull(rows);
  // };
  onRowsDeselected = rows => {
      const rowIds = rows.map(r => r.row);
      // const rowIds = rows.map(r => r.row[this.props.rowKey]);
      //console.log('rowIds',rows);
      // loanPoolStore.dashboardRemoveCheck(rows, rowIds);
      loanPoolStore.dashboardRemoveCheckFull(rowIds);
  };

  rowGetData = () => {
      var rtn = loanPoolStore.loanableAssetsForCustomerLoanpoolGrid;
      return JSON.parse(JSON.stringify(rtn));
  };

  onRowSelected = event => {
      let rows = event.api.getSelectedRows();
      loanPoolStore.dashboardAddCheckFull(rows);
  };

  onGridReady = params => {
      const updateData = data => {
          params.api.setRowData(data);
      };
      updateData(this.rowGetData());
      this.api = params.api;
      this.columnApi = params.columnApi;
      this.setState({ totalPages: this.api.paginationGetTotalPages() });
      //console.log("Total_pages", this.api.paginationGetTotalPages());
      this.setGridItemsSelection();
  };

  onBtFirst = () => {
      this.api.paginationGoToFirstPage();
  };

  onBtLast = () => {
      this.api.paginationGoToLastPage();
  };

  onBtNext = () => {
      this.api.paginationGoToNextPage();
  };

  onBtPrevious = () => {
      this.api.paginationGoToPreviousPage();
  };

  getTotalPages = () => {
      return this.api.paginationGetTotalPages();
  };

  paginationGoToPage = e => {
      if (e.target.value > 0) {
          this.api.paginationGoToPage(parseInt(e.target.value) - 1);
      }
  };
  handleRefresh = () => {
      loanPoolStore.dataLoaded = false;
      {
          !loanPoolStore.dataLoaded ? LoadingView1 : "";
      }
      loanPoolStore.reRenderLoanPool();
  };

  handleDensityDefault() {
      this.setState({
          isDensityApplied: "false",
          currentDensityState: "default"
      });
      this.currentRowHeight = "35";
      this.api.resetRowHeights();
      this.api.onRowHeightChanged();
  }

  handleDensityMedium() {
      this.setState({
          isDensityApplied: "true",
          currentDensityState: "medium"
      });
      this.currentRowHeight = "43";

      this.api.resetRowHeights();
      this.api.onRowHeightChanged();
  }

  handleDensityLarge() {
      this.setState({
          isDensityApplied: "true",
          currentDensityState: "large"
      });
      this.currentRowHeight = "50";

      this.api.resetRowHeights();
      this.api.onRowHeightChanged();
  }

  handlePageSize(e) {
      var currentLimit = e.target.value;
      this.api.paginationSetPageSize(currentLimit);
  }

  onPaginationChanged() {
      if (this.api) {
          var currentPage = this.api.paginationGetCurrentPage();
          var currentPageSize = this.api.paginationGetPageSize();
          var startItem = currentPage * currentPageSize + 1;

          var lastItem = +parseInt(startItem) + parseInt(currentPageSize) - 1;
          if (lastItem > this.rowGetData().length)
              lastItem = this.rowGetData().length;
          //console.log("OnChanged ->", this.api.paginationGetCurrentPage() + 1);
          //console.log("Total_pages", this.api.paginationGetTotalPages());

          const totalPages = this.api.paginationGetTotalPages();
          //this.setState({ lastPageFound: this.api.paginationIsLastPageFound() });
          this.setState({
              totalPages,
              startItem,
              lastItem,
              currentPage: this.api.paginationGetCurrentPage() + 1
          });
      //console.log("OnChanged ->", this.api.paginationGetCurrentPage() + 1);
      //console.log("Total_pages", this.api.paginationGetTotalPages());
      }
  }

  getRowHeight = () => {
      return parseInt(this.currentRowHeight);
  };

  render() {
      let gridStyles = {
          clearBoth: {
              clear: "both"
          },
          windowHeight: {
              height: window.innerHeight - 486,
              color: "#666"
          }
      };

      //var dashboardChecked = loanPoolStore.selectedAssetsFull.map(a => a.EquipmentNo);
      //var dashboardChecked = loanPoolStore.selectedAssetsFull.map();
      //console.log("gridChecked", dashboardChecked);

      let gridRowData = this.rowGetData();

      return (
          <div className="lp-grid-wrapper">
              <div
                  className="loanPoolselectedAssetsOpenRowGrid ag-fresh GridPadding"
                  style={gridStyles.windowHeight}
              >
                  <AgGridReact
                      rowData={gridRowData}
                      columnDefs={loanPoolStore.AssetGridColumnDefs.map(e => e)}
                      rowSelection={this.state.rowSelection}
                      suppressRowClickSelection={true}
                      suppressCellSelection={true}
                      suppressPaginationPanel={true}
                      getRowHeight={this.getRowHeight}
                      headerHeight="50"
                      enableSorting={true}
                      enableColResize={true}
                      pagination={true}
                      paginationPageSize="25"
                      onGridReady={this.onGridReady}
                      onPaginationChanged={this.onPaginationChanged.bind(this)}
                  />
              </div>
              <div id="">
                  <div>
                      <nav className="navbar navbar-dark bg-dark paginationBar">
                          <div className="col-sm-3 paginationButtons">
                              <ul>
                                  <li className="pageControls">
                                      <i
                                          className="fa fa-angle-double-left"
                                          onClick={this.onBtFirst.bind(this)}
                                      />
                                  </li>
                                  <li className="pageControls">
                                      <i
                                          className="fa fa-angle-left"
                                          onClick={this.onBtPrevious.bind(this)}
                                      />
                                  </li>
                                  <li>
                                      <span className="page">Page</span>
                                  </li>
                                  <li>
                                      <input
                                          className="pageNumberInput"
                                          type="number"
                                          min="1"
                                          onChange={this.paginationGoToPage.bind(this)}
                                          value={this.state.currentPage}
                                      />
                                  </li>
                                  <li>
                                      <span className="of38">of {this.state.totalPages}</span>
                                  </li>
                                  <li className="pageControls">
                                      <i
                                          className="fa fa-angle-right"
                                          onClick={this.onBtNext.bind(this)}
                                      />
                                  </li>
                                  <li className="pageControls">
                                      <i
                                          className="fa fa-angle-double-right"
                                          onClick={this.onBtLast.bind(this)}
                                      />
                                  </li>
                                  <li
                                      className="pageControls"
                                      // onClick={this.handleRefresh.bind(this)}
                                  >
                                      <i
                                          className="icon-refresh"
                                          onClick={this.handleRefresh.bind(this)}
                                      />
                                  </li>
                              </ul>
                          </div>

                          {/*============== 'Display Density Group' ==============*/}
                          <div className="col-sm-2 displayDensity">
                              <ul>
                                  <li className="densityButtons">
                                      <span className="displayDensityLabel">Display Density</span>
                                  </li>
                                  <li
                                      className="densityButtons"
                                      onClick={this.handleDensityDefault.bind(this)}
                                  >
                                      <a href="#">
                                          <i
                                              className={
                                                  "icon-menu " +
                          (this.state.currentDensityState == "default"
                              ? "selected"
                              : "")
                                              }
                                              style={{ fontSize: "0.8em", "padding-right": 15 }}
                                          />
                                      </a>
                                  </li>
                                  <li
                                      className="densityButtons"
                                      onClick={this.handleDensityMedium.bind(this)}
                                      style={{ "margin-top": 2 }}
                                  >
                                      <a href="#">
                                          <i
                                              className={
                                                  "icon-menu " +
                          (this.state.currentDensityState == "medium"
                              ? "selected"
                              : "")
                                              }
                                              style={{ fontSize: "1.2em", "padding-right": 15 }}
                                          />
                                      </a>
                                  </li>
                                  <li
                                      className="densityButtons"
                                      onClick={this.handleDensityLarge.bind(this)}
                                      style={{ "margin-top": -1 }}
                                  >
                                      <a href="#">
                                          <i
                                              className={
                                                  "icon-menu " +
                          (this.state.currentDensityState == "large"
                              ? "selected"
                              : "")
                                              }
                                              style={{ fontSize: "1.5em", "padding-right": 15 }}
                                          />
                                      </a>
                                  </li>
                              </ul>
                          </div>

                          <span
                              className="page"
                              style={{
                                  paddingLeft: "5px",
                                  paddingRight: "5px",
                                  color: "#fff"
                              }}
                          >
                Page Size
                          </span>
                          <div className="col-sm-1 pageSize">
                              <select
                                  id="tabSelect"
                                  className="dashfooterSelect"
                                  onChange={this.handlePageSize.bind(this)}
                              >
                                  <option key={25}>25</option>
                                  <option key={50}>50</option>
                                  <option key={75}>75</option>
                                  <option key={100}>100</option>
                                  <option key={150}>150</option>
                                  <option key={200}>200</option>
                                  <option key={250}>250</option>
                              </select>
                          </div>

                          <span className="grid-page-label">
                Displaying {this.state.startItem}-{this.state.lastItem} of{" "}
                              {this.rowGetData().length}
                          </span>
                          {/*</div>*/}
                      </nav>
                  </div>
              </div>
          </div>
      );
  }
}

export default AssetsGrid;
