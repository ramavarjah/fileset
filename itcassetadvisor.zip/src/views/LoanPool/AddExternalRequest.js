import React, { Component } from "react";
import { observer } from "mobx-react";
import loanPoolStore from "../../stores/loanPoolStore";
import userStore from "../../stores/userStore";
import moment from "moment";
import { Col, Form, Input, DatePicker } from "antd";
import { Button, Modal, ModalHeader, ModalBody } from "reactstrap";
import UIFunctions from "./../../helpers/UIFunctions";
import Functions from "../../api/Functions";

const FormItem = Form.Item;
const { TextArea } = Input;

const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 8 }
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 15 }
    }
};

const formRightItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 24 }
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 24 }
    }
};

@observer
class AddFormExternalRequest extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "",
            emailAddress: "",
            mobileNumber: "",
            startValue: null,
            endValue: null,
            endOpen: false
        };
    }

  disabledStartDate = startValue => {
      const endValue = this.state.endValue;
      if (!startValue || !endValue) {
          return false;
      }
      return startValue.valueOf() > endValue.valueOf();
  };

  disabledEndDate = endValue => {
      const startValue = this.state.startValue;
      if (!endValue || !startValue) {
          return false;
      }
      return endValue.clone().endOf("day") <= startValue.valueOf();
  };

  onChange = (field, value) => {
      this.setState({
          [field]: value
      });
  };

  onStartChange = value => {
      loanPoolStore.setStartDate(value.toISOString());
      this.onChange("startValue", value);
  };

  onEndChange = value => {
      loanPoolStore.setEndDate(value.toISOString());
      this.onChange("endValue", value);
  };

  handleStartOpenChange = open => {
      if (!open) {
          this.setState({ endOpen: true });
      }
  };

  handleEndOpenChange = open => {
      this.setState({ endOpen: open });
  };

  handleStartDate(date) {
      loanPoolStore.setStartDate(date.toISOString());
  }
  handleRangeChange(date) {
      loanPoolStore.setRange(date);
  }
  handleEndDate(date) {
      loanPoolStore.setEndDate(date.toISOString());
  }
  componentDidMount() {
      //for testing email field needs to be edited so making a state for that
      var firstName = userStore.userDetails.firstName;
      var lastName = userStore.userDetails.lastName;
      var emailAddress = userStore.userDetails.emailAddress;
      //var mobile = userStore.userDetails.mobile;
      var name = "No Name";
      if (firstName || lastName) {
          name = firstName + " " + lastName;
      }
      // if (!mobile) {
      //   mobile = "No Mobile Number";
      // }
      if (!emailAddress) {
          emailAddress = "No emailAddress";
      }
      this.props.form.setFieldsValue({
          name,
          emailAddress
      });
      this.setState({
          name,
          emailAddress
      });
  }

  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFields(err => {
          if (!err) {
              var startDate = moment(loanPoolStore.startDate)
                  .startOf("day")
                  .toISOString();
              var endDate = moment(loanPoolStore.endDate)
                  .startOf("day")
                  .toISOString();
              var justification = loanPoolStore.justification;
              var modelNumber = loanPoolStore.modelNumber;
              var manufacturer = loanPoolStore.manufacturer;
              var notes = loanPoolStore.notes;
              var description = loanPoolStore.description;
              var location = loanPoolStore.location;
              var mobile = loanPoolStore.mobile;
              Functions.AddExternalAssetRequest(
                  endDate,
                  startDate,
                  notes,
                  location,
                  justification,
                  description,
                  modelNumber,
                  manufacturer,
                  mobile
              ).then(response => {
                  if (response.data.success) {
                      UIFunctions.Toast(
                          "Equipment request created successfully",
                          "success"
                      );
                  } else {
                      UIFunctions.Toast(
                          "Equipment request could not be created",
                          "error"
                      );
                  }
                  this.props.onCancel();
              });
          }
      });

      //this.props.onCancel();
  };

  render() {
      const { getFieldDecorator } = this.props.form;
      const { startValue, endValue, endOpen } = this.state;

      return (
          <Modal
              isOpen={true}
              className="modal-dialog modal-lg equipmentRequestModal"
              style={{ maxWidth: 900 }}
          >
              <ModalHeader
                  className="row modalHeader equipmentRequestModalHeader"
                  style={{ borderBottom: "1px solid #ccd0d8" }}
              >
                  <span className="equipmentRequestLabel">EQUIPMENT REQUEST</span>
                  <span onClick={this.props.onCancel} style={{ cursor: "pointer" }}>
                      <i className="icon-close" />
                  </span>
              </ModalHeader>
              <ModalBody style={{ padding: 0 }}>
                  <div className="col-md-12 equipmentRequestFormContainer">
                      <Form style={{ width: "100%" }}>
                          <div>
                              <Col span={12} className="col-md-6 pull-left">
                                  <FormItem {...formItemLayout} label="Name">
                                      {getFieldDecorator("name", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter name!"
                                              }
                                          ]
                                      })(<Input disabled value={this.state.name} />)}
                                  </FormItem>
                                  {/* <FormItem
                     {...formItemLayout}
                     label="Dates"
                     required={true}
                     validateStatus={loanPoolStore.dateValidator.mode}
                     help={loanPoolStore.dateValidator.message}>
                     <RangePicker
                       ranges={{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }}
                       onChange={this.handleRangeChange.bind(this)} />
                   </FormItem> */}
                                  <FormItem
                                      {...formItemLayout}
                                      label="Start Date"
                                      required={true}
                                      validateStatus={loanPoolStore.dateValidator.mode}
                                      help={loanPoolStore.dateValidator.message}
                                  >
                                      <DatePicker
                                          format="YYYY-MM-DD"
                                          disabledDate={this.disabledStartDate}
                                          onOpenChange={this.handleStartOpenChange}
                                          value={startValue}
                                          onChange={this.onStartChange}
                                      />
                                  </FormItem>
                                  <FormItem
                                      {...formItemLayout}
                                      label="Returned Date"
                                      required={true}
                                  >
                                      <DatePicker
                                          disabledDate={this.disabledEndDate}
                                          format="YYYY-MM-DD"
                                          onChange={this.onEndChange}
                                          value={endValue}
                                          onOpenChange={this.handleEndOpenChange}
                                          open={endOpen}
                                      />
                                  </FormItem>
                                  <FormItem {...formItemLayout} label="Email address">
                                      {getFieldDecorator("emailAddress", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter email!"
                                              }
                                          ]
                                      })(<Input disabled value={this.state.emailAddress} />)}
                                  </FormItem>
                                  <FormItem {...formItemLayout} label="Mobile">
                                      {getFieldDecorator("mobile", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter mobile!"
                                              }
                                          ]
                                      })(
                                          <Input
                                              onChange={e => {
                                                  loanPoolStore.setMobile(e.target.value);
                                              }}
                                          />
                                      )}
                                  </FormItem>
                                  <FormItem {...formItemLayout} label="Location">
                                      {getFieldDecorator("location", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter location!"
                                              }
                                          ]
                                      })(
                                          <Input
                                              onChange={e => {
                                                  loanPoolStore.setLocation(e.target.value);
                                              }}
                                          />
                                      )}
                                  </FormItem>
                                  <FormItem {...formItemLayout} label="Model">
                                      {getFieldDecorator("modelno", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter model number!"
                                              }
                                          ]
                                      })(
                                          <Input
                                              onChange={e => {
                                                  loanPoolStore.setModelNumber(e.target.value);
                                              }}
                                          />
                                      )}
                                  </FormItem>
                                  <FormItem {...formItemLayout} label="Manufacturer">
                                      {getFieldDecorator("manufacturer", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter manufacturer!"
                                              }
                                          ]
                                      })(
                                          <Input
                                              onChange={e => {
                                                  loanPoolStore.setManufacturer(e.target.value);
                                              }}
                                          />
                                      )}
                                  </FormItem>
                              </Col>

                              <Col span={12} className="col-md-6 pull-left borderLeft">
                                  <FormItem {...formRightItemLayout} label="Justification">
                                      {getFieldDecorator("justification", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter justification!"
                                              }
                                          ]
                                      })(
                                          <TextArea
                                              rows={6}
                                              onChange={e => {
                                                  loanPoolStore.setJustification(e.target.value);
                                              }}
                                          />
                                      )}
                                  </FormItem>
                                  <FormItem {...formRightItemLayout} label="Description">
                                      {getFieldDecorator("description", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter description!"
                                              }
                                          ]
                                      })(
                                          <TextArea
                                              rows={6}
                                              onChange={e => {
                                                  loanPoolStore.setDescription(e.target.value);
                                              }}
                                          />
                                      )}
                                  </FormItem>
                                  <FormItem
                                      {...formRightItemLayout}
                                      label="Notes/ Options/ Accessories"
                                  >
                                      {getFieldDecorator("notes", {
                                          rules: [
                                              {
                                                  required: true,
                                                  message: "Please enter notes!"
                                              }
                                          ]
                                      })(
                                          <TextArea
                                              rows={6}
                                              onChange={e => {
                                                  loanPoolStore.setNotes(e.target.value);
                                              }}
                                          />
                                      )}
                                  </FormItem>
                              </Col>

                              <div className="clear" />
                          </div>
                          <div className="col-md-12 pull-left">
                              <div className="equipmentRequestButton">
                                  <FormItem>
                                      <Button
                                          className="cancelButton"
                                          type="primary"
                                          style={{ marginLeft: 8 }}
                                          onClick={this.props.onCancel}
                                      >
                      Cancel
                                      </Button>
                                      <Button
                                          className="submitButton"
                                          type="primary"
                                          style={{ marginLeft: 8 }}
                                          onClick={this.handleSubmit.bind(this)}
                                      >
                      Submit
                                      </Button>
                                  </FormItem>
                              </div>
                          </div>
                      </Form>
                  </div>
              </ModalBody>
          </Modal>
      );
  }
}

const AddExternalRequest = Form.create()(AddFormExternalRequest);
export default AddExternalRequest;
