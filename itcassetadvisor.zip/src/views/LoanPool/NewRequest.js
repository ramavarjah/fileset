import React, { Component } from "react";
import { observer } from "mobx-react";
import loanPoolStore from "../../stores/loanPoolStore";
import userStore from "../../stores/userStore";
import moment from "moment";
import { Form, Input, DatePicker, Row, Spin, Icon } from "antd";
import SelectedAssets from "./SelectedAssets";

const FormItem = Form.Item;
const { TextArea } = Input;
const formItemLayout = {
	labelCol: {
		xs: {
			span: 7
		},
		sm: {
			span: 7
		}
	},
	wrapperCol: {
		xs: {
			span: 16
		},
		sm: {
			span: 16
		}
	}
};
@observer
class NewRequest extends Component {
	constructor(props) {
		super(props);
		this.state = {
			name: "",
			emailAddress: "",
			mobile: "",
			startValue: null,
			endValue: null,
			endOpen: false
		};
	}
	totalLoanCost = () => {
		var total = 0;
		loanPoolStore.selectedAssetsFull.map(a => {
			total = +a.LoanDailyCost + total;
		});
		//get startdate and end date to calculate total loan cost
		if (loanPoolStore.startDate && loanPoolStore.startDate) {
			var startDate = moment(loanPoolStore.startDate).format();
			var endDate = moment(loanPoolStore.endDate).format();
			var diff = moment(endDate).diff(startDate, "days");
			if (diff == 0) {
				diff = diff + 1;
			}
			total = total * diff;
		}
		//if total is not valid set 0 as total
		if (!total) total = 0;
		return total;
	};

	disabledStartDate = startValue => {
		const endValue = this.state.endValue;
		if (!startValue || !endValue) {
			return false;
		}
		return startValue.valueOf() > endValue.valueOf();
	};

	disabledDate(current) {
		// Can not select days before today
		return current <= moment().startOf("day");
	}

	disabledEndDate = endValue => {
		const startValue = this.state.startValue;
		if (!endValue || !startValue) {
			return false;
		}
		return endValue.clone().endOf("day") <= startValue.valueOf();
	};

	onChange = (field, value) => {
		this.setState({ [field]: value });
	};

	onStartChange = value => {
		if (value) {
			loanPoolStore.setStartDate(value.toISOString());
			if (this.state.endValue) {
				loanPoolStore.dateValidator.valid = true;
			}
		} else {
			loanPoolStore.dateValidator.valid = false;
		}
		this.onChange("startValue", value);
	};

	onEndChange = value => {
		if (value) {
			loanPoolStore.setEndDate(value.toISOString());
			if (this.state.startValue) {
				loanPoolStore.dateValidator.valid = true;
			}
		} else {
			loanPoolStore.dateValidator.valid = false;
		}
		this.onChange("endValue", value);
	};

	handleStartOpenChange = open => {
		if (!open) {
			this.setState({ endOpen: true });
		}
	};

	handleEndOpenChange = open => {
		this.setState({ endOpen: open });
	};

	handleStartDate(date) {
		loanPoolStore.setStartDate(date.toISOString());
	}
	handleRangeChange(date) {
		loanPoolStore.setRange(date);
	}
	handleEndDate(date) {
		loanPoolStore.setEndDate(date.toISOString());
	}
	handleSubmit = e => {
		e.preventDefault();
		this.props.form.validateFieldsAndScroll((err, values) => {
			if (!err) {
				values.startValue = values.startValue.startOf("day").toISOString();
				values.endValue = values.endValue.endOf("day").toISOString();
				loanPoolStore.submitNewrequest(values);
			}
		});
	};
	componentDidMount() {
		var firstName = userStore.userDetails.firstName;
		var lastName = userStore.userDetails.lastName;
		var emailAddress = userStore.userDetails.emailAddress;
		var name = "No Name";
		if (firstName && lastName) {
			name = firstName + " " + lastName;
		}
		if (!emailAddress) {
			emailAddress = "No emailAddress";
		}
		this.setState({ name, emailAddress });
	}

	compareToStartDate = (rule, value, callback) => {
		const form = this.props.form;
		if (value && value > form.getFieldValue("endValue")) {
			callback("Start Date cannot be more then End Date");
		} else {
			callback();
		}
	};

	validateToEndDate = (rule, value, callback) => {
		const form = this.props.form;
		if (value && value > form.getFieldValue("startValue")) {
			form.validateFields(["startValue"], { force: true });
		}
		callback();
	};
	rowGetter = i => {
		var rtn = loanPoolStore.selectedAssetsFull.map(a => a)[i];
		return rtn;
	};

	render() {
		const { getFieldDecorator } = this.props.form;
		var totalLoanCost = this.totalLoanCost();
		const { startValue } = this.state;

		var newReqStyles = {
			windowHeight: {
				height: window.innerHeight - 531,
				color: "#666"
			}
		};
		const createClass = loanPoolStore.selectedAssetsFull.length
			? ""
			: "inactive";
		return (
			<div>
				<section className="lp-section-box">
					<div className="moduleContainerWrapper">
						<Spin spinning={loanPoolStore.isButtonDisabled} delay={500}>
							<Form
								style={{
									width: "100%"
								}}
							>
								<div className="loanPoolNewReqFormContainer">
									<div className="col-md-6 pull-left borderRight">
										<FormItem
											{...formItemLayout}
											label="Requestor Name"
											required={true}
											validateStatus=""
											help=""
										>
											<Input disabled value={this.state.name} />
										</FormItem>
										<FormItem {...formItemLayout} label="Request Start Date">
											{getFieldDecorator("startValue", {
												rules: [
													{
														required: true,
														message: "Please input request start date"
													},
													{
														validator: this.compareToStartDate
													}
												]
											})(
												<DatePicker
													format="YYYY-MM-DD"
													disabledDate={this.disabledDate}
													onChange={this.onStartChange}
												/>
											)}
										</FormItem>
										<FormItem {...formItemLayout} label="Request End Date">
											{getFieldDecorator("endValue", {
												rules: [
													{
														required: true,
														message: "Please input request end date"
													},
													{
														validator: this.validateToEndDate
													}
												]
											})(
												<DatePicker
													disabledDate={this.disabledEndDate}
													format="YYYY-MM-DD"
													onChange={this.onEndChange}
													defaultPickerValue={startValue}
												/>
											)}
										</FormItem>

										<FormItem
											{...formItemLayout}
											label="Requestor Email Address"
											required={true}
											validateStatus=""
											help=""
										>
											<Input
												disabled
												onChange={e =>
													this.setState({ emailAddress: e.target.value })
												}
												value={this.state.emailAddress}
											/>
										</FormItem>

										<FormItem
											{...formItemLayout}
											label="Requestor Phone Number"
										>
											{getFieldDecorator("mobile", {
												rules: [
													{
														required: true,
														message: "Please input requestor phone number"
													}
												]
											})(<Input />)}
										</FormItem>
									</div>

									<div className="col-md-6 pull-left">
										<FormItem {...formItemLayout} label="Proposed Use Location">
											{getFieldDecorator("Location", {
												rules: [
													{
														required: true,
														message: "Please input proposed use location"
													}
												]
											})(<Input />)}
										</FormItem>

										<FormItem {...formItemLayout} label="Total Loan Cost">
											<Input disabled value={totalLoanCost} />
										</FormItem>

										<FormItem {...formItemLayout} label="Charge Code">
											{getFieldDecorator("ChargeCode", {
												rules: [
													{
														required: true,
														message: "Please input ChargeCode"
													}
												]
											})(
												<Input
													onChange={e => {
														loanPoolStore.setChargeBack(e.target.value);
													}}
												/>
											)}
										</FormItem>

										<FormItem {...formItemLayout} label="Justification">
											{getFieldDecorator("justification", {
												rules: [
													{
														required: true,
														message: "Please input justification"
													}
												]
											})(<TextArea rows={6} />)}
										</FormItem>
									</div>
									<div className="clear" />
								</div>
								{/*end of form container*/}
								<div className="clear" />
							</Form>
						</Spin>
					</div>
				</section>

				<section className="lp-section-box loanPoolSelectedAssets">
					<Row>
						<div className="col-md-12 pull-left">
							<div className="selectedAssetsTitle">Selected Assets</div>
							<div className="lp-sel-grid-wrapper">
								<div
									className="loanPoolselectedAssetsOpenRowGrid ag-fresh"
									style={newReqStyles.windowHeight}
								>
									<SelectedAssets isDeleteActionHide={false} />
								</div>
							</div>
						</div>
						<div className="clear" />
					</Row>
				</section>

				<section className="lp-section-box">
					<Row>
						<div className="col-md-12 pull-left">
							<div className="buttonContainer">
								<button
									className="lpBackButton"
									onClick={this.props.handle2PageCancel}
								>
									<Icon
										type="left"
										style={{
											fontWeight: 700
										}}
									/>
									Back
								</button>
								<button
									className={"lpCreateButton " + createClass}
									disabled={loanPoolStore.isButtonDisabled}
									onClick={this.handleSubmit.bind(this)}
								>
									Create
									<Icon
										type="plus"
										style={{
											fontWeight: 700
										}}
									/>
								</button>
							</div>
						</div>
						<div className="clear" />
					</Row>
				</section>
			</div>
		);
	}
}
const WrappedRegistrationForm = Form.create()(NewRequest);
export default WrappedRegistrationForm;
