import React, { Component } from "react";
import { observable } from "mobx";
import CACalendar from "src/views/Components/CACalendar";
import moment from "moment";
import dateArray from "moment-array-dates";
import { Table } from "antd";

class Home extends Component {
  @observable
  calenderData;
  @observable
  calendarHeader;
  constructor(props) {
      super(props);
      this.state = {
          markers: [
              {
                  yellow: [
                      moment("3-17-2019", "MM-DD-YYYY"),
                      moment("1-2-2019", "MM-DD-YYYY"),
                      moment("1-3-2019", "MM-DD-YYYY"),
                      moment("1-1-2019", "MM-DD-YYYY")
                  ]
              },
              {
                  pink: [
                      moment("2-6-2019", "MM-DD-YYYY"),
                      moment("2-9-2019", "MM-DD-YYYY"),
                      moment("3-12-2019", "MM-DD-YYYY")
                  ]
              }
          ],
          selectedDates: []
      };
      this.calenderData = [];
      this.calendarHeader = [];
  }
  onSelectionChange = (date, props) => {
      const { selectedDates, markers } = this.state;
      const dateObj = moment(
          `${props.month}-${date.currentTarget.textContent}-${props.year}`,
          "MM-DD-YYYY"
      );

      let newMarkers = [...markers, { blue: [dateObj] }];
      if (selectedDates.length == 0) {
          this.setState({
              selectedDates: [dateObj],
              markers: newMarkers
          });
      } else if (selectedDates.length == 1) {
          if (
              selectedDates[0].format("MM-DD-YYYY") == dateObj.format("MM-DD-YYYY")
          ) {
              return;
          }
          this.setState(prevState => ({
              selectedDates: [...prevState.selectedDates, dateObj],
              markers: newMarkers
          }));

          newMarkers = dateArray
              .range(
                  moment(selectedDates[0] > dateObj ? dateObj : selectedDates[0]),
                  moment(dateObj > selectedDates[0] ? dateObj : selectedDates[0]),
                  "MM-DD-YYYY",
                  true
              )
              .map(i => moment(i, "MM-DD-YYYY"));
          this.setState({ markers: [...markers, { blue: newMarkers }] });
      } else {
          if (
              selectedDates[1].format("MM-DD-YYYY") == dateObj.format("MM-DD-YYYY")
          ) {
              return;
          }
          newMarkers = markers.filter(i => !i.blue && !i.lightblue);
          this.setState(() => ({
              selectedDates: [],
              markers: newMarkers
          }));
      }
  };

  onHoverChange = (date, props) => {
      const { selectedDates, markers } = this.state;
      const dateObj = moment(
          `${props.month}-${date.currentTarget.textContent}-${props.year}`,
          "MM-DD-YYYY"
      ).format("MM-DD-YYYY");

      let newMarkers = [];
      let startDate = null;
      let endDate = null;
      if (selectedDates.length == 0) {
          newMarkers = markers.filter(i => !i.lightblue);
          this.setState({ markers: newMarkers });
          return;
      }
      if (selectedDates.length == 1) {
          startDate = selectedDates[0].format("MM-DD-YYYY");
      }
      if (selectedDates.length == 2) {
          endDate = selectedDates[1].format("MM-DD-YYYY");
      }
      if (endDate) {
          newMarkers = markers.filter(i => !i.lightblue);
          this.setState({ markers: newMarkers });
          return;
      }
      if (startDate) {
          let updatedMarkers = markers.filter(i => !i.lightblue);
          if (startDate > dateObj) {
              this.setState({ markers: updatedMarkers });
              return;
          }

          if (startDate == dateObj) {
              this.setState({ markers: updatedMarkers });
              return;
          }
          const TstartDate = moment(startDate, "MM-DD-YYYY")
              .add(1, "days")
              .format("MM-DD-YYYY");
          if (TstartDate == dateObj) {
              newMarkers.push(moment(dateObj, "MM-DD-YYYY"));
              this.setState({
                  markers: [...updatedMarkers, { lightblue: newMarkers }]
              });
              return;
          }

          newMarkers = dateArray
              .range(moment(TstartDate), moment(dateObj), "MM-DD-YYYY", true)
              .map(i => moment(i, "MM-DD-YYYY"));
          this.setState({
              markers: [...updatedMarkers, { lightblue: newMarkers }]
          });
      }
  };
  getCalendar = (month, year, markers) => {
      return (
          <CACalendar
              year={year}
              month={month}
              markers={markers}
              onSelectionChange={this.onSelectionChange}
              onHoverChange={this.onHoverChange}
          />
      );
  };
  getCalendarRange = (startDate, endDate, markers) => {
      var monthRange = [];
      var yearRange = [];

      while (
          endDate > startDate ||
      startDate.format("M") === endDate.format("M")
      ) {
          monthRange.push(startDate.format("MM"));
          startDate.add(1, "month");
      }
      while (
          endDate > startDate ||
      startDate.format("YYYY") === endDate.format("YYYY")
      ) {
          yearRange.push(startDate.format("YYYY"));
          startDate.add(1, "year");
      }
      //apply map for dynamically getting getcalendar here
      this.calenderData = [
          {
              jan: this.getCalendar(1, 2019, markers),
              feb: this.getCalendar(2, 2019, markers),
              mar: this.getCalendar(3, 2019, markers),
              apr: this.getCalendar(4, 2019, markers),
              may: this.getCalendar(5, 2019, markers)
          },
          {
              jan: this.getCalendar(1, 2019, markers),
              feb: this.getCalendar(2, 2019, markers),
              mar: this.getCalendar(3, 2019, markers),
              apr: this.getCalendar(4, 2019, markers),
              may: this.getCalendar(5, 2019, markers)
          },
          {
              jan: this.getCalendar(1, 2019, markers),
              feb: this.getCalendar(2, 2019, markers),
              mar: this.getCalendar(3, 2019, markers),
              apr: this.getCalendar(4, 2019, markers),
              may: this.getCalendar(5, 2019, markers)
          }
      ];

      this.calendarHeader = [
          {
              dataIndex: "jan"
          },
          {
              dataIndex: "feb"
          },
          {
              dataIndex: "mar"
          },
          {
              dataIndex: "apr"
          },
          {
              dataIndex: "may"
          }
      ];
      //return monthRange.map(i => this.getCalendar(i, 2019, markers));
  };

  render() {
      let { markers } = this.state;
      var startDate = moment("1-1-2019");
      var endDate = moment("3-1-2019");

      // let dateRange = dateArray.range(moment("1-1-2019"), moment("5-1-2019"), "MM-DD-YYYY", true);
      return (
          <div style={{ display: "flex" }}>
              {this.getCalendarRange(startDate, endDate, markers)}
              <div className="CA-Table">
                  <Table
                      pagination={{ position: "top" }}
                      columns={this.calendarHeader}
                      dataSource={this.calenderData}
                  />
              </div>
          </div>
      );
  }
}

export default Home;
