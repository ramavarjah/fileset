import React, { Component } from "react";
import { Switch, Route } from "react-router-dom";
import Header from "../../components/Header/";
import Sidebar from "../../components/Sidebar/";
import Aside from "../../components/Aside/";
import Footer from "../../components/Footer/";
import Dashboard from "../../views/Dashboard/";
import Charts from "../../views/Charts/ChartsNew";
import addAssetsStore from "./../../stores/addAssetsStore";

//spotfire
import Spotfire from "../../views/SpotfireDashboard/";

//mobx
import { observable } from "mobx";
import { observer } from "mobx-react";

//utillities
import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";

import tabModelStore from "../../stores/tabModelStore";
import permissionStore from "../../stores/permissionStore";

import userStore from "../../stores/userStore";

// Icons
import moment from "moment";
import * as mtz from 'moment-timezone';

@observer
class Full extends Component {
  @observable tabs;
  @observable tabsData;
  @observable loaded;

  constructor(props) {
    super(props);
    this.updateData = this.updateData.bind(this);
    this.tabs = false;
    this.tabsData = false;
    this.loaded = false;
    this.onTabChange = this.onTabChange.bind(this);
  }

  // onLoad = () => {
  //   this.tabs = true;
  // };

  componentDidMount() {
    // UIFunctions.Toast('test','error');
    // console.log("componentDidMount", userStore.userDetails, userStore.me, tabModelStore.dataLoaded)
    if (
      userStore.userDetails &&
      userStore.me &&
      tabModelStore.dataLoaded &&
      tabModelStore.currentScreenDataArray
    ) {
      this.loaded = true;
      return;
    }
    tabModelStore.setDataLoaded(false);
    var loggedUserTZ = mtz.tz.guess();
    Functions.InitializeApplication(loggedUserTZ).then(resp => {
      //console.log("got UserTabs:", resp);
      if (resp.data.success) {
        var response = resp.data;

        var userDetails = response.userDetails;
        userStore.setUserDetails(userDetails);
        userStore.setbaseUserDetails(userDetails);
        userStore.setMe(userDetails);
        userStore.setPreferences(userDetails.preferences);
        userStore.setbasePreferences(userDetails.preferences);

        var tabs = response.userTabs;
        tabModelStore.setTabsJson(JSON.stringify(tabs));

        var inputData = {};
        inputData.data = {};
        inputData.data.data = response.gridDataModel;

        tabModelStore.setCurrentTabColoumns(inputData);

        inputData.data = {};
        inputData.data = response.completeGridData; // TODO validate the Performance
        tabModelStore.setCurrentScreenDataJson(inputData);
        tabModelStore.setCurrentScreenDataLoading(false);
        tabModelStore.setChartCategoryData(JSON.stringify(response.viewNames));
        tabModelStore.setChartViewData(JSON.stringify(response.subViewOptions));
        // UIFunctions.switchChart(tabModelStore.getActiveChartCategory, tabModelStore.getActiveTab.ChartViewId, tabModelStore.getActiveTab.TabId)
        tabModelStore.setActiveCategoryId(
          tabModelStore.getActiveTab.ChartCategoryId
        );
        tabModelStore.setChartId(tabModelStore.getActiveTab.ChartViewId);
        tabModelStore.setWorkingHours(
          tabModelStore.getActiveTab.NoOfWorkingHours
        );
        tabModelStore.setChartBucketType(tabModelStore.getActiveTab.BucketType);
        tabModelStore.setPreset(tabModelStore.getActiveTab.DatePreset);
        //   UIFunctions.setPreset(tabModelStore.getActiveTab.DatePreset);
        tabModelStore.setTabStartDate(
          moment(tabModelStore.getActiveTab.ChartStartDate)
        );
        tabModelStore.setTabEndDate(
          moment(tabModelStore.getActiveTab.ChartEndDate)
        );
        //   return Functions.GetAssetCountByLocation(tabModelStore.getActiveTab.TabId).then((resp) => {
        //       var dataProvider = resp.data.data;
        //       var config = chartConfig.assetCountByLoc;
        //
        //       config.dataProvider = dataProvider;
        //       tabModelStore.setChartConfig(config);
        //       return onSuccess('success');
        //   }).catch(onError)
       
        this.loaded = true;
        tabModelStore.setDataLoaded(true);
        document.getElementsByTagName("BODY")[0].className =
          "app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden pace-done pace-done";
        document.getElementsByTagName("BODY")[0].id = "body";
        addAssetsStore.getDropDownValues();
        userStore.userDetails.CustomerId == ""
          ? ""
          : addAssetsStore.getAllApi("CreateAsset");
        //addAssetsStore.getAllApi("CreateAsset");
      }
    });
  }
  updateData() {}

  onTabChange(tabId) {
    var value = tabId;
    tabModelStore.setDataLoaded(false);
    tabModelStore.setBackButtonVisibility(false);
    // value = document.querySelector('#tabSelect').value;
    // if (value) {
    if (tabId) {
      //setting active tab in the server
      Functions.SetActiveTab(value).then(() => {
        //console.log("updating..")
        Functions.GetUserTab().then(resp => {
          //console.log("got UserTabs:", resp);
          if (resp.data.success && resp.data.tabs) {
            var tabss = resp.data.tabs;
            //console.log("tabsnumber:", Object.keys(tabss).length)
            tabModelStore.setTabsJson(JSON.stringify(tabss));
            //console.log("testTabsFormStore:", JSON.stringify(tabModelStore.getTabs))
          }
          UIFunctions.ReRenderGrid().then(() => {
            //console.log("respGrid", resp)
            tabModelStore.onChartActive
              ? UIFunctions.ReRenderChart().then(() => {
                  this.loaded = true;
                  tabModelStore.setDataLoaded(true);
                  //console.log("respChart", resp)
                })
              : tabModelStore.setOnTabActive(true);
            this.loaded = true;
            tabModelStore.setDataLoaded(true);
          });
        });
      });
    } else {
      Functions.GetUserTab().then(resp => {
        //console.log("got UserTabs:", resp);
        if (resp.data.success && resp.data.tabs) {
          var tabss = resp.data.tabs;
          //console.log("tabsnumber:", Object.keys(tabss).length)
          tabModelStore.setTabsJson(JSON.stringify(tabss));
          //console.log("testTabsFormStore:", JSON.stringify(tabModelStore.getTabs))
        }
        //console.log("got UserTabs:", resp);
        //console.log("autorunfromDashboard fetching tab:", tabModelStore.activeTab);
        //console.log("tabModelStore.getCurrentPage", tabModelStore.getCurrentPage);
        UIFunctions.ReRenderGrid().then(() => {
          //console.log("respGrid", resp)
          tabModelStore.onChartActive
            ? UIFunctions.ReRenderChart().then(() => {
                this.loaded = true;
                tabModelStore.setDataLoaded(true);
                //console.log("respChart", resp)
              })
            : "";
          this.loaded = true;
          tabModelStore.setDataLoaded(true);
        });
      });
    }
  }

  render() {
    // //console.log("Full renders")

    return (
      <div className="app">
        {this.loaded ? (
          <div>
            <Header
              activeTab={tabModelStore.activeTab}
              tabs={tabModelStore.tabs}
              onTabChange={this.onTabChange}
            />
            <div className="app-body">
              <Sidebar {...this.props} />
              <main style={{ width: "100%" }}>
                {/* <Breadcrumb /> */}
                <Switch>
                  <Route
                    path="/dashboard"
                    name="Dashboard"
                    component={Dashboard}
                  />
                  <Route
                    path="/reports"
                    name="Dashboard"
                    component={Spotfire}
                  />
                  <Route
                    path="/charts"
                    name="Charts"
                    component={Charts}
                    loading={permissionStore.chartLoading}
                    config={tabModelStore.chartConfig}
                  />
                  {/*<Redirect from="/" to="/dashboard"/>*/}
                </Switch>
              </main>
              <Aside />
            </div>
            <Footer authed={this.props.authed} />
          </div>
        ) : (
          <div
            className="divCenterrr"
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              marginTop: "-50px",
              marginLeft: "-50px",
              width: 100,
              height: 100
            }}
          >
            <div className="loaderrr" />
          </div>
        )}
      </div>
    );
  }
}

export default Full;
