import React, { Component } from "react";
import { observer } from 'mobx-react';
import {DatePicker} from 'antd';
import moment from 'moment';

@observer class AddRequestItems extends Component {


  constructor(props) {
    super(props);
    this.state={
      name:'',
      emailAddress:'',
      mobileNumber:''
    }
  }

  handleAddReq(){

  }
  handleCancel(){
    document.getElementById("thisWrapper").style.display = "none"
  }
  render() {
    return (
      <div className='addRequestWrapper' id='thisWrapper'>
        <div className='newItemText'><h6><b>Add New Items</b></h6></div>
        <div className='row' style={{ padding: '0 36px'}}>
          <div className='col-lg-6'>
            <div className='inputField'>
              <div>Manufacture</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Serial Number</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Model Number</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Asset Number</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Attach Fault Report/Cal Spec</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Requested Service</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div> 

            <div className='inputField'>
              <div>Preferred Date</div>&nbsp;
              <div><DatePicker style={{marginRight:15}} defaultValue={moment('2017-01-01', 'YYYY-MM-DD')} /></div>
            </div>  

            <div className='inputField'>
              <div>Fault Description</div>&nbsp;
              <div><input type="text-area" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>        
          </div>          
          
          <div className='col-lg-6'>
            <div className='inputField'>
              <div>Calibration Cycle</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Service Agreement</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Pament Method</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Purchase Order Number</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Attach Purchase Order</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>

            <div className='inputField'>
              <div>Requested Service</div>&nbsp;
              <div><input type="text" onChange={e => this.setState({ name: e.target.value })} /></div>
            </div>
          </div>
        </div>
        <div className='row' style={{ display:'flex', justifyContent:'flex-end', padding: '24px 50px 50px'}}>
          <button type="button" className="aaSmallBtn btn btn-primary btn-sm" onClick={this.handleCancel.bind(this)}>Cancel</button>
          <button type="button" className="aaSmallBtn btn btn-primary btn-sm" onClick={this.handleAddReq.bind(this)}>Add</button>
        </div>
      </div>
    )
  }
}

export default AddRequestItems;
