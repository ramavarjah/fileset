import React, { Component } from "react";
import { Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import "../../helpers/Antd/antd.css"; // new line of code
import ReactDataGrid from "react-data-grid";
import AddRequestItems from "./AddRequestItems";
// import DatePicker from 'react-bootstrap-date-picker'

// import 'moment/locale/en-gb';
// moment.locale('en-gb');

class ServiceRequest extends Component {
    constructor(props) {
        super(props);

        this.createRows();
        this._columns = [
            { key: "id", name: "ID" },
            { key: "title", name: "Equipment Number" },
            { key: "manufacturer", name: "Manufacturer" },
            { key: "serial", name: "Serial Number" },
            { key: "count", name: "Count" }
        ];

        this.state = {
            modal: true,
            nextClicked: false,
            addRequest: false
        };
    }

  createRows = () => {
      let rows = [];
      for (let i = 1; i < 100; i++) {
          rows.push({
              id: i,
              title: "company " + i,
              manufacturer: "manufacturer " + i,
              serial: i,
              count: i * 100
          });
      }

      this._rows = rows;
  };

  rowGetter = i => {
      return this._rows[i];
  };

  toggleNew() {
      if (this.state.modal) {
          this.setState({ modal: false });
      } else {
          this.setState({ modal: true });
      }
  }

  handleNext() {
      this.setState({ nextClicked: true });
  }

  handleAddReq() {
      if (this.state.addRequest) {
          this.setState({ addRequest: false });
      } else {
          this.setState({ addRequest: true });
      }
  }
  render() {
      return (
          <div className="loanPool row">
              <Modal
                  isOpen={this.state.modal}
                  toggle={this.toggleNew.bind(this)}
                  className="modal-dialog modal-lg newWidth"
                  id="createAssetModal"
              >
                  <ModalHeader
                      className="row modalHeader LoanPoolModal"
                      style={{
                          borderBottom: "1px solid #4e4e4e",
                          backgroundColor: "#2d2d32"
                      }}
                  >
                      <span className="createAssetLabel" style={{ color: "#fff" }}>
              Service Request
                      </span>
                      <span
                          onClick={this.toggleNew.bind(this)}
                          style={{ cursor: "pointer" }}
                      >
                          <i className="icon-close" style={{ top: 0 }} />
                      </span>
                  </ModalHeader>

                  <ModalBody
                      style={{
                          padding: 0,
                          borderTop: "1px solid #4e4e4e",
                          backgroundColor: "#34343b",
                          color: "#fff"
                      }}
                  >
                      <div>
                          <div className="row">
                              <div className="col-lg-3" />
                              <div className="col-lg-6 stepsWrapper">
                                  <div id="step1">1</div>
                                  <div id="step1">2</div>
                                  <div id="step1">3</div>
                                  <div id="step1">4</div>
                              </div>
                              <div className="col-lg-3" />
                          </div>
                          <div className="tableStyle" style={{ margin: "0 20px 20px" }}>
                              <ReactDataGrid
                                  columns={this._columns}
                                  rowGetter={this.rowGetter}
                                  rowsCount={this._rows.length}
                                  minHeight={320}
                              />
                              <h1>hello</h1>
                          </div>
                          <div style={{ textAlign: "right" }}>
                              <div className="addName" onClick={this.handleAddReq.bind(this)}>
                  Add new item to this Request
                              </div>
                          </div>
                          {this.state.addRequest ? (
                              <div>
                                  <AddRequestItems />
                              </div>
                          ) : (
                              ""
                          )}
                      </div>
                  </ModalBody>

                  <ModalFooter style={{ backgroundColor: "#2d2d32", padding: 25 }}>
                      {/* 'Footer Buttons' */}
                      {!this.state.nextClicked ? (
                          <div id="createAssetFooterButtons">
                              <button
                                  type="button"
                                  className="srButton btn btn-primary btn-sm"
                                  onClick={this.toggleNew.bind(this)}
                              >
                  Back
                              </button>
                              <button
                                  type="button"
                                  className="srButton btn btn-primary btn-sm"
                                  onClick={this.toggleNew.bind(this)}
                              >
                  Cancel
                              </button>
                              <button
                                  type="button"
                                  className="srButton btn btn-primary btn-sm"
                                  onClick={this.handleNext.bind(this)}
                              >
                  Continue
                              </button>
                          </div>
                      ) : (
                          <div id="createAssetFooterButtons" style={{ margin: "0 500px" }}>
                              <button
                                  type="button"
                                  className="createButton aaSmallBtn btn btn-primary btn-sm"
                                  bsSize="large"
                                  onClick={this.toggleNew.bind(this)}
                              >
                  Create
                              </button>
                          </div>
                      )}
                  </ModalFooter>
              </Modal>
          </div>
      );
  }
}
export default ServiceRequest;
