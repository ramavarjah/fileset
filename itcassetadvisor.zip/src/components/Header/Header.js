/* eslint "react/no-deprecated":0 */
import React, { Component } from "react";
import Autosuggest from "react-autosuggest";
import PropTypes from "prop-types";
import { Dropdown, DropdownMenu, DropdownToggle } from "reactstrap";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { Icon, Tooltip } from "antd";
import Filter from "../../components/Filter/";
import { signOut } from "../../helpers/auth";
import Functions from "../../api/Functions";
import tabModelStore from "../../stores/tabModelStore";
import UIFunctions from "../../helpers/UIFunctions";
import { observer } from "mobx-react";
// import Reorder, { reorder } from 'react-reorder';
import _ from "lodash";
import ReactTooltip from "react-tooltip";
// Using an ES6 transpiler like Babel
import {
  SortableContainer,
  SortableElement,
  SortableHandle,
  arrayMove
} from "react-sortable-hoc";
import moment from "moment";

//utillities
const dates = [
  "ReplacementDate",
  "CalibrationDate",
  "CalibrationDueDate",
  "LastServiceDate",
  "ServiceDueDate",
  "PlannedDisposalDate",
  "OrderDate",
  "ReceivedDate",
  "BookValueDate",
  "InventoryDate",
  "LastUpdate"
];

const renderSuggestion = suggestion => {
  return (
    <div
      style={{
        color: "white",
        zIndex: 10000000,
        backgroundColor: "grey",
        marginBottom: 1,
        borderBottomColor: "black",
        cursor: "pointer"
      }}
    >
      {suggestion.searchValue}
    </div>
  );
};

const getSectionSuggestions = section => {
  return section.results;
};

const getSuggestionValue = suggestion => suggestion.searchValue;
@observer
class Header extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    // this.makeline = this.makeline.bind(this);
    this.onTabChange = this.onTabChange.bind(this);
    this.search = _.debounce(this.search.bind(this), 1000);
    this.onTabDelete = this.onTabDelete.bind(this);
    this.state = {
      rename: false,
      dropdownOpen: false,
      addClicked: false,
      modal: false,
      filterClicked: false,
      TabName: null,
      options: null,
      searchText: "",
      value: "",
      suggestions: [],
      items: ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Item 6"],
      width: 0,
      height: 0,
      cloneLoading:false
    };
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this);
  }
  renderSectionTitle = suggestion => {
    if (suggestion.title.colName === "No") {
      return <div>{"No results found"}</div>;
    } else if (dates.indexOf(suggestion.title.colName) > -1)
      return (
        <div>
          {suggestion.results.length +
            " results in " +
            suggestion.title.colHeaderName}
        </div>
      );
    else
      return (
        <div
          onClick={() => this.suggestionTitleSelected(suggestion)}
          style={{ textDecoration: "underline", cursor: "pointer" }}
        >
          {suggestion.results.length +
            " results in " +
            suggestion.title.colHeaderName}
        </div>
      );
  };

  suggestionTitleSelected = e => {
    var resultData = {
      colName: e.title.colName,
      colHeaderName: e.title.colHeaderName,
      searchValue: this.state.value,
      operator: "contains"
      // 'searchStr': docs[i][key][0] + " in " + test[key],
    };
    var event = "";
    var click = "";

    var self = this;
    this.setState({ suggestions: [] }, () =>
      self.onSuggestionSelected(event, { suggestion: resultData, click })
    );
  };

  componentDidMount() {
    this.updateWindowDimensions();
    // tabModelStore.setHideHeader(true)
    window.addEventListener("resize", this.updateWindowDimensions);
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.updateWindowDimensions);
  }

  updateWindowDimensions() {
    this.setState({ width: window.innerWidth, height: window.innerHeight });
  }

  onChange = (event, { newValue }) => {
    // console.log("On Change : ", newValue);
    this.setState({
      value: newValue
    });
    // search(value)
  };

  onSuggestionSelected = (event, { suggestion }) => {
    var filterparams = { type: "string" };
    if (dates.indexOf(suggestion.colName) > -1) {
      filterparams.operator = "equal";
      filterparams.type = "date";
      suggestion.searchValue = new Date(suggestion.searchValue).toISOString();
    }
    var FilterData = {};
    FilterData.TabId = tabModelStore.activeTab.TabId;
    FilterData.baseQuery = {
      condition: "AND",
      rules: [
        {
          field: suggestion.colHeaderName,
          id: suggestion.colName,
          input: "text",
          operator: suggestion.operator ? suggestion.operator : "equal",
          type: filterparams.type,
          value: suggestion.searchValue
        }
      ],
      valid: true
    };
    FilterData.filterQuery = {};
    Functions.SetFilters(FilterData).then(() => {
      tabModelStore.setDataLoaded(false);
      tabModelStore.activeTab.baseQuery = FilterData.baseQuery;
      Functions.GetUserTab().then(resp => {
        if (resp.data.success && resp.data.tabs) {
          var tabss = resp.data.tabs;
          tabModelStore.setTabsJson(JSON.stringify(tabss));
        }
        UIFunctions.ReRenderGrid().then(() => {
          tabModelStore.onChartActive
            ? UIFunctions.ReRenderChart().then(() => {
                this.loaded = true;
                tabModelStore.setDataLoaded(true);
                //console.log("respChart", resp)
              })
            : tabModelStore.setOnTabActive(true);
          this.loaded = true;
          tabModelStore.setDataLoaded(true);
        });
      });
    });
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };
  search(value) {
    // console.log("search Value : ", value)
    if (value.value.length >= 2) {
      this.setState({ value: value.value });
      Functions.GetSolrSearchResult(value.value, "Global").then(resp => {
        //tabModelStore.setSolrSearchResult(resp.data);
        //buildSearchList(resp.data.response,this.state.searchText);
        var srcStr = value.value;
        var response = resp.data.response;
        var data = [];
        if (response && response.numFound > 0) {
          var docs = response.docs;
          var len = docs.length;
          var exist;
          var FieldDisplayNames = {};
          var displayNames = JSON.parse(
            JSON.stringify(tabModelStore.currentTabColoumnsArray)
          );

          for (var j = 0; j < displayNames.length; j++) {
            FieldDisplayNames[displayNames[j].field] =
              displayNames[j].headerName;
          }
          // console.log("Display Names..", test);
          for (var i = 0; i < len; i++) {
            // Processing the docs
            for (var key in docs[i]) {
              if (dates.indexOf(key) > -1)
                // Changing dates to required format
                docs[i][key][0] = moment(docs[i][key][0]).format("YYYY/MM/DD");
              if (typeof docs[i][key][0] != "string") {
                // Changing all values to String
                docs[i][key] = "" + docs[i][key];
              }
              if (
                typeof docs[i][key] === "string" &&
                docs[i][key].toLowerCase().indexOf(srcStr.toLowerCase()) >= 0
              ) {
                exist = false;

                for (var index = 0; index < data.length; index++) {
                  var item = data[index];

                  item.results.map(result => {
                    if (
                      result.colName === key &&
                      result.searchValue === docs[i][key]
                    ) {
                      // Condition to check whether the entry is already there or not
                      exist = true;
                    }
                  });
                }
                if (!exist) {
                  var flag = true;
                  var resultData = {
                    colName: key,
                    colHeaderName: FieldDisplayNames[key],
                    searchValue: docs[i][key]
                    // 'searchStr': docs[i][key][0] + " in " + test[key],
                  };
                  data.map(item => {
                    if (item.title.colHeaderName === FieldDisplayNames[key]) {
                      // If group(JSON) exists , adding to the results
                      item.results.push(resultData);
                      item.title = {
                        colName: key,
                        colHeaderName: FieldDisplayNames[key]
                      };
                      flag = false; // after Adding setting the flag to false
                    }
                  });
                  if (flag) {
                    var newObj = {};
                    newObj.results = [];
                    newObj.title = {
                      colName: key,
                      colHeaderName: FieldDisplayNames[key]
                    };
                    newObj.results.push(resultData);
                    data.push(newObj);
                  }
                }
              }
            }
          }
        }
        data.map(item => {
          item.results = _.sortBy(item.results, ["searchValue"]);
        });
        var sortedData = _.sortBy(data, [
          function(o) {
            return -o.results.length;
          }
        ]);

        if (sortedData.length == 0) {
          var NoResultObj = {};
          NoResultObj.results = [{}];
          NoResultObj.title = { colName: "No", colHeaderName: "No" };
          sortedData.push(NoResultObj);
        }

        this.setState({ suggestions: sortedData });
        tabModelStore.setSolrSearchResult(sortedData);
      });
    }
  }
  componentWillReceiveProps(nextProps) {
    //console.log("tabs length:",JSON.parse(tabModelStore.tabs))
    var arrTen = [];
    var result = JSON.parse(nextProps.tabs);
    for (var k = 0; k < result.length; k++) {
      var item = result[k];
      // //console.log(item.TabName);
      // arrTen.push(<option key={item.TabId} selected={item.Active} value={item.TabId}> {item.TabName} </option>);
      arrTen.push(item);
    }
    // console.log('arrTen', arrTen)

    this.setState({
      options: arrTen
    });
    //console.log('options',this.state.options)
  }
  componentWillMount() {
    var arrTen = [];
    var result = JSON.parse(this.props.tabs);
    for (var k = 0; k < result.length; k++) {
      var item = result[k];
      arrTen.push(item);
    }
    this.setState({
      options: arrTen
    });
  }

  handleRename() {
    tabModelStore.setRemaneButtonLoading(true);
    var tabName = document.getElementById("newGroupName").value;
    if (!tabName.replace(/\s/g, "").length) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Asset group cannot be blank!"
      });
      tabModelStore.setRemaneButtonLoading(false);
      return;
    }
    var isExist = false;
    this.state.options &&
      this.state.options.map(item => {
        if (item.TabName == tabName) {
          isExist = true;
        }
      });
    if (isExist) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Asset group " + tabName + " already exist!"
      });
      tabModelStore.setRemaneButtonLoading(false);
      return;
    }

    var tabId = this.state.rename.TabId;
    tabName = document.getElementById("newGroupName").value;
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure want to Rename the group to  " + tabName,
      okText: "Yes",
      cancelText: "No",
      onOk() {
        tabModelStore.renameTab(tabName, tabId).then(() =>
          Functions.GetUserTab()
            .then(resp => {
              if (resp.data.success && resp.data.tabs) {
                var tabs = resp.data.tabs;
                tabModelStore.setTabsJson(JSON.stringify(tabs));
                var arrTen = [];
                for (var k = 0; k < tabs.length; k++) {
                  var item = tabs[k];
                  arrTen.push(item);
                }
                self.setState({
                  options: arrTen
                });
                self.rename(false);
              }
            })
            .then(() => {
              tabModelStore.setRemaneButtonLoading(false);
            })
        );
      },
      onCancel() {
        tabModelStore.setRemaneButtonLoading(false);
      }
    });
  }

  handleCloneTab() {
    this.setState({ cloneLoading: true });
    var tabId = tabModelStore.activeTab.TabId;
    var tabName = document.getElementById("newGroupName").value;
    if (!tabName.replace(/\s/g, "").length) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Asset group cannot be blank!"
      });
      this.setState({ cloneLoading: false });
      return;
    }
    var isExist = false;
    this.state.options &&
      this.state.options.map(item => {
        if (item.TabName == tabName) {
          isExist = true;
        }
      });
    if (isExist) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Asset group " + tabName + " already exist!"
      });
      this.setState({ cloneLoading: false });
      return;
    }
    var self = this;
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Are you sure want to clone group " + tabName,
      okText: "Yes",
      cancelText: "No",
      // content: 'When clicked the OK button, this dialog will be closed after 1 second',
      onOk() {
        self.setState({cloneLoading:true})
        Functions.CloneTab(tabId, tabName).then(() => {
          Functions.GetUserTab()
            .then(resp => {
              // tabModelStore.reRenderGrid();
              if (resp.data.success && resp.data.tabs) {
                var tabs = resp.data.tabs;
                tabModelStore.setTabsJson(JSON.stringify(tabs));
                var arrTen = [];
                for (var k = 0; k < tabs.length; k++) {
                  var item = tabs[k];
                  arrTen.push(item);
                }
                self.setState({
                  options: arrTen,
                  cloneLoading:false
                });
                self.toggleNew();
              }
            })
            .then(() => {
              this.setState({ cloneLoading: false });
            });
        });
      },
      onCancel() {
        this.setState({ cloneLoading: false });
    
      }
    });
  }
  handleNewTab() {
    tabModelStore.setCreateButtonLoading(true);
    var tabName = document.getElementById("newGroupName").value;
    if (!tabName.replace(/\s/g, "").length) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Asset group cannot be blank!"
      });
      tabModelStore.setCreateButtonLoading(false);
      return;
    }
    var isExist = false;
    this.state.options &&
      this.state.options.map(item => {
        if (item.TabName == tabName) {
          isExist = true;
        }
      });
    if (isExist) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title: "Asset group " + tabName + " already exist!"
      });
      tabModelStore.setCreateButtonLoading(false);
      return;
    }
    Functions.CreateUserTab(tabName).then(() => {
      Functions.GetUserTab()
        .then(resp => {
          if (resp.data.success && resp.data.tabs) {
            var tabs = resp.data.tabs;
            tabModelStore.setTabsJson(JSON.stringify(tabs));
            var arrTen = [];
            for (var k = 0; k < tabs.length; k++) {
              var item = tabs[k];
              // arrTen.push(<option key={item.TabId} selected={item.Active} value={item.TabId}> {item.TabName} </option>);
              arrTen.push(item);
            }
            this.setState({
              options: arrTen
            });
            this.toggleNew();
            if (tabModelStore.onChartActive) {
              tabModelStore.reRenderGrid().then(() => {
                UIFunctions.ReRenderChart().then(() => {});
                tabModelStore.setDataLoaded(true);
              });
            } else {
              tabModelStore.reRenderGrid().then(() => {
                tabModelStore.setDataLoaded(true);
              });
            }
          }
        })
        .then(() => {
          tabModelStore.setCreateButtonLoading(false);
        });
    });
  }

  toggle() {
    // console.log("toggle");
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  }

  toggleNew() {
    this.setState({
      modal: !this.state.modal
    });
  }

  sidebarToggle(e) {
    e.preventDefault();
    document.body.classList.toggle("sidebar-hidden");
  }

  sidebarMinimize(e) {
    e.preventDefault();
    document.body.classList.toggle("sidebar-minimized");
  }

  mobileSidebarToggle(e) {
    e.preventDefault();
    document.body.classList.toggle("sidebar-mobile-show");
  }

  asideToggle(e) {
    e.preventDefault();
  }
  handleAdd() {
    document.getElementById("exampleModal").classList.toggle("show");
    if (!this.state.addClicked) {
      document.body.classList.toggle("modal-open");
      this.setState({ addClicked: true });
      document.getElementById("exampleModal").style.display = "block";
    } else {
      this.setState({ addClicked: false });
      // document.getElementById("exampleModal").classList.remove("show")
      document.getElementById("exampleModal").style.display = "none";
    }
  }
  loadClick() {
    document.getElementById("exampleModal").classList.toggle("show");
    document.getElementById("exampleModal").style.display = "block";
  }
  logout() {
    //e.preventDefault()
    // UIFunctions.Toast("testtttttt","info");
    signOut();
  }
  handleFilterClick() {
    if (tabModelStore.filterModalOpen) {
      tabModelStore.setFilterModalopen(false);
    } else {
      tabModelStore.setFilterModalopen(true);
    }
  }
  formatfilterDate(baseQueryy) {
    //console.log(JSON.parse(JSON.stringify(baseQuery)));
    var baseQuery = JSON.parse(JSON.stringify(baseQueryy));
    var noOfRules = baseQuery.rules ? baseQuery.rules.length : 0;

    // console.log("Inside..",baseQuery.rules.length)
    if (noOfRules == 1) {
      // if(baseQuery.rules[0].operator == "in" || baseQuery.rules[0].operator == "not_in"){
      //       var value = baseQuery.rules[0].value.split(",");
      //   }
      if (baseQuery.rules[0].type == "date") {
        if (
          baseQuery.rules[0].operator == "between" ||
          baseQuery.rules[0].operator == "not_between"
        ) {
          baseQuery.rules[0].value[0] = moment(
            baseQuery.rules[0].value[0]
          ).format("YYYY/MM/DD");
          baseQuery.rules[0].value[1] = moment(
            baseQuery.rules[0].value[1]
          ).format("YYYY/MM/DD");
        } else {
          baseQuery.rules[0].value = moment(baseQuery.rules[0].value).format(
            "YYYY/MM/DD"
          );
        }
      }
    } else {
      for (var i = 0; i < noOfRules; i++) {
        if (baseQuery.rules[i].rules == undefined) {
          // || baseQuery.rules[i].operator == "in" || baseQuery.rules[i].operator == "not_in"
          if (baseQuery.rules[i].type == "date") {
            if (
              baseQuery.rules[i].operator == "between" ||
              baseQuery.rules[i].operator == "not_between"
            ) {
              baseQuery.rules[i].value[0] = moment(
                baseQuery.rules[i].value[0]
              ).format("YYYY/MM/DD");
              baseQuery.rules[i].value[1] = moment(
                baseQuery.rules[i].value[1]
              ).format("YYYY/MM/DD");
            } else {
              baseQuery.rules[i].value = moment(
                baseQuery.rules[i].value
              ).format("YYYY/MM/DD");
            }
          }
        } else {
          baseQuery.rules[i] = this.formatfilterDate(baseQuery.rules[i]);
        }
      }
    }
    return baseQuery;
  }
  formatFilterTags(resultt) {
    var result = this.formatfilterDate(resultt);
    // console.log("formatFilterTags",result);

    var filterTagObj = new Object();
    if (typeof result === "string") result = JSON.parse(result);
    var filterTag = "";
    if (Object.keys(result).length !== 0) {
      for (var i = 0; i < result.rules.length; i++) {
        if (result.rules[i].hasOwnProperty("condition")) {
          for (var ii = 0; ii < result.rules[i].rules.length; ii++) {
            if (result.rules[i].rules[ii].hasOwnProperty("condition")) {
              for (
                var iii = 0;
                iii < result.rules[i].rules[ii].rules.length;
                iii++
              ) {
                if (
                  result.rules[i].rules[ii].rules[iii].hasOwnProperty(
                    "condition"
                  )
                ) {
                  for (
                    var iiii = 0;
                    iiii < result.rules[i].rules[ii].rules[iii].rules.length;
                    iiii++
                  ) {
                    filterTag =
                      filterTag.replace("))", "") +
                      " ( " +
                      this.concatFilterTags(
                        result.rules[i].rules[ii].rules[iii],
                        iiii
                      ) +
                      ") ) )";
                  }
                } else {
                  filterTag =
                    filterTag.replace(")", "") +
                    " ( " +
                    this.concatFilterTags(result.rules[i].rules[ii], iii) +
                    " ) ) " +
                    (iii == result.rules[i].rules[ii].rules.length - 1
                      ? ""
                      : result.rules[i].rules[ii].condition);
                }
              }
            } else {
              filterTag =
                filterTag +
                " ( " +
                this.concatFilterTags(result.rules[i], ii) +
                " ) " +
                (ii == result.rules[i].rules.length - 1
                  ? ""
                  : result.rules[i].condition);
            }
          }
        } else {
          filterTag =
            filterTag +
            " " +
            this.concatFilterTags(result, i) +
            " " +
            (i == result.rules.length - 1 ? "" : result.condition);
        }
      }
    }
    var filterLength = this.state.width / 10 - 70;
    // console.log(filterLength);
    filterTagObj.filterTagAlt = filterTag;
    filterTagObj.filterTag =
      filterTag.length > filterLength
        ? filterTag.substring(0, filterLength) + " ..."
        : filterTag;

    return filterTagObj;
  }

  operatorLib = {
    equal: { type: "EQ", value: "value", category: "comparison", symbol: "=" },
    not_equal: {
      type: "NE",
      value: "value",
      category: "comparison",
      symbol: "!="
    },
    in: { type: "IN", value: "value", category: "list", symbol: "in" },
    less: { type: "LT", value: "value", category: "comparison", symbol: "<" },
    less_or_equal: {
      type: "LE",
      value: "value",
      category: "comparison",
      symbol: "<="
    },
    greater: {
      type: "GT",
      value: "value",
      category: "comparison",
      symbol: ">"
    },
    greater_or_equal: {
      type: "GE",
      value: "value",
      category: "comparison",
      symbol: ">="
    },
    between: {
      type: "Between",
      value: "value",
      category: "range",
      symbol: "Between"
    },
    not_between: {
      type: "NotBetween",
      value: "value",
      category: "range",
      symbol: "Not Between"
    },
    begins_with: {
      type: "LIKE",
      value: "value*",
      category: "comparison",
      symbol: "Begins with"
    },
    not_begins_with: {
      type: "NOTLIKE",
      value: "value*",
      category: "comparison",
      symbol: "Not Begins with"
    },
    contains: {
      type: "LIKE",
      value: "*value*",
      category: "comparison",
      symbol: "Contains"
    },
    not_contains: {
      type: "NOTLIKE",
      value: "*value*",
      category: "comparison",
      symbol: "Not Contains"
    },
    ends_with: {
      type: "LIKE",
      value: "*value",
      category: "comparison",
      symbol: "Ends with"
    },
    not_ends_with: {
      type: "NOTLIKE",
      value: "*value",
      category: "comparison",
      symbol: "Not Ends With"
    },
    is_empty: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsEmpty"
    },
    is_not_empty: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNotEmpty"
    },
    is_null: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNull"
    },
    is_not_null: {
      type: "MissingValue",
      value: null,
      category: "comparison",
      symbol: "IsNotNull"
    }
  };

  handleEmptyRulesClick() {
    //  const newRules = { ...emptyRule };
    // newRules.rules[0].value = newRules.rules[0].value + 10;
    // //console.log(" Set Rules clicked" + newRules);
    //  $(this.refs.queryBuilder).queryBuilder('setRules', newRules);
    // //console.log("rule", newRules);
    // this.setState({ rules: newRules });
    var tabId = tabModelStore.activeTab.TabId;
    tabModelStore.setDataLoaded(false);
    tabModelStore.setServiceDueChartLoading(true);
    tabModelStore.setChartLoading(true);
    Functions.ClearFilters(tabId).then(() => {
      // //console.log("Fliters are cleared");
      //  this.toggleNew();
      Functions.GetUserTab().then(resp => {
        if (resp.data.success && resp.data.tabs) {
          var tabss = resp.data.tabs;
          tabModelStore.setTabsJson(JSON.stringify(tabss));
        }
        UIFunctions.ReRenderGrid().then(() => {
          //console.log("respGrid", resp)
          tabModelStore.onChartActive
            ? UIFunctions.ReRenderChart().then(() => {
                this.loaded = true;
                tabModelStore.setDataLoaded(true);
                //console.log("respChart", resp)
              })
            : tabModelStore.setOnTabActive(true);
          this.loaded = true;
          tabModelStore.setDataLoaded(true);
        });
      });
      tabModelStore.activeTab.baseQuery = {};
    });
    this.setState({ value: "", suggestions: [] });
  }

  concatFilterTags(result, i) {
    // console.log("concatFilterTags",result,i);
    var filter = result.rules[i],
      retStr = "";
    if (this.operatorLib.hasOwnProperty(filter.operator)) {
      var operatorObj = this.operatorLib[filter.operator];

      if (operatorObj.category == "comparison") {
        // console.log("filter.value", filter)
        retStr =
          filter.field +
          " " +
          operatorObj.symbol +
          " " +
          (filter.value != undefined || filter.value != null
            ? filter.value != "1970/01/01"
              ? JSON.stringify(filter.value + "")
              : ""
            : "");
        // retStr = filter.field + ' ' + operatorObj.symbol + ' ' + JSON.stringify(filter.value);
      } else if (operatorObj.category == "list") {
        var str = JSON.stringify(filter.value);
        retStr = filter.field + " " + operatorObj.symbol + " " + str;
      } else if (operatorObj.category == "range") {
        retStr =
          filter.field +
          " " +
          operatorObj.symbol +
          " ( " +
          filter.value[0] +
          " AND " +
          filter.value[1] +
          " ) ";
      }
    }
    return retStr;
  }

  rename(item) {
    this.setState({ rename: item });
  }
  onTabChange(item, e) {
    var self = this;
    if (e.target.id == "edit") {
      this.rename(item);
    } else if (e.target.id == "delete")
      UIFunctions.Confirm({
        zIndex: 2000,
        title: "Are you sure want to delete group " + item.TabName,
        okText: "Yes",
        cancelText: "No",
        // content: 'When clicked the OK button, this dialog will be closed after 1 second',
        onOk() {
          self.onTabDelete(item, e);
        },
        onCancel() {}
      });
    else {
      tabModelStore.setActiveTab(item);
      this.props.onTabChange(item.TabId);
    }
    this.toggle();
    this.setState({ value: "", suggestions: [] });
  }
  onTabDelete(item) {
    var self = this;
    var tabs = JSON.parse(tabModelStore.tabs);
    tabs.length > 1 // check if number of tabs more than 1
      ? item.Active // if active tab delete and set first inactive tab active
        ? Functions.DeleteTab(item.TabId).then(() => {
            var tabId;
            self.props.onTabChange(tabId);
          })
        : Functions.DeleteTab(item.TabId).then(() => {
            self.props.onTabChange(false);
          })
      : UIFunctions.Toast("You can't delete all the tabs !", "error");
  }
  onSortEnd = ({ oldIndex, newIndex }) => {
    this.setState({
      options: arrayMove(this.state.options, oldIndex, newIndex)
    });
    var payload = {};
    payload.TabList = this.state.options;
    Functions.ReorderTabs(payload);
  };

  render() {
    var activetabName = tabModelStore.activeTab.TabName
      ? tabModelStore.activeTab.TabName
      : ".";
    const DragHandle = SortableHandle(() => (
      <span style={{ paddingRight: 0, marginRight: 5 }}>
        <Icon type="arrows-alt" className="drag-handle-icon" />
      </span>
    )); // This can be any component you want

    const SortableItem = SortableElement(({ value, vvalue }) => {
      return (
        <div
          className="customDropdown"
          toggle={"false"}
          onClick={e => {
            this.onTabChange(vvalue, e);
          }}
        >
          <Tooltip placement="right" title={value} className="tool">
            <li
              style={{
                display: "flex",
                padding: " 8px 20px 0px 10px",
                alignItems: "center"
              }}
            >
              <DragHandle />

              <span style={{ flexGrow: 1 }}>
                {" "}
                {value.length > 20 ? value.substring(0, 20) + "..." : value}
              </span>

              <span id="edit" className="pull-right">
                {" "}
                <Icon type="edit" id="edit" />
              </span>
              <span
                id="delete"
                className="pull-right"
                style={{ paddingLeft: 5, marginRight: "-6px" }}
              >
                <Icon
                  type="close-circle-o"
                  id="delete"
                  style={{ paddingLeft: 5, marginRight: "-6px" }}
                />
              </span>
            </li>
          </Tooltip>
        </div>
      );
    });

    const SortableList = SortableContainer(({ items }) => {
      let sortedItems = items.sort(function(a, b) {
        return b.Active - a.Active;
      });

      return (
        <ul>
          {sortedItems.map((value, index) => (
            <SortableItem
              key={`item-${index}`}
              index={index}
              vvalue={value}
              value={value.TabName}
            />
          ))}
        </ul>
      );
    });

    const { value, suggestions,cloneLoading } = this.state;
    const inputProps = {
      placeholder: "Search For Asset...",
      value,
      onChange: this.onChange
    };
    return (
      <div>
        {/* style={{display:tabModelStore.hideHeader ? 'none': 'flex'}} */}
        <header
          id="app-header"
          className="app-header navbar"
          style={{ display: tabModelStore.isVisible ? "none" : "flex" }}
        >
          <div className="row headerContent" style={{marginTop:-5}}>
            <div className="col-sm-2 assetGroups">
              <div className="dropdowntabs dropdown row">
                <div className="col-md-8 col-sm-8">
                  {this.state.options ? (
                    <Dropdown
                      size="sm"
                      style={{ width: "100%" }}
                      isOpen={this.state.dropdownOpen}
                      toggle={this.toggle}
                      className="tooltipcss"
                    >
                      <DropdownToggle
                        disabled={!tabModelStore.dataLoaded}
                        style={{
                          cursor: tabModelStore.dataLoaded
                            ? "pointer"
                            : "not-allowed"
                        }}
                        id="asset-groups-toggle"
                        caret
                      >
                        {activetabName.length > 20
                          ? activetabName.substring(0, 10) + "..."
                          : activetabName}
                      </DropdownToggle>
                      <DropdownMenu>
                        <SortableList
                          items={this.state.options}
                          onSortEnd={this.onSortEnd.bind(this)}
                          useDragHandle={true}
                          helperClass="Drag_drop"
                        />
                      </DropdownMenu>
                      <span className="headertooltiptext">Asset Groups</span>
                    </Dropdown>
                  ) : (
                    ""
                  )}
                </div>
                <div className="col-md-2">
                  <button
                    onClick={this.toggleNew.bind(this)}
                    type="button"
                    className="btn btn-secondary tooltipcss"
                    id="newGroupBtn"
                    data-toggle="modal"
                    data-target=".assetGroupModal"
                  >
                    <i className="fa fa-plus" />
                    <span className="headertooltiptext">New Asset Group</span>
                  </button>
                </div>
              </div>
            </div>
            {/*****'Asset Search Bar'*****/}
            <div className="col-sm-2 searchBar">
              <ul className="nav navbar-nav">
                <li>
                  <a className="searchIcon ">
                    <i className="icon-magnifier tooltipcss">
                      <span className="headertooltiptext">Search Asset</span>
                    </i>
                  </a>
                  <Autosuggest
                    suggestions={suggestions}
                    multiSection={true}
                    onSuggestionsFetchRequested={this.search.bind(this)}
                    onSuggestionsClearRequested={
                      this.onSuggestionsClearRequested
                    }
                    getSuggestionValue={getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    renderSectionTitle={this.renderSectionTitle.bind(this)}
                    getSectionSuggestions={getSectionSuggestions}
                    inputProps={inputProps}
                    onSuggestionSelected={this.onSuggestionSelected}
                  />
                </li>
              </ul>
            </div>
            <div className="col-sm-7 filters">
              <ul className="filters">
                <a onClick={this.handleFilterClick.bind(this)}>
                  <li className="filterTags ">
                    <i
                      className="fa fa-filter tooltipcss"
                      data-toggle="modal"
                      data-target=".filtersModal"
                    >
                      <span className="headertooltiptext">Filter</span>
                    </i>
                  </li>
                </a>
                {this.formatFilterTags(tabModelStore.activeTab.baseQuery)
                  .filterTag.length > 0 ? (
                  <a>
                    <li className="filterTags">
                      <span
                        className="badge badge-pill badge-primary"
                        data-tip={
                          this.formatFilterTags(
                            tabModelStore.activeTab.baseQuery
                          ).filterTagAlt
                        }
                        onClick={this.handleFilterClick.bind(this)}
                      >
                        {
                          this.formatFilterTags(
                            tabModelStore.activeTab.baseQuery
                          ).filterTag
                        }
                      </span>
                      <a>
                        <i
                          className="icon-close"
                          style={{ marginTop: 5 }}
                          onClick={this.handleEmptyRulesClick.bind(this)}
                        />
                      </a>
                    </li>
                    <ReactTooltip />
                  </a>
                ) : (
                  ""
                )}
              </ul>
            </div>
          </div>
        </header>

        {tabModelStore.filterModalOpen ? <Filter /> : ""}

        <Modal
          isOpen={this.state.modal}
          className="modal-dialog modal-lg"
          id="assetGroupModal"
        >
          <ModalHeader
            className="row modalHeader modal-dialog modal-lg"
            style={{ borderBottom: "1px solid #ccd0d8" }}
          >
            <span className="filtersLabel">NEW ASSET GROUP</span>
            <span
              onClick={this.toggleNew.bind(this)}
              style={{ cursor: "pointer" }}
            >
              <i className="icon-close" />
            </span>
          </ModalHeader>
          <ModalBody style={{ padding: 0 }}>
            <div
              className="row newGroupContent modal-dialog modal-lg"
              style={{ paddingBottom: 25 }}
              >
              <input
                className="aaTextInput"
                type="text"
                name="newGroupName"
                id="newGroupName"
              />
            </div>
          </ModalBody>
          <ModalFooter>
            <nav
              className="modalFooter navbar"
              style={{
                height: "auto",
                borderTop: "0px",
                width: "100%",
                padding: "0px"
              }}
            >
              <div className="newGroupButtons" style={{ margin: "auto" }}>
                <button
                  type="button"
                  className="aaSmallBtn btn"
                  style={{ margin: "0px" }}
                  onClick={this.handleNewTab.bind(this)}
                  disabled={tabModelStore.createButtonLoading}
                >
               <Icon type= {tabModelStore.createButtonLoading ? "loading" : ""}/>
                  Create Group
                </button>
                <button
                  type="button"
                  className="aaSmallBtn btn"
                  id="cloneGroup"
                  style={{ margin: "0px 0px 0px 10px" }}
                  onClick={this.handleCloneTab.bind(this)}
                  disabled={tabModelStore.createButtonLoading}
                >
                <Icon type= {cloneLoading ? "loading" : ""}/>
                  Clone Group
                </button>
              </div>
            </nav>
          </ModalFooter>
        </Modal>
        <Modal
          isOpen={this.state.rename}
          className="modal-dialog modal-lg"
          id="assetGroupModal"
        >
          <ModalHeader
            className="row modalHeader modal-dialog modal-lg"
            style={{ borderBottom: "1px solid #ccd0d8" }}
          >
            <span className="filtersLabel">Rename The Group</span>
            <span
              onClick={() => this.setState({ rename: false })}
              style={{ cursor: "pointer" }}
            >
              <i className="icon-close" />
            </span>
          </ModalHeader>
          <ModalBody style={{ padding: 0 }}>
            <div
              className="row newGroupContent modal-dialog modal-lg"
              style={{ paddingBottom: 25 }}
            >
              <input
                className="aaTextInput"
                type="text"
                name="newGroupName"
                id="newGroupName"
              />
            </div>
          </ModalBody>
          <ModalFooter>
            <nav
              className="modalFooter navbar"
              style={{
                height: "auto",
                borderTop: "0px",
                width: "100%",
                padding: "0px"
              }}
            >
              <div className="newGroupButtons" style={{ margin: "auto" }}>
                <Button
                  loading={tabModelStore.buttonLoading}
                  type="button"
                  className="aaSmallBtn btn"
                  id="cloneGroup"
                  style={{ margin: "0px 0px 0px 10px" }}
                  onClick={this.handleRename.bind(this)}
                  disabled={tabModelStore.remaneButtonLoading}
                >
                  Rename
                </Button>
              </div>
            </nav>
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}

export default Header;

Header.propTypes = {
  tabs: PropTypes.string,
  onTabChange: PropTypes.func
};
