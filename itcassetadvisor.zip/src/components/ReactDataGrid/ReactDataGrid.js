import React, { Component } from "react";

class Grid extends Component {
  constructor(props) {
    super(props);
    this.rowGetter = this.rowGetter.bind(this);
  }

  state = {
    value: undefined
  };
  onChange = value => {
    //console.log(arguments);
    this.setState({ value });
  };
  componentDidMount() {
    this.createRows();
    //console.log("Dash:will Mount")
  }

  rowGetter(i) {
    return this._rows[i];
  }
  createRows() {
    let rows = [];
    for (let i = 1; i < 1000; i++) {
      rows.push({
        id: i,
        title: "Title " + i,
        count: i * 1000
      });
    }

    this._rows = rows;
  }

  render() {
    //console.log("rendering dashboard..")
    return (
      <div className="animated fadeIn container-fluid">
        <Grid
          columns={[
            { key: "id", name: "ID" },
            { key: "title", name: "Title" },
            { key: "count", name: "Count" }
          ]}
          rowGetter={this.rowGetter}
          rowsCount={this._rows.length}
          minHeight={500}
        />
      </div>
    );
  }
}

export default Grid;
