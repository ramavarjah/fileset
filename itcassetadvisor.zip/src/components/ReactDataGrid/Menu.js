import React from "react";
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem
} from "reactstrap";

import tabModelStore from "../../stores/tabModelStore";
import PropTypes from "prop-types";

const DEFINE_SORT = {
  ASC: "ASC",
  DESC: "DESC",
  NONE: "NONE"
};
export default class HeaderMenu extends React.Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      dropdownOpen: false,
      direction: null
    };
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  }

  onRadioBtnClick(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleAscSort(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleDscSort(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleUnsort(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleHideAll(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleShowAll(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleUnlock(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleLock(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  handleHideColumn(rSelected) {
    tabModelStore.setHideColumn();
    alert(rSelected);
  }
  onClick = () => {
    switch (this.state.direction) {
      default:
      case null:
      case undefined:
      case DEFINE_SORT.NONE:
        this.setState({ direction: DEFINE_SORT.ASC });
        break;
      case DEFINE_SORT.ASC:
        this.setState({ direction: DEFINE_SORT.DESC });
        break;
      case DEFINE_SORT.DESC:
        this.setState({ direction: DEFINE_SORT.NONE });
        break;
    }
    // this.props.onSort(
    //     this.props.columnKey,
    //     direction);
  };

  getSortByText = () => {
    let unicodeKeys = {
      ASC: "9650",
      DESC: "9660"
    };
    return this.state.direction === "NONE"
      ? ""
      : String.fromCharCode(unicodeKeys[this.state.direction]);
  };

  componentDidMount() {
    this.setState({ direction: this.props.sortDirection });
  }
  render() {
    return (
      <div>
        <div
          className="pull-left"
          onClick={this.onClick}
          style={{ cursor: "pointer" }}
        >
          <span className="pull-right">{this.getSortByText()}</span>
          {this.props.headerName}
        </div>
        <div className="pull-right">
          <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
            <DropdownToggle caret />
            <DropdownMenu>
              <DropdownItem
                onClick={() => this.handleAscSort(this.props.columnId)}
              >
                Sort Asending
              </DropdownItem>
              <DropdownItem
                onClick={() => this.handleDscSort(this.props.columnId)}
              >
                Sort Decending
              </DropdownItem>
              <DropdownItem
                onClick={() => this.handleUnsort(this.props.columnId)}
              >
                Unsort
              </DropdownItem>
              <DropdownItem
                onClick={() => this.handleHideAll(this.props.columnId)}
              >
                Hide All Columns
              </DropdownItem>
              <DropdownItem
                onClick={() => this.handleShowAll(this.props.columnId)}
              >
                Show All Columns
              </DropdownItem>
              <DropdownItem divider />
              <DropdownItem
                onClick={() => this.handleHideColumn(this.props.columnId)}
              >
                Hide Column
              </DropdownItem>

              <DropdownItem divider />
              <DropdownItem
                onClick={() => this.handleUnlock(this.props.columnId)}
              >
                Unlock
              </DropdownItem>
              <DropdownItem
                onClick={() => this.handleLock(this.props.columnId)}
              >
                Lock
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </div>
      </div>
    );
  }
}
HeaderMenu.propTypes = {
  headerName: PropTypes.String,
  columnId: PropTypes.String,
  sortDirection: PropTypes.String
};
