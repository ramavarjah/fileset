import React, { Component } from "react";
import { Modal } from "reactstrap";
import ForgotPasswordStore1 from "../../stores/ForgotPasswordStore";
import Functions from "./../../api/Functions";
import UIFunctions from "./../../helpers/UIFunctions";
import "./css/style.scss";

class ForgotPassword extends Component {
	constructor(props) {
		super(props);
		this.doClick = this.doClick.bind(this);
		this.state = {
			emailid: null,
			errorMess: null,
			disabled: false
			// successMess :null
		};
		this.requestNewPassword = this.requestNewPassword.bind(this);
		this.validateEmail = this.validateEmail.bind(this);
	}
	validateEmail(email) {
		let re = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
		return re.test(email);
	}
	requestNewPassword(e) {
		this.setState({
			disabled: true
		});
		e.preventDefault();
		if (this.validateEmail(this.state.emailid)) {
			Functions.mailConformation(this.state.emailid)
				.then(resp => {
					if (resp.data.success) {
						UIFunctions.Toast(resp.data.message, "info");
						ForgotPasswordStore1.toggleModal();
					} else {
						this.setState({
							errorMess: resp.data.message,
							disabled: false
						});
					}
				})
				.catch(() => {
					this.setState({
						errorMess: "Failed, Please try again later !!!",
						disabled: false
					});
				});
		} else {
			this.setState({
				errorMess: "Invalid e-mail format",
				disabled: false
			});
		}
	}
	doClick() {
		ForgotPasswordStore1.toggleModal();
	}
	render() {
		return (
			<Modal
				isOpen={ForgotPasswordStore1.assetDetailModalOpen}
				toggle={this.doClick}
				className="modal-dialog modal-lg fPwd "
			>
				<div>
					<h5>Forgot your password?</h5>
					<span onClick={this.doClick} style={{ cursor: "pointer" }}>
						<i className="icon-close" />
					</span>
					<p>
						Enter your login email address to reset your password. You may need
						to check your spam folder.
					</p>
					<form className="mainForms">
						<div>
							<label htmlFor="emailId">
								email <span>*</span>{" "}
							</label>
							<input
								id="emailId"
								value={this.state.emailid}
								onChange={e => this.setState({ emailid: e.target.value })}
								type="text"
								placeholder="Enter your mail-id"
							/>
						</div>
						<h3 className="errorMess">{this.state.errorMess} </h3>
						{/*
                        <h3 className='successMess'>{this.state.successMess} </h3> */}
						<button
							type="submit"
							name="submit"
							className="mailConfiramationBtn btn btn-primary btn-sm "
							disabled={this.state.disabled}
							onClick={this.requestNewPassword}
						>
							{" "}
							submit{" "}
						</button>
					</form>
				</div>
			</Modal>
		);
	}
}

export default ForgotPassword;
