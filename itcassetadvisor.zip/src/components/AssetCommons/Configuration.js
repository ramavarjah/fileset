import React from "react";
import { Form, Input } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;
import Functions from "../../api/Functions";
import permissionStore from "../../stores/permissionStore";
import addAssetsStore from "../../stores/addAssetsStore";
import "react-select/dist/react-select.css";
const { TextArea } = Input;
import UIFunctions from "../../helpers/UIFunctions";
import { AgGridReact } from "ag-grid-react";

@observer
class Configuration extends React.Component {
    constructor(props) {
        super(props);
        this._LicenseColumns = [
            { field: "license_name", headerName: "License Name", menuTabs: [] },
            { field: "option_number", headerName: "Option Number", menuTabs: [] },
            { field: "expire_date", headerName: "Expiration Date", menuTabs: [] }
        ];
    }
  state = {
      confirmDirty: false,
      autoCompleteResult: [],
      Organization: "",
      Location: "",
      configValue: false,
      icons: {
          filter: '<i class="fa fa-filter"/>',
          sortAscending: '<i class="fa fa-arrow-down"/>',
          sortDescending: '<i class="fa fa-arrow-up"/>'
      }
  };
  LicenceRowGetter = i => {
      var rtn = addAssetsStore.fieldState.Licences[i];
      var item = rtn;
      typeof item.size == "number"
          ? (item.size = this.humanFileSize(item.size, true))
          : "";
      return item;
  };
  onGridReady = params => {
      params.api.sizeColumnsToFit();
  };
  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll();
  };
  handleClick = () => {
      var details = JSON.stringify(addAssetsStore.fieldState.Information);
      if (!details) details = "No Data Found";
      UIFunctions.ShowInfo({
          zIndex: 2000,
          title: "Reported Configuration",
          content: (
              <div>
                  <TextArea
                      rows={6}
                      disabled={true}
                      placeholder={this.parseInfoArray(details.OS, "OS")}
                  />
                  <br />
                  <br />
                  <TextArea
                      rows={6}
                      disabled={true}
                      placeholder={this.parseInfoArray(details.SCPI, "SCPI")}
                  />
              </div>
          )
      });
  };
  parseInfoArray(jsonArray) {
      var ret = "";
      if (jsonArray != undefined) {
          for (var x = 0; x < jsonArray.length; x++) {
              ret =
          ret + "----------------------------------------------------------";
              ret = ret + "\n " + jsonArray[x] + "\n\n";
          }
      }
      return ret;
  }
  onOrgTreeChange = value => {
      addAssetsStore.addToFieldState({ Organization: value });
      Functions.GetAllUsersForCustomer(value, "").then(resp => {
          addAssetsStore.setUsersForCustomer(resp.data.UserList);
      });
  };
  onLocTreeChange = value => {
      addAssetsStore.addToFieldState({ Location: value });
  };
  render() {
      const { getFieldDecorator } = this.props.form;
      const formItemLayout = {
          labelCol: {
              xs: { span: 24 },
              sm: { span: 6 }
          },
          wrapperCol: {
              xs: { span: 24 },
              sm: { span: 14 }
          }
      };
      return (
          <Form onSubmit={this.handleSubmit} autoComplete="off">
              {permissionStore.permissions.fields.FirmwareRevision && (
                  <FormItem {...formItemLayout} label="Firmware revision">
                      {getFieldDecorator("FirmwareRevision", {
                          rules: [{}]
                      })(
                          <Input
                              id="FirmwareRevision"
                              placeholder={
                                  addAssetsStore.fieldState.FirmwareRevision
                                      ? addAssetsStore.fieldState.FirmwareRevision
                                      : "Please Provide Firmware Revision"
                              }
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({
                                      FirmwareRevision: e.target.value
                                  })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.HardwareVersion && (
                  <FormItem
                      {...formItemLayout}
                      label="Hardware version"
                      // hasFeedback
                  >
                      {getFieldDecorator("HardwareVersion", {
                          rules: [
                              {
                                  value: "test"
                              }
                          ]
                      })(
                          <Input
                              id="HardwareVersion"
                              placeholder={
                                  addAssetsStore.fieldState.HardwareVersion
                                      ? addAssetsStore.fieldState.HardwareVersion
                                      : "Please Provide Hardware Version"
                              }
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({
                                      HardwareVersion: e.target.value
                                  })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.Accessories && (
                  <FormItem
                      {...formItemLayout}
                      label="Accessories"
                      // hasFeedback
                  >
                      {getFieldDecorator("Accessories", {
                          rules: [{}]
                      })(
                          <Input
                              id="Accessories"
                              placeholder={
                                  addAssetsStore.fieldState.Accessories
                                      ? addAssetsStore.fieldState.Accessories
                                      : "Please Provide Accessories"
                              }
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({
                                      Accessories: e.target.value
                                  })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.Options && (
                  <FormItem
                      {...formItemLayout}
                      label="Options"
                      // hasFeedback
                  >
                      {getFieldDecorator("Options", {
                          rules: [{}]
                      })(
                          <Input
                              id="Options"
                              placeholder={
                                  addAssetsStore.fieldState.Options
                                      ? addAssetsStore.fieldState.Options
                                      : "Please Provide Options"
                              }
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({ Options: e.target.value })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.SoftwareRevision && (
                  <FormItem
                      {...formItemLayout}
                      label="Software revision"
                      // hasFeedback
                  >
                      {getFieldDecorator("SoftwareRevision", {
                          rules: [{}]
                      })(
                          <Input
                              id="SoftwareRevision"
                              placeholder={
                                  addAssetsStore.fieldState.SoftwareRevision
                                      ? addAssetsStore.fieldState.SoftwareRevision
                                      : "Please Provide Software Revision"
                              }
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({
                                      SoftwareRevision: e.target.value
                                  })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {addAssetsStore.mode === "DETAILS" || addAssetsStore.mode === "EDIT" ? (
                  <div>
                      <div>
                          <label className="formLabels" htmlFor="other">
                Licenses
                          </label>
                          <div
                              style={{
                                  height: "200px",
                                  color: "#666",
                                  backgroundColor: "#e5e5e5"
                              }}
                              className="ag-fresh"
                          >
                              <AgGridReact
                                  columnDefs={this._LicenseColumns}
                                  onGridReady={this.onGridReady.bind(this)}
                                  enableColResize={true}
                                  rowData={
                                      addAssetsStore.fieldState.Licences
                                          ? addAssetsStore.fieldState.Licences.map(e => e)
                                          : []
                                  }
                                  enableSorting={true}
                                  suppressMovableColumns={true}
                                  icons={this.state.icons}
                                  rowHeight="35"
                                  headerHeight="35"
                              />
                          </div>
                      </div>
                      <br />
                      <FormItem
                          className="configurationInfo"
                          style={{ marginBottom: "35px", marginTop: "20px" }}
                          {...formItemLayout}
                          label="Information"
                      >
                          {getFieldDecorator("InformationNew", {
                              rules: [{}],
                              initialValue: this.parseInfoArray(
                                  addAssetsStore.fieldState.Information
                              )
                          })(
                              <TextArea
                                  rows={6}
                                  offset={6}
                                  id="InformationNew"
                                  readOnly={true}
                              />
                          )}
                      </FormItem>
                  </div>
              ) : (
                  ""
              )}
          </Form>
      );
  }
}
const WrappedRegistrationForm = Form.create()(Configuration);
export default WrappedRegistrationForm;
