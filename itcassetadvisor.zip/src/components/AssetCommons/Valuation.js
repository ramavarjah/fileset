import React from "react";
import { Form, Input, DatePicker } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;
import Functions from "../../api/Functions";
import permissionStore from "../../stores/permissionStore";
import addAssetsStore from "../../stores/addAssetsStore";
import "react-select/dist/react-select.css";

@observer
class Inventory extends React.Component {
  state = {
      confirmDirty: false,
      autoCompleteResult: [],
      Organization: "",
      Location: ""
  };
  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll();
  };

  onOrgTreeChange = value => {
      addAssetsStore.setFieldState({ Organization: value });
      Functions.GetAllUsersForCustomer(value, "").then(resp => {
          addAssetsStore.setUsersForCustomer(resp.data.UserList);
      });
  };
  onLocTreeChange = value => {
      addAssetsStore.setFieldState({ Location: value });
  };

  render() {
      const { getFieldDecorator } = this.props.form;
      const formItemLayout = {
          labelCol: {
              xs: { span: 24 },
              sm: { span: 6 }
          },
          wrapperCol: {
              xs: { span: 24 },
              sm: { span: 14 }
          }
      };

      return (
          <Form onSubmit={this.handleSubmit} autoComplete="off">
              {permissionStore.permissions.fields.BookValue && (
                  <FormItem
                      {...formItemLayout}
                      label="Book value"
                      // hasFeedback
                  >
                      {getFieldDecorator("BookValue", {
                          rules: [
                              {
                                  pattern: new RegExp("^[0-9{.}]+(.[0-9]{1,3})?$"),
                                  message: "Not a Valid Book Value"
                              }
                          ]
                      })(
                          <Input
                              id="BookValue"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e => {
                                  e.target.value == ""
                                      ? addAssetsStore.addToFieldState({ BookValue: -999999 })
                                      : addAssetsStore.addToFieldState({
                                          BookValue: e.target.value
                                      });
                                  this.props.checkAndSetLoanDailyCost();
                              }}
                              style={{ width: "82px" }}
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.BookValueDate && (
                  <FormItem
                      {...formItemLayout}
                      label="Book value date"
                      // hasFeedback
                  >
                      {getFieldDecorator("BookValueDate", {})(
                          <DatePicker
                              id="BookValueDate"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              format="YYYY-MM-DD"
                              getCalendarContainer={trigger => trigger.parentElement}
                              onChange={e =>
                                  e != null
                                      ? addAssetsStore.addToFieldState({
                                          BookValueDate: e.toISOString()
                                      })
                                      : addAssetsStore.addToFieldState({ BookValueDate: "" })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.Depreciation && (
                  <FormItem
                      {...formItemLayout}
                      label="Depreciation rate (%/year)"
                      // hasFeedback
                  >
                      {getFieldDecorator("Depreciation", {
                          rules: [
                              {
                                  pattern: new RegExp("^[0-9{.}]+(.[0-9]{1,3})?$"),
                                  message: "Not a Valid Depreciation Rate"
                              }
                          ]
                      })(
                          <Input
                              id="Depreciation"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  e === undefined
                                      ? addAssetsStore.addToFieldState({ Depreciation: 0 })
                                      : addAssetsStore.addToFieldState({
                                          Depreciation: e.target.value
                                      })
                              }
                              style={{ width: "82px" }}
                          />
                      )}
                  </FormItem>
              )}
          </Form>
      );
  }
}

const WrappedRegistrationForm = Form.create()(Inventory);
export default WrappedRegistrationForm;
