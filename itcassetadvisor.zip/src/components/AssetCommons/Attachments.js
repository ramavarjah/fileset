import React, { Component } from "react";
import { Form, Icon, Button, Upload } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;
import addAssetsStore from "../../stores/addAssetsStore";
import "react-select/dist/react-select.css";
import moment from "moment";
import UIFunctions from "../../helpers/UIFunctions";
import { AgGridReact } from "ag-grid-react";
import mobx from "mobx";
import _ from "lodash";

@observer
class Attachments extends Component {
	constructor(props) {
		// var me=this;
		super(props);
		this.ShowWarning = _.debounce(UIFunctions.ShowWarning, 1000);
		this._AttachmentColAdd = [
			{ key: "name", name: "Name" },
			{ key: "size", name: "Size" },
			{
				name: "Actions",
				key: "$delete",
				getRowMetaData: row => row,
				formatter: ({ row }) => (
					<span>
						<a href="javascript:;" onClick={() => this.deleteRows(row)}>
							Delete
						</a>
					</span>
				)
			}
		];
		this._AttachmentCol = [
			{ key: "name", name: "Name" },
			{ key: "lastModifiedDate", name: "LastModifiedDate" },
			{
				name: "Actions",
				key: "$delete",
				getRowMetaData: row => row,
				formatter: ({ dependentValues }) => ((
					<span>
						<a
							href="javascript:;"
							onClick={() => {
								addAssetsStore.mode === "EDIT"
									? this.deleteRows(dependentValues)
									: "return false";
							}}
						>
							Delete
						</a>
					</span> /*:""*/ /*:""*/
					//:""
				) /*:""*/)
			}
		];
	}
	state = {
		binaryFiles: { data: "", fileName: "" },
		CustomerId: "",
		autoCompleteResult: [],
		storeb64File: this.storeb64File,
		isUploadFileSelected: false,
		attachmentData: [],
		rows: [],
		filearr: [],
		columnsDetails: [
			{ field: "name", headerName: "Filename", menuTabs: [] },
			{
				field: "lastModifiedDate",
				headerName: "Create Date and Time",
				menuTabs: []
			},
			{
				field: "downloadLink",
				headerName: "Download Link",
				menuTabs: [],
				cellRenderer: function(params) {
					return (
						"<a href=" +
						params.value +
						'> Download </a>&nbsp;&nbsp;&nbsp;&nbsp;<i id="del" class="icon-trash cell-btn-remove attachDel"></i>'
					);
				}
			}
		],
		columnsEdit: [
			{ field: "name", headerName: "Name", menuTabs: [] },
			{
				field: "lastModifiedDate",
				headerName: "Last Modified Date",
				menuTabs: []
			},
			{
				field: "downloadLink",
				headerName: "Download",
				//headerName: "Download Link",
				menuTabs: [],
				cellRenderer: function(params) {
					return "<a href=" + params.value + "> Download </a>";
				}
			},
			{
				headerName: "Delete",
				field: "delete",
				menuTabs: [],
				cellRenderer: function() {
					return '<Icon class="icon-trash cell-btn-remove" />';
				}
			}
		],
		icons: {
			filter: '<i class="fa fa-filter"/>',
			sortAscending: '<i class="fa fa-arrow-down"/>',
			sortDescending: '<i class="fa fa-arrow-up"/>'
		}
	};

	componentDidUpdate() {
		//below code to set delete icon disable in Asset Detail mode
		var delIcons = document.getElementsByClassName("attachDel");
		if (delIcons.length > 0) {
			for (let i = 0; i < delIcons.length; i++) {
				if (addAssetsStore.mode === "EDIT") {
					delIcons[i].style.opacity = 1;
				} else {
					delIcons[i].style.opacity = 0.2;
				}
			}
		}
		//end here ----set delete icon disable----
	}
	onGridReady(params) {
		// console.log("GridReady", params)
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
		this.gridApi.sizeColumnsToFit();
	}

	onGridColumnsChanged(params) {
		params.api.sizeColumnsToFit();
	}
	deleteRows(value) {
		//console.log("Row value",value);
		if (value.event.target.id == "del" && addAssetsStore.mode == "EDIT") {
			addAssetsStore.removeAssetFileUploadList(value.data);

			this.state.filearr.push(value.data.name);
			addAssetsStore.setAssetFileDeleteList(this.state.filearr);
		}
		// Functions.DeleteUploadedFiles
		return true;
	}
	humanFileSize(bytes, si) {
		// console.log("bytes", typeof (bytes), bytes);
		var thresh = si ? 1000 : 1024;
		if (Math.abs(bytes) < thresh) {
			return bytes + " B";
		}
		var units = si
			? ["kB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]
			: ["KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB", "YiB"];
		var u = -1;
		do {
			bytes /= thresh;
			++u;
		} while (Math.abs(bytes) >= thresh && u < units.length - 1);
		// console.log("bytes", bytes.toFixed(1) + ' ' + units[u]);
		return bytes.toFixed(1) + " " + units[u];
	}
	AttachmentRowGetter = i => {
		// console.log("rowgetter",i);

		var rtn = addAssetsStore.assetFileUploadList[i];

		// console.log("rowgetter", i, rtn);

		var item = rtn;

		typeof item.size == "number"
			? (item.size = this.humanFileSize(item.size, true))
			: "";
		item.lastModifiedDate = moment(rtn.lastModifiedDate).format(
			"YYYY-MM-DD HH:mm:ss"
		);

		return item;
	};
	handleSubmit = e => {
		// console.log("event** ", e.target.id);
		e.preventDefault();
		this.props.form.validateFieldsAndScroll(err => {
			if (!err) {
				// console.log('Received values of form: ', values);
			}
		});
	};

	componentDidMount() {
		// console.log("addAssetsStore before create", addAssetsStore.assetFileUploadList);
		// addAssetsStore.setEntriesAssetFileList([]);
		// addAssetsStore.setAssetFileUploadList([]);
		// console.log("addAssetsStore.fieldState after", addAssetsStore.fieldState);
		// this.createRows();
		// this.props.form.setFieldsValue({"FirmwareRevision":"test","HardwareVersion":"test"});
	}

	handleFileChange = info => {
		let fileList = info.fileList;
		const isLt10M = info.file.size / 1024 / 1024 <= 10;
		if (!isLt10M) {
			return UIFunctions.Toast(
				info.file.name + " is greater than 10MB",
				"info"
			);
		}

		let fileListFromStore = mobx.toJS(addAssetsStore.entriesAssetFileList);
		if (
			info.fileList.length > 5 &&
			fileList.length != fileListFromStore.length
		) {
			var payload = [];
			info.fileList.map((e, index) => {
				if (index < 5) payload.push(e);
			});
			// console.log('payload[5]', payload)
			addAssetsStore.setEntriesAssetFileList(payload);
			// console.log('You can not upload more than 5 files')
			this.ShowWarning({
				zIndex: 2000,
				title: "You can not upload more than 5 files "
			});
		} else {
			// var list = ooStore.entriesFileList;
			// info.file.status='done';
			// list.push(info.file);
			var FileList = fileListFromStore;
			info.fileList.forEach((item, i) => {
				var isNewItem = true;
				// Looping throught State-FileList to check whether the file is in the list or not
				fileListFromStore.map(fileitem => {
					item.name == fileitem.name ? (isNewItem = false) : "";
				});
				//
				info.fileList[i].status = "done";
				isNewItem && FileList.push(info.fileList[i]);
			});
			// info.fileList.forEach((item, i) => {
			//   info.fileList[i].status = 'done';

			// })
			addAssetsStore.setEntriesAssetFileList(FileList);
			// console.log("info ",info);
			// console.log("added" + info.fileList)
		}
	};
	removeFile = info => {
		addAssetsStore.removeEntriesAssetFileList(info);
		// console.log("removed", info)
	};
	storeb64File(e) {
		const fileName = e.target.files[0].name;
		const reader = new FileReader();
		// self = this;
		reader.onload = file => {
			let tempData = file.target.result.split(",")[1];
			let tempObj = { data: tempData, fileName: fileName };
			self.setState({
				binaryFiles: tempObj,
				isUploadFileSelected: true
			});
		};

		reader.readAsDataURL(e.target.files[0]);
	}

	render() {
		// console.log("form", this.props.form)
		const formItemLayout = {
			labelCol: {
				xs: { span: 24 },
				sm: { span: 6 }
			},
			wrapperCol: {
				xs: { span: 24 },
				sm: { span: 14 }
			}
		};

		return (
			<Form onSubmit={this.handleSubmit} autoComplete="off">
				<div>
					<FormItem {...formItemLayout} label="Upload attachment">
						{/*<div style={{ padding: '10px 25px', height: (window.innerHeight * (0.1)) }} >*/}
						<div
							style={{
								padding: "10px 25px",
								display: "flex",
								position: "relative"
							}}
						>
							<Upload
								//eslint-disable-next-line
								customRequest={() => console.log("")}
								onChange={this.handleFileChange}
								loading={false}
								fileList={addAssetsStore.entriesAssetFileList.map(e => e)}
								disabled={addAssetsStore.mode == "DETAILS"}
								onRemove={this.removeFile}
								multiple={true}
							>
								<Button disabled={addAssetsStore.mode == "DETAILS"}>
									<Icon type="upload" /> upload
								</Button>
							</Upload>
							<span
								style={{
									"letter-spacing": "0.5px",
									color: " #79838c",
									position: "absolute",
									left: 130,
									width: 250
								}}
							>
								Maximum upload file size : 10MB
							</span>
						</div>
					</FormItem>
				</div>

				{addAssetsStore.mode === "DETAILS" || addAssetsStore.mode === "EDIT" ? (
					<div>
						<label className="formLabels" htmlFor="other">
							Attachments
						</label>
						<div
							style={{
								height: "200px",
								color: "#666",
								backgroundColor: "#e5e5e5"
							}}
							className="ag-fresh"
						>
							<AgGridReact
								onCellClicked={this.deleteRows.bind(this)}
								onGridReady={this.onGridReady.bind(this)}
								onGridColumnsChanged={this.onGridColumnsChanged.bind(this)}
								rowSelection="single"
								//disabled={submitIssuesStore.selectedIssueData ? submitIssuesStore.selectedIssueData.Status == "Closed" : false}
								// rowData={this.state.rows}
								rowData={
									addAssetsStore.assetFileUploadList
										? addAssetsStore.assetFileUploadList.map(e => e)
										: []
								}
								columnDefs={this.state.columnsDetails}
								suppressMovableColumns={true}
								icons={this.state.icons}
								enableSorting={true}
								enableColResize={true}
								rowHeight="35"
								headerHeight="35" //defaultColDef={this.state.defaultColDef}
							/>
						</div>
					</div>
				) : (
					""
				)}
			</Form>
		);
	}
}
// class EmptyRowsView extends React.Component {
//   render() {
//     return <div>&nbsp;&nbsp;No attachments</div>;
//   }
// }
const WrappedRegistrationForm = Form.create()(Attachments);
export default WrappedRegistrationForm;
