import React from "react";
import { Form } from "antd";
import moment from "moment";
const FormItem = Form.Item;
import addAssetsStore from "../../stores/addAssetsStore";
import { Tabs } from "antd";
import { AgGridReact } from "ag-grid-react";
import "react-select/dist/react-select.css";

const TabPane = Tabs.TabPane;

class History extends React.Component {
    constructor(props) {
        super(props);

        this._Changecolumns = [
            {
                field: "Timestamp",
                headerName: "Last Changed Date and Time",
                sort: "desc",
                menuTabs: []
            },
            { field: "Description", headerName: "Details", menuTabs: [] },
            { field: "EditedBy", headerName: "Edited By", menuTabs: [] }
        ];

        this._Servicecolumns = [
            { field: "order_Id", headerName: "Service Order ID", menuTabs: [] },
            {
                field: "CalibrationType",
                headerName: "Calibration Type",
                menuTabs: []
            },
            {
                field: "receivedCondition",
                headerName: "Received Condition",
                menuTabs: []
            },
            // {
            //     field: "returnedCondition",
            //     headerName: "Returned Condition",
            //     menuTabs: []
            // },
            { field: "serviceDate", headerName: "Service Date", menuTabs: [] },
            {
                field: "calibrationDueDate",
                headerName: "Calibration Due Date",
                menuTabs: []
            },
            { field: "ootCaseNo", headerName: "OOT Case Number", menuTabs: [] },
            {
                field: "docUrl",
                headerName: " Download Document",
                cellRenderer: params =>
                    params.value ? "<a href=" + params.value + ">Download</a>" : ""
            }
        ];
    }
  state = {
      confirmDirty: false,
      autoCompleteResult: [],
      binaryFiles: { data: "", fileName: "" },
      isUploadFileSelected: false,
      storeb64File: this.storeb64File,
      defaultTabKey: 1,
      icons: {
          filter: '<i class="fa fa-filter"/>',
          sortAscending: '<i class="fa fa-arrow-down"/>',
          sortDescending: '<i class="fa fa-arrow-up"/>'
      }
  };
  onGridReady = params => {
      params.api.sizeColumnsToFit();
  };
  onTabChange(key) {
      if (key == 1) {
      //Tab 1 Selected
      } else if (key == 2) {
      //Tab 2 Selected
      }
  }

  render() {
      var rowData = addAssetsStore.serviceHistory
          ? addAssetsStore.serviceHistory.map(e => {
              var rtn = e;
              rtn.serviceDate = moment(e.serviceDate).format("YYYY-MM-DD HH:mm:ss");
              rtn.calibrationDueDate = moment(e.calibrationDueDate).format(
                  "YYYY-MM-DD HH:mm:ss"
              );
              return rtn;
          })
          : [];
      return (
          <Form onSubmit={this.handleSubmit}>
              {addAssetsStore.mode === "DETAILS" ? (
                  <div className="asset_service_TabContainer">
                      <FormItem>
                          <Tabs
                              type="card"
                              defaultActiveKey={this.state.defaultTabKey}
                              onChange={this.onTabChange.bind(this)}
                          >
                              <TabPane tab="ASSET" key="1">
                                  <div
                                      style={{
                                          height: "200px",
                                          color: "#666",
                                          backgroundColor: "#e5e5e5"
                                      }}
                                      className="ag-fresh"
                                  >
                                      <AgGridReact
                                          id="changeGrid"
                                          columnDefs={this._Changecolumns}
                                          onGridReady={this.onGridReady.bind(this)}
                                          enableColResize={true}
                                          suppressMovableColumns={true}
                                          icons={this.state.icons}
                                          rowData={
                                              addAssetsStore.fieldState.ChangeLog
                                                  ? addAssetsStore.fieldState.ChangeLog.map(e => e)
                                                  : []
                                          }
                                          rowHeight="35"
                                          headerHeight="35"
                                          enableSorting={true}
                                      />
                                  </div>
                              </TabPane>

                              <TabPane tab="SERVICE" key="2">
                                  <div
                                      style={{
                                          height: "200px",
                                          color: "#666",
                                          backgroundColor: "#e5e5e5"
                                      }}
                                      className="ag-fresh"
                                  >
                                      <AgGridReact
                                          columnDefs={this._Servicecolumns}
                                          rowData={rowData}
                                          rowHeight="35"
                                          headerHeight="35"
                                          enableSorting={true}
                                          enableColResize={true}
                                          suppressMovableColumns={true}
                                          icons={this.state.icons}
                                      />
                                  </div>
                              </TabPane>
                          </Tabs>
                      </FormItem>
                  </div>
              ) : (
                  ""
              )}
          </Form>
      );
  }
}

const WrappedRegistrationForm = Form.create()(History);
export default WrappedRegistrationForm;
