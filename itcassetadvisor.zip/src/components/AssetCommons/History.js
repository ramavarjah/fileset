import React  from "react";
import {
  Form,
  Button,
  Table,
  Input,
  Popconfirm,
  Icon,
  Upload,
  Tooltip,
  DatePicker 
} from "antd";
import _ from "lodash";
import moment from "moment";
const FormItem = Form.Item;
import addAssetsStore from "../../stores/addAssetsStore";
import { Tabs, Spin } from "antd";
import { AgGridReact } from "ag-grid-react";
import "react-select/dist/react-select.css";
import { observer } from "mobx-react";
import mobx from "mobx";
import styled from "styled-components";
import tabModelStore from "../../stores/tabModelStore";
const TabPane = Tabs.TabPane;
import UIFunctions from "src/helpers/UIFunctions";
import Functions from "./../../api/Functions";
import noDataImage from "../../../public/img/no-data-placeholder_standard.png";
import { CSVLink } from "react-csv";

import './history.scss';

var serverData = [];
//eslint-disable-next-line
var scheduleTasksCount = 0;
var clearAttachedFile = false;

const dates = [
  "ReplacementDate",
  "CalibrationDate",
  "CalibrationDueDate",
  "LastServiceDate",
  "ServiceDueDate",
  "PlannedDisposalDate",
  "OrderDate",
  "ReceivedDate",
  "BookValueDate",
  "InventoryDate",
  "LastUpdate"
];
const Div = styled.div`
  .editable-cell {
    position: relative;
    width:80%;
  }

  .editable-cell-input-value-wrapper {
    padding-right: 24px;
   
    span {
      .ant-upload.ant-upload-select {
        display: inline-block;
        position: relative;
        left: 13px;
      }

      .ant-upload-list {
        position: absolute;
        width: 35%;
        top: 11px;
        margin-left: 230px;
      }
      .ant-upload-list-item .anticon-cross {
        position: absolute;
        left: 95%;
        color: red;
      }
    }
  }
  .editable-cell-input-wrapper {
    padding-right: 0px;
    .ant-calendar{
      height: 219px;
    overflow: auto;
    scroll-behavior: smooth;
    font-size: 12px;
    width: 218px;
    }
    .ant-calendar-picker{
      width:100%;
    }
    .ant-calendar-input-wrap {
      height: 21px;
      padding: 0px;
      border-bottom: 0px solid #e9e9e9;
  }
  .ant-calendar-input {
    border: 0;
    width: 100%;
    cursor: auto;
    outline: 0;
    height: 25px;
    color: rgba(0, 0, 0, 0.65);
    background: #fff;
    margin-left: 0px;
    text-align: center;
}
.ant-calendar-header {
  height: 22px;
  text-align: center;
  border-bottom: 0px solid #e9e9e9;
}
.ant-calendar-cell {
  padding: 0px 0px;
}
.ant-calendar-body {
  padding: 0px 0px;
}
.ant-calendar-footer {
  border-top: 0px solid #e9e9e9;
  line-height: 3px;
  padding: 8px 0px;
}
    .ant-upload-list {
      top: 16px;
      position: absolute;
      margin-left: 155px;
      width: 35%;
    }
    .ant-upload-list-item .anticon-cross {
      position: absolute;
      left: 95%;
      color: red;
    }
  }

  .editable-cell-text-wrapper {
    padding-right: 24px;
    span {
      .ant-upload-list {
        position: absolute;
        left: 250px;
        bottom: 7px;
      }
    }
  }

  .editable-cell-text-wrapper {
    padding: 0px 5px 0px 7px;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin-left: -5px;

    .selectStyles {
      container: (base, state) => ({...base, zIndex: "9999"});
    }
  }

  .editable-cell-icon,
  .editable-cell-icon-check {
    position: absolute;
    right: 0;
    width: 20px;
    cursor: pointer;
  }

  .editable-cell-icon {
    line-height: 18px;
    display: none;
  }

  .editable-cell-icon-check {
    line-height: 28px;
  }

  .editable-cell:hover .editable-cell-icon {
    display: inline-block;
  }

  .editable-cell-icon:hover,
  .editable-cell-icon-check:hover {
    color: #108ee9;
  }

  .editable-add-btn {
    margin-bottom: 8px;
  }

  .ant-table-bordered {
    border-right: none;
  }
`;

const Div2 = styled.div`
  .service-history-buttongroup {
    display: inline-flex;
    margin-bottom: 15px;
    margin-top: 32px;
    float: right;

    .sh-clear-button {
      height: 27px;
      width: 86px;
      border: 1px solid #b8b8b8;
      border-radius: 3px;
      background-color: #dedddd;
      color: #686a6f;
    }
    .sh-clear-button:hover {
      background: #3131339c;
      color: white;
    }
    .sh-save-button {
      height: 27px;
      width: 75px;
      border: 1px solid #4ac27c;
      border-radius: 3px;
      color: #f7f7f7!important;
      background-color: #1cb359;
      margin-left: 20px;
    } 
    
    .sh-save-button:hover {
      color: white;
      background: #0d980de0;
    }

    .sh-add-button {
      height: 27px;
      width: 108px;
      border: 1px solid #b8b8b8;
      border-radius: 3px;
      background-color: #c3c3c3;
      color: #686a6f;
      margin-left: 20px;
    }

    .sh-add-button:hover {
      background: #3131339c;
      color: white;
    }
  }
`;
const Div3 = styled.div`

  .ant-table-body {
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px lightgrey; 
  border-radius: 10px;
    width:1px;
  height:2px;
}
::-webkit-scrollbar {
  width: 9px!important;
  height:9px!important;
}
    max-height: 250px;
    min-height:250px;
  .ant-table-thead > tr, .ant-table-tbody > tr:nth-child(even) {background-color: #f2f2f2;
    .ant-table-thead > tr > th {
      background-color: #e8ebed;
      padding: 9px 7px;
      color: #646c72;
      font-family: "Open Sans";
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.9px;
  }
  }


 
  table {
    overflow: visible !important;
    .ant-table-placeholder {
      margin-top: -237px!important;
    }
  }
  .ant-table-tbody > tr > td {
    padding: 12px 8px;
    color: #848181 !important;
    font-family: "Open Sans" !important;
    font-size: 13px;
    letter-spacing: 0.69px;
    word-break: break-word;
}
`;


const dummyFileUploadRequest = ({ onSuccess }) => {
  setTimeout(() => {
    onSuccess("ok");
  }, 0);
};
var dataSourceForExport = [];
var dataSourceForExportCSV = [];
var TabCount = 0 ; 
 var char = ""


 class Dropdown extends React.Component{
   
  constructor(props){
    super(props);
    this.Input = React.createRef();
  }

  maintainScroll = (e)=>{
    e.stopPropagation();
  }

onEnterValue = (e) => {
  if(e.keyCode == 13){
    e.preventDefault();
    this.props.onEnterPress(e.target.value);
  }
  
}
  render() {
      const {option , handleChange, show ,defaultValue, handleToggle , value ,clearValue, onChange , search , placeholder , promtText , handleChangeValue  }  = this.props
      const suffix = show ? (<Icon style={{color:'#d0d0d0',fontSize:9}} className="ddIcon" onClick={handleToggle} type="caret-down" />) : (<Icon style={{color:'#d0d0d0',fontSize:9}} type="caret-up" onClick={(e)=>{handleToggle(e)}} />)
      return (
      <React.Fragment>
          <div onKeyDown={this.onEnterValue}>
       <Input
      ref={this.Input}
       placeholder={placeholder}
       onClick={handleToggle}
       value={value ? value : ""}
        suffix={suffix} 
        defaultValue={defaultValue}
       onChange = {onChange}
       />
       <Icon 
       style={{color:'#d0d0d0' }}
        className="sh-close-icon" 
        onClick={clearValue} type="close" 
        />
         <div className="ddoutermenu" >

           <ul  className="dropdown-list" 
           onScroll={ this.maintainScroll }
           hidden={!show} 
           style={{listStyleType:"none" ,
            paddingInlineStart : '0px'}} >
           <ul 
           style={{listStyleType:"none" , 
           paddingInlineStart : '2px' ,
           marginBlockStart: "2px",
           marginBlockEnd: "3px"}}>
                  { search && search.length ===0 && value && value.length >= 1 ? ( 
                      <span className='dropdown-add'>
                          {option.length>0 && 
                            option.some(item => item.value == value ) ? "" : 
                            <li onClick={handleChangeValue(value)} >{ `${promtText} '${value}'` }</li> }
                       
                      </span>  )  : " "}
                  </ul>
          {search && search.length > 0 ? (
             <div>
                  {search.map(item => (
                  
                  <li
                  key={item.key}
                    className="option"
                    onClick={handleChange(item)}
                  >
                    {item.value}
                  </li>
                ))}
                </div>
          ) : (
              <div className="ddmenu">
                  
             { option && option.length > 0 ? 
               option.map(item => ( 
                  <li
                  key={item.key}
                    className="option"
                    onClick={handleChange(item)}
                  > 
                    {item.value}
                  </li>
                  
                ))
              : (
                <li className="ddmenu-no-data">
                  <span>No Result Found</span>
                </li>
              )
              } 
                
          </div>
          )}
        </ul>
      
           </div>
           </div>
      </React.Fragment>
    );
  }
}

class UploadDocument extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: this.props.value,
      fileList: []
    };
  }
  handleChange = info => {
    let fileList = [...info.fileList];
    const isLt2M = info.file.size / 1024 / 1024 <= 10;
    const isLt0M = info.file.size / 1024 / 1024 === 0;
    if (!isLt2M) {
      return UIFunctions.Toast(
        info.file.name + " is greater than 10MB",
        "info"
      );
    }
    if (isLt0M) {
      return UIFunctions.Toast(
        info.file.name + " is empty",
        "info"
      );
    }
    // 1. Limit the number of uploaded files
    // Only to show two recent uploaded files, and old ones will be replaced by the new
    fileList = fileList.slice(-1);
    // 2. Read from response and show file link
    fileList = fileList.map(file => {
      if (file.response) {
        // Component will show file.url as link
        file.url = file.response.url;
      }
      return file;
    });

    this.setState({ fileList });
    if (this.props.onChange) {
      this.props.onChange(fileList, this.props.dataIndex, this.props.record);
    }
  };

  componentDidUpdate(prevProps) {
    // Typical usage ( comparing props):
    if (this.props.value !== prevProps.value) {
      this.setState({ value: this.props.value });
      clearAttachedFile ? this.setState({ fileList: "" }) : "";
    }
  }

  render() {
    const { value, fileList } = this.state;
    return (
      <div>
        {value && (
          <span style={{ marginRight: "5px" }}>
            <a href={value}>Download</a>
          </span>
        )} {this.props.record.Key !== 0 ? (
          <Upload
          customRequest={dummyFileUploadRequest}
          fileList={fileList}
          onChange={this.handleChange.bind(this)}
          multiple={false}
        >
          <Button>
            <Icon type="upload" /> Upload File
          </Button>
        </Upload>
        ) : ""}
        
      </div>
    );
  }
}

var SProvider = "";
var datePopup = 0;
class EditableCell extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: this.props.value,
      editable: false,
      fileList: [] ,
      clearSp : true,
      menuIsOpen: true,
      ddvalue:""
    };
    this.select = null;
  }
  //comparing props 
  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.state.value !== nextProps.value) {
      this.setState({ value: nextProps.value });
    }
  }
 
  handleChange = e => {
    const value = e.target.value;
    this.setState({ value });
  };

handleDate =(date, dateString)=> {
  this.setState({ value : dateString });
  const sleep = milliseconds => { 
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  };
  sleep(1000).then(() => {
    this.check();
  });
}

closePopup = () => {
  
  datePopup = datePopup +1
  if(datePopup === 2 ){
    datePopup = 0
    const sleep = milliseconds => { 
      return new Promise(resolve => setTimeout(resolve, milliseconds));
    };
    sleep(1000).then(() => {
      this.check();
    });
     
  }
}

  check = () => {
    this.setState({ editable: false });
    if (this.props.onChange) {
      this.props.onChange(
        this.state.value,
        this.props.dataIndex,
        this.props.record
      );
    }
  };

  getServiceProvider = () => {
    var CalibrationProvider =
      tabModelStore.assetDetails.data.CalibrationProvider;
    var RepairProvider = tabModelStore.assetDetails.data.RepairProvider;
    if (
      CalibrationProvider &&
      RepairProvider &&
      CalibrationProvider === RepairProvider
    ) {
      var serviceProviderArray = [];
      let dataIndex = "ServiceProvider";
      serviceProviderArray = addAssetsStore.serviceProvider;

      let SProviderTemp = serviceProviderArray.filter(item => {
        return item.value === CalibrationProvider;
      });
      SProvider = SProviderTemp[0].value;
     this.props.onChange(SProvider, dataIndex, this.props.record);
      return SProvider;
    } else {
      return (SProvider = "");
    }
  };

  checkSProvider = () => {
    let value = "";
    if (this.state.value) {
      if (this.state.value.value) {
        value = this.state.value.value;
      } else {
        value = this.state.value;
      }
    }
    this.setState({ editable: false });
    if (this.props.onChange) {
      this.props.onChange(value, this.props.dataIndex, this.props.record);
    }
  };

  edit = () => {
    this.setState({ editable: true }, () => {
     
      try {
        this.input.focus();
      } catch (e) {
    //
    }
    
    });
  };
  
  handleChangedd = (item) => () => {
    this.setState({ show: false  , value : item.value });
    const sleep = milliseconds => { 
      return new Promise(resolve => setTimeout(resolve, milliseconds));
    };
    sleep(1500).then(() => {
      this.checkSProvider();
    });
  }
  handleChangeValue = (item) => () => {
    this.setState({ show: false , value : item });
    let arryobj = {}
    arryobj.label= item 
    arryobj.value=item
addAssetsStore.serviceProvider.push(arryobj)
const sleep = milliseconds => { 
  return new Promise(resolve => setTimeout(resolve, milliseconds));
};
sleep(1000).then(() => {
  this.checkSProvider();
});
  }
  onEnterPress = (item) =>{
    this.handleChangeValue(item)();
  }
  handleToggle = (e) => {
    e.target.focus();
    this.setState({ show: !this.state.show });
  }
  
  onChange = (e) => {
    char = e.target.value
   this.setState ({
    search : addAssetsStore.serviceProvider.filter(item => {
       return   item.value.toLowerCase().indexOf(char.toLowerCase()) == 0;
            } )
   
   })
    this.setState({value : char , show : true } )
  }
  render() {
    const { value, editable } = this.state;
    let  record = this.props.record ; 
    var CalibrationProvider =
      tabModelStore.assetDetails.data.CalibrationProvider;
    var RepairProvider = tabModelStore.assetDetails.data.RepairProvider;
    let placeHolder = this.props.placeHolder;
    let serviceProvider = false;
    var serviceDate = false
    let Servicedate = ""
    if(this.props.type == "DatePicker") {
      serviceDate= true
      if (value) {
        if (value.value) {
          Servicedate = value.value;
                } else {
          Servicedate = value;
        }
      }
    }
    let SProvider = "";
  
    if (this.props.type == "dropdown") {
      serviceProvider = true;
      if (value) {
        if (value.value) {
          SProvider = value.value;
        } else {
          SProvider = value;
        }
      }
      if (CalibrationProvider === RepairProvider && SProvider == "") {
      this.state.clearSp ?  (SProvider = this.getServiceProvider()) : " "
      }
    }

    if (serviceProvider) {
      return (
        <Div>
          <div className="editable-cell" onClick={this.edit}>
            {editable  &&  record.Key != 0  ? (
              <div   ref={ref => {
                this.select = ref;
              }} className="editable-cell-input-wrapper">
      <Dropdown
        promtText= "Create new ServiceProvider"
        show={this.state.show}
        value={this.state.value}
        clearValue = { (e) =>{
          if (!e.target.value) {
            this.setState({ value: "" ,
            clearSp : false });
          }
        }
          }
        defaultValue={SProvider || ""}
        option={addAssetsStore.serviceProvider}
        search={this.state.search}
        handleToggle={this.handleToggle}
        onChange={(e) => 
           
         {
          if (!e.target.value) {
          this.setState({ value: "" ,
          clearSp : false });
        } else {
          this.onChange(e)
        }  
      }
          }
        handleChangeValue={this.handleChangeValue}
        onEnterPress={this.onEnterPress}
        handleChange={this.handleChangedd}
        placeholder="Service Provider"
      />
              </div>
            ) : (
              <div className= { record.Key != 0  ? "editable-cell-text-wrapper" : "edit-cell-wrapper" }>
                {SProvider ? (
                  <Tooltip title={record.Key !==0 ? "Click to edit" : ""}>{SProvider}</Tooltip>
                ) : (
                  <span>
                    {" "}
                    <span style={{ color: "#bababa" }}>
                      <Tooltip title={record.Key !==0 ? "Click to edit" : ""}>
                        {placeHolder}
                      </Tooltip>
                    </span>
                    <span style={{ color: "red" }}>
                      {" "}
                      {this.props.mandatory}{" "}
                    </span>{" "}
                  </span>
                )}
              </div>
            )}
          </div>
        </Div>
      );
    } else  if(serviceDate) {
      return (
      <Div>
         <div className="editable-cell" onClick={this.edit}>
            {editable  &&  record.Key != 0  ? (<div className="editable-cell-input-wrapper">
            <DatePicker 
             onChange={this.handleDate}
             defaultValue={Servicedate ? moment(Servicedate, 'YYYY/MM/DD'): ""} 
             getCalendarContainer={trigger => trigger.parentElement}
             format="YYYY-MM-DD"
             onOpenChange={this.closePopup}
             />

            </div> ) : (
               
               <div className={ record.Key != 0  ? "editable-cell-text-wrapper" : "edit-cell-wrapper" }>
                {Servicedate ? (
                  <Tooltip title={record.Key !==0 ? "Click to edit" : ""}>{Servicedate}</Tooltip>
                ) : (
                  <span>
                    {" "}
                    <span style={{ color: "#bababa" }}>
                      <Tooltip title={record.Key !==0 ? "Click to edit" : ""}>
                        {placeHolder}
                      </Tooltip>
                    </span>
                    <span style={{ color: "red" }}>
                      {" "}
                      {this.props.mandatory}{" "}
                    </span>{" "}
                  </span>
                )}
              </div>
            )
             
            
            }
              
          </div>

      </Div>)
    }
  else  {
      return (
        <Div>
          <div className="editable-cell" onClick={this.edit}>
            {editable &&  record.Key != 0 ? (
              <div className="editable-cell-input-wrapper">
                <Input
                  ref={node => (this.input = node)}
                  value={value}
                  onChange={this.handleChange}
                  onPressEnter={this.check}
                  onBlur={this.check}
                />
              </div>
            ) : (
              <div className={ record.Key != 0  ? "editable-cell-text-wrapper" : "edit-cell-wrapper" }>
                {value ? (
                  <Tooltip title={record.Key !==0 ? "Click to edit" : ""}>{value}</Tooltip>
                ) : (
                  <span>
                    {" "}
                    <span style={{ color: "#bababa" }}>
                      <Tooltip title={record.Key !==0 ? "Click to edit" : ""}>
                        {placeHolder}
                      </Tooltip>
                    </span>
                    <span style={{ color: "red" }}>
                      {" "}
                      {this.props.mandatory}{" "}
                    </span>{" "}
                  </span>
                )}
              </div>
            )}
          </div>
        </Div>
      );
    }
  }
}

@observer
class History extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "",
        dataIndex: "operation",
        width: 50,
        render: (text, record) => {
          return this.state.dataSource.length >= 1 ? (
            record.Key != 0 ? (
              <Popconfirm
                title="Are you sure you want to Delete?"
                onConfirm={() => this.handleDelete(record, record.Key)}
              >
                <span
                  style={{
                    cursor: "pointer",
                    fontSize: 15,
                    color: "red",
                    paddingLeft: 11
                  }}
                >
                  <Icon type="close" />
                </span>
              </Popconfirm>
            ) : (
              ""
            )
          ) : null;
        }
      },
      {
        dataIndex: "ServiceOrderID",
        title: "SERVICE ORDER ID",
        width: 250,
        editable: true,
        render: (text, record) =>{
          return  (
              <EditableCell
            value={text}
            type="input"
            record={record}
            dataIndex="ServiceOrderID"
            mandatory="*"
            placeHolder="Service Order ID"
            onChange={this.onCellChange}
          />
            ) 
          
        }
        
      },
      {
        dataIndex: "ServiceType",
        title: "SERVICE TYPE",
        width: 250,
        editable: true,
        render: (text, record) => (
          <EditableCell
            value={text}
            type="input"
            record={record}
            dataIndex="ServiceType"
            mandatory="*"
            placeHolder="Service Type"
            onChange={this.onCellChange}
          />
        )
      },
      {
        dataIndex: "ServiceProvider",
        title: "SERVICE PROVIDER",
        width: 250,
        editable: true,
        render: (text, record) => (
          <EditableCell
            value={text}
            placeHolder="Service Provider"
            type="dropdown"
            record={record}
            mandatory="*"
            dataIndex="ServiceProvider"
            onChange={this.onCellChange}
          />
        )
      },
      {
        dataIndex: "RecievedCondition",
        title: "RECEIVED CONDITION",
        width: 300,
        editable: true,
        render: (text, record) => (
          <EditableCell
            value={text}
            type="input"
            record={record}
            dataIndex="RecievedCondition"
            placeHolder="Recieved Condition"
            onChange={this.onCellChange}
          />
        )
      },
      {
        dataIndex: "ReturnedCondition",
        title: "RETURNED CONDITION",
        width: 250,
        editable: true,
        render: (text, record) => (
          <EditableCell
            value={text}
            type="input"
            record={record}
            dataIndex="ReturnedCondition"
            placeHolder="Returned Condition"
            onChange={this.onCellChange}
          />
        )
      },
      {
        dataIndex: "ServiceDate",
        title: "SERVICE DATE",
        width: 250,
        editable: true,
        render: (text, record) => {
      text =  record.ServiceDate
              ?  new Date(record.ServiceDate) > 0
                ? moment(record.ServiceDate).format("YYYY-MM-DD")
                :  ""
                : "";

          return (
            <EditableCell
              value={text}
              type="DatePicker"
              record={record}
              dataIndex="ServiceDate"
              mandatory="*"
              placeHolder="Service Date"
              onChange={this.onCellChange}
            />
          );
        }
      },
      {
        dataIndex: "CalibrationDueDate",
        title: "CALIBRATION DUE DATE",
        width: 300,
        editable: true,
        render: (text, record) => {

           text = record.CalibrationDueDate
              ? new Date(record.CalibrationDueDate) > 0
                ? moment(record.CalibrationDueDate).format("YYYY-MM-DD")
                : ""
              : "";
         
              return (
            <EditableCell
              value={text}
              type="DatePicker"
              record={record}
              dataIndex="CalibrationDueDate"
              placeHolder="Calibration Due Date"
              onChange={this.onCellChange}
            />
          );
        }
      },
      {
        dataIndex: "OOTCaseNumber",
        title: "OOT CASE NUMBER",
        width: 250,
        editable: true,
        render: (text, record) => (
          <EditableCell
            value={text}
            type="input"
            record={record}
            dataIndex="OOTCaseNumber"
            placeHolder="OOT Case Number"
            onChange={this.onCellChange}
          />
        )
      },
      {
        dataIndex: "DocumentURL",
        title: "ATTACHED DOCUMENT",
        width: 250,
        render: (text, record) => {
          return (
            <div>
              <UploadDocument
                record={record}
                value={text}
                type="upload"
                dataIndex="FileList"
                placeHolder="ATTACHED DOCUMENT"
                onChange={this.onCellChange}               
              />
            </div>
          );
        }
      }
    ];
    this._Changecolumns = [
      {
        field: "Timestamp",
        headerName: "Last Changed Date and Time",
        sort: "desc",
        menuTabs: []
      },
      { field: "Description", headerName: "Details", menuTabs: [] },
      { field: "EditedBy", headerName: "Edited By", menuTabs: [] }
    ];
 
  }
  state = {
    confirmDirty: false,
    dataSource: [],
    count: 1,
    deletedKeys: [],
    serviceProviderList: [],
    editedServiceHistory: [],
    inputServiceHistory: [],
    autoCompleteResult: [],
    binaryFiles: { data: "", fileName: "" },
    isUploadFileSelected: false,
    storeb64File: this.storeb64File,
    defaultTabKey: 1,
    disableSave: true,
    icons: {
      filter: '<i class="fa fa-filter"/>',
      sortAscending: '<i class="fa fa-arrow-down"/>',
      sortDescending: '<i class="fa fa-arrow-up"/>'
    }
  };

   clearValue = (dataIndex , record ) =>{
    let { dataSource, inputServiceHistory, editedServiceHistory } = this.state;
    dataSource.map(item => {
      if (item.New) {
        if(item.Key === record.key) item[dataIndex] = "";
      }
    });
    inputServiceHistory.map(item => {
      if (item.New) {
        if(item.Key === record.key) item[dataIndex] = "";
      }
    });
    editedServiceHistory.map(item => {
      if (item) {
        if(item.Key === record.key)  item[dataIndex] = "";
      }
    });
    this.setState({
      dataSource,
      inputServiceHistory,
      editedServiceHistory
    });
   }
  onCellChange = (value, dataIndex, record) => {

    if (value && dataIndex !== "FileList") {
      var newvalue = value.trim();
    } else {
      newvalue = value;
    }

    if (newvalue.length === 0){

      switch(dataIndex) {
        case "RecievedCondition" : this.clearValue(dataIndex , record)
        break ;
        case "ReturnedCondition" : this.clearValue(dataIndex , record)
        break ;
        case "CalibrationDueDate" : this.clearValue(dataIndex, record)
        break ;
        case "OOTCaseNumber" : this.clearValue(dataIndex , record)
        break ;
        case "FileList" : this.clearValue(dataIndex , record)
        break ;
      }
       }

    if ( value.length > 0 && dataIndex === "FileList" && value[0].status === "done") {
      var fileList = {};
      var read = new FileReader();
      var data = value[0].originFileObj;
      read.onerror = function() {
        return UIFunctions.Toast("Error in uploading the file", "error");
      };
      read.onload = function() {
        fileList.name = data.name;
        fileList.data = read.result;
      };
      read.readAsDataURL(data);

      newvalue = fileList;
      this.handleFile(newvalue, dataIndex, record);
    } else {
      const dataSource = [...this.state.dataSource];
      let editedServiceHistory = this.state.editedServiceHistory;
      let inputServiceHistory = this.state.inputServiceHistory;
      const target = dataSource.find(item => item.Key === record.Key);
      if (target) {
        let index = dataSource.findIndex(({ Key }) => Key === target.Key);
        if (target.New) {
          if (index === -1) {
            target[dataIndex] = newvalue;
            dataSource.push(target);
          } else {
            target[dataIndex] = newvalue;
            dataSource[index] = target;
            let insert = true;
            if (inputServiceHistory.length > 0) {
              inputServiceHistory.map(item => {
                if (item.Key && item.Key == record.Key) {
                  insert = false;
                  Object.assign(item, target);
                }
              });
              if (insert) {
                inputServiceHistory.push(target);
              }
            } else {
              inputServiceHistory.push(target);
            }
          }
        } else {
          if (index === -1) {
            target[dataIndex] = newvalue;
            dataSource.push(target);
          } else {
            target[dataIndex] = newvalue;
            dataSource[index] = target;
            let insert = true;
            if (editedServiceHistory.length > 0) {
              editedServiceHistory.map(item => {
                if (item.Key && item.Key == record.Key) {
                  insert = false;
                  Object.assign(item, target);
                }
              });
              if (insert) {
                editedServiceHistory.push(target);
              }
            } else {
              editedServiceHistory.push(target);
            }
          }
        }
      }
      this.setState({ dataSource });
      this.setState({ disableSave: false });
    }
  };
  componentWillUnmount() {
    addAssetsStore.setServiceHistory([]);
    TabCount = 0
  }
 
  updateServiceHistory = () => {
    clearAttachedFile = true;
    var rowData = [];

    if (
      addAssetsStore.serviceHistory &&
      addAssetsStore.serviceHistory.length > 0
    ) {
      rowData = mobx.toJS(addAssetsStore.serviceHistory);
      this.setState({ dataSource: rowData });
      addAssetsStore.isServiceHistory = false;
    }
  };

  handleFile(value, dataIndex, record) {
    var newvalue = value;
    const dataSource = [...this.state.dataSource];
    let editedServiceHistory = this.state.editedServiceHistory;
    let inputServiceHistory = this.state.inputServiceHistory;
    const target = dataSource.find(item => item.Key === record.Key);
    if (target) {
      let index = dataSource.findIndex(({ Key }) => Key === target.Key);
      if (target.New) {
        if (index === -1) {
          target[dataIndex] = newvalue;
          dataSource.push(target);
        } else {
          target[dataIndex] = newvalue;
          dataSource[index] = target;
          let insert = true;
          if (inputServiceHistory.length > 0) {
            inputServiceHistory.map(item => {
              if (item.Key && item.Key == record.Key) {
                insert = false;
                Object.assign(item, target);
              }
            });
            if (insert) {
              inputServiceHistory.push(target);
            }
          } else {
            inputServiceHistory.push(target);
          }
        }
      } else {
        if (index === -1) {
          target[dataIndex] = newvalue;
          dataSource.push(target);
        } else {
          target[dataIndex] = newvalue;
          dataSource[index] = target;
          let insert = true;
          if (editedServiceHistory.length > 0) {
            editedServiceHistory.map(item => {
              if (item.Key && item.Key == record.Key) {
                insert = false;
                Object.assign(item, target);
              }
            });
            if (insert) {
              editedServiceHistory.push(target);
            }
          } else {
            editedServiceHistory.push(target);
          }
        }
      }
    }
    this.setState({ dataSource, disableSave: false });
  }

  
  fetchServiceHistory = () => {
    addAssetsStore.isServiceHistory = true;
    var uniqId =
      addAssetsStore.doubleClickedUniqueID != ""
        ? addAssetsStore.doubleClickedUniqueID
        : addAssetsStore.dashboardChecked[0];
        addAssetsStore.getServiceProvideValue(uniqId);
        Functions.GetServiceHistory(uniqId)
        .then(resp => {
          addAssetsStore.setServiceHistory(resp.data.data)
          dataSourceForExport = resp.data.data;
          this.fetchCSVdata(dataSourceForExport);
          let rowData = mobx.toJS(addAssetsStore.serviceHistory);
      this.setState({dataSource : rowData})
      addAssetsStore.isServiceHistory = false;
        }).catch(() => {
                  addAssetsStore.isServiceHistory = false;
                })
  }
  
  fetchCSVdata = dataSourceForExport => {
    dataSourceForExportCSV = [];
    let dataSource = dataSourceForExport;

    for (let i = 0; i < dataSource.length; i++) {
      let item = {};
      item.ServiceOrderID = dataSource[i].ServiceOrderID;
      item.ServiceType = dataSource[i].ServiceType;
      item.ServiceProvider = dataSource[i].ServiceProvider;
      item.RecievedCondition = dataSource[i].RecievedCondition;
      item.ReturnedCondition = dataSource[i].ReturnedCondition;

      if (new Date(dataSource[i].ServiceDate).getTime() > 10000)
        item.ServiceDate = moment(dataSource[i].ServiceDate).format("YYYY-MM-DD");
      else 
        item.ServiceDate = "";
      if (new Date(dataSource[i].CalibrationDueDate).getTime() > 10000)
        item.CalibrationDueDate = moment(dataSource[i].CalibrationDueDate).format("YYYY-MM-DD");
      else item.CalibrationDueDate = "";

      item.OOTCaseNumber = dataSource[i].OOTCaseNumber;
      item.DocumentURL = dataSource[i].DocumentURL;
      dataSourceForExportCSV.push(item);
    }
  };
  getFetchAssets = uniqId => {
    var self = this;
    Functions.fetchAssetDetailsValues(uniqId)
      .then(resp => {
        var values = resp.data.AssetDetails;
        if (serverData.length > 0) {
         
          scheduleTasksCount = serverData.length;
          for (var i = 0; i < serverData.length; i++) {
            serverData[i].DueDate = moment(serverData[i].DueDate);
          }
        }
        this.setState({ taskArray: serverData });

        tabModelStore.setAssetDetails(resp.data.AssetDetails);
        values.data.SystemName2 = values.data.SystemName;
        values.data.SystemParent2 = values.data.SystemParent;
        addAssetsStore.addToFieldStateFromCode(values.data);
        addAssetsStore.addToFieldStateFromCode({
          ThingName: resp.data.AssetDetails.data.thingName
        });
        addAssetsStore.clearEntriesAssetFileList();
        addAssetsStore.addToFieldStateFromCode({
          SysComponentList: resp.data.SystemComponents.SystemComponents
        });
        addAssetsStore.setSystemComponents(
          resp.data.SystemComponents.SystemComponents
        );
        for (var j = 0; j < dates.length; j++) {
          var date = dates[j];
          if (addAssetsStore.fieldState[date] === "1970-01-01T00:00:00.000Z")
            addAssetsStore.fieldState[date] = null;
        }

        var x = JSON.parse(values.data.History);
        x.forEach(item => {
          item.Timestamp = moment(item.Timestamp).format("YYYY-MM-DD HH:mm:ss");
        });
        addAssetsStore.addToFieldStateFromCode({ ChangeLog: x });
        addAssetsStore.setAssetFileUploadList([]);
        if (resp.data.AssetFiles.data) {
          var dataVal = resp.data.AssetFiles.data;
          var temprows = [];
          for (var k = 0; k < dataVal.length; k++) {
            temprows.push({
              downloadLink: dataVal[k].downloadLink,
              name: dataVal[k].name,
              lastModifiedDate: moment(dataVal[k].lastModifiedDate).format(
                "YYYY-MM-DD HH:mm:ss"
              )
            });
            addAssetsStore.addToFieldState({ AssetFilesList: temprows });
            addAssetsStore.setAssetFileUploadList(temprows);
          }
        }
        self.state.CustomerAssetList = addAssetsStore.getCustomerAssets;
        addAssetsStore.addToFieldStateFromCode({
          Licences: resp.data.License.License
        });
      }).catch(() => {
        addAssetsStore.isServiceHistory = false;
      });
  };

  handleDelete = (record, key) => {
    const dataSource = [...this.state.dataSource];
    const tempEditedServiceHistory = [...this.state.editedServiceHistory];
    const tempInputServiceHistory = [...this.state.inputServiceHistory];
    let deletedKeys = this.state.deletedKeys;
    if (record) {
      if (record.New !== true) {
        deletedKeys.push(key);
      }
    }
    this.setState({
      dataSource: dataSource.filter(item => item.Key !== key),
      deletedKeys: deletedKeys,
      editedServiceHistory: tempEditedServiceHistory.filter(
        item => item.Key !== key
      ),
      inputServiceHistory: tempInputServiceHistory.filter(
        item => item.Key !== key
      )
    });

    let deletionKeys = JSON.parse(JSON.stringify(this.state.deletedKeys));
    let payload = {};

    payload.DeletionKeys = deletionKeys;
    payload.EditData = [];
    payload.ThingName = tabModelStore.assetDetails.data.thingName;
    payload.InputData = [];
    if (deletionKeys.length !== 0) {
      addAssetsStore.isServiceHistory = true;
      Functions.manualServiceRequestHistory(
        payload.ThingName,
        payload.EditData,
        payload.DeletionKeys,
        payload.InputData
      )
        .then(resp => {
          let resultDeletion = false;

          if (resp.data.resultDeletion) {
            if (resp.data.resultDeletion.success === false) {
              addAssetsStore.isServiceHistory = false;
              return UIFunctions.Toast(
                "Oops ! Something went wrong in delete operation",
                "error"
              );
            } else {
              resultDeletion = true;
            }
          }
          if (resultDeletion) {
            UIFunctions.Toast("Deletion successful!", "success");
            this.setState({
              deletedKeys: []
            });

            var uniqId =
              addAssetsStore.doubleClickedUniqueID != ""
                ? addAssetsStore.doubleClickedUniqueID
                : addAssetsStore.dashboardChecked[0];
            Functions.GetServiceHistory(uniqId).then(resp => {
              dataSourceForExport = resp.data.data;
              this.fetchCSVdata(dataSourceForExport);
              this.getFetchAssets(uniqId);
              addAssetsStore.isServiceHistory = false;
            });
          }
        })

        .catch(() => {
          addAssetsStore.isServiceHistory = false;
        });
    }
  };

  handleAdd = () => {
    const { count, dataSource, inputServiceHistory } = this.state;
    const newData = {
      Key: count,
      ServiceProviderList: this.state.serviceProviderList,
      New: true,
      ServiceOrderID: "",
      ServiceType: "",
      ServiceProvider: "",
      CalibrationDueDate: "",
      ReturnedCondition: "",
      RecievedCondition: "",
      ServiceDate: "",
      OOTCaseNumber: "",
      FileList: ""
    };
    this.setState({
      dataSource: [...dataSource, newData],
      count: count + 1,
      inputServiceHistory: [...inputServiceHistory, newData],
      disableSave: false
    });

    const element = document.getElementsByClassName("ant-table-body")[0];
    if (element) {
      setTimeout(() => {
        element.scrollTop = element.scrollHeight;
      }, 100);
    }
  };
  handleClear = () => {
    addAssetsStore.isServiceHistory = true;
     let temp = this.state.dataSource ;
     let localData = [];
     temp.map((e)=>{
      if(!e.New){
        localData.push(e);
      }
     })
   
    var uniqId =
      addAssetsStore.doubleClickedUniqueID != ""
        ? addAssetsStore.doubleClickedUniqueID
        : addAssetsStore.dashboardChecked[0];
    Functions.GetServiceHistory(uniqId)
      .then(resp => {
        addAssetsStore.setServiceHistory(resp.data.data);
        addAssetsStore.isServiceHistory = false ;
        this.updateServiceHistory();
      })
      .catch(() => {
        addAssetsStore.isServiceHistory = false;
      });
    
    
    this.setState({
      dataSource : localData,
      disableSave: true ,
       inputServiceHistory : []
    });
    this.forceUpdate();
  };

  handleSave = () => {
    let deletionKeys = JSON.parse(JSON.stringify(this.state.deletedKeys));
    let editedServiceHistory = JSON.parse(
      JSON.stringify(this.state.editedServiceHistory)
    );
    let inputServiceHistory = JSON.parse(
      JSON.stringify(this.state.inputServiceHistory)
    );
    //validation

    let validate = editedServiceHistory.every(function(item) {
      if (
        !item.ServiceOrderID ||
        !item.ServiceProvider ||
        !item.ServiceType ||
        !item.ServiceDate
      ) {
        UIFunctions.Toast("One or more mandatory fields are empty!", "error");
        return false;
      } else return true;
    });
    var validate2 = false;

    if (validate) {
      validate2 = inputServiceHistory.every(function(item) {
        if (
          !item.ServiceOrderID ||
          !item.ServiceProvider ||
          !item.ServiceType ||
          !item.ServiceDate
        ) {
          UIFunctions.Toast("One or more mandatory fields are empty!", "error");
          return false;
        } else return true;
      });
    }
    if (validate && validate2) {
      editedServiceHistory.map(item => {
        if (item.DocumentURL) delete item.DocumentURL;
        if (item.ServiceProviderList) delete item.ServiceProviderList;
        if (item.Editable) delete item.Editable;
        if (item.CalibrationDueDate) {
          item.CalibrationDueDate = moment(item.CalibrationDueDate)
            .startOf("day")
            .toISOString();
        }
        if (item.ServiceDate) {
          item.ServiceDate = moment(item.ServiceDate)
            .startOf("day")
            .toISOString();
        }
      });
      inputServiceHistory.map(item => {
        if (item.Key) delete item.Key;
        if (item.ServiceProviderList) delete item.ServiceProviderList;
        if (item.New) delete item.New;
        if (item.CalibrationDueDate) {
          item.CalibrationDueDate = moment(item.CalibrationDueDate)
            .startOf("day")
            .toISOString();
        }
        if (item.ServiceDate) {
          item.ServiceDate = moment(item.ServiceDate)
            .startOf("day")
            .toISOString();
        }
      });
      addAssetsStore.isServiceHistory = true;
      let payload = {};
      payload.DeletionKeys = deletionKeys;
      payload.ThingName = tabModelStore.assetDetails.data.thingName;
      payload.EditData = editedServiceHistory;
      payload.InputData = inputServiceHistory;
      if (
        this.state.editedServiceHistory.length <= 0 &&
        this.state.inputServiceHistory <= 0
      ) {
        UIFunctions.Toast("Nothing has been edited ", "error");
        addAssetsStore.isServiceHistory = false;
      } else {
        Functions.manualServiceRequestHistory(
          payload.ThingName,
          payload.EditData,
          payload.DeletionKeys,
          payload.InputData
        )
          .then(resp => {
            let resultDeletion = false;
            let resultEdit = false;
            let resultInsertion = false;
            if (resp.data) {
              if (resp.data.resultDeletion) {
                if (resp.data.resultDeletion.success === false) {
                  addAssetsStore.isServiceHistory = false;
                  return UIFunctions.Toast(
                    "Oops ! Something went wrong in delete operation",
                    "error"
                  );
                } else {
                  resultDeletion = true;
                }
              }
              if (resp.data.resultEdit) {
                if (resp.data.resultEdit.success === false) {
                  addAssetsStore.isServiceHistory = false;
                  return UIFunctions.Toast(
                    "Oops ! Something went wrong in edit operation",
                    "error"
                  );
                } else {
                  resultEdit = true;
                }
              }
              if (resp.data.resultInsertion) {
                if (resp.data.resultInsertion.success === false) {
                  addAssetsStore.isServiceHistory = false;
                  return UIFunctions.Toast(
                    "Oops ! Something went wrong in insert operation",
                    "error"
                  );
                } else {
                  resultInsertion = true;
                }
              }
              if (resultDeletion && resultEdit && resultInsertion) {
                UIFunctions.Toast("Operation successful!", "success");
                this.setState({
                  deletedKeys: [],
                  editedServiceHistory: [],
                  inputServiceHistory: []
                });
                var uniqId =
                addAssetsStore.doubleClickedUniqueID != ""
                ? addAssetsStore.doubleClickedUniqueID
                : addAssetsStore.dashboardChecked[0];   
                Functions.GetServiceHistory(uniqId)
                  .then(resp => {
                    addAssetsStore.setServiceHistory(resp.data.data);
                    this.updateServiceHistory();
                    dataSourceForExport = resp.data.data;
                    this.fetchCSVdata(dataSourceForExport);
                    this.getFetchAssets(uniqId);
                  })
                  .catch(() => {
                    addAssetsStore.isServiceHistory = false;
                  });
                this.forceUpdate();
         
              }
            } else {
              return UIFunctions.Toast("Oops ! Something went wrong.", "error");
            }
          })
          .catch(() => {
            addAssetsStore.isServiceHistory = false;
          });
      }
    }
  };

  getRowHeight = () => {
    return 46;
  };

  onGridReady = params => {
    params.api.sizeColumnsToFit();
  };
  onServiceGridReady = params => {
    this.api = params.api;
    this.columnApi = params.columnApi;
  };
  onTabChange(key) {
    this.setState({ defaultTabKey: key });
  if(key === '2' ) {
    TabCount = TabCount+1 ;
    if(TabCount === 1) this.fetchServiceHistory()
  }}

  render() {
    var rowData = [];
    if (addAssetsStore.serviceHistory) {
      rowData = mobx.toJS(addAssetsStore.serviceHistory);
      rowData.map(e => {
        e.serviceDate = moment(e.serviceDate).format("YYYY-MM-DD");
        e.calibrationDueDate = moment(e.calibrationDueDate).format(
          "YYYY-MM-DD"
        );
      });
    }
    const { dataSource } = this.state;

    //Manipulating the dataSource

    const columns = this.columns;

    const headers = [
      { label: "Service Order ID", key: "ServiceOrderID" },
      { label: "Service Type", key: "ServiceType" },
      { label: "Service Provider", key: "ServiceProvider" },
      { label: "Received Condition", key: "RecievedCondition" },
      { label: "Returned Condition", key: "ReturnedCondition" },
      { label: "Service Date", key: "ServiceDate" },
      { label: "Calibration Due Date", key: "CalibrationDueDate" },
      { label: "OOT Case Number", key: "OOTCaseNumber" },
      { label: "Download Document", key: "DocumentURL" }
    ];

    return (
      <Form onSubmit={this.handleSubmit}>
        {addAssetsStore.mode === "DETAILS" ? (
          <div className="asset_history_wrapper">
            <div
              style={{ width: "100%" }}
              className="asset_service_TabContainer"
            >
              <FormItem>
                <Tabs
                  type="card"
                  defaultActiveKey={this.state.defaultTabKey}
                  onChange={this.onTabChange.bind(this)}
                >
                  <TabPane tab="ASSET" key="1">
                    <div
                      style={{
                        height: "200px",
                        color: "#666",
                        backgroundColor: "#e5e5e5"
                      }}
                      className="ag-fresh"
                    >
                      <AgGridReact
                        overlayLoadingTemplate='<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                        overlayNoRowsTemplate='<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow;">This is a custom no rows</span>'
                        id="changeGrid"
                        columnDefs={this._Changecolumns}
                        onGridReady={this.onGridReady.bind(this)}
                        enableColResize={true}
                        suppressMovableColumns={true}
                        icons={this.state.icons}
                        rowData={
                          addAssetsStore.fieldState.ChangeLog
                            ? addAssetsStore.fieldState.ChangeLog.map(e => e)
                            : []
                        }
                        rowHeight="35"
                        headerHeight="35"
                        enableSorting={true}
                      />
                    </div>
                  </TabPane>
                  <TabPane tab="SERVICE" key="2">                     
                    <Spin
                      spinning={addAssetsStore.isServiceHistory}
                      delay={500}
                    >
                      <Div3
                        style={{
                          height: 'auto',
                          color: "#666",
                          backgroundColor: "#e5e5e5"
                        }}
                      >
                        <Table
                          dataSource={dataSource}
                          columns={columns}
                          scroll={{ x: 2800, y: 250 }}
                          pagination={false}
                          getRowHeight={this.getRowHeight.bind(this)}
                          locale={{
                            emptyText: (
                              <div style={{marginTop:'-191px'}}>
                                <img src={noDataImage} />
                                  <p className="sp-no-data"> No Service Records Found</p>
                              </div>
                            )
                          }}
                        />
                      </Div3>
                    </Spin>
                    <Div2>
                      <div className="service-history-buttongroup">
                        <div>
                          <Popconfirm
                            title=" Do you want to clear all the unsaved data?"
                            onConfirm={this.handleClear.bind(this)}
                          >
                            <Button
                              size="medium"
                              type="primary"
                              className="sh-clear-button"
                            >
                              <Icon type="close" />
                              Clear
                            </Button>
                          </Popconfirm>
                        </div>
                        <div>
                          <Button
                            size="medium"
                            type="primary"
                            onClick={_.debounce(this.handleSave.bind(this) , 300)}
                            className="sh-save-button"
                            disabled={this.state.disableSave}
                          >
                            <Icon type="check" />
                            Save
                          </Button>
                        </div>
                        <div>
                          <Button
                            size="medium"
                            type="primary"
                            onClick={this.handleAdd.bind(this)}
                            className="sh-add-button"
                          >
                            <Icon type="plus" />
                            Add Item
                          </Button>
                        </div>
                      </div>
                    </Div2>
                  </TabPane>
                </Tabs>
              </FormItem>
            </div>
            {this.state.defaultTabKey == 2 ? (
              <div
                className="exportOptions"
                style={{ width: 100, marginLeft: -95, marginTop: 4 }}
              >
                {
                  <Button.Group
                    style={{ width: 100 }}
                    className="export-btn-group"
                  >
                    <CSVLink
                      data={dataSourceForExportCSV}
                      separator={","}
                      headers={headers}
                      filename={"export.csv"}
                      target="_blank"
                    >
                      <Button
                        type="primary"
                        icon="cloud-download"
                        size="small"
                      >
                        Export CSV
                      </Button>
                    </CSVLink>
                  </Button.Group>
                }
              </div>
            ) : (
              ""
            )}
          </div>
        ) : (
          ""
        )}
      </Form>
    );
  }
}

const WrappedRegistrationForm = Form.create()(History);
export default WrappedRegistrationForm;
