import React from "react";
import { Form, DatePicker, Cascader, Select } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;
import Functions from "../../api/Functions";
import permissionStore from "../../stores/permissionStore";
import addAssetsStore from "../../stores/addAssetsStore";
import "react-select/dist/react-select.css";
import userStore from "./../../stores/userStore";
import UIFunctions from "../../helpers/UIFunctions";

@observer
class Inventory extends React.Component {
  state = {
      confirmDirty: false,
      autoCompleteResult: [],
      Organization: "",
      Location: "",
      cordinator: userStore.userDetails.UserName
  };

  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll();
  };
  onOrgTreeChange = value => {
      addAssetsStore.addToFieldState({ Organization: value });
      Functions.GetAllUsersForCustomer(value[value.length - 1], "").then(resp => {
          addAssetsStore.setUsersForCustomer(resp.data.UserList);
          let userLogin =
        resp.data.UserList.filter(
            item => item == userStore.userDetails.UserName
        ).length == 0
            ? ""
            : userStore.userDetails.UserName;
          addAssetsStore.addToFieldState({ Coordinator: userLogin });
          this.setState({ cordinator: userLogin });
          this.props.form.setFieldsValue({ Coordinator: this.state.cordinator })(
              addAssetsStore.mode == "EDIT" || addAssetsStore.mode == "DETAILS"
          ) && addAssetsStore.fieldState.Coordinator
              ? this.props.form.setFieldsValue({
                  Coordinator: addAssetsStore.fieldState.Coordinator
              })
              : true;
      });
  };
  onOrgTreeChangeEdit = () => {
      Functions.GetAllUsersForCustomer(addAssetsStore.fieldState.Organization, "")
          .then(resp => {
              addAssetsStore.setUsersForCustomer(resp.data.UserList);
          })
          .catch(() => {
              UIFunctions.Toast("Oops ! Something wrong happened.");
          });
  };
  onLocTreeChange = value => {
      addAssetsStore.addToFieldState({ Location: value });
  };
  componentDidMount() {
      var self = this;
      setTimeout(function() {
          self.props.form.setFieldsValue({
              Coordinator: addAssetsStore.fieldState.Coordinator
          });
      }, 3000);
  }

  render() {
      const { getFieldDecorator } = this.props.form;
      const formItemLayout = {
          labelCol: {
              xs: { span: 24 },
              sm: { span: 6 }
          },
          wrapperCol: {
              xs: { span: 24 },
              sm: { span: 14 }
          }
      };

      return (
          <Form onSubmit={this.handleSubmit} autoComplete="off">
              {permissionStore.permissions.fields.Organization && (
                  <FormItem
                      {...formItemLayout}
                      label="Organization"
                      // hasFeedback
                  >
                      {getFieldDecorator("Organization", {
                          rules: [
                              {
                                  required:
                    addAssetsStore.mode === "CREATE" ||
                    addAssetsStore.mode == "EDIT" ||
                    addAssetsStore.mode == "DETAILS",
                                  message: "Please Select Organization"
                              }
                          ]
                      })(
                          <Cascader
                              getPopupContainer={trigger => trigger.parentElement}
                              options={addAssetsStore.OrganizationTree}
                              onChange={this.onOrgTreeChange.bind(this)}
                              disabled={addAssetsStore.mode === "DETAILS"}
                              changeOnSelect
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.Location && (
                  <FormItem {...formItemLayout} label="Location">
                      {getFieldDecorator("Location", {
                          rules: [
                              {
                                  required:
                    addAssetsStore.mode === "CREATE" ||
                    addAssetsStore.mode == "EDIT" ||
                    addAssetsStore.mode == "DETAILS",
                                  message: "Please Select Location"
                              }
                          ]
                      })(
                          <Cascader
                              getPopupContainer={trigger => trigger.parentElement}
                              options={addAssetsStore.locationTree}
                              onChange={this.onLocTreeChange}
                              disabled={addAssetsStore.mode === "DETAILS"}
                              changeOnSelect
                          />
                      )}
                  </FormItem>
              )}
              <FormItem {...formItemLayout} label="Coordinator">
                  {getFieldDecorator("Coordinator", {
                      rules: [
                          {
                              required:
                  addAssetsStore.mode === "CREATE" ||
                  addAssetsStore.mode == "EDIT" ||
                  addAssetsStore.mode == "DETAILS",
                              message: "Please Select Coordinator"
                          }
                      ]
                  })(
                      <Select
                          id="Coordinator"
                          disabled={
                              addAssetsStore.mode === "DETAILS" ||
                !addAssetsStore.usersForCustomer
                          }
                          getPopupContainer={trigger => trigger.parentElement}
                          showSearch={true}
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                              option.props.children
                                  .toLowerCase()
                                  .indexOf(input.toLowerCase()) >= 0
                          }
                          allowClear
                          onChange={value => {
                              addAssetsStore.addToFieldState({ Coordinator: value });
                          }}
                          placeholder="Please Select Coordinator"
                      >
                          {addAssetsStore.usersForCustomer
                              ? addAssetsStore.usersForCustomer.map(dropdown => (
                                  <option key={dropdown} value={dropdown}>
                                      {dropdown}
                                  </option>
                              ))
                              : ""}
                      </Select>
                  )}
              </FormItem>

              <FormItem
                  {...formItemLayout}
                  label="User"
                  // hasFeedback
              >
                  {getFieldDecorator("User", {
                      rules: [{}]
                  })(
                      <Select
                          id="User"
                          disabled={
                              addAssetsStore.mode === "DETAILS" ||
                !addAssetsStore.usersForCustomer
                          }
                          getPopupContainer={trigger => trigger.parentElement}
                          showSearch={true}
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                              option.props.children
                                  .toLowerCase()
                                  .indexOf(input.toLowerCase()) >= 0
                          }
                          //value={statess.User}
                          defaultValue={
                              addAssetsStore.fieldState.Coordinator
                                  ? addAssetsStore.fieldState.Coordinator
                                  : ""
                          }
                          allowClear
                          onChange={value => {
                              addAssetsStore.addToFieldState({ User: value });
                          }}
                          placeholder="Please Select User"
                      >
                          {addAssetsStore.usersForCustomer
                              ? addAssetsStore.usersForCustomer.map(dropdown => (
                                  <option key={dropdown}>{dropdown}</option>
                              ))
                              : ""}
                      </Select>
                  )}
              </FormItem>
              {permissionStore.permissions.fields.InventoryDate && (
                  <FormItem
                      {...formItemLayout}
                      label="Inventory date"
                      // hasFeedback
                  >
                      {getFieldDecorator("InventoryDate", {})(
                          <DatePicker
                              id="InventoryDate"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              format="YYYY-MM-DD"
                              getCalendarContainer={trigger => trigger.parentElement}
                              onChange={e =>
                                  e != null
                                      ? addAssetsStore.addToFieldState({
                                          InventoryDate: e.toISOString()
                                      })
                                      : addAssetsStore.addToFieldState({ InventoryDate: "" })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.LastUpdate && (
                  <FormItem
                      {...formItemLayout}
                      label="Last used on"
                      // hasFeedback
                  >
                      {getFieldDecorator("LastUpdate", {})(
                          <DatePicker
                              id="LastUpdate"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              format="YYYY-MM-DD"
                              getCalendarContainer={trigger => trigger.parentElement}
                              onChange={e =>
                                  e != null
                                      ? addAssetsStore.addToFieldState({
                                          LastUpdate: e.toISOString()
                                      })
                                      : addAssetsStore.addToFieldState({ LastUpdate: "" })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {/* <FormItem {...tailFormItemLayout}>
          <Button type="primary" htmlType="submit">Register</Button>
        </FormItem> */}
          </Form>
      );
  }
}

const WrappedRegistrationForm = Form.create()(Inventory);
export default WrappedRegistrationForm;
