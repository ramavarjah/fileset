import React from "react";
import Autosuggest from "react-autosuggest";
import _ from "lodash";
import { Icon } from "antd";
import styled from "styled-components";
import PropTypes from "prop-types";
// import { propTypes } from "mobx-react";

/* --------------- */
/*    Component    */
/* --------------- */

const Div = styled.div`
 background-color : ? "#f7f7f7" : "#ffffff"
 align-items: center;
 flex-wrap: wrap;
 flex-direction: row;
 display: flex;
 .div{
	 width: 100%;
 }
.react-autosuggest__container{
	width: 100%;
}
input.react-autosuggest__input{
	height: 32px;
	color: #949494 !important;
	padding: 6px 7px;
	font-size: 13px !important;
	line-height: 1.5;
	background-color:inherit;
	border: 1px solid #d9d9d9;
	border-radius: 4px;
	overflow: visible;
	width: 100%;
}
.react-autosuggest__suggestions-container.react-autosuggest__suggestions-container--open{
	border: 1px solid #c5c6ca;
	background-color: #fff;
	box-shadow: 0 1px 6px rgba(0, 0, 0, 0.2);
	border-radius: 4px;
	box-sizing: border-box;
	z-index: 1050;
	position: absolute;
	outline: none;
	overflow: auto;
	max-height: 250px;
	font-size: 13px;
	width: 550px;
	left: -0.015625px;
	top: 36.2305px;
	margin: 0px;
	padding: 5px 0px 2px 2px;
	ul{
		outline: none;
		margin-bottom: 0;
		padding-left: 0;
		list-style: none;
		overflow: auto;
		background-color: #fff;
		color: #949494;
		li{
			//border-bottom: 1px #ccd0d8 solid;
			line-height: 26px;
			padding: 5px 10px;
			font-weight: normal;
			color: rgba(0, 0, 0, 0.65);
			cursor: pointer;
			word-break: normal;
			}
			.react-autosuggest__suggestion--highlighted{
				background:#ebf5ff;
			}
			div{
					background-color: #0000 !important;
					color: #949494 !important;
			}
		}
	}
}
.header-close-icon-ML{
	position: absolute;
	right: 42px;
	margin-right: 2px;
	margin-top: 2px;
	i{
		font-size:14px;
		:hover{
			color:rgb(255, 61, 95);
			cursor:pointer;
		}
  }
  .disabled-close-icon{
    font-size:14px;
    :hover{
			color:inherit;
			cursor: inherit;
		}
  }
}
.header-searchbox-icon-ML{
    position: absolute;
    right: 0;
    height: 28px;
    width: 39px;
    margin-right: 2px;
    margin-top: 2px;
  i{
    height: 18px;
    width: 39px;
    color: #646c72;
    font-size: 14px;
    font-weight: 500;
    vertical-align: top;
    margin-top: 7px;
  }
    }
`;

function getSuggestionValue(suggestion) {
  return suggestion.label;
}
const renderStyle = {
  color: "white",
  zIndex: 10000000,
  backgroundColor: "grey",
  marginBottom: 1,
  borderBottomColor: "black",
  cursor: "pointer"
};
function renderSuggestion(suggestion) {
  return <div style={renderStyle}>{suggestion.label}</div>;
}

class AsyncCreatableSelect extends React.Component {
  constructor() {
    super();

    this.state = {
      value: null,
      suggestions: [],
      isLoading: false,
      isSelected: false
    };
    this.lastRequestId = null;
    this.loadSuggestions = _.debounce(this.loadSuggestions, 800);
  }

  loadSuggestions(value) {
    const { options } = this.props;
    // Cancel the previous request
    if (this.lastRequestId !== null) {
      clearTimeout(this.lastRequestId);
    }
    this.setState({
      isLoading: true
    });
    // Fake request
    this.lastRequestId = setTimeout(() => {
      function getMatchingLanguages(value) {
        const escapedValue = escapeRegexCharacters(value.trim());
        if (escapedValue === "") {
          return [];
        }
        const regex = new RegExp("^" + escapedValue, "i");
        let ret = options.filter(option => regex.test(option.value));
        const found = ret.findIndex(i => i.value === value);
        if (found == -1)
          return [
            ...ret,
            { value, label: `Create new Manufacturer "${value}"` }
          ];
        return ret;
      }

      /* ----------- */
      /*    Utils    */
      /* ----------- */

      // https://developer.mozilla.org/en/docs/Web/JavaScript/Guide/Regular_Expressions#Using_Special_Characters
      function escapeRegexCharacters(str) {
        return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      }
      this.setState({
        isLoading: false,
        suggestions: getMatchingLanguages(value)
      });
    }, 1000);
  }

  onChange = (event, value) => {
    let { newValue } = value;
    if (newValue) {
      this.props.clearErrors("Manufacturer");
    }
    if (!newValue || newValue == "") {
      this.setState({ isSelected: false });
      this.props.onClear();
    }
    this.setState({
      value: value.newValue ? value.newValue : ""
    });
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.loadSuggestions(value);
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };
  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.state.isSelected && nextProps.propValue == "") {
      this.setState({ value: "", isSelected: false });
      this.props.onClear();
    }
  }
  onBlur = () => {
    this.state.isSelected ? "" : this.setState({ value: "" });
  };
  shouldComponentUpdate(nextProps, nextState) {
    let { state, props } = this;
    const differentState = state !== nextState;
    const differentProps = props !== nextProps;
    return differentState || differentProps; //differentTitle || differentDone;
  }
  onSuggestionSelected = (event, { suggestion }) => {
    //eslint-disable-next-line
    console.log("onSuggestionSelected", (event, { suggestion }));
    this.setState({
      value: suggestion.value,
      isSelected: true
    });
    this.props.onChange(suggestion);
  };

  render() {
    const { value, suggestions, isLoading } = this.state;
    const { placeholder, disabled, propValue, modeType } = this.props;
    const inputProps = {
      placeholder: placeholder,
      onChange: this.onChange,
      onBlur: modeType ? () => {} : this.onBlur,
      value: value !== null ? value : propValue,
      disabled: disabled
    };
    const manufacturerStyle = {
      width: "100%",
      backgroundColor: disabled ? "#f7f7f7" : "#ffffff"
    };
    const searchstyle = {
      backgroundColor: disabled ? "#f7f7f7" : "#ffffff"
    };
    let clearButton;
    if ((value && value.length >= 1) || propValue) {
      clearButton = (
        <Icon
          className={disabled ? "disabled-close-icon" : "close-icon"}
          type="close"
          onClick={
            disabled ? () => {} : () => this.onChange("e", { newValue: "" })
          }
        />
      );
    }

    return (
      <React.Fragment>
        <Div className="manufacturer-list">
          <div style={manufacturerStyle}>
            <Autosuggest
              suggestions={suggestions}
              onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
              onSuggestionsClearRequested={this.onSuggestionsClearRequested}
              onSuggestionSelected={this.onSuggestionSelected}
              getSuggestionValue={getSuggestionValue}
              renderSuggestion={renderSuggestion}
              inputProps={inputProps}
            />
          </div>
          <div className="header-close-icon-ML">{clearButton}</div>
          <div className="header-searchbox-icon-ML" style={searchstyle}>
            <Icon type={isLoading ? "loading" : "search"} />
          </div>
        </Div>
      </React.Fragment>
    );
  }
}
export default AsyncCreatableSelect;
AsyncCreatableSelect.propTypes = {
  options: PropTypes.object,
  onChange: PropTypes.func,
  onClear: PropTypes.func,
  placeholder: PropTypes.string,
  disabled: PropTypes.bool,
  propValue: PropTypes.string
};
