import React from "react";
import { Form, Input, Select, Row, Col, Checkbox } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;

import Functions from "../../api/Functions";
import permissionStore from "../../stores/permissionStore";
import addAssetsStore from "../../stores/addAssetsStore";
import "react-select/dist/react-select.css";
import moment from "moment";
import UIFunctions from "../../helpers/UIFunctions";
import { AgGridReact } from "ag-grid-react";
// import tabModelStore from "../../stores/tabModelStore";

@observer
class SystemIntegration extends React.Component {
  state = {
    confirmDirty: false,
    autoCompleteResult: [],
    Organization: "",
    Location: "",
    ParentSystemNameList: [],
    icons: {
      filter: '<i class="fa fa-filter"/>',
      sortAscending: '<i class="fa fa-arrow-down"/>',
      sortDescending: '<i class="fa fa-arrow-up"/>'
    },
    SysComponentList: []
  };
  constructor(props) {
    super(props);
    this._Syscolumns = [
      { field: "EquipmentNo", headerName: "Equipment Number", menuTabs: [] },
      { field: "Manufacturer", headerName: "Manufacturer", menuTabs: [] },
      { field: "ModelNo", headerName: "Model Number", menuTabs: [] },
      { field: "SerialNo", headerName: "Serial Number", menuTabs: [] },
      { field: "Description", headerName: "Description", menuTabs: [] },
      {
        field: "CalibrationDueDate",
        headerName: "Calibration Due Date",
        menuTabs: []
      }
    ];

    this._AssetDetailsSyscolumns = [
      // { field: 'ParentChild ', headerName: 'Parent or Child ', width: 160, menuTabs: [] },
      {
        field: "EquipmentNo",
        name: "Equipment Number",
        width: 180,
        menuTabs: []
      },
      {
        field: "AssetNo",
        headerName: "Asset Number",
        width: 180,
        menuTabs: []
      },
      { field: "ModelNo", name: "Model Number", width: 180, menuTabs: [] },
      { field: "SerialNo", name: "Serial Number", width: 180, menuTabs: [] },
      { field: "Description", name: "Description", width: 200, menuTabs: [] },
      //{ field: 'ServiceDueDate', headerName: 'Service Due Date', width: 220, menuTabs: [],valueFormatter: this.dateFormatter },
      {
        field: "CalibrationDueDate",
        name: "Calibration Due Date",
        width: 260,
        menuTabs: [],
        valueFormatter: this.dateFormatter
      },
      {
        field: "SystemParentName",
        name: "System Parent Name",
        width: 260,
        menuTabs: []
      },
      {
        field: "PartOfSystemCalibration",
        headerName: "Part of Parent System Calibration",
        width: 320,
        menuTabs: []
      }
    ];
  }
  dateFormatter = params => {
    if (params.value) return moment(params.value).format("YYYY-MM-DD");
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll(() => {});
  };
  SysrowGetter = i => {
    var rtn = addAssetsStore.systemComponents;
    return rtn[i];
  };
  onGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  };
  onOrgTreeChange = value => {
    //console.log("onOrgTreeChange", arguments, value);
    addAssetsStore.addToFieldState({ Organization: value });
    Functions.GetAllUsersForCustomer(value, "").then(resp => {
      //console.log('GetAllUsersForCustomer', resp.data.UserList);
      addAssetsStore.setUsersForCustomer(resp.data.UserList);
    });
  };
  onLocTreeChange = value => {
    //console.log("onlocTreeChange", arguments, value);
    addAssetsStore.addToFieldState({ Location: value });
  };
  getSystemChild(systemName) {
    Functions.GetSystemChild(systemName).then(resp => {
      addAssetsStore.setSystemComponents(resp.data.SystemChild);
    });
  }
  getSystemComponents(ParentSystemName) {
    var SystemName = addAssetsStore.fieldState.SystemName;
    Functions.GetSystemComponents(SystemName, ParentSystemName).then(resp => {
      addAssetsStore.setSystemComponents(resp.data.SystemComponents);
    });
  }
  validateSystemName = (rule, value, callback) => {
    if (addAssetsStore.mode == "EDIT" && addAssetsStore.fieldState.SystemName2)
      if (addAssetsStore.fieldState.SystemName2 === value) return callback();

    Functions.ValidateSystemName(value).then(resp => {
      //console.log('ValidateEquipmentNumber', resp.data)
      if (!resp.data.isValid || !resp.data.success) {
        callback(new Error("More than one must be selected!"));
      } else callback();
    });
  };
  validateSystemParentUncheck = (rule, value, callback) => {
    if (addAssetsStore.fieldState.SystemParent2)
      if (addAssetsStore.fieldState.SystemParent2 === true && value === false) {
        Functions.ValidateSystemParentUncheck(
          addAssetsStore.fieldState.ThingName
        ).then(resp => {
          //console.log('ValidateEquipmentNumber', resp.data)
          if (!resp.data.isValid && resp.data.success) {
            UIFunctions.ShowError({ zIndex: 2000, title: resp.data.message });
            callback(new Error("Cannot change System Parent flag "));
          } else callback();
        });
      } else callback();
    else callback();
  };
  //Two functions added to Set Value to Text box while unchecking and checking back the check box
  onChangeSystemParent(e) {
    addAssetsStore.addToFieldState({ SystemParent: e.target.checked });
    if (
      addAssetsStore.fieldState.SystemName != null &&
      addAssetsStore.fieldState.SystemName != ""
    ) {
      var self = this;
      setTimeout(function() {
        self.props.form.setFieldsValue({
          SystemName: addAssetsStore.fieldState.SystemName
        });
      }, 500);
    }
  }
  onChangeSystemChild(e) {
    addAssetsStore.addToFieldState({ SystemChild: e.target.checked });
    if (
      addAssetsStore.fieldState.ParentSystemName != null &&
      addAssetsStore.fieldState.ParentSystemName != ""
    ) {
      var self = this;
      setTimeout(function() {
        self.props.form.setFieldsValue({
          ParentSystemName: addAssetsStore.fieldState.ParentSystemName
        });
      }, 500);
    }
    if (e.target.checked == false) {
      addAssetsStore.systemComponents = [];
      addAssetsStore.fieldState.ParentSystemName = "";
    }
  }
  componentDidMount() {
    /* eslint-disable  */
    if (addAssetsStore.mode === "BULKEDIT") {
      let nArray = [];
      const PartOfSystemCalibration = addAssetsStore.dataForBulkEdit.map(i =>
        nArray.push(i.PartOfSystemCalibration)
      );
      const valueTrue = function(element) {
        return element;
      };
      let PartOfSystemCalibrations = "";
      if (nArray.every(valueTrue)) {
        PartOfSystemCalibrations = nArray.every(valueTrue);
      } else if (nArray.some(valueTrue)) {
        PartOfSystemCalibrations = "Retain Setting";
      } else {
        PartOfSystemCalibrations = nArray.every(valueTrue);
      }

      this.props.form.setFieldsValue({
        PartOfSystemCalibration: PartOfSystemCalibrations
      });
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 }
      }
    };
    const formItemLayoutLabelCheckbox = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 18 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 6 }
      }
    };
    const formItemLayoutSystemParent = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 13 }
      }
    };
    return (
      <Form onSubmit={this.handleSubmit} autoComplete="off">
        <Row>
          <Col span={4} />
          <Col span={3}>
            {permissionStore.permissions.fields.SystemParent &&
              (addAssetsStore.mode === "CREATE" ||
                addAssetsStore.mode === "DETAILS" ||
                addAssetsStore.mode === "EDIT") && (
                <FormItem
                  {...formItemLayoutLabelCheckbox}
                  label="System parent"
                  style={{ "margin-left": -40 }}
                >
                  {getFieldDecorator("SystemParent", {
                    rules: [
                      {
                        validator:
                          addAssetsStore.mode === "EDIT"
                            ? this.validateSystemParentUncheck.bind(this)
                            : (rule, value, callback) => {
                                callback();
                              }
                      }
                    ]
                  })(
                    <Checkbox
                      id="SystemParent"
                      disabled={addAssetsStore.mode === "DETAILS"}
                      onChange={e => this.onChangeSystemParent(e)}
                      checked={addAssetsStore.fieldState.SystemParent}
                    />
                  )}
                </FormItem>
              )}
          </Col>
          <Col span={15} style={{ "margin-left": 18 }}>
            {addAssetsStore.fieldState.SystemParent && (
              <FormItem
                {...formItemLayoutSystemParent}
                label="System name"
                // hasFeedback
              >
                {getFieldDecorator("SystemName", {
                  rules: [
                    // { pattern: new RegExp('[a-zA-Z0-9 ]+$'), message: 'Not a Valid System Name' },
                    {
                      required: addAssetsStore.fieldState.SystemParent,
                      message: "Please input System name"
                    },
                    {
                      validator:
                        addAssetsStore.mode === "CREATE" ||
                        addAssetsStore.mode === "EDIT"
                          ? this.validateSystemName.bind(this)
                          : "",
                      message: "System Name already exists"
                    }
                  ]
                })(
                  <Input
                    id="SystemName"
                    placeholder={
                      addAssetsStore.fieldState.SystemName !== ""
                        ? addAssetsStore.fieldState.SystemName
                        : "Please Provide System Name"
                    }
                    disabled={addAssetsStore.mode === "DETAILS"}
                    onChange={e => {
                      addAssetsStore.addToFieldState({
                        SystemName: e.target.value
                      });
                    }}
                    // setFieldValue={addAssetsStore.fieldState.SystemName}
                  />
                )}
              </FormItem>
            )}
          </Col>
        </Row>
        <Row>
          <Col span={4} />
          <Col span={3}>
            {permissionStore.permissions.fields.SystemChild && (
              <FormItem
                {...formItemLayoutLabelCheckbox}
                label="System child"
                style={{ "margin-left": -40 }}
              >
                {getFieldDecorator("SystemChild", {})(
                  <Checkbox
                    id="System child"
                    disabled={addAssetsStore.mode === "DETAILS"}
                    onChange={e => this.onChangeSystemChild(e)}
                    checked={addAssetsStore.fieldState.SystemChild}
                  />
                )}
              </FormItem>
            )}
          </Col>
          <Col span={15} style={{ "margin-left": 18 }}>
            {addAssetsStore.fieldState.SystemChild &&
              permissionStore.permissions.fields.ParentSystemName && (
                <FormItem
                  {...formItemLayoutSystemParent}
                  label="Parent system name"
                  // hasFeedback
                >
                  {getFieldDecorator("ParentSystemName", {
                    rules: [
                      {
                        required: addAssetsStore.fieldState.SystemChild,
                        message: "Please input Parent system name"
                      }
                    ]
                  })(
                    <Select
                      id="ParentSystemName"
                      disabled={addAssetsStore.mode === "DETAILS"}
                      getPopupContainer={trigger => trigger.parentElement}
                      showSearch={true}
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                      allowClear={true}
                      onChange={value => {
                        if (!value)
                          return addAssetsStore.clearFromFieldState(
                            "ParentSystemName"
                          );
                        addAssetsStore.addToFieldState({
                          ParentSystemName: value
                        });
                        this.getSystemComponents(value);
                      }}
                      placeholder={
                        addAssetsStore.fieldState.ParentSystemName !== ""
                          ? addAssetsStore.fieldState.ParentSystemName
                          : "Please Select Parent System Name"
                      }
                    >
                      {addAssetsStore.fieldState.ParentSystemNameList
                        ? addAssetsStore.fieldState.ParentSystemNameList.map(
                            val =>
                              val.SystemName && (
                                <Select.Option key={val.SystemName}>
                                  {val.SystemName}
                                </Select.Option>
                              )
                          )
                        : ""}
                    </Select>
                  )}
                </FormItem>
              )}
          </Col>
        </Row>
        {/*<FormItem>
        {addAssetsStore.mode === "DETAILS" ?
        <div>
          {<ReactDataGrid columns={this._Syscolumns} rowGetter={this.SysrowGetter} rowsCount={addAssetsStore.fieldState.SysComponentList.length} minHeight={225} emptyRowsView={EmptyRowsView} />}
          </div>:""}
        </FormItem>*/}
        {/* {(permissionStore.permissions.fields.ParentSystemName && addAssetsStore.mode === "CREATE" || addAssetsStore.mode === "DETAILS") && */}
        {/*{addAssetsStore.fieldState.SystemChild &&
          <FormItem
            {...formItemLayout}
            label="Parent system name"
            >
            {getFieldDecorator('ParentSystemName', {
              rules: [
                { required: addAssetsStore.fieldState.SystemChild, message: 'Please input Parent system name', },
              ]
            })(
              <Select
                id="ParentSystemName"
                disabled={addAssetsStore.mode === "DETAILS"}
                placeholder="Please Select Parent system Name">
                {addAssetsStore.fieldState.ParentSystemNameList.map(val =>val.SystemName&&
                  <Select.Option key={val.SystemName}>{val.SystemName}</Select.Option>
                  )}
              </Select>
            )}
          </FormItem>}*/}
        {permissionStore.permissions.fields.PartOfSystemCalibration && (
          <FormItem
            {...formItemLayout}
            label="Part of parent system calibration"
            className="assetLabelCustomLetterSpacing1"
          >
            {getFieldDecorator("PartOfSystemCalibration", {})(
              addAssetsStore.mode === "BULKEDIT" ? (
                <Select
                  defaultValue="Retain Setting"
                  style={{ width: 120 }}
                  onChange={value => {
                    value == "Retain Setting"
                      ? addAssetsStore.removeFromFieldState({
                          PartOfSystemCalibration: value
                        })
                      : addAssetsStore.addToFieldState({
                          PartOfSystemCalibration: value
                        });
                  }}
                >
                  <option value={true}>True</option>
                  <option value={false}>False</option>
                  <option value="Retain Setting">Retain Setting</option>
                </Select>
              ) : (
                <Checkbox
                  id="PartOfSystemCalibration"
                  disabled={addAssetsStore.mode === "DETAILS"}
                  onChange={e => {
                    addAssetsStore.addToFieldState({
                      PartOfSystemCalibration: e.target.checked
                    });
                  }}
                  checked={addAssetsStore.fieldState.PartOfSystemCalibration}
                />
              )
            )}
          </FormItem>
        )}
        {!(addAssetsStore.mode === "BULKEDIT") && (
          <div className="systemInterationAgGridReact">
            <label className="formLabels" htmlFor="other">
              System components
            </label>
            <div
              style={{
                height: "275px",
                color: "#666",
                backgroundColor: "#e5e5e5"
              }}
              className="ag-fresh"
            >
              <AgGridReact
                columnDefs={
                  addAssetsStore.mode === "DETAILS"
                    ? this._AssetDetailsSyscolumns
                    : this._Syscolumns
                }
                onGridReady={this.onGridReady.bind(this)}
                enableColResize={true}
                rowData={
                  addAssetsStore.systemComponents
                    ? addAssetsStore.systemComponents.map(e => e)
                    : []
                }
                enableSorting={true}
                rowHeight="35"
                headerHeight="35"
                suppressMovableColumns={true}
                icons={this.state.icons}
              />
            </div>{" "}
          </div>
        )}

        {/* <FormItem {...tailFormItemLayout}>
          <Button type="primary" htmlType="submit">Register</Button>
        </FormItem> */}
      </Form>
    );
  }
}

const WrappedRegistrationForm = Form.create()(SystemIntegration);
export default WrappedRegistrationForm;
