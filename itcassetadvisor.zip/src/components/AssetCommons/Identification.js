import React from "react";
import { Form, Input, Select, Checkbox, DatePicker } from "antd";
const FormItem = Form.Item;
const { TextArea } = Input;
const Option = Select.Option;
import addAssetsStore from "../../stores/addAssetsStore";
import Functions from "../../api/Functions";

import URL from "../../api/Urls";
import request from "../../api/request";
import select from "react-select";
import permissionStore from "../../stores/permissionStore";
import _ from "lodash";
import "react-select/dist/react-select.css";

class RegistrationForm extends React.Component {
  constructor(props) {
    super(props);
    this._Servicecolumns = [
      { key: "EquipmentNo", name: "Equipment Number" },
      { key: "Manufacturer", name: "Manufacturer" },
      { key: "ModelNo", name: "ModelNo" },
      { key: "SerialNo", name: "Serial Number" },
      { key: "Description", name: "Description" },
      { key: "CalibrationDueDate", name: "CalibrationDueDate" }
    ];
    this._Syscolumns = [
      { key: "EquipmentNo", name: "Equipment Number" },
      { key: "Manufacturer", name: "Manufacturer" },
      { key: "ModelNo", name: "ModelNo" },
      { key: "SerialNo", name: "Serial Number" },
      { key: "Description", name: "Description" },
      { key: "CalibrationDueDate", name: "CalibrationDueDate" }
    ];

    this._Changecolumns = [
      { field: "Timestamp", headerName: "Last Changed Date" },
      { field: "Description", headerName: "Details" },
      { field: "EditedBy", headerName: "Edited By" }
    ];

    this._Servicecolumns = [
      { field: "Timestamp", headerName: "Last Changed Date" },
      { field: "Description", headerName: "Details" },
      { field: "EditedBy", headerName: "Edited By" }
    ];
  }
  state = {
    confirmDirty: false,
    autoCompleteResult: [],
    binaryFiles: { data: "", fileName: "" },
    isUploadFileSelected: false,
    storeb64File: this.storeb64File,
    defaultTabKey: 1
  };
  onGridReady = params => {
    params.api.sizeColumnsToFit();
  };

  ChangerowGetter = i => {
    var rtn = addAssetsStore.fieldState.ChangeLog;
    return rtn[i];
  };

  componentDidMount() {
    this.getModelNo();
    /*eslint-disable*/
    console.log("Manufact",addAssetsStore.ManufacturerList)
  }

  getModelNo() {
    if (
      addAssetsStore.fieldState.Manufacturer != null &&
      addAssetsStore.fieldState.Manufacturer != undefined &&
      addAssetsStore.fieldState.Manufacturer != ""
    ) {
      Functions.GetModelNoList(
        addAssetsStore.fieldState.Manufacturer
      ).then(resp => {
        var optionList = [];
        if (resp.data.details.length > 0) {
          var finallist = [];
          for (var i = 0; i < resp.data.details[0].length; i++) {
            Array.prototype.push.apply(finallist, resp.data.details[0][i]);
          }
          optionList = finallist.map(function(val) {
            return { label: val, value: val };
          });
        }
        this.setState({ ModelNoList: optionList });
        addAssetsStore.addToFieldState({ ModelNoList: optionList });
        var data = _.cloneDeep(addAssetsStore.fieldState);
        this.props.form.setFieldsValue(this.parseAndMakeForForm(data));
      });
    }
  }
  parseAndMakeForForm() {
    var IntegerFields = addAssetsStore.IntegerFields;
    var rtn = [];
    for (var fields of IntegerFields) {
      if (rtn[fields] && rtn[fields] == -999999) {
        rtn[fields] = "";
      }
    }
  }
  dateParsingFn(dateToFormat) {
    let defaultDate = "02-08-1991";
    if (dateToFormat != undefined)
      defaultDate = new Date(dateToFormat).toLocaleString().split(",")[0];
    return defaultDate;
  }
  addManufacturer(value) {
    var send = true;
    let ManufacturerList = addAssetsStore.ManufacturerList;
    ManufacturerList.map((item, index) => {
      if (item.value === value && index != 0) {
        send = false;
      }
    });
    send &&
      Functions.AddManufacturer(value).then(() => {
        ManufacturerList.push(value);
        addAssetsStore.setManufacturerList( ManufacturerList );
      }); //no action required
    if (!send) {
      this.getModelNo();
    } else {
      this.setState({
        ModelNoList: []
      });
    }
  }
  addModelNo(value) {
    var send = true;
    addAssetsStore.fieldState.ModelNoList &&
      addAssetsStore.fieldState.ModelNoList.map((item, index) => {
        if (item.value === value && index != 0) {
          send = false;
        }
      });
    send && Functions.AddModelNo(addAssetsStore.fieldState.Manufacturer, value); //no action required
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll();
  };
  handleConfirmBlur = e => {
    const value = e.target.value;
    addAssetsStore.addToFieldState({
      confirmDirty: addAssetsStore.fieldState.confirmDirty || !!value
    });
  };
  checkPassword = (rule, value, callback) => {
    const form = this.props.form;
    if (value && value !== form.getFieldValue("password")) {
      callback("Two passwords that you enter is inconsistent!");
    } else {
      callback();
    }
  };
  checkConfirm = (rule, value, callback) => {
    const form = this.props.form;
    if (value && addAssetsStore.fieldState.confirmDirty) {
      form.validateFields(["confirm"], { force: true });
    }
    callback();
  };

  handleWebsiteChange = value => {
    let autoCompleteResult;
    if (!value) {
      autoCompleteResult = [];
    } else {
      autoCompleteResult = [".com", ".org", ".net"].map(
        domain => `${value}${domain}`
      );
    }
    addAssetsStore.addToFieldState({ autoCompleteResult });
  };

  storeb64File(e) {
    const fileName = e.target.files[0].name;
    const reader = new FileReader();
    var self = this;
    reader.onload = file => {
      let tempData = file.target.result.split(",")[1];
      let tempObj = { data: tempData, fileName: fileName };
      self.setState({
        binaryFiles: tempObj,
        isUploadFileSelected: true
      });

      request({
        method: "post",
        url: URL.fileupload,
        data: {
          File: tempData,
          AssetEqNum: addAssetsStore.fieldState.EquipmentNo,
          FileName: fileName
        }
      })
        .then(() => {})
        .catch(() => {});
    };

    reader.readAsDataURL(e.target.files[0]);
  }

  validateEqNo = (rule, value, callback) => {
    Functions.ValidateEquipmentNumber(value).then(resp => {
      if (!resp.data.isUnique || !resp.data.success) {
        callback(new Error("More than one must be selected!"));
      } else callback();
    });
  };
  validateManufacturer = (rule, value, callback) => {
    var re = new RegExp("^[a-zA-Z0-9].*");
    if (!re.test(value)) {
      callback(new Error("More than one must be selected!"));
    } else {
      callback();
    }
  };
  validateModelNo = (rule, value, callback) => {
    var re = new RegExp("^[a-zA-Z0-9].*");
    if (!re.test(value)) {
      callback(new Error("More than one must be selected!"));
    } else {
      callback();
    }
  };
  onTabChange(key) {
    if (key == 1) {
      //Tab 1 Selected
    } else if (key == 2) {
      //Tab 2 Selected
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;

    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 }
      }
    };

    <Select style={{ width: 60 }}>
      <Option value="86">+86</Option>
      <Option value="87">+87</Option>
    </Select>;

    return (
      <Form onSubmit={this.handleSubmit} autoComplete="off">
        {!(addAssetsStore.mode === "BULKEDIT") && (
          <FormItem
            {...formItemLayout}
            label="Equipment number"
            // hasFeedback
          >
            {getFieldDecorator("EquipmentNo", {
              rules: [
                {
                  required:
                    addAssetsStore.mode === "CREATE" ||
                    addAssetsStore.mode == "EDIT" ||
                    addAssetsStore.mode == "DETAILS",
                  message: "Please input equipment number"
                },
                {
                  validator:
                    addAssetsStore.mode === "CREATE"
                      ? this.validateEqNo.bind(this)
                      : (rule, value, callback) => {
                          callback();
                        },
                  message: "Equipment number already exist"
                }
              ]
            })(
              <Input
                id="EquipmentNo"
                disabled={addAssetsStore.mode === "CREATE" ? false : true}
                placeholder={addAssetsStore.fieldState.EquipmentNo}
                onChange={e =>
                  addAssetsStore.addToFieldState({
                    EquipmentNo: e.target.value
                  })}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.Manufacturer && (
          <FormItem
            {...formItemLayout}
            label="Manufacturer"
            // hasFeedback
          >
            {getFieldDecorator("Manufacturer", {
              rules: [
                {
                  required:
                    addAssetsStore.mode === "CREATE" ||
                    addAssetsStore.mode === "DETAILS" ||
                    addAssetsStore.mode === "EDIT",
                  message: "Please input Manufacturer"
                },
                {
                  transform: value => {
                    if (value) {
                      return value.value;
                    } else return value;
                  }
                }
              ]
            })(
              <select.Creatable
                clearableValue
                promptTextCreator={value =>
                  'Create new manufacturer "' + value + '"'}
                onChange={value => {
                  if (!value)
                    return addAssetsStore.clearFromFieldState("Manufacturer");
                  addAssetsStore.addToFieldState({ Manufacturer: value.value });
                  this.addManufacturer(value.value);
                  addAssetsStore.clearFromFieldState("ModelNo");
                }}
                id="tabSelect"
                placeholder={
                  addAssetsStore.fieldState.Manufacturer
                    ? addAssetsStore.fieldState.Manufacturer
                    : "Please input Manufacturer"
                }
                options={addAssetsStore.ManufacturerList}
                style={{ width: "100%" }}
                disabled={addAssetsStore.mode === "DETAILS"}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.AltManufacturerName && (
          <FormItem
            {...formItemLayout}
            label="Alternative Manufacturer Name"
            className="assetLabelCustomLetterSpacing1"
            // hasFeedback
          >
            {getFieldDecorator("AltManufacturerName", {
              rules: []
            })(
              <Input
                id="AltManufacturerName"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  addAssetsStore.addToFieldState({
                    AltManufacturerName: e.target.value
                  })}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ModelNo &&
          !(addAssetsStore.mode === "BULKEDIT") && (
            <FormItem
              {...formItemLayout}
              label="Model number"
              // hasFeedback
            >
              {getFieldDecorator("ModelNo", {
                rules: [
                  {
                    required:
                      addAssetsStore.mode === "CREATE" ||
                      addAssetsStore.mode === "DETAILS" ||
                      addAssetsStore.mode === "EDIT",
                    message: "Please input Model number"
                  },
                  {
                    transform: value => {
                      if (value) {
                        return value.value;
                      } else return value;
                    }
                  }
                ]
              })(
                <select.Creatable
                  clearableValue
                  promptTextCreator={value =>
                    'Create new model number "' + value + '"'}
                  id="tabSelect"
                  onChange={value => {
                    if (!value)
                      return addAssetsStore.clearFromFieldState("ModelNo");
                    this.addModelNo(value.value);
                    addAssetsStore.addToFieldState({ ModelNo: value.value });
                  }}
                  placeholder={
                    addAssetsStore.fieldState.ModelNo != ""
                      ? addAssetsStore.fieldState.ModelNo
                      : "Please input ModelNo"
                  }
                  options={this.state.ModelNoList ? this.state.ModelNoList : []}
                  style={{ width: "100%" }}
                  disabled={
                    addAssetsStore.mode === "DETAILS" ||
                    addAssetsStore.mode === "BULKEDIT"
                  }
                />
              )}
            </FormItem>
          )}
        {permissionStore.permissions.fields.SerialNo &&
          !(addAssetsStore.mode === "BULKEDIT") && (
            <FormItem
              {...formItemLayout}
              label="Serial number"
              // hasFeedback
            >
              {getFieldDecorator("SerialNo", {
                rules: [
                  {
                    required:
                      addAssetsStore.mode === "CREATE" ||
                      addAssetsStore.mode == "EDIT" ||
                      addAssetsStore.mode == "DETAILS",
                    message: "Please input Serial number"
                  }
                ]
              })(
                <Input
                  id="SerialNo"
                  disabled={
                    addAssetsStore.mode === "DETAILS" ||
                    addAssetsStore.mode === "BULKEDIT"
                  }
                  onChange={e =>
                    addAssetsStore.addToFieldState({
                      SerialNo: e.target.value
                    })}
                  placeholder=""
                />
              )}
            </FormItem>
          )}
        {permissionStore.permissions.fields.AssetNo &&
          !(addAssetsStore.mode === "BULKEDIT") && (
            <FormItem
              {...formItemLayout}
              label="Asset number"
              // hasFeedback
            >
              {getFieldDecorator("AssetNo", {
                rules: [{}]
              })(
                <Input
                  id="AssetNo"
                  disabled={
                    addAssetsStore.mode === "DETAILS" ||
                    addAssetsStore.mode === "BULKEDIT"
                  }
                  onChange={e =>
                    addAssetsStore.addToFieldState({ AssetNo: e.target.value })}
                />
              )}
            </FormItem>
          )}
        {permissionStore.permissions.fields.Barcode &&
          !(addAssetsStore.mode === "BULKEDIT") && (
            <FormItem
              {...formItemLayout}
              label="Barcode/RFID"
              // hasFeedback
            >
              {getFieldDecorator("Barcode", {
                rules: [{}]
              })(
                <Input
                  id="Barcode"
                  disabled={
                    addAssetsStore.mode === "DETAILS" ||
                    addAssetsStore.mode === "BULKEDIT"
                  }
                  onChange={e =>
                    addAssetsStore.addToFieldState({ Barcode: e.target.value })}
                />
              )}
            </FormItem>
          )}
        {permissionStore.permissions.fields.Description && (
          <FormItem
            {...formItemLayout}
            label="Description"
            // hasFeedback
          >
            {getFieldDecorator("Description", {})(
              <TextArea
                rows={4}
                id="Description"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  addAssetsStore.addToFieldState({
                    Description: e.target.value
                  })}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ProductCategory && (
          <FormItem
            {...formItemLayout}
            label="Product category"
            // hasFeedback
          >
            {getFieldDecorator("ProductCategory", {})(
              <Select
                getPopupContainer={trigger => trigger.parentElement}
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0}
                onChange={value => {
                  if (!value)
                    return addAssetsStore.clearFromFieldState(
                      "ProductCategory"
                    );
                  addAssetsStore.addToFieldState({ ProductCategory: value });
                }}
                id="tabSelect"
                allowClear={true}
                disabled={addAssetsStore.mode === "DETAILS"}
              >
                {addAssetsStore
                  .getPageWiseDropDownValues("ProductCategory")
                  .map(dropdown => <option key={dropdown}>{dropdown}</option>)}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ReplacedBy && (
          <FormItem
            {...formItemLayout}
            label="Replaced by"
            // hasFeedback
          >
            {getFieldDecorator("ReplacedBy", {})(
              <Select
                getPopupContainer={trigger => trigger.parentElement}
                onChange={value => {
                  if (!value)
                    return addAssetsStore.clearFromFieldState("Manufacturer");
                  addAssetsStore.addToFieldState({ ReplacedBy: value });
                }}
                id="tabSelect"
                allowClear={true}
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0}
                disabled={addAssetsStore.mode === "DETAILS"}
              >
                {addAssetsStore.getCustomerAssets.map(dropdown => (
                  <option key={dropdown}>{dropdown}</option>
                ))}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.UtilizationCategory && (
          <FormItem
            {...formItemLayout}
            label="Utilization category"
            // hasFeedback
          >
            {getFieldDecorator("UtilizationCategory", {})(
              <Select
                getPopupContainer={trigger => trigger.parentElement}
                onChange={value => {
                  if (!value)
                    return addAssetsStore.clearFromFieldState("Manufacturer");
                  addAssetsStore.addToFieldState({
                    UtilizationCategory: value
                  });
                }}
                id="tabSelect"
                allowClear={true}
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0}
                disabled={addAssetsStore.mode === "DETAILS"}
              >
                {addAssetsStore
                  .getPageWiseDropDownValues("UtilizationCategory")
                  .map(dropdown => <option key={dropdown}>{dropdown}</option>)}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.LoanDailyRate && (
          <FormItem
            {...formItemLayout}
            label="Loan Daily Rate (%)"
            // hasFeedback
          >
            {getFieldDecorator("LoanDailyRate", {
              rules: [
                {
                  pattern: new RegExp("^[0-9{.}]+(.[0-9]{1,3})?$"),
                  message: "Not a Valid value."
                }
              ]
            })(
              <Input
                id="LoanDailyRate"
                defaultValue={4}
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e => {
                  e.target.value === ""
                    ? addAssetsStore.addToFieldState({ LoanDailyRate: 4 })
                    : addAssetsStore.addToFieldState({
                        LoanDailyRate: e.target.value
                      });
                  this.props.checkAndSetLoanDailyCost();
                }}
                onBlur={val =>
                  val.target.value == ""
                    ? this.props.form.setFieldsValue({ LoanDailyRate: 4 })
                    : ""}
                style={{ width: "82px" }}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.icons.LoanPool && (
          <FormItem
            {...formItemLayout}
            label="Auto calculate 'Loan daily cost'"
          >
            {getFieldDecorator("LoanAutoCalculate", {})(
              <Checkbox
                id="LoanAutoCalculate"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e => {
                  addAssetsStore.addToFieldState({
                    LoanAutoCalculate: e.target.checked
                  });
                  this.props.checkAndSetLoanDailyCost();
                }}
                checked={addAssetsStore.fieldState.LoanAutoCalculate}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.LoanDailyCost && (
          <FormItem
            {...formItemLayout}
            label="Loan daily cost"
            // hasFeedback
          >
            {getFieldDecorator("LoanDailyCost", {
              rules: [
                {
                  pattern: new RegExp("^[0-9{.}]+(.[0-9]{1,3})?$"),
                  message: "Not a valid Loan daily cost"
                }
              ]
            })(
              <Input
                id="LoanDailyCost"
                disabled={
                  addAssetsStore.mode === "DETAILS" ||
                  addAssetsStore.fieldState.LoanAutoCalculate
                }
                onChange={e =>
                  e.target.value != ""
                    ? addAssetsStore.addToFieldState({
                        LoanDailyCost: e.target.value
                      })
                    : addAssetsStore.addToFieldState({
                        LoanDailyCost: -999999
                      })}
                style={{ width: "82px" }}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.Currency && (
          <FormItem
            {...formItemLayout}
            label="Currency"
            // hasFeedback
          >
            {getFieldDecorator("Currency", {})(
              <Select
                allowClear={true}
                getPopupContainer={trigger => trigger.parentElement}
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0}
                onChange={value => {
                  if (!value)
                    return addAssetsStore.clearFromFieldState("Manufacturer");
                  addAssetsStore.addToFieldState({ Currency: value });
                }}
                id="tabSelect"
                disabled={addAssetsStore.mode == "DETAILS"}
              >
                {addAssetsStore
                  .getPageWiseDropDownValues("Currency")
                  .map(dropdown => <option key={dropdown}>{dropdown}</option>)}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.StickyNotes && (
          <FormItem
            {...formItemLayout}
            label="Sticky notes"
            // hasFeedback
          >
            {getFieldDecorator("StickyNotes", {})(
              <TextArea
                rows={3}
                id="StickyNotes"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  addAssetsStore.addToFieldState({
                    StickyNotes: e.target.value
                  })}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.EquipmentType && (
          <FormItem
            {...formItemLayout}
            label="Equipment type"
            // hasFeedback
          >
            {getFieldDecorator("EquipmentType", {})(
              <Select
                getPopupContainer={trigger => trigger.parentElement}
                onChange={value => {
                  if (!value)
                    return addAssetsStore.clearFromFieldState("Manufacturer");
                  addAssetsStore.addToFieldState({ EquipmentType: value });
                }}
                id="tabSelect"
                allowClear={true}
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0}
                disabled={addAssetsStore.mode == "DETAILS"}
              >
                {addAssetsStore
                  .getPageWiseDropDownValues("EquipmentType")
                  .map(dropdown => <option key={dropdown}>{dropdown}</option>)}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ReplacementDate && (
          <FormItem {...formItemLayout} label="Replacement date">
            {getFieldDecorator("ReplacementDate", {})(
              <DatePicker
                id="ReplacementDate"
                getCalendarContainer={trigger => trigger.parentElement}
                format="YYYY-MM-DD"
                size={addAssetsStore.fieldState}
                onChange={e =>
                  e != null
                    ? addAssetsStore.addToFieldState({
                        ReplacementDate: e.toISOString()
                      })
                    : addAssetsStore.addToFieldState({ ReplacementDate: "" })}
                disabled={addAssetsStore.mode == "DETAILS"}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.Project && (
          <FormItem
            {...formItemLayout}
            label="Project name"
            // hasFeedback
          >
            {getFieldDecorator("Project", {
              rules: []
            })(
              <Input
                id="Project"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  addAssetsStore.addToFieldState({ Project: e.target.value })}
              />
            )}
          </FormItem>
        )}
      </Form>
    );
  }
}

const WrappedRegistrationForm = Form.create()(RegistrationForm);
export default WrappedRegistrationForm;
