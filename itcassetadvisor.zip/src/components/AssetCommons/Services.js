import React from "react";
import { Form, Input, DatePicker, Select, Checkbox, Button } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;
import Functions from "../../api/Functions";
import permissionStore from "../../stores/permissionStore";
import addAssetsStore from "../../stores/addAssetsStore";
import "react-select/dist/react-select.css";
import UIFunctions from "../../helpers/UIFunctions";
import select from "react-select";

@observer
class Services extends React.Component {
  state = {
    confirmDirty: false,
    autoCompleteResult: [],
    Organization: "",
    Location: "",
    CalibrationProvider:"",
    
  };
  constructor(props) {
    super(props);
    this.state = {
      value: null,
      suggestions: [],
      isSelected: false
    };
    this._Syscolumns = [
      { key: "EquipmentNo", name: "Equipment Number" },
      { key: "Manufacturer", name: "Manufacturer" },
      { key: "ModelNo", name: "ModelNo" },
      { key: "SerialNo", name: "Serial Number" },
      { key: "Description", name: "Description" },
      { key: "CalibrationDueDate", name: "CalibrationDueDate" }
    ];
  }
  handleClickAddAgreement = () => {
    UIFunctions.ShowInfo({
      zIndex: 2000,
      title: "Functionality not implemented..!! "
    });
  };
  handleSubmit = e => {
    e.preventDefault();
  };

  onOrgTreeChange = value => {
    addAssetsStore.addToFieldState({ Organization: value });
    Functions.GetAllUsersForCustomer(value, "").then(resp => {
      addAssetsStore.setUsersForCustomer(resp.data.UserList);
    });
  };
  onLocTreeChange = value => {
    addAssetsStore.addToFieldState({ Location: value });
  };

  componentDidMount() { 
    
    addAssetsStore.mode === "BULKEDIT" ? addAssetsStore.addToFieldState({ CalibrationProvider: "" }): 
                  "" 

    addAssetsStore.mode === "BULKEDIT" ? addAssetsStore.addToFieldState({ RepairProvider: "" }): 
       ""
  }
  addCaliProvider = value => {
    var send = true;
    let calProviderList = addAssetsStore.calProviderList;
    calProviderList.map((item, index) => {
      if (item.value === value && index != 0) {
        send = false;
      }
    });
    send &&
      Functions.AddCalibrationProvider(value).then(() => {
        calProviderList.push(value);
        addAssetsStore.getDropDownValues();
      });
  };

  addRepairProvider = value => {
    var send = true;
    let repairProviderList = addAssetsStore.repairProviderList;
    repairProviderList.map((item, index) => {
      if (item.value === value && index != 0) {
        send = false;
      }
    });
    send &&
      Functions.AddRepairProvider(value).then(() => {
        repairProviderList.push(value);
        addAssetsStore.getDropDownValues();
      });
  }




  onClear = () => {
    addAssetsStore.clearFromFieldState("CalibrationProvider");
    this.props.form.resetFields(["CalibrationProvider"]);
  };
  onChange = (event, selectedValue) => {
    let { newValue } = selectedValue;
    if (!newValue || newValue == "") {
      this.setState({ isSelected: false });
      this.onClear();
    }
    this.setState({
      value: selectedValue.newValue ? selectedValue.newValue : ""
    });
  };
  onSuggestionSelected = (event, { suggestion }) => {
    this.setState({
      value: suggestion.value
    });
    this.onCalProviderSelected(suggestion);
  };
  
  validateValues = (current, { CalibrationProvider }) => {
    if (!CalibrationProvider && current) {
     
      this.setState({ value: null });
    }
  };
  UNSAFE_componentWillReceiveProps(nextProps) {
    
    this.validateValues(this.state.value, addAssetsStore.fieldState);
    if (this.state.isSelected && nextProps.propValue == "") {
      this.setState({ value: "", isSelected: false });
      this.props.onClear();
    }
  }
  render() {
    
    const { getFieldDecorator } = this.props.form;

    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 }
      }
    };
    return (
      <Form onSubmit={this.handleSubmit} autoComplete="off">
        {permissionStore.permissions.fields.LastReportedCondition && (
          <FormItem
            {...formItemLayout}
            label="Last reported condition"
            // hasFeedback
          >
            {getFieldDecorator("LastReportedCondition", {})(
              <Select
                id="tabSelect"
                placeholder="Please Select Last reported condition"
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0
                }
                getPopupContainer={trigger => trigger.parentElement}
                allowClear={true}
                onChange={value => {
                  addAssetsStore.addToFieldState({
                    LastReportedCondition: value
                  });
                }}
              >
                {addAssetsStore
                  .getPageWiseDropDownValues("LastReportedCondition")
                  .map(dropdown => (
                    <option key={dropdown}>{dropdown}</option>
                  ))}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.CalibrationProvider && (
          <FormItem
            {...formItemLayout}
            label="Calibration Provider"
          >
            {getFieldDecorator("CalibrationProvider", {})(
              <select.Creatable
                  clearableValue
                  promptTextCreator={value =>
                    'Create new Calibration Provider "' + value + '"'
                  }
                  id="tabSelect"
                  onChange={( value) => {
                    if (!value)
                      return addAssetsStore.clearFromFieldState("CalibrationProvider");
                      this.addCaliProvider(value.value)
                      addAssetsStore.addToFieldState({ CalibrationProvider:value.value })
                  }}
                  placeholder={
                    addAssetsStore.fieldState.CalibrationProvider != ""
                      ? addAssetsStore.fieldState.CalibrationProvider
                      : "Please input Calibration Provider"
                  }
                  options={addAssetsStore.calProviderList}
                  style={{ width: "100%" }}
                  disabled={
                    addAssetsStore.mode === "DETAILS"
                  }
                />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ServiceLogistics && (
          <FormItem
            {...formItemLayout}
            label="Service logistics"
            // hasFeedback
          >
            {getFieldDecorator("ServiceLogistics", {})(
              <Select
                id="tabSelect"
                placeholder="Please Select Service Logistics"
                getPopupContainer={trigger => trigger.parentElement}
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0
                }
                allowClear={true}
                onChange={value => {
                  addAssetsStore.addToFieldState({ ServiceLogistics: value });
                }}
                disabled={addAssetsStore.mode === "DETAILS"}
              >
                {addAssetsStore
                  .getPageWiseDropDownValues("ServiceLogistics")
                  .map(dropdown => (
                    <option key={dropdown}>{dropdown}</option>
                  ))}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.CalibrationType && (
          <FormItem
            {...formItemLayout}
            label="Calibration type"
            // hasFeedback
          >
            {getFieldDecorator("CalibrationType", {})(
              <Select
                id="tabSelect"
                placeholder="Please Select Calibration Type"
                getPopupContainer={trigger => trigger.parentElement}
                allowClear={true}
                showSearch={true}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children
                    .toLowerCase()
                    .indexOf(input.toLowerCase()) >= 0
                }
                onChange={value => {
                  addAssetsStore.addToFieldState({ CalibrationType: value });
                }}
                disabled={addAssetsStore.mode === "DETAILS"}
              >
                {addAssetsStore
                  .getPageWiseDropDownValues("CalibrationType")
                  .map(dropdown => (
                    <option key={dropdown}>{dropdown}</option>
                  ))}
              </Select>
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.LastCalibrationDate && (
          <FormItem
            {...formItemLayout}
            label="Last calibration date"
            // hasFeedback
          >
            {getFieldDecorator("CalibrationDate", {})(
              <DatePicker
                id="CalibrationDate"
                disabled={addAssetsStore.mode === "DETAILS"}
                format="YYYY-MM-DD"
                getCalendarContainer={trigger => trigger.parentElement}
                onChange={e =>
                  e != null
                    ? addAssetsStore.addToFieldState({
                        CalibrationDate: e.toISOString()
                      })
                    : addAssetsStore.addToFieldState({ CalibrationDate: "" })
                }
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.CalibrationInterval && (
          <FormItem
            {...formItemLayout}
            label="Calibration interval (months)"
            // hasFeedback
          >
            {getFieldDecorator("CalibrationInterval", {
              rules: [
                {
                  pattern: new RegExp("^[0-9]*$"),
                  message: "Not a Valid Calibration interval"
                }
              ]
            })(
              <Input
                id="CalibrationInterval"
                placeholder="Please Provide Calibration Interval"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  e.target.value != ""
                    ? addAssetsStore.addToFieldState({
                        CalibrationInterval: e.target.value
                      })
                    : addAssetsStore.addToFieldState({
                        CalibrationInterval: -999999
                      })
                }
                style={{ width: "82px" }}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.CalibrationDueDate && (
          <FormItem
            {...formItemLayout}
            label="Calibration due date"
            // hasFeedback
          >
            {getFieldDecorator("CalibrationDueDate", {})(
              <DatePicker
                id="CalibrationDueDate"
                disabled={addAssetsStore.mode === "DETAILS"}
                format="YYYY-MM-DD"
                getCalendarContainer={trigger => trigger.parentElement}
                onChange={e =>
                  e != null
                    ? addAssetsStore.addToFieldState({
                        CalibrationDueDate: e.startOf("day").toISOString()
                      })
                    : addAssetsStore.addToFieldState({ CalibrationDueDate: "" })
                }
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.LastServiceDate && (
          <FormItem
            {...formItemLayout}
            label="Last service date"
            // hasFeedback
          >
            {getFieldDecorator("LastServiceDate", {})(
              <DatePicker
                id="LastServiceDate"
                disabled={addAssetsStore.mode === "DETAILS"}
                format="YYYY-MM-DD"
                getCalendarContainer={trigger => trigger.parentElement}
                onChange={e =>
                  e != null
                    ? addAssetsStore.addToFieldState({
                        LastServiceDate: e.toISOString()
                      })
                    : addAssetsStore.addToFieldState({ LastServiceDate: "" })
                }
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ServiceInterval && (
          <FormItem
            {...formItemLayout}
            label="Service interval (months)"
            // hasFeedback
          >
            {getFieldDecorator("ServiceInterval", {
              rules: [
                {
                  pattern: new RegExp("^[0-9]*$"),
                  message: "Not a Valid Service interval"
                }
              ]
            })(
              <Input
                id="ServiceInterval"
                placeholder="Please provide service interval"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  e.target.value != ""
                    ? addAssetsStore.addToFieldState({
                        ServiceInterval: e.target.value
                      })
                    : addAssetsStore.addToFieldState({
                        ServiceInterval: -999999
                      })
                }
                style={{ width: "82px" }}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ServiceDueDate && (
          <FormItem
            {...formItemLayout}
            label="Service due date"
            // hasFeedback
          >
            {getFieldDecorator("ServiceDueDate", {})(
              <DatePicker
                id="ServiceDueDate"
                disabled={addAssetsStore.mode === "DETAILS"}
                format="YYYY-MM-DD"
                getCalendarContainer={trigger => trigger.parentElement}
                onChange={e =>
                  e != null
                    ? addAssetsStore.addToFieldState({
                        ServiceDueDate: e.toISOString()
                      })
                    : addAssetsStore.addToFieldState({ ServiceDueDate: "" })
                }
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.ServiceCost && (
          <FormItem
            {...formItemLayout}
            label="Service cost"
            // hasFeedback
          >
            {getFieldDecorator("ServiceCost", {
              rules: [
                {
                  pattern: new RegExp("^[0-9{.}]+(.[0-9]{1,3})?$"),
                  message: "Not a valid Service cost"
                }
              ]
            })(
              <Input
                id="ServiceCost"
                placeholder="Please Provide Service Cost"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  e.target.value != ""
                    ? addAssetsStore.addToFieldState({
                        ServiceCost: e.target.value
                      })
                    : addAssetsStore.addToFieldState({ ServiceCost: -999999 })
                }
                style={{ width: "82px" }}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.RepairProvider && (
          <FormItem
            {...formItemLayout}
            label="Repair provider"          
          >
            {getFieldDecorator("RepairProvider", {})(
              <select.Creatable
              clearableValue
              promptTextCreator={value =>
                'Create new RepairProvider "' + value + '"'
              }
              id="tabSelect"
              onChange={value => {
                if (!value)
                  return addAssetsStore.clearFromFieldState("RepairProvider");
                 this.addRepairProvider(value.value)
                addAssetsStore.addToFieldState({ RepairProvider: value.value });
              }}
              placeholder={
                addAssetsStore.fieldState.RepairProvider != ""
                  ? addAssetsStore.fieldState.RepairProvider
                  : "Please input Repair Provider"
              }
              options={addAssetsStore.repairProviderList}
              style={{ width: "100%" }}
              disabled={
                addAssetsStore.mode === "DETAILS" 
              }
            />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.UseProviderCalibrationType && (
          <FormItem {...formItemLayout} label="Use provider calibration type">
            {getFieldDecorator("UseProviderCalibrationType", {})(
              <Checkbox
                id="UseProviderCalibrationType"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  addAssetsStore.addToFieldState({
                    UseProviderCalibrationType: e.target.checked
                  })
                }
                checked={addAssetsStore.fieldState.UseProviderCalibrationType}
              />
            )}
          </FormItem>
        )}
        {permissionStore.permissions.fields.UseProviderCalibrationSchedule && (
          <FormItem
            {...formItemLayout}
            label="Use provider calibration schedule"
            className="assetLabelCustomLetterSpacing2"
          >
            {getFieldDecorator("UseProviderCalibrationSchedule", {})(
              <Checkbox
                id="UseProviderCalibrationSchedule"
                disabled={addAssetsStore.mode === "DETAILS"}
                onChange={e =>
                  addAssetsStore.addToFieldState({
                    UseProviderCalibrationSchedule: e.target.checked
                  })
                }
                checked={
                  addAssetsStore.fieldState.UseProviderCalibrationSchedule
                }
              />
            )}
          </FormItem>
        )}
        {
          <FormItem>
            <Button
              type="button"
              onClick={e => {
                this.handleClickAddAgreement(e);
              }}
              disabled={addAssetsStore.mode === "DETAILS"}
            >
              Add agreements
            </Button>
          </FormItem>
        }
      </Form>
    );
  }
}

const WrappedRegistrationForm = Form.create()(Services);
export default WrappedRegistrationForm;
