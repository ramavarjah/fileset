import React from "react";
import { Form, Input, Select, DatePicker } from "antd";
import { observer } from "mobx-react";
const FormItem = Form.Item;
import Functions from "../../api/Functions";
import permissionStore from "../../stores/permissionStore";
import addAssetsStore from "../../stores/addAssetsStore";
import "react-select/dist/react-select.css";

@observer
class OrderingAndRecieving extends React.Component {
  state = {
      confirmDirty: false,
      autoCompleteResult: [],
      Organization: "",
      Location: ""
  };
  handleSubmit = e => {
      e.preventDefault();
      this.props.form.validateFieldsAndScroll();
  };

  onOrgTreeChange = value => {
      addAssetsStore.addToFieldState({ Organization: value });
      Functions.GetAllUsersForCustomer(value, "").then(resp => {
          addAssetsStore.setUsersForCustomer(resp.data.UserList);
      });
  };
  onLocTreeChange = value => {
      addAssetsStore.addToFieldState({ Location: value });
  };
  dateParsingFn(dateToFormat) {
      let defaultDate = "02-08-1991";
      if (dateToFormat != undefined)
          defaultDate = new Date(dateToFormat).toLocaleString().split(",")[0];
      return defaultDate;
  }

  render() {
      const { getFieldDecorator } = this.props.form;
      const formItemLayout = {
          labelCol: {
              xs: { span: 24 },
              sm: { span: 6 }
          },
          wrapperCol: {
              xs: { span: 24 },
              sm: { span: 14 }
          }
      };

      return (
          <Form onSubmit={this.handleSubmit} autoComplete="off">
              {permissionStore.permissions.fields.OwnershipStatus && (
                  <FormItem {...formItemLayout} label="Ownership status">
                      {getFieldDecorator("OwnershipStatus", {})(
                          <Select
                              id="OwnershipStatus"
                              placeholder="Please Select Ownership status"
                              getPopupContainer={trigger => trigger.parentElement}
                              allowClear={true}
                              showSearch={true}
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                  option.props.children
                                      .toLowerCase()
                                      .indexOf(input.toLowerCase()) >= 0
                              }
                              onChange={value => {
                                  addAssetsStore.addToFieldState({ OwnershipStatus: value });
                              }}
                              disabled={addAssetsStore.mode === "DETAILS"}
                          >
                              {addAssetsStore
                                  .getPageWiseDropDownValues("OwnershipStatus")
                                  .map(dropdown => (
                                      <option key={dropdown}>{dropdown}</option>
                                  ))}
                          </Select>
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.OwningCompany && (
                  <FormItem
                      {...formItemLayout}
                      label="Owning company"
                      // hasFeedback
                  >
                      {getFieldDecorator("OwningCompany", {
                          rules: [{}]
                      })(
                          <Input
                              id="OwningCompany"
                              placeholder="Please Provide Owning Company"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({
                                      OwningCompany: e.target.value
                                  })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.OrderNumber && (
                  <FormItem
                      {...formItemLayout}
                      label="Order number"
                      // hasFeedback
                  >
                      {getFieldDecorator("OrderNumber", {
                          rules: [{}]
                      })(
                          <Input
                              id="OrderNumber"
                              placeholder="Please Provide Order Number"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({
                                      OrderNumber: e.target.value
                                  })
                              }
                              setFieldsValue={addAssetsStore.fieldState.OrderNumber}
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.PurchasePrice && (
                  <FormItem
                      {...formItemLayout}
                      label="Purchase price"
                      // hasFeedback
                  >
                      {getFieldDecorator("PurchasePrice", {
                          rules: [
                              {
                                  pattern: new RegExp("^[0-9{.}]+(.[0-9]{1,3})?$"),
                                  message: "Not a Valid value."
                              }
                          ]
                      })(
                          <Input
                              id="PurchasePrice"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  e.target.value != ""
                                      ? addAssetsStore.addToFieldState({
                                          PurchasePrice: e.target.value
                                      })
                                      : addAssetsStore.addToFieldState({ PurchasePrice: -999999 })
                              }
                              setFieldsValue={addAssetsStore.fieldState.PurchasePrice}
                              style={{ width: "82px" }}
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.InvoiceNumber && (
                  <FormItem
                      {...formItemLayout}
                      label="Invoice number"
                      // hasFeedback
                  >
                      {getFieldDecorator("InvoiceNumber", {
                          rules: [{}]
                      })(
                          <Input
                              id="InvoiceNumber"
                              placeholder="Please Provide Invoice Number"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              onChange={e =>
                                  addAssetsStore.addToFieldState({
                                      InvoiceNumber: e.target.value
                                  })
                              }
                              setFieldsValue={addAssetsStore.fieldState.InvoiceNumber}
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.PlannedDisposalDate && (
                  <FormItem {...formItemLayout} label="Planned disposal date">
                      {getFieldDecorator("PlannedDisposalDate", {})(
                          <DatePicker
                              id="PlannedDisposalDate"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              format="YYYY-MM-DD"
                              getCalendarContainer={trigger => trigger.parentElement}
                              onChange={e =>
                                  e != null
                                      ? addAssetsStore.addToFieldState({
                                          PlannedDisposalDate: e.toISOString()
                                      })
                                      : addAssetsStore.addToFieldState({
                                          PlannedDisposalDate: ""
                                      })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.OrderDate && (
                  <FormItem {...formItemLayout} label="Order date">
                      {getFieldDecorator("OrderDate", {})(
                          <DatePicker
                              id="OrderDate"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              format="YYYY-MM-DD"
                              getCalendarContainer={trigger => trigger.parentElement}
                              onChange={e =>
                                  e != null
                                      ? addAssetsStore.addToFieldState({
                                          OrderDate: e.toISOString()
                                      })
                                      : addAssetsStore.addToFieldState({ OrderDate: "" })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.ReceivedDate && (
                  <FormItem
                      {...formItemLayout}
                      label="Received date"
                      // hasFeedback
                  >
                      {getFieldDecorator("ReceivedDate", {})(
                          <DatePicker
                              id="ReceivedDate"
                              disabled={addAssetsStore.mode === "DETAILS"}
                              format="YYYY-MM-DD"
                              getCalendarContainer={trigger => trigger.parentElement}
                              onChange={e =>
                                  e != null
                                      ? addAssetsStore.addToFieldState({
                                          ReceivedDate: e.toISOString()
                                      })
                                      : addAssetsStore.addToFieldState({ ReceivedDate: "" })
                              }
                          />
                      )}
                  </FormItem>
              )}
              {permissionStore.permissions.fields.LifeCycleStage && (
                  <FormItem
                      {...formItemLayout}
                      label="Life cycle stage"
                      // hasFeedback
                  >
                      {getFieldDecorator("LifeCycleStage", {})(
                          <Select
                              id="LifeCycleStage"
                              placeholder="Please Select Ownership Life Cycle Stage"
                              allowClear={true}
                              getPopupContainer={trigger => trigger.parentElement}
                              showSearch={true}
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                  option.props.children
                                      .toLowerCase()
                                      .indexOf(input.toLowerCase()) >= 0
                              }
                              onChange={value => {
                                  addAssetsStore.addToFieldState({ LifeCycleStage: value });
                              }}
                              disabled={addAssetsStore.mode === "DETAILS"}
                              setFieldsValue={addAssetsStore.fieldState.BookValue}
                          >
                              {addAssetsStore
                                  .getPageWiseDropDownValues("LifeCycleStage")
                                  .map(dropdown => (
                                      <option key={dropdown}>{dropdown}</option>
                                  ))}
                          </Select>
                      )}
                  </FormItem>
              )}
          </Form>
      );
  }
}

const WrappedRegistrationForm = Form.create()(OrderingAndRecieving);
export default WrappedRegistrationForm;
