import React, { Component } from "react";
import logoImage from "../../views/Pages/images/keysight_logo_dark.png";
import PropTypes from "prop-types";

class Footer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      thinFooter: true
    };
  }
  render() {
    const { authed } = this.props;
    return (
      <div id="mainFooter" className="pos-f-b appFooter">
        {this.state.thinFooter ? (
          <nav
            className="navbar navbar-dark bg-dark footerLinks"
            data-toggle="collapse"
            data-target="#navbarToggleExternalContent"
            aria-controls="navbarToggleExternalContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            {/*<button className="navbar-toggler" type="button" onClick={() => this.setState({ thinFooter: false })}>
              <span className="navbar-toggler-icon">
            */}
            <a
              className="footer-up-toggle"
              onClick={() => this.setState({ thinFooter: false })}
            >
              <i className="icon-arrow-up" />
            </a>

            <li className="footerCopyright">
              &copy; Keysight Technologies 2000-2018
            </li>
            <a
              className="footer-labels"
              onClick={() => this.setState({ thinFooter: false })}
            >
              <span className="footer-title">
                <p>Buy</p>
                <p>Support Task</p>
                <p>Legal</p>
              </span>
            </a>
          </nav>
        ) : (
          <div className="container-fluide footer-expand-outer-wrap">
            <div
              className="overlay"
              onMouseOver={() => this.setState({ thinFooter: true })}
            />
            <div className="container-fluide footer-expand-wrap">
              <div className="efw-content">
                <button
                  className="collapse-footer"
                  type="button"
                  onClick={() => this.setState({ thinFooter: true })}
                >
                  <i className="icon-arrow-down" />
                </button>
                <div className="clearfix">
                  <div className="fl">
                    <img src={logoImage} alt="Keysight" className="f-logo" />
                  </div>
                  <div className="fr">
                    <div className="footertlt">
                      <span>Buy</span>
                      <span>Support Tasks</span>
                      <span>Legal</span>
                      {/* <span>Submit Tasks</span>
                            <span>V1.5.08 BF2 (12-06-2017</span> */}
                    </div>
                    <div className="footerLinks">
                      <p>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/my/faces/pages_home?showTab=products"
                          title="Products"
                          rel="noopener noreferrer"
                        >
                          Products
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/main/facet.jspx?pageMode=SO&cc=US&lc=eng"
                          title="See Special Offers"
                          rel="noopener noreferrer"
                        >
                          See Special Offers
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/find/trade"
                          title="View Trade-in Offers"
                          rel="noopener noreferrer"
                        >
                          View Trade-in Offers
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/find/used"
                          title="Browse Used Equipment"
                          rel="noopener noreferrer"
                        >
                          Browse Used Equipment
                        </a>
                      </p>
                      <p>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/main/facet.jspx?pageMode=LB&t=79841.g.1&cc=US&lc=eng"
                          title="Privacy"
                          rel="noopener noreferrer"
                        >
                          Find a Manual
                        </a>
                        {authed && (
                          <a
                            target="_blank"
                            href="/files/UserGuide.pdf"
                            title="Privacy"
                          >
                            Asset Advisor User Manual
                          </a>
                        )}
                        <a
                          target="_blank"
                          href="http://www.keysight.com/main/facet.jspx?pageMode=DS&cc=US&lc=eng"
                          title="Privacy"
                          rel="noopener noreferrer"
                        >
                          Update Firmware / Software
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/find/repairandcal_pricing"
                          title="Privacy"
                          rel="noopener noreferrer"
                        >
                          Request Repair or Calibration
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/find/warrantystatus"
                          title="Privacy"
                          rel="noopener noreferrer"
                        >
                          Check Warranty Status
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/my/faces/fapHomePage.jspx?cc=US&lc=eng"
                          title="Privacy"
                          rel="noopener noreferrer"
                        >
                          Find a Part
                        </a>
                      </p>
                      <p>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/main/editorial.jspx?pmode=Privacy&lc=eng&cc=US"
                          title="Privacy"
                          rel="noopener noreferrer"
                        >
                          Privacy
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/main/editorial.jspx?pmode=TermsOfUse&lc=eng&cc=US"
                          title="Terms"
                          rel="noopener noreferrer"
                        >
                          Terms
                        </a>
                        <a
                          target="_blank"
                          href="http://www.keysight.com/main/redirector.jspx?action=ref&nid=-33506.1029522.00&lc=eng&cc=US&ckey=trademarks&cname=EDITORIAL"
                          title="Trademark Acknowlegements"
                          rel="noopener noreferrer"
                        >
                          Trademark Acknowlegements
                        </a>
                        <p
                          className="footerCopyright"
                          style={{ color: "#3385FF" }}
                        >
                          V1.6.10_1 (12-14-2018)
                        </p>{" "}
                        {/* Current Build Label */}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default Footer;

Footer.propTypes = {
  authed: PropTypes.bool
};
