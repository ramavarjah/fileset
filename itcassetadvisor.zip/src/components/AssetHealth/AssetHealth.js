import React, { Component } from "react";
import { Modal, ModalHeader, ModalBody } from "reactstrap";

class AssetHealth extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="row">
        <Modal
          isOpen={this.state.modal}
          toggle={this.toggleNew.bind(this)}
          className="modal-dialog modal-lg"
          id="createAssetModal"
        >
          <ModalHeader
            className="row modalHeader"
            style={{ borderBottom: "1px solid #ccd0d8" }}
          >
            <span className="createAssetLabel">CREATE ASSET</span>
            <span
              onClick={this.toggleNew.bind(this)}
              style={{ cursor: "pointer" }}
            >
              <i className="icon-close" />
            </span>
          </ModalHeader>
          <ModalBody style={{ padding: 0 }}>
            <h1>test</h1>
          </ModalBody>
        </Modal>
      </div>
    );
  }
}

export default AssetHealth;
