import React, { Component } from "react";
import { Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { observer } from "mobx-react";
import { observable } from "mobx";
import Functions from "./../../api/Functions";
import UIFunctions from "./../../helpers/UIFunctions";
import addAssetsStore from "./../../stores/addAssetsStore";
import { Form, Card, Button } from "antd";
import "react-select/dist/react-select.css";
import "../../helpers/Antd/antd.css"; // new line of code
import permissionStore from "../../stores/permissionStore";
import Waypoint from "react-waypoint";
//segments
import Identification from "../AssetCommons/Identification";
import Configuration from "../AssetCommons/Configuration";
import OrderingAndRecieving from "../AssetCommons/OrderingAndRecieving";
import Inventory from "../AssetCommons/Inventory";
import Valuation from "../AssetCommons/Valuation";
import SystemIntegration from "../AssetCommons/SystemIntegration";
import Services from "../AssetCommons/Services";

var rr, locTree;
const dates = [
  "ReplacementDate",
  "CalibrationDate",
  "CalibrationDueDate",
  "LastServiceDate",
  "ServiceDueDate",
  "PlannedDisposalDate",
  "OrderDate",
  "ReceivedDate",
  "BookValueDate",
  "InventoryDate",
  "LastUpdate"
];

@observer
class BulkEdit extends Component {
  @observable formLoaded;
  @observable renderer;
  @observable orgTreeData;
  @observable locTreeData;

  state = {
    size: "default"
  };

  constructor(props) {
    super(props);
    this.state = {
      // ReplacementDate:' 08-02-1991',
      LoanAutoCalculate: false,
      modal: true,
      modalNew: !this.props.clicked,
      activeTab: "Identification",
      value: undefined,
      Organization: undefined,
      Location: undefined,
      renderedTree: null,

      Manufacturer: "",
      AltManufacturerName: "",
      Description: "",
      ProductCategory: null,
      ReplacedBy: null,
      UtilizationCategory: null,
      LoanDailyCost: -999999,
      Currency: null,
      StickyNotes: "",
      EquipmentType: null,
      FirmwareRevision: "",
      HardwareVersion: "",
      Accessories: "",
      Options: "",
      SoftwareRevision: "",
      SystemParent: false,
      SystemName: "",
      SystemChild: false,
      ParentSystemName: null,
      PartOfSystemCalibration: false,
      LastReportedCondition: null,
      CalibrationProvider: null,
      ServiceLogistics: null,
      CalibrationType: null,
      //  "ServiceDueDate":null,
      ServiceCost: -999999,
      RepairProvider: null,
      UseProviderCalibrationType: false,
      UseProviderCalibrationSchedule: false,
      OwnershipStatus: null,
      OwningCompany: "",
      OrderNumber: "",
      PurchasePrice: -999999,
      InvoiceNumber: "",
      LifeCycleStage: null,
      Depreciation: 0,
      BookValue: -999999,
      Coordinator: null,
      User: null,
      ServiceInterval: 0,
      CalibrationInterval: -999999,
      CustomerId: "",
      LoanDailyRate: 4,
      ServiceDueDate: null,
      InventoryDate: null,
      ReceivedDate: "",
      OrderDate: null,
      PlannedDisposalDate: "",
      LastUpdate: null,
      BookValueDate: "",
      ReplacementDate: "",
      CalibrationDate: "",
      CalibrationDueDate: "",
      LastServiceDate: "",
      Project: "",
      permissions: {
        EditableFieldDetails: {}
      }
    };
    this.orgTreeData = [];
    this.locTreeData = [];
    this.formLoaded = false;
    this.renderer = null;
    this.baseState = this.state;
    this.process = this.process.bind(this);
    this.checkAndSetLoanDailyCost = this.checkAndSetLoanDailyCost.bind(this);
    this.processLocTree = this.processLocTree.bind(this);
    addAssetsStore.setMode("BULKEDIT");
    addAssetsStore.clearFieldState();
  }

  onOrgTreeChange = value => {
    this.setState({ Organization: value });
    Functions.GetAllUsersForCustomer(value, "").then(resp => {
      addAssetsStore.setUsersForCustomer(resp.data.UserList);
    });
  };
  onLocTreeChange = value => {
    this.setState({ Location: value });
  };
  resetForm = () => {
    var self = this; 
    this.setState(this.baseState);
    addAssetsStore.addToFieldStateFromCode(this.baseState);
    this.props.form.setFieldsValue(self.parseAndMakeForForm(this.state));
  };

  process(json, tag, pos, currentValue) {
    var currentVal = currentValue;

    if (json.text) {
      var toadd =
        '{"label":"' +
        json.text +
        '",' +
        '"key":"' +
        tag +
        "-" +
        pos +
        '",' +
        '"value":"' +
        json.text +
        '",';
      if (currentVal) {
        toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          currentVal +
          " > " +
          json.text +
          '",';
        currentVal = currentVal + " > " + json.text;
      } else {
        currentVal = json.text;
      }
      if (rr) {
        rr = rr + toadd;
      } else {
        rr = toadd;
      }
    }
    if (json.expanded) {
      if (json.text) {
        let toadd = '"children":[';
        rr = rr + toadd;
      }

      json.children.map((item, index) => {
        var poss = index + 1;
        this.process(item, tag + "-" + pos, poss, currentVal);
        var toadd = ",";
        rr = rr + toadd;
      });
      rr = rr.slice(0, -1);
      if (json.text) {
        let toadd = "]";
        rr = rr + toadd;
      }
    } else {
      rr = rr.slice(0, -1);
    }
    if (json.text) {
      let toadd = "}";
      rr = rr + toadd;
    }

    return true;
  }
  processLocTree(json, tag, pos, currentValue) {
    var currentVal = currentValue;
    if (json.text) {
      var toadd =
        '{"label":"' +
        json.text +
        '",' +
        '"key":"' +
        tag +
        "-" +
        pos +
        '",' +
        '"value":"' +
        json.text +
        '",';
      if (currentVal) {
        toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          currentVal +
          " > " +
          json.text +
          '",';
        currentVal = currentVal + " > " + json.text;
      } else {
        currentVal = json.text;
      }
      if (locTree) {
        locTree = locTree + toadd;
      } else {
        locTree = toadd;
      }
    }
    if (json.expanded) {
      if (json.text) {
        let toadd = '"children":[';
        locTree = locTree + toadd;
      }

      json.children.map((item, index) => {
        var poss = index + 1;
        this.processLocTree(item, tag + "-" + pos, poss, currentVal);
        var toadd = ",";
        locTree = locTree + toadd;
      });
      locTree = locTree.slice(0, -1);
      if (json.text) {
        let toadd = "]";
        locTree = locTree + toadd;
      }
    } else {
      locTree = locTree.slice(0, -1);
    }
    if (json.text) {
      let toadd = "}";
      locTree = locTree + toadd;
    }

    return true;
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll(err => {
      if (!err) {
        this.saveAsset();
      }
    });
  };
  toggleNew() {
    function close() {
      if (self.state.modal) {
        var currentUrl = window.location.href;
        if (currentUrl.includes("#")) {
          var toUrl = currentUrl.split("#");
          history.pushState({}, null, toUrl[0]);
        }
        self.setState({ modal: false });
        addAssetsStore.setBulkEditOpen(false);
        addAssetsStore.addToFieldStateFromCode(self.baseState);
        addAssetsStore.dashboardClearCheck();
        addAssetsStore.setEntriesAssetFileList([]);
      } else {
        self.setState({ modal: true });
      }
    }
    var self = this;

    addAssetsStore.editting
      ? UIFunctions.ShowConfirm({
          zIndex: 2000,
          title: "Do you want to discard changes?",
          okText: "Yes",
          cancelText: "No",
          onOk() {
            close();
          },
          onCancel() {}
        })
      : close();
  }
  checkAndSetLoanDailyCost() {
    var LoanDailyCost = 0;
    var BookValue = addAssetsStore.fieldState.BookValue
      ? addAssetsStore.fieldState.BookValue
      : 0;
    var LoanDailyRate = addAssetsStore.fieldState.LoanDailyRate
      ? addAssetsStore.fieldState.LoanDailyRate
      : 0;
    var LoanAutoCalculate = addAssetsStore.fieldState.LoanAutoCalculate
      ? addAssetsStore.fieldState.LoanAutoCalculate
      : false;
    LoanDailyCost =
      BookValue < 0 || LoanDailyRate < 0 || BookValue * LoanDailyRate / 100 < 0
        ? -999999
        : BookValue * LoanDailyRate / 100;
    if (LoanAutoCalculate) {
      addAssetsStore.addToFieldState({ LoanDailyCost });
      if (LoanDailyCost >= 0) this.props.form.setFieldsValue({ LoanDailyCost });
      else this.props.form.setFieldsValue({ LoanDailyCost: "" });
    }
  }

  saveAsset() {
    if (addAssetsStore.fieldState.Organization != undefined) {
      addAssetsStore.addToFieldState({
        Organization:
          addAssetsStore.fieldState.Organization[
            addAssetsStore.fieldState.Organization.length - 1
          ]
      });
    }

    if (addAssetsStore.fieldState.Location != undefined) {
      addAssetsStore.addToFieldState({
        Location:
          addAssetsStore.fieldState.Location[
            addAssetsStore.fieldState.Location.length - 1
          ]
      });
    }

    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        if (values.SystemChild == true) {
          if (
            values.ParentSystemName != null &&
            values.ParentSystemName != "" &&
            values.ParentSystemName != undefined
          ) {
            Functions.ValidateParentSystemNameForBulkEdit(
              values.ParentSystemName,
              addAssetsStore.dashboardChecked
            ).then(resp => {
              if (resp.data.isValid == true) {
                addAssetsStore.setSubmitting(true);
                this.saveToServer();
              } else {
                UIFunctions.Toast(resp.data.message, "failure");
              }
            });
          }
        } else {
          addAssetsStore.setSubmitting(true);
          this.saveToServer();
        }
      }
    });
  }
  saveToServer() {
    var stateCopy = addAssetsStore.fieldState;
    stateCopy.EquipmentNo = "";
    /* eslint-disable  */
    console.log("myvalues", addAssetsStore.fieldState);
    Functions.BulkEdit(addAssetsStore.dashboardChecked, stateCopy)
      .then(resp => {
        this.setState({ modal: false });
        if (resp.data.success) {
          UIFunctions.Toast(
            "Your request for bulk edit of assets is submitted and is currently getting processed. We will notify on the status of completion.",
            "success"
          );
          addAssetsStore.setSubmitting(false);
          addAssetsStore.dashboardClearCheck();
        } else {
          addAssetsStore.setSubmitting(false);
          this.setState({ modal: false });
          addAssetsStore.dashboardClearCheck();
          UIFunctions.Toast(
            "There was an issue in editing the Assets.",
            "failure"
          );
        }
      })
      .catch(() => {});
  }
  activeFinder(component) {
    return component === this.state.activeTab
      ? "breadcrumb-item active"
      : "breadcrumb-item";
  }
  componentDidMount() {
    var self = this;
    addAssetsStore.setEditting(false);
    addAssetsStore.setSubmitting(false);
    Functions.GetBulkEditableFields().then(resp => {
      permissionStore.setBulkEditPermissions(resp.data);

        Functions.GetOrgs().then(resp => {
          addAssetsStore.setOrgs(resp.data.orgDetails[0]);
          var customerId = addAssetsStore.getOrgs;
          customerId = customerId.CustomerId;
          Functions.GetOrganizationTree(customerId).then(resp => {
            var json = resp.data.tree;
            rr = null;
            this.process(json, "0", "0", false);
            var dta = "[" + rr + "]";
            var tdta = JSON.parse(dta);
            this.orgTreeData = tdta;
            addAssetsStore.setOrganizationTree(tdta);
            Functions.GetLocationTree(customerId).then(resp => {
              locTree = null;
              this.processLocTree(resp.data.tree, "0", "0", false);
              var dta = "[" + locTree + "]";
              var tdta = JSON.parse(dta);
              this.locTreeData = tdta;
              addAssetsStore.setLocationTree(tdta);
              Functions.GetCustomerAssets(customerId).then(resp => {
                var assets = resp.data.data;
                var lastAsset = assets[+assets.length - 1];
                this.setState({ EquipmentNo: +lastAsset + 1 });
                addAssetsStore.addToFieldStateFromCode({
                  EquipmentNo: +lastAsset + 1
                });
                addAssetsStore.setCustomerAssets(resp.data.data);
                addAssetsStore.setLastAsset(lastAsset);
                self.formLoaded = true;
                Functions.GetParentSystemName(customerId).then(resp => {
                  addAssetsStore.addToFieldStateFromCode({
                    ParentSystemNameList: resp.data.data
                  });
                });
              });
            });
          });
        });
      });
  }
  parseAndMakeForForm(json) {
    var rtn = json;
    var IntegerFields = addAssetsStore.IntegerFields;
    for (var fields of IntegerFields) {
      if (rtn[fields] && rtn[fields] == -999999) {
        rtn[fields] = "";
      }
    }
    for (var currentPicker of dates) {
      if (rtn[currentPicker]) {
        // console.log("item", currentPicker, rtn[currentPicker]);
        rtn[currentPicker] = moment(rtn[currentPicker]);
      }
    }
    return rtn;
  }
  setScrollState(obj) {
    setTimeout(() => {
      this.setState(obj);
    }, 10);
  }
  render() {
    return (
      <div className="row">
        {this.formLoaded ? (
          <Form onSubmit={this.handleSubmit} autoComplete="off">
            <Modal
              isOpen={this.state.modal}
              className="modal-dialog modal-lg"
              id="createAssetModal"
              style={{ maxWidth: "1000px" }}
            >
              <ModalHeader
                className="row modalHeader"
                style={{ borderBottom: "1px solid #ccd0d8" }}
              >
                <span className="createAssetLabel">Bulk Edit</span>
                <span
                  onClick={this.toggleNew.bind(this)}
                  style={{ cursor: "pointer" }}
                >
                  <i className="icon-close" />
                </span>
              </ModalHeader>
              <ModalBody style={{ paddingLeft: 0, paddingRight: 0 }}>
                <nav className="breadcrumb" id="createAssetNav">
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Identification" });
                    }}
                    className={this.activeFinder("Identification")}
                    href="#Identification"
                  >
                    Identification
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Configuration" });
                    }}
                    className={this.activeFinder("Configuration")}
                    href="#Configuration"
                  >
                    Configuration
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "SystemIntegration" });
                    }}
                    className={this.activeFinder("SystemIntegration")}
                    href="#SystemIntegration"
                  >
                    System Integration
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Services" });
                    }}
                    className={this.activeFinder("Services")}
                    href="#Services"
                  >
                    Service
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({
                        activeTab: "OrderingAndRecieving"
                      });
                    }}
                    className={this.activeFinder("OrderingAndRecieving")}
                    href="#OrderingAndRecieving"
                  >
                    Ordering & Receiving
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Valuation" });
                    }}
                    className={this.activeFinder("Valuation")}
                    href="#Valuation"
                  >
                    Valuation
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Inventory" });
                    }}
                    className={this.activeFinder("Inventory")}
                    href="#Inventory"
                  >
                    Inventory
                  </a>
                </nav>
                <div
                  className="addAssetBody"
                  id="scrollarea"
                  style={{ paddingLeft: 25, height: window.innerHeight - 210 }}
                >
                  {/*'IDENTIFICATION' */}
                  <div id="Identification">
                    <fieldset className="fieldsetHeading">
                      <legend>Identification </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "Identification" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    <Identification
                      {...this.props}
                      mode="BULKEDIT"
                      checkAndSetLoanDailyCost={this.checkAndSetLoanDailyCost}
                    />
                  </div>
                  {/* 'Configuration' */}
                  <div id="Configuration">
                    <fieldset className="fieldsetHeading">
                      <legend> Configuration</legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "Configuration" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    <Configuration {...this.props} mode="EDIT" />
                  </div>
                  {/*'system Integration' */}
                  <div id="SystemIntegration">
                    <fieldset className="fieldsetHeading">
                      <legend>System Integration </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "SystemIntegration" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    <SystemIntegration {...this.props} mode="BULKEDIT" />
                  </div>
                  {/*'service' */}
                  <div id="Services">
                    <fieldset className="fieldsetHeading">
                      <legend>Service</legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() => this.setState({ activeTab: "Services" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    <Services {...this.props} mode="BULKEDIT" />
                  </div>
                  {/*'Order Recieve' */}
                  <div id="OrderingAndRecieving">
                    <fieldset className="fieldsetHeading">
                      <legend>Ordering & Receiving </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "OrderingAndRecieving" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    <OrderingAndRecieving {...this.props} mode="BULKEDIT" />
                  </div>
                  {/*˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜ 'Valuation' ˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜*/}
                  <div id="Valuation">
                    <fieldset className="fieldsetHeading">
                      <legend>Valuation </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() => this.setState({ activeTab: "Valuation" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    <Valuation
                      {...this.props}
                      mode="BULKEDIT"
                      checkAndSetLoanDailyCost={this.checkAndSetLoanDailyCost}
                    />
                  </div>
                  {/*˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜ 'Inventory' ˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜*/}
                  <div id="Inventory">
                    <fieldset className="fieldsetHeading">
                      <legend>Inventory </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() => this.setState({ activeTab: "Inventory" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    <Inventory {...this.props} mode="BULKEDIT" />
                  </div>
                </div>
              </ModalBody>
              <ModalFooter>
                {/* 'Create Asset Fixed Footer' */}
                <nav className="modalFooter navbar" style={{ padding: 10 }}>
                  <div
                    className="modalFooterBtnGroup"
                    id="createAssetFooterButtons"
                  >
                    <Button
                      loading={addAssetsStore.submitting}
                      type="button"
                      className="aaSmallBtn btn btn-primary btn-sm"
                      id="submitBtn"
                      htmlType="submit"
                      onClick={this.saveAsset.bind(this)}
                    >
                      Submit
                    </Button>
                    <button
                      type="button"
                      className="aaSmallBtn btn btn-primary btn-sm"
                      onClick={this.resetForm.bind(this)}
                    >
                      Clear All
                    </button>
                    <button
                      type="button"
                      className="aaSmallBtn btn btn-primary btn-sm"
                      id="cancelBtn"
                      onClick={this.toggleNew.bind(this)}
                    >
                      Cancel
                    </button>
                  </div>
                </nav>
              </ModalFooter>
            </Modal>
          </Form>
        ) : (
          <Modal
            isOpen={this.state.modal}
            className="modal-dialog modal-lg"
            style={{ maxWidth: "1000px" }}
            id="createAssetModal"
          >
            <ModalHeader
              className="row modalHeader"
              style={{ borderBottom: "1px solid #ccd0d8" }}
            >
              <span className="createAssetLabel">Bulk Edit</span>
              <span
                onClick={this.toggleNew.bind(this)}
                style={{ cursor: "pointer" }}
              >
                <i className="icon-close" />
              </span>
            </ModalHeader>
            <Card loading>Whatever content</Card>
          </Modal>
        )}
      </div>
    );
  }
}
const WrappedRegistrationForm = Form.create()(BulkEdit);

export default WrappedRegistrationForm;
