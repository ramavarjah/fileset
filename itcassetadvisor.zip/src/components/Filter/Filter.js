import React, { Component } from "react";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
// import QueryBuilder from 'react-querybuilder';
// eslint-disable-next-line
import JQueryBuilder from "src/libs/jQuery-QueryBuilder-chosen/query-builder";
// eslint-disable-next-line
import chosen from "src/libs/jQuery-QueryBuilder-chosen/chosen-js-patched";
// eslint-disable-next-line
import datepicker from "bootstrap-datepicker";

import PropTypes from "prop-types";
import moment from "moment";

import Functions from "../../api/Functions";
import UIFunctions from "../../helpers/UIFunctions";
//import styles from './style.css';
import "./style.scss";
import tabModelStore from "../../stores/tabModelStore";
import { Select } from "antd";
import _ from "lodash";
import tippy from "tippy.js";
import permissionStore from "../../stores/permissionStore";

// import JQueryBuilder from 'jQuery-QueryBuilder';
var $ = require("jquery");
const emptyRule = {
  rules: [
    {
      empty: true
    }
  ]
};

class Filter extends Component {
  constructor(props) {
    super(props);

    this.handleSaveFilterClick = this.handleSaveFilterClick.bind(this);
    this.handleDeleteFilterClick = this.handleDeleteFilterClick.bind(this);

    this.state = {
      modal: true,
      modalNew: !this.props.clicked,
      rules: {},
      savedFilters: null,
      searchInput: "",
      filterSaving: false,
      savedSearchID: "",
      savedSearchSelected: false,
      saveFilterEnabled: false,
      savedFilterName: ""
    };
  }

  initializeQueryBuilder(element, newRules, filters) {
    try {
      if (Object.getOwnPropertyNames(newRules).length === 0) {
        newRules = null;
      }

      const plugins = {
        "chosen-selectpicker": null,
        "unique-filter": null,
        "bt-checkbox": { color: "primary" }
      };

      var operators = [
        { type: "equal", optgroup: "basic" },
        { type: "not_equal", optgroup: "basic" },
        { type: "in", optgroup: "basic" },
        { type: "not_in", optgroup: "basic" },
        { type: "less", optgroup: "numbers" },
        { type: "less_or_equal", optgroup: "numbers" },
        { type: "greater", optgroup: "numbers" },
        { type: "greater_or_equal", optgroup: "numbers" },
        { type: "between", optgroup: "numbers" },
        { type: "not_between", optgroup: "numbers" },
        { type: "begins_with", optgroup: "text" },
        { type: "not_begins_with", optgroup: "text" },
        { type: "contains", optgroup: "text" },
        { type: "not_contains", optgroup: "text" },
        { type: "ends_with", optgroup: "text" },
        { type: "not_ends_with", optgroup: "text" },
        { type: "is_empty", optgroup: "empty/null" },
        { type: "is_not_empty", optgroup: "empty/null" },
        { type: "is_null", optgroup: "empty/null" },
        { type: "is_not_null", optgroup: "empty/null" }
      ];

      var optgroups = {
        Dates: { en: "Dates" },
        Booleans: { en: "Yes/No" },
        Lists: { en: "Lists" },
        Strings: { en: "Text Input" },
        Spinner: { en: "numeric spinner input" },
        Doubles: { en: "Prices" },
        Integers: { en: "Numbers" }
      };

      const rules = newRules ? newRules : null;
      $(element).queryBuilder({
        plugins: plugins,
        operators: operators,
        filters: filters,
        rules: rules,
        optgroups: optgroups,
        conditions: ["AND", "OR"],
        allow_groups: 3
      });

      this.setState({ rules: newRules });

      //added code to enable save filter
      var thisRef = this;
      $(element).on(
        "afterUpdateRuleValue.queryBuilder afterUpdateGroupCondition.queryBuilder afterUpdateRuleOperator.queryBuilder afterAddRule.queryBuilder afterDeleteRule.queryBuilder afterDeleteGroup.queryBuilder",
        function() {
          $(".form-control").on("change keyup paste", function() {
            if (this.value === "" && $(this)[0]._tippy)
              $(this)[0]._tippy.destroy();

            $(this).attr("title", this.value);

            if (!$(this)[0]._tippy) {
              tippy(".form-control", { dynamicTitle: true });
            }
          });

          if (thisRef.state.savedSearchSelected) {
            thisRef.setState({ saveFilterEnabled: true });
          }
        }
      );
    } catch (error) {
      UIFunctions.Toast("Oops ! Something went wrong", "error");
    }
  }

  toggleNew() {
    if (tabModelStore.filterModalOpen) {
      tabModelStore.setFilterModalopen(false);
    } else {
      tabModelStore.setFilterModalopen(true);
    }
  }
  /* eslint-disable react/no-string-refs*/
  // get data from jQuery Query Builder and pass to the react component
  handleGetRulesClick() {
    const rules = $(this.refs.queryBuilder).queryBuilder("getRules");
    this.setState({ rules: rules });
    this.forceUpdate();
  }
  // reinitialize jQuery Query Builder based on react state
  handleSetRulesClick(rule) {
    const newRules = rule;
    if (Object.getOwnPropertyNames(rule).length === 0) {
      const newRule = { ...emptyRule };
      $(this.refs.queryBuilder).queryBuilder("setRules", newRule);
    } else {
      $(this.refs.queryBuilder).queryBuilder("setRules", rule);
      this.setState({ rules: newRules });
    }
  }

  formatfilterDate(baseQueryy) {
    var baseQuery = JSON.parse(JSON.stringify(baseQueryy));
    var noOfRules = baseQuery.rules ? baseQuery.rules.length : 0;
    if (noOfRules == 1) {
      if (baseQuery.rules[0].type == "date") {
        if (
          baseQuery.rules[0].operator == "between" ||
          baseQuery.rules[0].operator == "not_between"
        ) {
          baseQuery.rules[0].value[0] = moment(
            baseQuery.rules[0].value[0]
          ).format("YYYY/MM/DD");
          baseQuery.rules[0].value[1] = moment(
            baseQuery.rules[0].value[1]
          ).format("YYYY/MM/DD");
        } else {
          baseQuery.rules[0].value = moment(baseQuery.rules[0].value).format(
            "YYYY/MM/DD"
          );
        }
      }
    } else {
      for (var i = 0; i < noOfRules; i++) {
        if (baseQuery.rules[i].rules == undefined) {
          if (baseQuery.rules[i].type == "date") {
            if (
              baseQuery.rules[i].operator == "between" ||
              baseQuery.rules[i].operator == "not_between"
            ) {
              baseQuery.rules[i].value[0] = moment(
                baseQuery.rules[i].value[0]
              ).format("YYYY/MM/DD");
              baseQuery.rules[i].value[1] = moment(
                baseQuery.rules[i].value[1]
              ).format("YYYY/MM/DD");
            } else {
              baseQuery.rules[i].value = moment(
                baseQuery.rules[i].value
              ).format("YYYY/MM/DD");
            }
          }
        } else {
          baseQuery.rules[i] = this.formatfilterDate(baseQuery.rules[i]);
        }
      }
    }
    return baseQuery;
  }
  SetDateISOString(baseQuery) {
    var noOfRules = baseQuery.rules.length;
    if (noOfRules == 1) {
      if (baseQuery.rules[0].type == "date") {
        if (
          baseQuery.rules[0].operator == "between" ||
          baseQuery.rules[0].operator == "not_between"
        ) {
          baseQuery.rules[0].value[0] = new Date(
            baseQuery.rules[0].value[0]
          ).toISOString();
          baseQuery.rules[0].value[1] = new Date(
            baseQuery.rules[0].value[1]
          ).toISOString();
        } else {
          baseQuery.rules[0].value = new Date(
            baseQuery.rules[0].value
          ).toISOString();
        }
      }
    } else {
      for (var i = 0; i < noOfRules; i++) {
        if (baseQuery.rules[i].rules == undefined) {
          if (baseQuery.rules[i].type == "date") {
            if (
              baseQuery.rules[i].operator == "between" ||
              baseQuery.rules[i].operator == "not_between"
            ) {
              baseQuery.rules[i].value[0] = new Date(
                baseQuery.rules[i].value[0]
              ).toISOString();
              baseQuery.rules[i].value[1] = new Date(
                baseQuery.rules[i].value[1]
              ).toISOString();
            } else {
              baseQuery.rules[i].value = new Date(
                baseQuery.rules[i].value
              ).toISOString();
            }
          }
        } else {
          baseQuery.rules[i] = this.SetDateISOString(baseQuery.rules[i]);
        }
      }
    }
    return baseQuery;
  }
  RemoveNullValues(baseQuery) {
    var noOfRules = baseQuery.rules.length;
    if (noOfRules == 1) {
      baseQuery.rules[0] = _.omitBy(baseQuery.rules[0], function(v) {
        return _.isNull(v) || v == "1970-01-01T00:00:00.000Z";
      });
    } else {
      for (var i = 0; i < noOfRules; i++) {
        if (baseQuery.rules[i].rules == undefined) {
          baseQuery.rules[i] = _.omitBy(baseQuery.rules[i], function(v) {
            return _.isNull(v) || v == "1970-01-01T00:00:00.000Z";
          });
        } else {
          baseQuery.rules[i] = this.RemoveNullValues(baseQuery.rules[i]);
        }
      }
    }
    return baseQuery;
  }
  handleApplyFilterClick() {
    //Getting the Saved Filter's Data
    var searchID = this.state.savedSearchID;
    function getFilter(filterName) {
      return filterName.props.value === searchID;
    }
    var selectedFilter = this.state.savedFilters.find(getFilter);
    var selectedBaseQuery = selectedFilter
      ? selectedFilter.props
        ? selectedFilter.props.baseQuery
        : {}
      : {};

    const appliedRule = $(this.refs.queryBuilder).queryBuilder("getRules");
    var FilterData = {};
    FilterData.TabId = tabModelStore.activeTab.TabId;
    FilterData.baseQuery = appliedRule;
    FilterData.filterQuery = {};

    if (!FilterData.baseQuery)
      return UIFunctions.ShowError({
        zIndex: 2000,
        title: "Invalid filter query!"
      });
    FilterData.baseQuery = this.SetDateISOString(appliedRule);
    //Checking the Applied Query and Selected Filter's Query
    var appliedBaseQuery = _.cloneDeep(FilterData.baseQuery);
    if (_.isEqual(selectedBaseQuery, this.RemoveNullValues(appliedBaseQuery)))
      FilterData.savedSearchID = searchID;

    tabModelStore.setDataLoaded(false);
    tabModelStore.setServiceDueChartLoading(true);
    tabModelStore.setChartLoading(true);
    Functions.SetFilters(FilterData).then(() => {
      this.toggleNew();
      tabModelStore.activeTab.baseQuery = appliedRule;
      Functions.GetUserTab().then(resp => {
        if (resp.data.success && resp.data.tabs) {
          var tabss = resp.data.tabs;
          tabModelStore.setTabsJson(JSON.stringify(tabss));
        }
        UIFunctions.ReRenderGrid().then(() => {
          tabModelStore.onChartActive
            ? UIFunctions.ReRenderChart().then(() => {
                this.loaded = true;
                tabModelStore.setDataLoaded(true);
              })
            : tabModelStore.setOnTabActive(true);
          this.loaded = true;
          tabModelStore.setDataLoaded(true);
        });
      });
    });
  }

  handleChange(value) {
    this.setState({
      searchInput: value
    });
  }

  handleSaveAsFilterClick() {
    const appliedRule = $(this.refs.queryBuilder).queryBuilder("getRules");
    var FilterData = {};
    FilterData.TabId = tabModelStore.activeTab.TabId;
    FilterData.baseQuery = appliedRule;
    FilterData.SearchName = this.state.searchInput;
    FilterData.filterQuery = {};
    if (!FilterData.baseQuery)
      return UIFunctions.ShowError({
        zIndex: 2000,
        title: "Invalid filter query!"
      });
    if (!this.state.searchInput)
      return UIFunctions.ShowError({
        zIndex: 2000,
        title: "Invalid filter name!"
      });
    var existingFilter = this.state.savedFilters;
    function existingFilterCheck(filterName) {
      return filterName.key === FilterData.SearchName;
    }
    if (existingFilter.find(existingFilterCheck) != undefined) {
      UIFunctions.ShowError({
        zIndex: 2000,
        title:
          "Filter name: " +
          this.state.searchInput +
          " already exist! Please use different name"
      });
    } else {
      this.setState({
        filterSaving: true
      });
      Functions.CreateSavedSearch(FilterData)
        .then(resp => {
          Functions.GetSavedSearch(tabModelStore.activeTab.TabId)
            .then(respFiData => {
              var arrTen = [];
              var editedFilter;
              var result = respFiData.data.data;
              for (var k = 0; k < result.length; k++) {
                var item = result[k];
                if (item.selected)
                  // To Unselect the Applied Saved Filter Locally
                  item.selected = false;
                if (item.SearchName === FilterData.SearchName) {
                  // To Select the Edited Filter Locally
                  item.selected = true;
                  editedFilter = item;
                }
                arrTen.push(
                  <option
                    key={item.SearchName}
                    baseQuery={item.baseQuery}
                    selected={item.selected}
                    value={item.SearchId}
                  >
                    {item.SearchName}
                  </option>
                );
              }
              this.setState({
                savedFilters: arrTen,
                filterSaving: false,
                savedSearchID: editedFilter.SearchId,
                savedFilterName: editedFilter.SearchName,
                savedSearchSelected: true,
                searchInput: ""
              });
            })
            .catch(() => {
              this.setState({
                filterSaving: false
              });
            });
          if (resp.data.success === true) {
            UIFunctions.ShowSuccess({
              zIndex: 2000,
              title:
                "Filter Name: " +
                this.state.searchInput +
                " Filter Created Successfully! "
            });
            this.setState({
              filterSaving: false
            });
          }
        })
        .catch(() => {
          this.setState({
            filterSaving: false
          });
        });
    }
  }

  handleSaveFilterClick() {
    this.setState({
      filterSaving: true,
      saveFilterEnabled: false
    });
    const appliedRule = $(this.refs.queryBuilder).queryBuilder("getRules");
    var FilterData = {};
    FilterData.baseQuery = appliedRule;
    FilterData.SearchId = this.state.savedSearchID;
    FilterData.filterQuery = {};
    if (!FilterData.baseQuery)
      return UIFunctions.ShowError({
        zIndex: 2000,
        title: "Invalid filter query!"
      });
    FilterData.baseQuery = this.SetDateISOString(appliedRule);
    Functions.EditSavedSearch(FilterData).then(resp => {
      if (resp.data.success === true) {
        UIFunctions.ShowSuccess({
          zIndex: 2000,
          title: "Filter : " + this.state.searchInput + " Updated Successfully "
        });
        Functions.GetSavedSearch(tabModelStore.activeTab.TabId).then(
          respFiData => {
            var arrTen = [];
            var result = respFiData.data.data;
            for (var k = 0; k < result.length; k++) {
              var item = result[k];
              arrTen.push(
                <option
                  key={item.SearchName}
                  baseQuery={item.baseQuery}
                  selected={item.selected}
                  value={item.SearchId}
                >
                  {item.SearchName}
                </option>
              );
            }

            this.setState({
              savedFilters: arrTen
            });
          }
        );
      }
    });
    this.setState({
      filterSaving: false
    });
  }
  handleEmptyRulesClick() {
    const newRules = { ...emptyRule };
    $(this.refs.queryBuilder).queryBuilder("setRules", newRules);
    this.setState({ rules: newRules });
    var tabId = tabModelStore.activeTab.TabId;
    tabModelStore.setDataLoaded(false);
    permissionStore.setChartLoading(true);
    Functions.ClearFilters(tabId).then(() => {
      this.toggleNew();
      this.loaded = false;
      tabModelStore.setDataLoaded(false);
      UIFunctions.ReRenderGrid().then(() => {
        tabModelStore.onChartActive
          ? UIFunctions.ReRenderChart().then(() => {
              this.loaded = true;
              tabModelStore.setDataLoaded(true);
            })
          : tabModelStore.setOnTabActive(true);
        this.loaded = true;
        tabModelStore.setDataLoaded(true);
      });

      tabModelStore.activeTab.baseQuery = {};
    });
  }
  onFilterChange(val) {
    this.setState({ saveFilterEnabled: false });
    this.setState({ savedSearchSelected: true });
    var allFilters = this.state.savedFilters;
    function getFilter(filterName) {
      return filterName.props.value === val;
    }
    var selectedFilter = allFilters.find(getFilter);
    $(this.refs.queryBuilder).queryBuilder(
      "setRules",
      this.formatfilterDate(selectedFilter.props.baseQuery)
    );
    this.setState({
      savedSearchID: val,
      savedFilterName: selectedFilter.key
    });
    this.forceUpdate();
  }
  handleDeleteFilterClick() {
    var self = this;
    UIFunctions.ShowConfirm({
      zIndex: 2000,
      title: 'Do you want delete "' + self.state.savedFilterName + '"?',
      okText: "Yes",
      cancelText: "No",
      onOk() {
        self.setState({ saveFilterEnabled: false, savedSearchSelected: false });
        var searchID = self.state.savedSearchID;
        Functions.DeleteSavedSearch(searchID).then(() => {
          Functions.GetSavedSearch(tabModelStore.activeTab.TabId).then(
            respFiData => {
              var arrTen = [];
              var result = respFiData.data.data;
              for (var k = 0; k < result.length; k++) {
                var item = result[k];
                arrTen.push(
                  <option
                    key={item.SearchName}
                    baseQuery={item.baseQuery}
                    selected={item.selected}
                    value={item.SearchId}
                  >
                    {" "}
                    {item.SearchName}{" "}
                  </option>
                );
              }
              self.setState({
                savedFilters: arrTen,
                savedFilterName: ""
              });
              $(self.refs.queryBuilder).queryBuilder("setRules", {
                condition: "AND",
                rules: [{}]
              });
            }
          );
        });
      },
      onCancel() {}
    });
  }
  componentDidMount() {
    const element = this.refs.queryBuilder;
    //  this.$node = $(this.refs.datepicker);
    $(".datepicker").datepicker();
    Functions.GetFilterValues().then(resp => {
      var tabId = tabModelStore.activeTab.TabId;
      Functions.GetFilters(tabId).then(respFiData => {
        respFiData.data.baseQuery = this.formatfilterDate(
          respFiData.data.baseQuery
        );
        this.initializeQueryBuilder(
          element,
          respFiData.data.baseQuery,
          resp.data.filters
        );
        Functions.GetSavedSearch(tabId).then(respFiData => {
          var arrTen = [];
          var result = respFiData.data.data;
          for (var k = 0; k < result.length; k++) {
            var item = result[k];
            if (item.selected == true) {
              this.setState({
                savedSearchID: item.SearchId,
                savedFilterName: item.SearchName,
                savedSearchSelected: true
              });
            }
            arrTen.push(
              <option
                key={item.SearchName}
                baseQuery={item.baseQuery}
                selected={item.selected}
                value={item.SearchId}
                className="savedFilterSelectBoxOption"
              >
                {item.SearchName}
              </option>
            );
          }
          this.setState({
            savedFilters: arrTen
          });
        });
      });
    });
  }
  render() {
    const SavedFilters = () => (
      <Select
        className="savedFilterSelectBox"
        style={{ width: "50%", float: "left" }}
        onChange={this.onFilterChange.bind(this)}
        placeholder={
          this.state.savedFilterName
            ? this.state.savedFilterName
            : "Select a saved filter"
        }
      >
        {this.state.savedFilters}
      </Select>
    );

    return (
      <Modal
        isOpen={true}
        className="modal-dialog modal-lg editFiltersModal"
        id="createAssetModal"
        style={{ maxWidth: 900 }}
      >
        <ModalHeader className="row modalHeader editFiltersModalHeader">
          <span className="createAssetLabel">EDIT FILTERS</span>
          <span
            onClick={this.toggleNew.bind(this)}
            style={{ cursor: "pointer" }}
          >
            <i className="icon-close" />
          </span>
        </ModalHeader>
        <ModalBody style={{ padding: 0 }}>
          <nav className="modalTopToolbar navbar">
            <div style={{ display: "flex", marginLeft: 11 }}>
              <div className="dropdown" style={{ width: "375px" }}>
                <SavedFilters />

                <button
                  type="button"
                  style={
                    this.state.saveFilterEnabled
                      ? { opacity: "1", float: "left" }
                      : { opacity: ".5", float: "left" }
                  }
                  className="aaSmallBtn btn btn-primary btn-sm"
                  onClick={
                    this.state.saveFilterEnabled
                      ? this.handleSaveFilterClick
                      : ""
                  }
                >
                  Save Filter
                </button>
                <div
                  id="saveDeleteBtns"
                  style={{ float: "left", marginRight: "0px" }}
                >
                  <button
                    type="button"
                    style={
                      this.state.savedSearchSelected
                        ? { opacity: "1" }
                        : { opacity: ".5" }
                    }
                    className="aaSmallBtn btn btn-primary btn-sm"
                    onClick={
                      this.state.savedSearchSelected
                        ? this.handleDeleteFilterClick
                        : ""
                    }
                  >
                    Delete
                  </button>
                </div>
              </div>
              <div className="modalFooterBtnGroup" id="filterModalButtons">
                <input
                  className="aaTextInput"
                  type="text"
                  value={this.state.searchInput}
                  onChange={e => this.handleChange(e.target.value)}
                  placeholder="Filter Name"
                />
              </div>
              <Button
                disabled={this.state.filterSaving || !this.state.searchInput}
                style={
                  this.state.filterSaving || !this.state.searchInput
                    ? { opacity: "0.5" }
                    : { opacity: "1" }
                }
                className="aaSmallBtn submitBtn"
                onClick={() => this.handleSaveAsFilterClick()}
              >
                Save As
              </Button>
            </div>
          </nav>
          <div
            className="filterBody"
            style={{ height: window.innerHeight - 230 }}
          >
            <div id="query-builder" ref="queryBuilder" />
          </div>
        </ModalBody>
        <ModalFooter>
          {/* 'Create Asset Fixed Footer' */}
          <nav className="modalFooter navbar">
            <div
              className="btn-group"
              id="queryBuilderButtons"
              role="group"
              aria-label="Basic example"
            >
              <button
                type="button"
                className="aaSmallBtn btn"
                onClick={this.handleEmptyRulesClick.bind(this)}
              >
                Clear Filters
              </button>
              <button
                type="button"
                className="aaSmallBtn btn"
                onClick={this.handleApplyFilterClick.bind(this)}
                id="applyBtn"
              >
                Apply Filters
              </button>
            </div>
          </nav>
        </ModalFooter>
      </Modal>
    );
  }
}
export default Filter;
Filter.propTypes = {
  clicked: PropTypes.bool
};
