import React, { Component } from "react";
import { Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
//mobx
//import FileUpload  from 'react-fileupload';
//import { Receiver } from 'react-file-uploader';
import { observer } from "mobx-react";
import { observable } from "mobx";
import Functions from "./../../api/Functions";
import UIFunctions from "./../../helpers/UIFunctions";
import addAssetsStore from "./../../stores/addAssetsStore";
import userStore from "./../../stores/userStore";
import "../../helpers/Antd/antd.css"; // new line of code
import { Select, Card, Switch, Tooltip } from "antd";
import moment from "moment";
import request from "../../api/request";
import URL from "../../api/Urls";
import permissionStore from "../../stores/permissionStore";
import "react-select/dist/react-select.css";
import { Row, Col, Input, Form, Button } from "antd";
// import ScheduleTaskDetails from "../AssetDetails/ScheduleTaskDetails";
//import ScheduleTasks from './ScheduleTasks';
import _ from "lodash";

import Waypoint from "react-waypoint";
//segments
import Identification from "../AssetCommons/Identification";
import Configuration from "../AssetCommons/Configuration";
import Attachments from "../AssetCommons/Attachments";
import OrderingAndRecieving from "../AssetCommons/OrderingAndRecieving";
import Inventory from "../AssetCommons/Inventory";
import Valuation from "../AssetCommons/Valuation";
import SystemIntegration from "../AssetCommons/SystemIntegration";
import Services from "../AssetCommons/Services";
import tabModelStore from "../../stores/tabModelStore";
import scheduledTaskStore from "../../stores/scheduledTaskStore";
// import ScheduleTasks from "../AssetDetails/ScheduleTasks";
var scheduleTasksCount = 0;

const dates = [
  "ReplacementDate",
  "CalibrationDate",
  "CalibrationDueDate",
  "LastServiceDate",
  "ServiceDueDate",
  "PlannedDisposalDate",
  "OrderDate",
  "ReceivedDate",
  "BookValueDate",
  "InventoryDate",
  "LastUpdate"
];

var rr, locTree;
const defaultState = {
  accept: "",
  files: [],
  accepted: [],
  fileBinary: null,
  dropzoneActive: false,
  modal: true,
  activeTab: "Identification",
  value: undefined,
  renderedTree: null,
  ModelNoList: [],
  ParentSystemNameList: [],
  TemplateName: "",

  ChooseTemplate: null,
  EquipmentNo: "",
  Manufacturer: "",
  AltManufacturerName: "",
  ModelNo: "",
  SerialNo: "",
  AssetNo: "",
  Barcode: "",
  Description: "",
  TaskName: "",
  ProductCategory: null,
  ReplacedBy: null,
  Borrowable: false,
  UtilizationCategory: null,
  LoanDailyCost: -999999,
  Currency: null,
  StickyNotes: "",
  EquipmentType: null,
  Project: "",
  FirmwareRevision: "",
  HardwareVersion: "",
  Accessories: "",
  Options: "",
  SoftwareRevision: "",
  SystemParent: false,
  SystemName: "",
  SystemChild: false,
  ParentSystemName: "",
  PartOfSystemCalibration: false,
  SystemComponents: "",
  LastReportedCondition: null,
  CalibrationProvider: "Keysight technologies Inc.",
  ServiceLogistics: null,
  CalibrationType: null,
  ServiceInterval: -999999,
  CalibrationInterval: -999999,
  ServiceCost: -999999,
  RepairProvider: "Keysight technologies Inc.",
  UseProviderCalibrationType: false,
  UseProviderCalibrationSchedule: false,
  OwnershipStatus: null,
  OwningCompany: "",
  OrderNumber: "",
  PurchasePrice: -999999,
  LoanAutoCalculate: true,
  InvoiceNumber: "",
  LifeCycleStage: null,
  Depreciation: -999999,
  BookValue: -999999,
  Organization: null,
  LoanDailyRate: 4,
  Location: null,
  Coordinator: null,
  User: "",
  CustomerId: null,
  ServiceDueDate: null,
  InventoryDate: null,
  ReceivedDate: "",
  OrderDate: null,
  PlannedDisposalDate: "",
  DepreciationRate: 0,
  LastUpdate: null,
  //"BookValue":'',
  BookValueDate: "",
  ReplacementDate: "",
  LastCalibrationDate: "",
  CalibrationDueDate: "",
  LastServiceDate: "",
  permissions: {
    icons: {},
    fields: {}
  }
};
@observer
class AddAsset extends Component {
  @observable formLoaded;
  @observable renderer;
  @observable orgTreeData;
  @observable locTreeData;
  state = {
    size: "default",
    footerController: "CREATE"
  };

  newState = {
    size: "default",
    footerController: "CREATE"
  };

  constructor(props) {
    super(props);
    this.activeFinder = this.activeFinder.bind(this);
    this.state = {
      checked: false,
      accept: "",
      files: [],
      accepted: [],
      fileBinary: null,
      dropzoneActive: false,
      modal: true,
      modalNew: !this.props.clicked,
      activeTab: "Identification",
      value: undefined,
      renderedTree: null,
      ManufacturerList: [],
      ModelNoList: [],
      ParentSystemNameList: [],
      TemplateName: "",
      CustomerId: userStore.userDetails.CustomerId,
      editval: true,
      taskDetails: [],
      taskArray: [],

      ChooseTemplate: null,
      EquipmentNo: "",
      Manufacturer: "",
      AltManufacturerName: "",
      ModelNo: "",
      SerialNo: "",
      AssetNo: "",
      Barcode: "",
      Description: "",
      TaskName: "",
      ProductCategory: null,
      ReplacedBy: null,
      Borrowable: false,
      UtilizationCategory: null,
      LoanDailyCost: -999999,
      Currency: null,
      StickyNotes: "",
      EquipmentType: null,
      Project: "",
      FirmwareRevision: "",
      HardwareVersion: "",
      Accessories: "",
      Options: "",
      SoftwareRevision: "",
      SystemParent: false,
      SystemName: "",
      SystemChild: false,
      ParentSystemName: "",
      PartOfSystemCalibration: false,
      SystemComponents: "",
      LastReportedCondition: null,
      CalibrationProvider: null,
      ServiceLogistics: null,
      CalibrationType: null,
      ServiceInterval: -999999,
      CalibrationInterval: -999999,
      ServiceCost: -999999,
      RepairProvider: null,
      UseProviderCalibrationType: false,
      UseProviderCalibrationSchedule: false,
      OwnershipStatus: null,
      OwningCompany: "",
      OrderNumber: "",
      PurchasePrice: -999999,
      LoanAutoCalculate: true,
      InvoiceNumber: "",
      LifeCycleStage: null,
      Depreciation: -999999,
      BookValue: -999999,
      Organization: null,
      LoanDailyRate: 4,
      Location: null,
      Coordinator: null,
      User: "",
      ServiceDueDate: null,
      InventoryDate: null,
      ReceivedDate: "",
      OrderDate: null,
      PlannedDisposalDate: "",
      DepreciationRate: -999999,
      LastUpdate: null,
      //"BookValue":'',
      BookValueDate: "",
      ReplacementDate: "",
      CalibrationDate: "",
      CalibrationDueDate: "",
      LastServiceDate: "",
      permissions: {
        icons: {},
        fields: {}
      }
    };
    this.orgTreeData = [];
    this.locTreeData = [];
    this.formLoaded = false;
    this.renderer = null;
    this.process = this.process.bind(this);
    this.processLocTree = this.processLocTree.bind(this);
    this.checkAndSetLoanDailyCost = this.checkAndSetLoanDailyCost.bind(this);
    this.baseState = defaultState;
    this.newBaseState = defaultState;
    scheduleTasksCount = 0;
    addAssetsStore.setMode("CREATE");
  }

  uploadFile(accepted) {
    var eqNo = this.state.EquipmentNo;
    accepted.map(file => {
      var r = new FileReader();
      r.readAsBinaryString(file);
      r.onloadend = function() {
        Functions.UploadFileForAsset(eqNo, file.name, r.result);
        // request({
        //   method: "post",
        //   url: URL.fileupload,
        //   data: { File: r.result, AssetEqNum: eqNo, FileName: file.name }
        // });
      };
    });
  }

  validateUncheckChild() {
    request({
      method: "post",
      url: URL.validateSystemChildUncheck
    }).then(resp => {
      if (resp.data.isValid == false) {
        <div>
          <label className="formLabels" htmlFor="validationMessage">
            {resp.message}
          </label>
        </div>;
      }
    });
  }

  onDragEnter() {
    this.setState({
      dropzoneActive: true
    });
  }
  onDrop(files) {
    this.setState({
      files
    });
  }
  onDragLeave() {
    this.setState({
      dropzoneActive: false
    });
  }
  applyMimeTypes(event) {
    this.setState({
      accept: event.target.value
    });
  }

  parseTree(data) {
    if (data != null) {
      // console.log("parse stree start", data)
      var original = data.split(">");
      // console.log("original", original)
      var length = original.length;
      var duplicate = [];
      var location = [];
      duplicate.push(data);

      for (var i = 0; i < length - 1; i++) {
        original.pop();
        duplicate.push(original.join(">").trim());
      }
      location = duplicate.reverse();
      // console.log("return parse data", location)
      return location;
    }
  }

  onOrgTreeChange = value => {
    //console.log("onOrgTreeChange", arguments, value);
    this.setState({ Organization: value });
    Functions.GetAllUsersForCustomer(value, "").then(resp => {
      //console.log('GetAllUsersForCustomer', resp.data.UserList);
      addAssetsStore.setUsersForCustomer(resp.data.UserList);
    });
  };
  onLocTreeChange = value => {
    //console.log("onlocTreeChange", arguments, value);
    this.setState({ Location: value });
  };

  openModel = () => {
    var self = this;
    addAssetsStore.editting
      ? UIFunctions.Confirm({
          zIndex: 2000,
          title: "Are you sure you want to Clear All fields?",
          okText: "Yes",
          cancelText: "No",
          // content: 'When clicked the OK button, this dialog will be closed after 1 second',
          onOk() {
            self.state.checked ? self.resetingForm() : self.resetForm();
            setTimeout(() => {
              self.props.form.setFields({
                
                Manufacturer: { errors: [] }
              })
      
            }, 0);
          },
          onCancel() {}
        })
      : "";
  };

  resetForm = () => {
    var self = this;
    //this.setState({ value: '' });
    // this.state.AltManufacturerName.value = "";
    this.baseState.EquipmentNo = this.state.EquipmentNo;
    this.baseState.ManufacturerList =
      addAssetsStore.fieldState.ManufacturerList;
    this.baseState.ModelNoList = this.state.ModelNoList;
    this.baseState.ParentSystemNameList =
      addAssetsStore.fieldState.ParentSystemNameList;
    this.baseState.CustomerId = this.state.CustomerId;
  
    this.setState(this.baseState);
    //self.props.form.setFieldsValue(this.state);
    this.props.form.setFieldsValue(self.parseAndMakeForForm(this.state));
    addAssetsStore.addToFieldStateFromCode(this.baseState);
    addAssetsStore.setEntriesAssetFileList([]);
    addAssetsStore.systemComponents = [];
    addAssetsStore.editting = false;
  };
  resetingForm = () => {
    var self = this;
    this.newBaseState.EquipmentNo = this.state.EquipmentNo;
    this.newBaseState.ManufacturerList =
      addAssetsStore.fieldState.ManufacturerList;
    this.newBaseState.ModelNoList = this.state.ModelNoList;
    this.newBaseState.ParentSystemNameList =
      addAssetsStore.fieldState.ParentSystemNameList;
    this.newBaseState.CustomerId = this.state.CustomerId;

    this.setState(this.newBaseState);
    // self.props.form.setFieldsValue(this.state);

    this.newBaseState.ManufacturerList =
      addAssetsStore.fieldState.ManufacturerList;
    //this.props.form.setFieldsValue(this.state);

    this.props.form.setFieldsValue(self.parseAndMakeForForm(this.state));
    addAssetsStore.addToFieldStateFromCode(this.newBaseState);
    addAssetsStore.setEntriesAssetFileList([]);
    addAssetsStore.systemComponents = [];
    addAssetsStore.editting = false;
  };
  process(json, tag, pos, currentValue) {
    //console.log('to parse', json)
    //console.log('tag,pos', tag, pos)
    var currentVal = currentValue;

    if (json.text) {
      var toadd =
        '{"label":"' +
        json.text +
        '",' +
        '"key":"' +
        tag +
        "-" +
        pos +
        '",' +
        '"value":"' +
        json.text +
        '",';
      if (currentVal) {
        //console.log('currentVal', currentVal, json.text);
        toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          currentVal +
          " > " +
          json.text +
          '",';
        currentVal = currentVal + " > " + json.text;
      } else {
        //console.log('currentVal else', currentVal, json.text);
        currentVal = json.text;
      }
      if (rr) {
        rr = rr + toadd;
      } else {
        rr = toadd;
      }
    }
    if (json.expanded) {
      if (json.text) {
        var toaddd = '"children":[';
        rr = rr + toaddd;
      }

      json.children.map((item, index) => {
        //console.log("index:", index, arr)
        var poss = index + 1;
        this.process(item, tag + "-" + pos, poss, currentVal);
        var toadd = ",";
        rr = rr + toadd;
      });
      rr = rr.slice(0, -1);
      if (json.text) {
        var toadd_ = "]";
        rr = rr + toadd_;
      }
    } else {
      rr = rr.slice(0, -1);
    }
    if (json.text) {
      var toadd__ = "}";
      rr = rr + toadd__;
    }

    return true;
    //  //console.log("processed till",JSON.stringify(rr))
  }
  processLocTree(json, tag, pos, currentValue) {
    //console.log('to parse', json)
    //console.log('tag,pos', tag, pos)
    //console.log("Marker", json);
    var currentVal = currentValue;

    if (json.text) {
      var toadd =
        '{"label":"' +
        json.text +
        '",' +
        '"key":"' +
        tag +
        "-" +
        pos +
        '",' +
        '"value":"' +
        json.text +
        '",';
      if (currentVal) {
        //console.log('currentVal', currentVal, json.text);
        toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          currentVal +
          " > " +
          json.text +
          '",';
        currentVal = currentVal + " > " + json.text;
      } else {
        //console.log('currentVal else', currentVal, json.text);
        currentVal = json.text;
      }
      if (locTree) {
        locTree = locTree + toadd;
      } else {
        locTree = toadd;
      }
    }
    if (json.expanded) {
      if (json.text) {
        var _toadd = '"children":[';
        locTree = locTree + _toadd;
      }

      json.children.map((item, index) => {
        //console.log("index:", index, alocTree)
        var poss = index + 1;
        this.processLocTree(item, tag + "-" + pos, poss, currentVal);
        var toadd = ",";
        locTree = locTree + toadd;
      });
      locTree = locTree.slice(0, -1);
      if (json.text) {
        var toadD = "]";
        locTree = locTree + toadD;
      }
    } else {
      locTree = locTree.slice(0, -1);
    }
    if (json.text) {
      locTree = locTree + "}";
    }

    return true;
    //  //console.log("processed till",JSON.stringify(rr))
  }

  toggleNew() {
    function close() {
      if (self.state.modal) {
        var currentUrl = window.location.href;
        if (currentUrl.includes("#")) {
          var toUrl = currentUrl.split("#");
          history.pushState({}, null, toUrl[0]);
        }
        self.setState({ modal: false });
        addAssetsStore.setAddAssetsOpen(false);
        // self.setState({ addAssetsStore.usersForCustomer: false });
        addAssetsStore.setUsersForCustomer(false);
        //clearing Asset Store
        addAssetsStore.addToFieldStateFromCode(self.baseState);
        addAssetsStore.setEntriesAssetFileList([]);
      } else {
        self.setState({ modal: true });
      }
    }
    var self = this;
    // console.log("editting", addAssetsStore.editting)
    addAssetsStore.editting
      ? UIFunctions.ShowConfirm({
          zIndex: 2000,
          title: "Do you want to discard changes?",
          okText: "Yes",
          cancelText: "No",
          onOk() {
            // console.log('OK');
            close();
          },
          onCancel() {
            // console.log('Cancel');
          }
        })
      : close();
  }
  // addTaskFunction() {
  //   let newTaskDetails = scheduledTaskStore.scheduledTasks.slice();
  //   let ipRange = {}
  //   ipRange["Description"] = ""
  //   ipRange["Status"] = ""
  //   ipRange["Interval"] = 0
  //   ipRange["isNew"] = true
  //   ipRange["dataAdded"] = false

  //   newTaskDetails.push(ipRange)

  //   scheduledTaskStore.setScheduledTasks(JSON.stringify(newTaskDetails));

  // }
  saveTaskRange(id, taskName, description, status, interval, clickState) {
    let newTaskDetails = scheduledTaskStore.scheduledTasks.slice();
    let ipRange = newTaskDetails[id];
    ipRange.Description = description;
    ipRange.TaskName = taskName;
    ipRange.Status = status;
    ipRange.Interval = interval;
    ipRange.dataAdded = clickState;
    ipRange.isNew = clickState;
    newTaskDetails.push(ipRange);
    scheduledTaskStore.setScheduledTasks(JSON.stringify(newTaskDetails));
  }

  removeTaskRange(id) {
    let newTaskDetails = scheduledTaskStore.scheduledTasks.slice();
    newTaskDetails.splice(id, 1);
    scheduledTaskStore.setScheduledTasks(JSON.stringify(newTaskDetails));
  }
  handleSubmit = e => {
    // console.log('onSubmit: ');
    e.preventDefault();
    this.props.form.validateFieldsAndScroll(err => {
      // console.log('onSubmit: ', values, err);
      if (!err) {
        // console.log('Received values of form: ', values);
        this.saveAsset();
      }
    });
  };
  checkAndSetLoanDailyCost() {
    var LoanDailyCost = 0;
    var BookValue = addAssetsStore.fieldState.BookValue
      ? addAssetsStore.fieldState.BookValue
      : 0;
    var LoanDailyRate = addAssetsStore.fieldState.LoanDailyRate
      ? addAssetsStore.fieldState.LoanDailyRate
      : 0;
    var LoanAutoCalculate = addAssetsStore.fieldState.LoanAutoCalculate
      ? addAssetsStore.fieldState.LoanAutoCalculate
      : false;
    //LoanDailyCost = ((BookValue * LoanDailyRate) / 100) < 0 ? -999999 : (BookValue * LoanDailyRate) / 100;
    LoanDailyCost =
      BookValue < 0 ||
      LoanDailyRate < 0 ||
      (BookValue * LoanDailyRate) / 100 < 0
        ? -999999
        : (BookValue * LoanDailyRate) / 100;
    if (LoanAutoCalculate) {
      addAssetsStore.addToFieldState({ LoanDailyCost });
      if (LoanDailyCost >= 0) this.props.form.setFieldsValue({ LoanDailyCost });
      else this.props.form.setFieldsValue({ LoanDailyCost: "" });
    }
  }
  add = () => {
    scheduleTasksCount++;
    let taskArray = this.state.taskArray;
    let ipRange = {};
    ipRange["Description"] = "";
    ipRange["TaskName"] = "";
    ipRange["Interval"] = null;
    ipRange["Id"] = "";
    ipRange["DueDate"] = "";
    ipRange["Action"] = "ADD";
    //ipRange["ThingName"] = "1_10000032";
    taskArray.push(ipRange);
    this.setState({ taskArray });
  };
  addToExisting = data => {
    scheduleTasksCount++;
    let taskArray = this.state.taskArray;
    let item = {};
    item["TaskName"] = data.TaskName;
    item["Description"] = data.Description;
    item["Interval"] = data.Interval;
    item["Id"] = "";
    item["isExisting"] = true;
    item["DueDate"] = data.DueDate;
    item["Action"] = "ADD";
    taskArray.push(item);
    this.setState({ taskArray });
    // console.log("taskarayss...", taskArray);
    setTimeout(() => {
      this.props.form.setFieldsValue({ taskArray });
    }, 500);
    //  this.add();
  };
  //it hides the array element from the array with setting action to "Delete"
  remove = k => {
    scheduleTasksCount--;
    let newkeys = [];
    this.state.taskArray.map((item, index) => {
      let obj = item;
      if (index == k) {
        obj["Action"] = "DELETE";
      }
      newkeys.push(obj);
    });
    this.setState({ taskArray: newkeys });
  };
  //it checks the the server data has chnaged are not if yes, changes action from "Details" to "Edit"
  //then it sets the fiels value to array
  getArray = () => {
    let values = this.props.form.getFieldValue("taskArray");
    if (values != undefined) {
      if (this.state.taskArray.length > 0) {
        let newkeys = [];
        this.state.taskArray.map((item, index) => {
          let obj = item;
          if (
            obj["Action"] === "DETAILS" &&
            (obj["Description"] !== values[index].Description ||
              obj["TaskName"] !== values[index].TaskName ||
              obj["DueDate"] !== values[index].DueDate ||
              obj["Interval"] !== values[index].Interval)
          ) {
            obj["Action"] = "EDIT";
          }
          obj["Description"] =
            values[index] == undefined
              ? obj["Description"]
              : //using regex  == to remove space bewteen words and trim to remove space between start and end
                values[index].Description.replace(/\s\s+/g, " ").trim();
          obj["TaskName"] =
            values[index] == undefined
              ? obj["TaskName"]
              : values[index].TaskName;
          obj["DueDate"] =
            values[index] == undefined ? obj["DueDate"] : values[index].DueDate;
          obj["Interval"] =
            values[index] == undefined
              ? obj["Interval"]
              : values[index].Interval;
          newkeys.push(obj);
        });
        this.setState({ taskArray: newkeys });
      }
    }
  };
  saveAsset() {
    let changed = [];
    if (Array.isArray(addAssetsStore.fieldState.Organization)) {
      addAssetsStore.addToFieldState({
        Organization:
          addAssetsStore.fieldState.Organization[
            addAssetsStore.fieldState.Organization.length - 1
          ]
      });
    }
    if (Array.isArray(addAssetsStore.fieldState.Location)) {
      addAssetsStore.addToFieldState({
        Location:
          addAssetsStore.fieldState.Location[
            addAssetsStore.fieldState.Location.length - 1
          ]
      });
    }
    this.props.form.validateFieldsAndScroll(err => {
      // console.log('onSubmit: ', values, err);
      if (!err) {
        if (addAssetsStore.maintenanceTaskInput == "unsave") {
          UIFunctions.ShowConfirm({
            zIndex: 2000,
            title: "You have unsaved Maintenance Task.Do you want to continue?",
            okText: "Yes",
            cancelText: "No",
            onOk() {
              addAssetsStore.maintenanceTaskInput = "save";
              close();
            },
            onCancel() {
              return;
            }
          });
        }
        if (addAssetsStore.maintenanceTaskInput !== "unsave") {
          addAssetsStore.maintenanceTaskInput = "save";
          this.getArray();
          let result = this.state.taskArray.slice();
          changed = result.map(item => {
            let obj = item;
            if (obj.Action == "DELETE" && obj.Id == "") {
              return;
            }
            return item;
          });
          let finalArray = changed.filter(k => k != undefined);
          for (var i = 0; i < finalArray.length; i++) {
            finalArray[i].DueDate = moment(finalArray[i].DueDate).toISOString();
          }
          // console.log("Thingname", ThingName);
          addAssetsStore.addToFieldState({ taskArray: finalArray });
          // Functions.CreateOrDeleteTasks({ 'Input': scheduleTasks }).then((response) => {
          // })
          addAssetsStore.setSubmitting(true);
          this.saveToServer();
        }
      }
    });
  }
  saveToServer() {
    // if (!this.state.Manufacturer) { return UIFunctions.ShowError({ zIndex: 2000, title: "Please Provide valid Manufacturer Name" }); }
    // if (!this.state.ModelNo) { return UIFunctions.ShowError({ zIndex: 2000, title: "Please Provide valid Model Number" }); }
    // if (!this.state.Organization) { return UIFunctions.ShowError({ zIndex: 2000, title: "Please Provide valid Organization" }); }
    // if (!this.state.Location) { return UIFunctions.ShowError({ zIndex: 2000, title: "Please Provide valid Location" }); }
    // if (!this.state.Cordinator) { return UIFunctions.ShowError({ zIndex: 2000, title: "Please Provide valid Coordinator" }); }
    // console.log("state", this.state, addAssetsStore.fieldState);
    Functions.ValidateEquipmentNumber(
      addAssetsStore.fieldState.EquipmentNo
    ).then(resp => {
      //console.log('ValidateEquipmentNumber', resp.data)
      if (!resp.data.isUnique || !resp.data.success) {
        addAssetsStore.setSubmitting(false);
        return UIFunctions.ShowError({
          zIndex: 2000,
          title: "Equipment Number Already exists!"
        });
      }

      if (resp.data.isUnique && resp.data.success) {
        //debugger
        var payload = JSON.parse(JSON.stringify(addAssetsStore.fieldState));
        if (Array.isArray(payload.Organization)) {
          payload.Organization =
            payload.Organization[payload.Organization.length - 1];
        }
        if (Array.isArray(payload.Location)) {
          payload.Location = payload.Location[payload.Location.length - 1];
        }
        if (payload.SystemParent == false) {
          payload.SystemName = "";
        }
        if (payload.SystemChild == false) {
          payload.ParentSystemName = "";
        }
        // console.log("payload", payload)
        Functions.CreateAsset({ Input: payload })
          .then(resp => {
            addAssetsStore.setSubmitting(false);
            var EqNum = resp.data.ThingName;
            if (resp.data.success == true) {
              addAssetsStore.setAddAssetsOpen(false);
              this.setState({ modal: false });
              UIFunctions.Toast(resp.data.message, "success");
              tabModelStore.reRenderGrid();
              addAssetsStore.entriesAssetFileList.forEach(item => {
                var r = new FileReader();
                var data = item.originFileObj;
                // console.log(item, data)
                r.onload = function() {
                  // alert(r.result);
                  Functions.UploadFileForAsset(
                    EqNum.split("_")[1],
                    item.name,
                    r.result
                  );
                };
                r.readAsDataURL(data);
              });
            } else {
              addAssetsStore.setAddAssetsOpen(false);
              UIFunctions.Toast(resp.data.message, "error");
            }
          })
          .catch(() => {
            UIFunctions.Toast(resp.data.message, "error");
          });
      } else {
        addAssetsStore.setSubmitting(false);
        //console.log('Error validating the equipment number')
      }
    });
  }
  saveTemplate() {
    if (addAssetsStore.fieldState.Organization != undefined) {
      addAssetsStore.addToFieldState({
        Organization:
          addAssetsStore.fieldState.Organization[
            addAssetsStore.fieldState.Organization.length - 1
          ]
      });
    }

    if (addAssetsStore.fieldState.Location != undefined) {
      addAssetsStore.addToFieldState({
        Location:
          addAssetsStore.fieldState.Location[
            addAssetsStore.fieldState.Location.length - 1
          ]
      });
    }

    var payload = JSON.parse(JSON.stringify(addAssetsStore.fieldState));
    if (Array.isArray(payload.Organization)) {
      payload.Organization =
        payload.Organization[payload.Organization.length - 1];
    }
    if (Array.isArray(payload.Location)) {
      payload.Location = payload.Location[payload.Location.length - 1];
    }
    var self = this;
    addAssetsStore.setSubmitting(true);
    Functions.IsExistingTemplate(
      this.state.CustomerId,
      this.state.TemplateName
    ).then(resp => {
      UIFunctions.Confirm({
        zIndex: 2000,
        title: resp.data.message,
        okText: "Yes",
        cancelText: "No",
        // content: 'When clicked the OK button, this dialog will be closed after 1 second',
        onOk() {
          Functions.CreateTemplateURL(payload)
            .then(resp => {
              // console.log("resp", resp);
              resp.data.success
                ? UIFunctions.ShowSuccess({
                    zIndex: 2000,
                    title: resp.data.message
                  })
                : UIFunctions.ShowError({
                    zIndex: 2000,
                    title: resp.data.message
                  });
              // console.log("GetTemplates", userStore.userDetails.CustomerId)
              Functions.GetTemplates(userStore.userDetails.CustomerId).then(
                response => {
                  // console.log("response", response);
                  addAssetsStore.setTemplates(response.data.data);
                  self.setState({ TemplateName: "" });
                  // console.log("Template", self.state.TemplateName);
                  self.formLoaded = true;

                  addAssetsStore.setSubmitting(false);
                }
              );
            })
            .catch(() => {
              UIFunctions.ShowError({
                zIndex: 2000,
                title: "Oops ! Something went wrong !"
              });
            });
        },
        onCancel() {
          addAssetsStore.setSubmitting(false);
        }
      });
    });
  }

  activeFinder(component) {
    return component === this.state.activeTab
      ? "breadcrumb-item active"
      : "breadcrumb-item";
  }
  onTemplateChange = e => {
    // console.log(e.target.value);
    this.setState({ TemplateName: e.target.value });
    addAssetsStore.addToFieldStateFromCode({ TemplateName: e.target.value });
  };
  onTemplateChangeSelect = e => {
    this.setState(defaultState);
    let item = addAssetsStore.templates.find(o => o.templateName === e);
    item = item.values;
    this.resetForm();
    this.setState(item);
    var self = this;
    addAssetsStore.addToFieldStateFromCode(item);

    //added for instant values and then in the background coordinator list will load from the server
    var data = _.cloneDeep(addAssetsStore.fieldState);
    self.props.form.setFieldsValue(self.parseAndMakeForForm(data));
    item.Organization
      ? Functions.GetAllUsersForCustomer(item.Organization, "").then(resp => {
          addAssetsStore.setUsersForCustomer(resp.data.UserList);
          self.props.form.setFieldsValue(self.parseAndMakeForForm(data));
        })
      : this.props.form.setFieldsValue(this.parseAndMakeForForm(data));
    // console.log("after", item);
  };

  parseAndMakeForForm(json) {
    var rtn = json;
    var loc = this.parseTree(rtn.Location);
    var org = this.parseTree(rtn.Organization);
    rtn.Location = loc;
    rtn.Organization = org;
    var IntegerFields = addAssetsStore.IntegerFields;
    for (var fields of IntegerFields) {
      if (rtn[fields] && rtn[fields] == -999999) {
        rtn[fields] = "";
      }
    }
    for (var currentPicker of dates) {
      if (rtn[currentPicker]) {
        // console.log("item", currentPicker, rtn[currentPicker]);
        rtn[currentPicker] = moment(rtn[currentPicker]);
      }
    }
    return rtn;
  }
  componentWillUnmount() {
    let ManufacturerList = addAssetsStore.fieldState.ManufacturerList;
    addAssetsStore.clearFieldState();
    addAssetsStore.addToFieldStateFromCode({
      ManufacturerList: ManufacturerList
    });
  }
  componentDidMount() {
    addAssetsStore.setEditting(false);
    var self = this;
    //clearing Asset Store
    var customerId = userStore.userDetails.CustomerId;
    this.setState({ CustomerId: customerId });
    this.baseState.CustomerId = this.state.CustomerId;
    addAssetsStore.addToFieldStateFromCode(self.baseState);
    addAssetsStore.setEntriesAssetFileList([]);
    addAssetsStore.clearSystemComponents();
    addAssetsStore.setSubmitting(false);
    self.props.form.setFieldsValue(this.parseAndMakeForForm(this.state));

    // console.log("userStore", userStore.userDetails);
    addAssetsStore.getAllApi("CreateAsset").then(() => {
      self.setState({
        EquipmentNo: +addAssetsStore.equipmentNumberSequence
      });
      this.baseState.EquipmentNo = self.state.EquipmentNo;
      self.formLoaded = true;
      this.props.form.setFieldsValue(this.parseAndMakeForForm(this.state));
    });
  }
  _handleWaypointLeave() {
    // console.log("Le")
  }
  setScrollState(obj) {
    setTimeout(() => {
      this.setState(obj);
    }, 10);
  }

  render() {
    //eslint-disable-next-line
    const count = scheduleTasksCount;
    var templates = addAssetsStore.templates
      ? JSON.parse(JSON.stringify(addAssetsStore.templates))
      : [];
    return (
      <div className="row">
        <Form onSubmit={this.handleSubmit} autoComplete="off">
          <Modal
            isOpen={addAssetsStore.addAssetsOpen}
            className="modal-dialog modal-lg"
            style={{ maxWidth: "1000px" }}
            id="createAssetModal"
          >
            {this.formLoaded ? (
              <div>
                <ModalHeader
                  className="row modalHeader"
                  style={{ borderBottom: "1px solid #ccd0d8" }}
                >
                  <span className="createAssetLabel">Create Asset</span>
                  <span
                    onClick={this.toggleNew.bind(this)}
                    style={{ cursor: "pointer" }}
                  >
                    <i className="icon-close" />
                  </span>
                  <Col span={8} className="template-dropdown">
                    {" "}
                    {/*'Template Select Dropdown'*/}
                    <Select
                      id="templateSelect"
                      style={{ width: 300, paddingLeft: -50 }}
                      onChange={this.onTemplateChangeSelect}
                      showSearch={true}
                      getPopupContainer={trigger => trigger.parentElement}
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.props.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                      placeholder="Select Saved Template"
                    >
                      {templates
                        ? templates.map(dropdown => (
                            <option key={dropdown.templateName}>
                              {dropdown.templateName}
                            </option>
                          ))
                        : ""}
                    </Select>
                  </Col>
                </ModalHeader>
                <ModalBody
                  style={{
                    paddingLeft: 0,
                    paddingRight: 0,
                    paddingBottom: "0px"
                  }}
                >
                  {/*
                <Row>
                  <Col span={8}> {/*'Template Select Dropdown'
                     <Select id="templateSelect" style={{ width: 300, paddingLeft: -50 }}
                        onChange={this.onTemplateChangeSelect}
                        placeholder="Select Saved Template">
                        {addAssetsStore.templates.map(dropdown =>
                        <option key={dropdown.templateName}>{dropdown.templateName}</option>)}
                     </Select>
                  </Col>
                </Row>
                */}
                  <nav className="breadcrumb" id="createAssetNav">
                    <a
                      onClick={() =>
                        this.setScrollState({ activeTab: "Identification" })
                      }
                      className={this.activeFinder("Identification")}
                      href="#Identification"
                    >
                      Identification
                    </a>
                    <a
                      onClick={() =>
                        this.setScrollState({ activeTab: "Configuration" })
                      }
                      className={this.activeFinder("Configuration")}
                      href="#Configuration"
                    >
                      Configuration
                    </a>
                    <a
                      onClick={() =>
                        this.setScrollState({ activeTab: "Attachments" })
                      }
                      className={this.activeFinder("Attachments")}
                      href="#Attachments"
                    >
                      Attachments
                    </a>
                    <a
                      onClick={() =>
                        this.setScrollState({ activeTab: "SystemIntegration" })
                      }
                      className={this.activeFinder("SystemIntegration")}
                      href="#SystemIntegration"
                    >
                      System Integration
                    </a>
                    <a
                      onClick={() =>
                        this.setScrollState({ activeTab: "Service" })
                      }
                      className={this.activeFinder("Services")}
                      href="#Services"
                    >
                      Service
                    </a>
                    <a
                      onClick={() =>
                        this.setScrollState({
                          activeTab: "OrderingAndRecieving"
                        })
                      }
                      className={this.activeFinder("OrderingAndRecieving")}
                      href="#OrderingAndRecieving"
                    >
                      Ordering & Receiving
                    </a>
                    <a
                      onClick={() =>
                        this.setScrollState({ activeTab: "Valuation" })
                      }
                      className={this.activeFinder("Valuation")}
                      href="#Valuation"
                    >
                      Valuation
                    </a>
                    <a
                      onClick={() =>
                        this.setScrollState({ activeTab: "Inventory" })
                      }
                      className={this.activeFinder("Inventory")}
                      href="#Inventory"
                    >
                      Inventory
                    </a>
                  </nav>
                  <div
                    className="addAssetBody"
                    id="scrollarea"
                    style={{
                      paddingLeft: 25,
                      height: window.innerHeight - 210
                    }}
                  >
                    {/* 'Indentification' */}
                    <div id="Identification">
                      <fieldset className="fieldsetHeading">
                        <legend>Identification </legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() =>
                          this.setState({ activeTab: "Identification" })
                        }
                        onLeave={this._handleWaypointLeave}
                      />
                      <Identification
                        {...this.props}
                        mode="CREATE"
                        checkAndSetLoanDailyCost={this.checkAndSetLoanDailyCost}
                      />
                    </div>
                    {/* 'Configuration' */}
                    <div id="Configuration">
                      <fieldset className="fieldsetHeading">
                        <legend> Configuration</legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() =>
                          this.setState({ activeTab: "Configuration" })
                        }
                        onLeave={this._handleWaypointLeave}
                      />
                      <Configuration {...this.props} mode="CREATE" />
                    </div>
                    {/* 'Attachments' */}
                    <div id="Attachments">
                      <fieldset className="fieldsetHeading">
                        <legend> Attachments</legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() =>
                          this.setState({ activeTab: "Attachments" })
                        }
                        onLeave={this._handleWaypointLeave}
                      />
                      <Attachments {...this.props} mode="CREATE" />
                    </div>
                    {/* 'System Integration' */}
                    <div id="SystemIntegration">
                      <fieldset className="fieldsetHeading">
                        <legend>System Integration </legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() =>
                          this.setState({ activeTab: "SystemIntegration" })
                        }
                        onLeave={this._handleWaypointLeave}
                      />
                      <SystemIntegration {...this.props} mode="CREATE" />
                    </div>
                    {/* 'Service' */}
                    <div id="Services">
                      <fieldset className="fieldsetHeading">
                        <legend>Service </legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() => this.setState({ activeTab: "Services" })}
                        onLeave={this._handleWaypointLeave}
                      />
                      <Services {...this.props} mode="CREATE" />
                    </div>
                    {/* { <div style={{ marginBottom: 20 }}>
                      {this.state.editval ? '' : <Button className='addTaskMain' onClick={this.addTaskFunction.bind(this)} href='javaScript: void(0)'>Add Task</Button>} }
                      {}  <div className='gridRow gridRowHeading'>
                  <div className='gridCol'>Description</div>
                  <div className='gridCol'>Due date</div>
                  <div className='gridCol'>Interval</div>
                  <div className='gridCol'>Action</div>
                </div>}
                      {
                        scheduledTaskStore.scheduledTasks.map((tasks, key) => {
                          return <SchedulingTask key={tasks.Id} index={tasks.Id} tasks={tasks} editVal={this.state.editval} saveTaskRange={this.saveTaskRange.bind(this)} removeTaskRange={this.removeTaskRange.bind(this)} addTaskRange={this.addTaskFunction.bind(this)} totalTask={this.state.taskDetails.length} />
                        })
                      }
                    </div><br /> */}
                    {/* <div
                      className="gridCol"
                      style={{ marginBottom: "6px", color: "grey" }}
                    >
                      Maintenance Tasks:
                    </div> */}
                    {/* <div> */}
                    {/* <div className='gridRow gridRowHeading'> */}
                    {/* <div className='gridRow gridRowHeading' style={{ borderLeftWidth: 0, borderRightWidth: 0 }}  >
                      <div className='gridCol'>Task Name</div>
                      <div className="gridCol">Description</div>
                      <div className='gridCol'>First Due date</div>
                      <div className='gridCol'>Task Interval</div>
                      {addAssetsStore.mode == "DETAILS" ? '' : <div className='gridCol'>Action</div>}
                    </div> */}
                    {/* {console.log("scheduleTasksCount", scheduleTasksCount)} */}
                    <div>
                      {/* {scheduleTasksCount < 1 ? (
                        <div>
                          <p
                            className="scheduleTask_p"
                            style={{ textAlign: "center" }}
                          >
                            {" "}
                            Add Maintenance Tasks
                          </p>
                        </div>
                      ) : (
                        <div className="scheduleTaskDetails">
                          <ScheduleTasks
                            {...this.props}
                            edit={!(addAssetsStore.mode == "DETAILS")}
                            addToExisting={this.addToExisting}
                            add={this.add}
                            taskArray={this.state.taskArray}
                            remove={this.remove}
                            disabled={addAssetsStore.mode == "DETAILS"}
                          />
                        </div>
                      )}
                      {addAssetsStore.mode == "DETAILS" ? "" : <hr />}

                      {addAssetsStore.mode == "DETAILS" ? (
                        ""
                      ) : (
                        <ScheduleTaskDetails
                          {...this.props}
                          edit={!(addAssetsStore.mode == "DETAILS")}
                          taskArray={this.state.taskArray}
                          addToExisting={this.addToExisting}
                          add={this.add}
                          remove={this.remove}
                          disabled={addAssetsStore.mode == "DETAILS"}
                        />
                      )} */}

                      <br />
                      {/*'Order Recieve' */}
                      <div id="OrderingAndRecieving">
                        <fieldset className="fieldsetHeading">
                          <legend>Ordering & Receiving </legend>
                        </fieldset>
                        <Waypoint
                          onEnter={() =>
                            this.setState({
                              activeTab: "OrderingAndRecieving"
                            })
                          }
                          onLeave={this._handleWaypointLeave}
                        />
                        <OrderingAndRecieving {...this.props} mode="CREATE" />
                      </div>
                      {/*˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜ 'Valuation' ˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜*/}
                      <div id="Valuation">
                        <fieldset className="fieldsetHeading">
                          <legend>Valuation </legend>
                        </fieldset>
                        <Waypoint
                          onEnter={() =>
                            this.setState({ activeTab: "Valuation" })
                          }
                          onLeave={this._handleWaypointLeave}
                        />
                        <Valuation
                          {...this.props}
                          mode="CREATE"
                          checkAndSetLoanDailyCost={
                            this.checkAndSetLoanDailyCost
                          }
                        />
                      </div>
                      {/*˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜ 'Inventory' ˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜*/}
                      <div id="Inventory">
                        <fieldset className="fieldsetHeading">
                          <legend>Inventory </legend>
                        </fieldset>
                        <Waypoint
                          onEnter={() =>
                            this.setState({ activeTab: "Inventory" })
                          }
                          onLeave={this._handleWaypointLeave}
                        />
                        <Inventory {...this.props} mode="CREATE" />
                      </div>
                    </div>
                  </div>
                </ModalBody>
                <ModalFooter>
                  {/* 'Create Asset Fixed Footer' */}
                  <nav className="modalFooter navbar">
                    <Col span={5}>
                      {/* 'Toggle Button' */}
                      <div
                        style={{ display: "flex", alignItems: "center" }}
                        id="createAssetToggle"
                        data-toggle="buttons"
                      >
                        {/* <Button className={this.state.footerController === "CREATE" ? "btn btn-secondary " : "btn btn-secondary active"} id="createAssetToggle" onClick={() => this.setState({ footerController: "TEMPLATE" })}> Create Asset</Button>
                        {permissionStore.permissions.icons.CreateTemplate &&
                          <Button className={this.state.footerController === "CREATE" ? "btn btn-secondary active" : "btn btn-secondary "} id="saveAsTemplateToggle" onClick={() => this.setState({ footerController: "CREATE" })}>Save as Template</Button>
                        } */}
                        <Tooltip
                          placement="bottom"
                          title={
                            this.state.checked
                              ? "Save as Template"
                              : "Create Asset"
                          }
                        >
                          <Switch
                            style={{ marginRight: 9 }}
                            size="small"
                            checked={this.state.checked}
                            onChange={() =>
                              this.state.checked
                                ? this.setState({
                                    footerController: "TEMPLATE",
                                    checked: false
                                  })
                                : permissionStore.permissions.icons
                                    .CreateTemplate &&
                                  this.setState({
                                    footerController: "CREATE",
                                    checked: true
                                  })
                            }
                          />
                        </Tooltip>
                        <p
                          style={{
                            fontSize: 14,
                            margin: "4px 0",
                            letterSpacing: ".1em",
                            color: this.state.checked ? "#4f96ff" : "#bfbfbf"
                          }}
                        >
                          Save as Template
                        </p>
                      </div>
                    </Col>
                    {/*'Template Select Dropdown'*/}{" "}
                    {/* COS
                  <Col span={6}>
                     <Select class="template-select" style={{ width: '300', paddingLeft: '-50' }}
                      onChange={this.onTemplateChangeSelect}
                      placeholder="Select Saved Template">
                      {addAssetsStore.templates.map(dropdown =>
                      <option key={dropdown.templateName}>{dropdown.templateName}</option>)}
                     </Select>
                  </Col>
                  */}
                    {this.state.footerController === "CREATE" ? (
                      <Col span={17}>
                        <Row>
                          <Col span={11}>
                            <Input
                              value={this.state.TemplateName}
                              style={{ width: "70%" }}
                              placeholder="Template Name"
                              ref={node => (this.userNameInput = node)}
                              onChange={this.onTemplateChange}
                            />
                          </Col>
                          <Col span={7}>
                            {this.state.TemplateName ? (
                              <Button
                                type="Button"
                                className="aaSmallBtn btn btn-primary btn-sm"
                                id="submitBtn"
                                loading={addAssetsStore.submitting}
                                onClick={this.saveTemplate.bind(this)}
                                style={{ float: "right", marginLeft: "0px" }}
                              >
                                Save Template
                              </Button>
                            ) : (
                              <Button
                                type="Button"
                                style={{ float: "right", marginLeft: "0px" }}
                                disabled
                                onClick={this.toggleNew.bind(this)}
                              >
                                Save Template
                              </Button>
                            )}
                          </Col>
                          <Col span={3}>
                            <Button
                              type="Button"
                              className="aaSmallBtn btn btn-primary btn-sm"
                              onClick={this.openModel.bind(this)}
                              style={{
                                float: "right",
                                backgroundColor: "#ffd3d3",
                                color: "#ff3d5f",
                                borderColor: "#ff3d5f"
                              }}
                            >
                              Clear All
                            </Button>
                          </Col>
                          <Col span={3}>
                            <Button
                              type="Button"
                              className="aaSmallBtn btn btn-primary btn-sm"
                              onClick={this.toggleNew.bind(this)}
                            >
                              Cancel
                            </Button>
                          </Col>
                        </Row>
                      </Col>
                    ) : (
                      <Col span={17}>
                        <Col span={11} />
                        <Col span={7}>
                          <Button
                            loading={addAssetsStore.submitting}
                            className="aaSmallBtn btn btn-primary btn-sm"
                            onClick={this.saveAsset.bind(this)}
                            id="submitBtn"
                            type="primary"
                            htmlType="submit"
                            style={{ marginRight: "10px", float: "right" }}
                          >
                            Save
                          </Button>
                        </Col>
                        <Col span={3}>
                          <Button
                            type="Button"
                            className="aaSmallBtn btn btn-primary btn-sm"
                            onClick={this.openModel.bind(this)}
                            style={{
                              float: "right",
                              backgroundColor: "#ffd3d3",
                              color: "#ff3d5f",
                              borderColor: "#ff3d5f"
                            }}
                          >
                            Clear All
                          </Button>
                        </Col>
                        <Col span={3}>
                          <Button
                            type="Button"
                            className="aaSmallBtn btn btn-primary btn-sm"
                            onClick={this.toggleNew.bind(this)}
                          >
                            Cancel
                          </Button>
                        </Col>
                      </Col>
                    )}
                  </nav>
                </ModalFooter>
              </div>
            ) : (
              <div>
                <ModalHeader
                  className="row modalHeader"
                  style={{ borderBottom: "1px solid #ccd0d8" }}
                >
                  <span className="createAssetLabel">Create Asset</span>
                  <span
                    onClick={this.toggleNew.bind(this)}
                    style={{ cursor: "pointer" }}
                  >
                    <i className="icon-close" />
                  </span>
                </ModalHeader>
                <Card loading>Whatever content</Card>
              </div>
            )}
          </Modal>
        </Form>
      </div>
    );
  }
}

const WrappedRegistrationForm = Form.create()(AddAsset);

export default WrappedRegistrationForm;
