import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import { Badge, NavItem, UncontrolledTooltip } from "reactstrap";
import { observer } from "mobx-react";
import classNames from "classnames";
import nav from "./_nav";
import AddAsset from "../../components/AddAsset/";
import AssetDetails from "../../components/AssetDetails/";
import addAssetsStore from "../../stores/addAssetsStore";
import permissionStore from "../../stores/permissionStore";
import userStore from "../../stores/userStore";
import serviceRequestStore from "../../stores/serviceRequestStore";
import BulkEdit from "../../components/BulkEdit/";
import LoanPool from "../../views/LoanPool";
import OOT from "../../views/OOT";
import ServiceRequest from "../../components/ServiceRequest/";
import Functions from "../../api/Functions.js";
import URL from "../../api/Urls";
import { signOut } from "../../helpers/auth";
import UserDetails from "../../views/UserDetails";
import { isSessionValid } from "../../api/request";
import NotificationBadge from "react-notification-badge";
import { Effect } from "react-notification-badge";
import tabModelStore from "../../stores/tabModelStore";
import UIFunctions from "../../helpers/UIFunctions";
import PropTypes from "prop-types";
import SubmitIssue from "src/views/SubmitIssue";
import { Icon } from "antd";
import "./style.css";

UIFunctions.Message.config({
  top: 100,
  duration: 2,
  maxCount: 3
});

@observer
class Sidebar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openLeftNav: false,
      addAssetClicked: false,
      loanPool: false,
      bulkEdit: false,
      OOT: false,
      submitIssue: false,
      serviceRequest: false,
      loanPoolNotificationCount: 0,
      permissions: {
        icons: {},
        fields: {}
      }
    };
    if (permissionStore.permissions.icons) {
      addAssetsStore.dashboardClearCheck();
      return;
    }
  }

  componentDidMount() {
    document.addEventListener("click", this.handleClickOutside);
    Functions.GetPermissionBasedColumns().then(response => {
      this.setState({
        permissions: response.data
      });
      permissionStore.setPermissions(JSON.stringify(response.data));

      const menuValues = response.data.icons
        ? Object.values(response.data.icons.Dashboards)
        : [];

      if (menuValues.length > 0) {
        Functions.spotfireAuth(userStore.userDetails.UserName).then(() => {
          function loadJS(file) {
            var jsElm = document.createElement("script");
            jsElm.type = "application/javascript";
            jsElm.src = file;
            document.body.appendChild(jsElm);
          }
          loadJS(
            "https://aa-w-spotfire.ssgaa.usw2.amzn.keysight.com/spotfire/wp/GetJavaScriptApi.ashx?Version=7.5"
          );
        });
      }
    });

    Functions.GetNotificationCount().then(response => {
      tabModelStore.loanPoolNotificationCount =
        response.data.LoanPoolNotificationCount;
      tabModelStore.IssueLogNotificationCount =
        response.data.IssueLogNotificationCount;
      tabModelStore.ServiceRequestNotificationCount =
        response.data.ServiceRequestNotificationCount;
      tabModelStore.OOTNotificationCount = response.data.OOTNotificationCount;
    });
  }
  componentWillUnmount() {
    document.removeEventListener("click", this.handleClickOutside);
  }

  handleClick(e) {
    e.preventDefault();
    e.target.parentElement.classList.toggle("open");
  }
  /**
   * Alert if clicked on outside of element
   */
  handleClickOutside = event => {
    if (!event.target.classList.contains("smallScreenRef")) {
      document
        .getElementById("iconSetting")
        .classList.remove("iconSettingColor");
      document
        .getElementById("subMenu")
        .classList.remove("settings-subMenu-active");
    }
  };
  activeRoute(routeName, props) {
    return props.location.pathname.indexOf(routeName) > -1
      ? "nav-item nav-dropdown open"
      : "nav-item nav-dropdown";
  }

  menuBtnClick() {
    document
      .getElementsByTagName("BODY")[0]
      .classList.toggle("pushy-open-left");

    var x = document.getElementsByClassName("sideNavItem");
    x = x.length; //x = x.length - 2;
    for (var i = 0; i < x; i++) {
      let element = document.getElementsByClassName("sideNavItem");
      element[i].classList.toggle("expanded");
    }
  }

  handleChartsView(e) {
    e.preventDefault();
    if (!isSessionValid()) return;
    document.getElementById("viewSelectId").classList.toggle("show");
  }
  handleAssetChart(e) {
    e.preventDefault();
    if (!isSessionValid()) return;
    UIFunctions.Message.loading("Loading..", 1.5);
    setTimeout(() => {
      addAssetsStore.setIsDashboardSelected(false);
      tabModelStore.setIsAssetListView(false);
      tabModelStore.setIsChartView(true);
      tabModelStore.setIsVisible(false);
      tabModelStore.setShowToolTip(true);
      this.context.router.history.push("/charts");
      document
        .getElementsByTagName("BODY")[0]
        .classList.remove("pushy-open-left");
    }, 300);
  }
  handleAssetsDashboard(e) {
    e.preventDefault();
    if (!isSessionValid()) return;
    UIFunctions.Message.loading("Loading..", 1.5);
    setTimeout(() => {
      tabModelStore.setIsAssetListView(true);
      tabModelStore.setIsChartView(false);
      tabModelStore.setIsVisible(false);
      tabModelStore.setShowToolTip(true);
      document.getElementById("viewSelectId").classList.toggle("show");
      addAssetsStore.setIsServiceChartDashboardSelected(false);

      this.context.router.history.push("/dashboard");
      document
        .getElementsByTagName("BODY")[0]
        .classList.remove("pushy-open-left");
    }, 300);
  }
  handleAssetsDashboard1(e) {
    if (!isSessionValid()) return;
    UIFunctions.Message.loading("Loading..", 1.5);
    setTimeout(() => {
      e.preventDefault();
      document.getElementById("viewSelectId").classList.toggle("show");
      var newAssests = addAssetsStore.rowArrayData.map(e => e);
      serviceRequestStore.serviceRequestNewAddCheck(
        JSON.parse(JSON.stringify(newAssests))
      );
      if (
        addAssetsStore.isDashboardSelected ||
        addAssetsStore.isServiceChartDashboardSelected
      )
        this.context.router.history.push("/request/RequestSelectedComponent");
      else {
        serviceRequestStore.serviceRequestNewAddCheck([]);
        this.context.router.history.push("/request");
      }
    }, 300);
  }
  handleAssetAdd() {
    if (!isSessionValid()) return;
    document
      .getElementsByTagName("BODY")[0]
      .classList.remove("pushy-open-left");
    if (addAssetsStore.addAssetsOpen) {
      this.setState({ addAssetClicked: false });
      addAssetsStore.setAddAssetsOpen(false);
    } else {
      this.setState({ addAssetClicked: true });
      addAssetsStore.setAddAssetsOpen(true);
    }
  }
  handleAssetDetails() {
    if (!isSessionValid()) return;
    document
      .getElementsByTagName("BODY")[0]
      .classList.remove("pushy-open-left");
    if (this.state.assetDetailsClicked) {
      this.setState({ assetDetailsClicked: false });
    } else {
      this.setState({ assetDetailsClicked: true });
    }
  }
  handleSubmitIssue() {
    if (!isSessionValid()) return;
    document.getElementById("viewSelectId").classList.toggle("show");
    this.context.router.history.push("/submit-issue");
  }

  handleBulkEdit(e) {
    e.preventDefault();
    if (!isSessionValid()) return;
    if (addAssetsStore.dashboardChecked.length > 1) {
      if (addAssetsStore.bulkEditOpen) {
        this.setState({ bulkEdit: false });
        addAssetsStore.setBulkEditOpen(false);
      } else {
        this.setState({ bulkEdit: true });
        addAssetsStore.setBulkEditOpen(true);
      }
    }
  }

  handleAssetDetailsModal(e) {
    e.preventDefault();
    if (!isSessionValid()) return;
    if (
      addAssetsStore.dashboardChecked.length === 1 &&
      (addAssetsStore.isDashboardSelected ||
        addAssetsStore.isServiceChartDashboardSelected)
    ) {
      addAssetsStore.toggleAssetDetailsModal();
    }
  }

  disableEnableBulkEditButton() {
    return addAssetsStore.dashboardChecked.length > 1 ? "1" : "0.5";
  }

  handleSignOut() {
    function loadJS(file) {
      var jsElm = document.createElement("script");
      jsElm.type = "application/javascript";
      jsElm.src = file;
      document.body.appendChild(jsElm);
    }
    UIFunctions.Confirm({
      zIndex: 2000,
      title: "Do you want to sign out?",
      okText: "Yes",
      cancelText: "No",
      onOk() {
        signOut()
          .then(() => {
            Functions.spotfireSignout().then(() => {
              loadJS(URL.spotfireLogout);
              setTimeout(()=>{
                location.reload();
              },2000)
              this.context.router.history.push("/");
            });
          })
          .catch(() => {
            Functions.spotfireSignout().then(() => {
              loadJS(URL.spotfireLogout);
              setTimeout(()=>{
                location.reload();
              },2000)
              this.context.router.history.push("/");
            });
          });
      },
      onCancel() {
        tabModelStore.setRemaneButtonLoading(false);
      }
    });
  }

  handleUserDetails() {
    if (!isSessionValid()) return;
    userStore.setUserDetailsModalopen(true);
  }

  handleLoanPool() {
    if (!isSessionValid()) return;
    document.getElementById("viewSelectId").classList.toggle("show");
    this.context.router.history.push("/loan-pool-notifications");
  }
  handleOOT() {
    if (!isSessionValid()) return;
    document.getElementById("viewSelectId").classList.toggle("show");
    this.context.router.history.push("/out-of-tolerance");
  }
  handleServiceRequest() {
    if (!isSessionValid()) return;
    document
      .getElementsByTagName("BODY")[0]
      .classList.remove("pushy-open-left");
    if (this.state.serviceRequest) {
      this.setState({ serviceRequest: false });
    } else {
      this.setState({ serviceRequest: true });
    }
  }

  showHideAssetDetails() {
    return addAssetsStore.dashboardChecked.length === 1 ? "block" : "none";
  }

  handleAdminSettingsClick = () => {
    if (!isSessionValid()) return;
    document.location.href = URL.adminRedirectUrl;
  };
  handleSettingsClick = () => {
    document.getElementById("iconSetting").classList.toggle("iconSettingColor");
    document
      .getElementById("subMenu")
      .classList.toggle("settings-subMenu-active");
  };
  handleSubOptions1(e, url) {
    e.preventDefault();
    addAssetsStore.setIsDashboardSelected(false);
    addAssetsStore.setIsServiceChartDashboardSelected(false);
    tabModelStore.setIsVisible(true);
    tabModelStore.setIsAssetListView(false);
    tabModelStore.setIsChartView(false);
    document.getElementById("viewSelectId").classList.toggle("show");
    // tabModelStore.setHideHeader(true)
    // console.log("storeee", tabModelStore.hideHeader)
    this.context.router.history.push(`/reports?target=${url}`);
    document
      .getElementsByTagName("BODY")[0]
      .classList.remove("pushy-open-left");
  }

  render() {
    const menuValues = permissionStore.permissions.icons
      ? Object.values(permissionStore.permissions.icons.Dashboards)
      : [];
    const props = this.props;
    const activeRoute = this.activeRoute;
    const handleClick = this.handleClick;

    // badge addon to NavItem
    const badge = badge => {
      if (badge) {
        const classes = classNames(badge.class);
        return (
          <Badge className={classes} color={badge.variant}>
            {badge.text}
          </Badge>
        );
      }
    };

    // simple wrapper for nav-title item
    const wrapper = item => {
      return item.wrapper && item.wrapper.element
        ? React.createElement(
            item.wrapper.element,
            item.wrapper.attributes,
            item.name
          )
        : item.name;
    };

    // nav list section title
    const title = (title, key) => {
      const classes = classNames("nav-title", title.class);
      return (
        <li key={key} className={classes}>
          {wrapper(title)}{" "}
        </li>
      );
    };

    // nav list divider
    const divider = (divider, key) => <li key={key} className="divider" />;

    // nav item with nav link
    const navItem = (item, key) => {
      const classes = classNames("nav-link", item.class);
      return (
        <NavItem key={key}>
          <NavLink to={item.url} className={classes} activeClassName="active">
            <i className={item.icon} />
            {item.name}
            {badge(item.badge)}
          </NavLink>
        </NavItem>
      );
    };

    // nav dropdown
    const navDropdown = (item, key) => {
      return (
        <li key={key} className={activeRoute(item.url, props)}>
          <a
            className="nav-link nav-dropdown-toggle"
            //href=""
            onClick={handleClick.bind(this)}
          >
            <i className={item.icon} /> {item.name}
          </a>
          <ul className="nav-dropdown-items">{navList(item.children)}</ul>
        </li>
      );
    };

    // nav link
    const navLink = (item, idx) =>
      item.title
        ? title(item, idx)
        : item.divider
        ? divider(item, idx)
        : item.children
        ? navDropdown(item, idx)
        : navItem(item, idx);

    // nav list
    const navList = items => {
      return items.map((item, index) => navLink(item, index));
    };

    const badgestyle = {
      color: "white",
      backgroundColor: "#ff4051",
      top: "",
      left: "",
      bottom: "-8px",
      right: "-11px"
    };
    const badgestyleIssueLog = {
      color: "white",
      backgroundColor: "#ff4051",
      top: "",
      left: "",
      bottom: "19px",
      right: "-11px",
      padding: "4px 7px 4px 7px"
    };

    // sidebar-nav root
    return (
      <div>
        {permissionStore.permissions.icons ? (
          <nav className="pushy pushy-left" data-focus="#first-link">
            <i
              className="icon-menu menu-btn"
              onClick={this.menuBtnClick.bind(this)}
              id="ToolTipExpandbtn"
              style={{ cursor: "pointer" }}
            />
            <UncontrolledTooltip
              placement="right"
              innerClassName="tooltip"
              target="ToolTipExpandbtn"
            >
              Expand/Hide menu
            </UncontrolledTooltip>
            <div className="sidebar-content">
              <div id="viewSelectId" className="dropdown viewSelect">
                {
                  <div>
                    <button //Active Grid Button
                      onClick={this.handleAssetsDashboard.bind(this)}
                      className={
                        "btn btn-secondary " +
                        (tabModelStore.isAssetListView ? "selected" : "")
                      }
                      type="button"
                      id="dropdownMenuButton"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      Asset List View
                      <i
                        className={
                          "icon-grid " +
                          (tabModelStore.isAssetListView ? "selected" : "")
                        }
                        id="ToolTipListbtn"
                      />
                      <UncontrolledTooltip
                        placement="right"
                        innerClassName="tooltip"
                        target="ToolTipListbtn"
                      >
                        Asset List View
                      </UncontrolledTooltip>
                    </button>
                    <button //Active Graph Button
                      onClick={this.handleAssetChart.bind(this)}
                      className={
                        "btn btn-secondary " +
                        (tabModelStore.isChartView ? "selected" : "")
                      }
                      type="button"
                      id="dropdownMenuButton"
                      aria-haspopup="true"
                      // title="Asset Chart View"
                      aria-expanded="false"
                    >
                      Asset Chart View
                      <i
                        className={
                          "icon-graph " +
                          (tabModelStore.isChartView ? "selected" : "")
                        }
                        id="ToolTipChartbtn"
                      />
                      <UncontrolledTooltip
                        placement="right"
                        innerClassName="tooltip"
                        target="ToolTipChartbtn"
                      >
                        Asset Chart View
                      </UncontrolledTooltip>
                    </button>
                  </div>
                }
              </div>
              <ul className="nav">
                {permissionStore.permissions.icons.CreateAsset && (
                  <a
                    className="sideNavItem"
                    onClick={this.handleAssetAdd.bind(this)}
                    data-toggle="modal"
                    data-target=".createAssetModal"
                  >
                    <li className="nav-item">
                      <span className="addAsset">Create Asset</span>
                      <i className="icon-plus" />
                    </li>
                    <span className="tooltiptext">Create Asset</span>
                  </a>
                )}
                <a
                  className={
                    "sideNavItem" +
                    (addAssetsStore.dashboardChecked.length === 1 &&
                    (addAssetsStore.isDashboardSelected ||
                      addAssetsStore.isServiceChartDashboardSelected)
                      ? ""
                      : " sideNavItemDisabled")
                  }
                  onClick={this.handleAssetDetailsModal.bind(this)}
                  data-toggle="modal"
                  data-target=".createAssetModal"
                >
                  <li className="nav-item">
                    <span className="addAsset">Asset Details</span>
                    <i className="icon-list" />
                    <span className="tooltiptext">Asset Details</span>
                  </li>
                </a>
                {permissionStore.permissions.icons.BulkEdit && (
                  <a
                    className={
                      "sideNavItem" +
                      (addAssetsStore.dashboardChecked.length > 1
                        ? ""
                        : " sideNavItemDisabled")
                    }
                    onClick={this.handleBulkEdit.bind(this)}
                    data-toggle="modal"
                    data-target=".createAssetModal"
                  >
                    <li className="nav-item">
                      <span className="addAsset">Bulk Edit</span>
                      <i className="icon-pencil" />
                      <span className="tooltiptext">Bulk Edit</span>
                    </li>
                  </a>
                )}
                {permissionStore.permissions.icons.ServiceRequestIcon && (
                  <a
                    className="sideNavItem"
                    onClick={this.handleAssetsDashboard1.bind(this)}
                  >
                    <li className="nav-item">
                      <span className="addAsset">Service Request</span>
                      {(addAssetsStore.isDashboardSelected ||
                        addAssetsStore.isServiceChartDashboardSelected) ==
                      true ? (
                        <i className="icon-service-request-shortcut" />
                      ) : (
                        <i className="icon-tag" />
                      )}

                      <span className="tooltiptext">Service Request</span>

                      {(addAssetsStore.isDashboardSelected ||
                        addAssetsStore.isServiceChartDashboardSelected) ==
                      true ? (
                        ""
                      ) : tabModelStore.ServiceRequestNotificationCount != 0 ? (
                        <NotificationBadge
                          count={tabModelStore.ServiceRequestNotificationCount}
                          effect={Effect.SCALE}
                          style={badgestyle}
                        />
                      ) : (
                        ""
                      )}
                    </li>
                  </a>
                )}
                {permissionStore.permissions.icons.LoanPool && (
                  <a
                    className="sideNavItem"
                    onClick={this.handleLoanPool.bind(this)}
                    data-toggle="modal"
                    data-target=".createAssetModal"
                  >
                    <li className="nav-item">
                      <span className="addAsset">Loan Pool</span>
                      <i className="icon-basket" />

                      <span className="tooltiptext">Loan Pool</span>
                      {tabModelStore.loanPoolNotificationCount != 0 ? (
                        <NotificationBadge
                          count={tabModelStore.loanPoolNotificationCount}
                          effect={Effect.SCALE}
                          style={badgestyle}
                        />
                      ) : (
                        ""
                      )}
                    </li>
                  </a>
                )}

                {permissionStore.permissions.icons.IssueLog && (
                  <a
                    className="sideNavItem"
                    onClick={this.handleSubmitIssue.bind(this)}
                    data-toggle="modal"
                    data-target=".createAssetModal"
                  >
                    <li className="nav-item">
                      <span className="addAsset">Issue Log</span>

                      <i className="icon-flag" />
                    </li>
                    <span className="tooltiptext">Issue Log</span>
                    {tabModelStore.IssueLogNotificationCount != 0 ? (
                      <NotificationBadge
                        count={tabModelStore.IssueLogNotificationCount}
                        effect={Effect.SCALE}
                        style={badgestyleIssueLog}
                      />
                    ) : (
                      ""
                    )}
                  </a>
                )}
                {menuValues.length > 0 ? (
                  <a
                    onClick={e => this.handleSubOptions1(e, "defaultDashboard")}
                    className=" ant-dropdown-link sideNavItem"
                    style={{
                      backgroundColor: tabModelStore.isVisible ? "#2C2E33" : ""
                    }}
                  >
                    <span className="addAsset">Dashboards</span>
                    <Icon
                      type="layout"
                      style={{
                        color: tabModelStore.isVisible ? "#3385FF" : ""
                      }}
                    />
                    <span className="tooltiptext">Dashboards</span>
                  </a>
                ) : (
                  ""
                )}
              </ul>
            </div>
            <ul className="nav navLowerItems big-screen-height">
              {permissionStore.permissions.icons.AdminSettingsIcon && (
                <a
                  onClick={this.handleAdminSettingsClick}
                  className="sideNavItem"
                >
                  <li className="nav-item">
                    <span className="addAsset">Admin settings</span>
                    <i className="icon-settings" />
                    <span className="tooltiptext">Admin Settings</span>
                  </li>
                </a>
              )}
              <a
                className="sideNavItem"
                onClick={this.handleUserDetails.bind(this)}
                data-toggle="modal"
                data-target=".createAssetModal"
              >
                <li className="nav-item">
                  <span className="addAsset">User Settings</span>

                  <i className="icon-user" />
                  <span className="tooltiptext">User Settings</span>
                </li>
              </a>
              {userStore.userDetailsModalOpen ? <UserDetails /> : ""}
              <a
                className="sideNavItem"
                onClick={this.handleSignOut.bind(this)}
                data-toggle="modal"
                data-target=".createAssetModal"
              >
                <li className="nav-item">
                  <span className="addAsset">Sign Out</span>
                  <i className="icon-logout" />
                  <span className="tooltiptext">Sign Out</span>
                </li>
              </a>
            </ul>
            <ul className="nav navLowerItems small-screen-height">
              <a
                onClick={this.handleSettingsClick}
                className="sideNavItem smallScreenRef"
                data-toggle="modal"
                data-target=".createAssetModal"
              >
                <li className="nav-item smallScreenRef">
                  <span className="addAsset smallScreenRef">Settings</span>
                  <i
                    className="icon-settings smallScreenRef"
                    id="iconSetting"
                  />
                  <span className="tooltiptext">Settings</span>
                  <ul className="settings-subMenu" id="subMenu">
                    {permissionStore.permissions.icons.AdminSettingsIcon && (
                      <a
                        onClick={this.handleAdminSettingsClick}
                        className="same-settings-subMenu"
                      >
                        <li>
                          <i className="icon-equalizer small-screen" />
                          Admin Settings
                        </li>
                      </a>
                    )}

                    <a
                      className="same-settings-subMenu"
                      onClick={this.handleUserDetails.bind(this)}
                    >
                      <li>
                        <i className="icon-user small-screen" />
                        User Settings
                      </li>
                    </a>
                    {userStore.userDetailsModalOpen ? <UserDetails /> : ""}
                    <a
                      className="same-settings-subMenu"
                      onClick={this.handleSignOut.bind(this)}
                    >
                      <li>
                        <i
                          className="icon-logout small-screen"
                          style={{ color: "#FF3E39" }}
                        />
                        Sign Out
                      </li>
                    </a>
                  </ul>
                </li>
              </a>
            </ul>
          </nav>
        ) : (
          ""
        )}
        {addAssetsStore.addAssetsOpen ? (
          <AddAsset clicked={this.state.addAssetClicked} />
        ) : (
          ""
        )}
        {addAssetsStore.assetDetailModalOpen ? (
          <AssetDetails UniqueID={addAssetsStore.dashboardChecked[0]} />
        ) : (
          ""
        )}
        {this.state.loanPool ? <LoanPool clicked={this.state.loanPool} /> : ""}
        {addAssetsStore.bulkEditOpen ? (
          <BulkEdit clicked={this.state.bulkEdit} />
        ) : (
          ""
        )}
        {this.state.OOT ? <OOT clicked={this.state.OOT} /> : ""}
        {this.state.submitIssue ? (
          <SubmitIssue clicked={this.state.submitIssue} />
        ) : (
          ""
        )}
        {this.state.serviceRequest ? (
          <ServiceRequest clicked={this.state.serviceRequest} />
        ) : (
          ""
        )}
        <div className="site-overlay" onClick={this.menuBtnClick.bind(this)} />
      </div>
    );
  }
}

export default Sidebar;
Sidebar.contextTypes = {
  history: PropTypes.object,
  router: PropTypes.object
};
