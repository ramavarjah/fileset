import React, { Component } from "react";

class SelectedAssets extends Component {
  render() {
    return (
      <div>
        <div className="serviceContentWrapper">
          <h4>Selected Assets</h4>
          <div className="gridStyle">grid will go here</div>

          <div className="row selectedItemList">
            <div className="col-lg-4">Selected items 1</div>
            <div className="col-lg-4">Selected items 2</div>
            <div className="col-lg-4">Selected items 3</div>
          </div>
        </div>
      </div>
    );
  }
}

export default SelectedAssets;
