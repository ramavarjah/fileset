import React, { Component } from 'react';


class ContactShipping extends Component {
  constructor(props) {    
    super(props);
    this.state = {
    
    }
  }
  render() {
    return (
      <div>
        <h3>ContactShipping ContactShipping</h3>
      </div>
    );
  }
}

export default ContactShipping;
