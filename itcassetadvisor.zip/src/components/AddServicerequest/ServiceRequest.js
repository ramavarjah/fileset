import React from 'react';
import SelectedAssets from './SelectedAssets'
import ContactShipping from './ContactShipping'
import './styles.css'

class ServiceRequest extends React.Component {
  constructor(props) {    
    super(props);
    this.state = {
      currentTab1:'',
      currentTab2:'',
      currentTab3:'',
      currentTab4:'',
      currentContent:'service'
    }
  }

  componentDidMount(){
    this.setState({currentTab1:'service'})
  }

  handleNext(){
    if(this.state.currentTab1 === 'service' && this.state.currentTab2 === 'contact'&& this.state.currentTab3 === 'budgetary'){
      this.setState({currentTab4:'confirmation', currentContent:'confirmation'})      
    }else if(this.state.currentTab1 === 'service' && this.state.currentTab2 === 'contact'){
      this.setState({currentTab3:'budgetary', currentContent:'budgetary'})      
    }else if(this.state.currentTab1 === 'service'){
      this.setState({currentTab2:'contact', currentContent:'contact'})
    }
  }
  handleBack(){
    if(this.state.currentTab1 === 'service' && this.state.currentTab2 === 'contact'&& this.state.currentTab3 === 'budgetary'&& this.state.currentTab4 === 'confirmation'){
      this.setState({currentTab4:'', currentContent:'budgetary'})      
    }else if(this.state.currentTab1 === 'service' && this.state.currentTab2 === 'contact'&& this.state.currentTab3 === 'budgetary'){
      this.setState({currentTab3:'', currentContent:'contact'})      
    }else if(this.state.currentTab1 === 'service' && this.state.currentTab2 === 'contact'){
      this.setState({currentTab2:'', currentContent:'service'})
    }else if(this.state.currentTab1 === 'service'){
      this.setState({currentTab1:'service', currentContent:'service'})
    }

  }
  render() {
    var activeStyle={backgroundColor:'#5ad1a4', color:'#fff'}
    var inactiveStyle={backgroundColor:'#ccd0d9', color:'#79828c'}
    return (
      <div>
        <div className='serviceWrapper'>
          <div className='serviceHeader'>SERVICE REQUEST</div>

          {/******** Breadcrump *********/}
          <div className='breadcrumpWrap'>
            <div style={this.state.currentTab1 === 'service' ? activeStyle:inactiveStyle}>
              1. Service Selected
            </div>
            <div style={this.state.currentTab2 === 'contact' ? activeStyle:inactiveStyle}>
              2. Contact & Shipping
            </div>
            <div style={this.state.currentTab3 === 'budgetary' ? activeStyle:inactiveStyle}>
              3. Budgetary Quote
            </div>
            <div style={this.state.currentTab4 === 'confirmation' ? activeStyle:inactiveStyle}>
              4. Confirmation
            </div>
          </div>
          
          {/******** Content *********/}
          {this.state.currentContent === 'service' ?
            <SelectedAssets />
            :''
          }

          {this.state.currentContent === 'contact' ?
            <div className='shiping'>

            <ContactShipping />
            </div>
            :''
          }

          {this.state.currentContent === 'budgetary' ?
            <p>I am in 3rd page</p>
            :''
          }

          {this.state.currentContent === 'confirmation' ?
            <p>I am in Final page</p>
            :''
          }


          
          {/******** Footer *********/}
          <div className='footerPosition'>
            <div onClick={this.handleBack.bind(this)}><span>&#60;</span>&nbsp;Back</div>
            <div onClick={this.handleNext.bind(this)}>Next <span>&#62;</span></div>
          </div>
        </div>
      </div>
    );
  }
}

export default ServiceRequest;
