import React from "react";
import { Form, Input, Icon, DatePicker } from "antd";
import PropTypes from "prop-types";
const FormItem = Form.Item;

export default class ScheduleTasks extends React.Component {
    componentDidMount() {
        if (this.props.taskArray.length > 0) {
            this.props.form.setFieldsValue({ taskArray: this.props.taskArray });
        }
    }
    componentDidUpdate(prevProps) {
        if (prevProps.edit == this.props.edit) return;
        else {
            if (this.props.taskArray.length > 0) {
                this.props.form.setFieldsValue({ taskArray: this.props.taskArray });
            }
        }
    }

  remove = k => {
      this.props.remove(k);
  };

  formItems() {
      let items = this.props.taskArray;
      const { getFieldDecorator } = this.props.form;
      return items.map(
          (k, index) =>
              k.Action == "DELETE" ? (
                  "" //this will hide the array elements with action as delete
              ) : (
                  <div
                      className="gridRow"
                      style={{
                          marginBottom: 8,
                          padding: "5px 10px 5px 10px",
                          borderLeftWidth: 0,
                          borderRightWidth: 0
                      }}
                      key={index}
                  >
                      <div className="gridCol">
                          <div
                              className="vlScheduletask"
                              style={{ marginTop: -5, marginLeft: -25 }}
                          />
                      </div>
                      <div className="gridCol">
                          <FormItem>
                              <span className="maintenanceTasktooltiptext">
                                  {this.props.taskArray[index].TaskName}
                              </span>
                              {getFieldDecorator("taskArray[" + index + "].TaskName", {
                                  rules: [
                                      {
                                          required: true,
                                          whitespace: true,
                                          message: "Please Provide Task Name."
                                      }
                                  ]
                              })(
                                  <Input
                                      className="textInputSchedule"
                                      placeholder="Task Name..."
                                      autosize={{ minRows: 2 }}
                                      disabled={this.props.disabled}
                                  />
                              )}
                          </FormItem>
                      </div>

                      <div className="gridCol">
                          <FormItem>
                              <span className="maintenanceTasktooltiptext">
                                  {this.props.taskArray[index].Description}
                              </span>
                              {getFieldDecorator("taskArray[" + index + "].Description", {
                                  rules: [
                                      {
                                          required: true,
                                          whitespace: true,
                                          message: "Please Provide Description."
                                      }
                                  ]
                              })(
                                  <Input
                                      className="textInputSchedule"
                                      placeholder="Description... "
                                      autosize={{ minRows: 2 }}
                                      disabled={this.props.disabled}
                                  />
                              )}
                          </FormItem>
                      </div>

                      <span
                          className="gridCol"
                          style={{
                              marginTop: 6,
                              marginRight: -20,
                              textAlign: "right",
                              fontSize: 13,
                              fontfamily: "Open Sans",
                              color: "grey"
                          }}
                      >
              Due:
                      </span>

                      {this.props.edit ? (
                          <div className="gridCol">
                              <FormItem className="textInputSchedule">
                                  {getFieldDecorator("taskArray[" + index + "].DueDate", {
                                      rules: [
                                          {
                                              required: true,
                                              message: "Please Select DueDate."
                                          }
                                      ]
                                  })(
                                      <DatePicker
                                          className="textInputSchedule"
                                          disabled={this.props.disabled}
                                          placeholder="First Due Date"
                                          format="MM/DD/YYYY"
                                      />
                                  )}
                              </FormItem>
                          </div>
                      ) : (
                          <div className="gridCol">
                              <FormItem className="textInputSchedule">
                                  <Input
                                      style={{ textAlign: "left" }}
                                      value={this.props.taskArray[index].DueDate.format(
                                          "MM/DD/YYYY"
                                      )}
                                      className="textInputSchedule"
                                      disabled={this.props.disabled}
                                      placeholder="First Due Date"
                                  />
                              </FormItem>
                          </div>
                      )}

                      <span
                          className="gridCol"
                          style={{
                              width: 110,
                              marginTop: 6,
                              marginRight: -20,
                              textAlign: "right",
                              fontSize: 13,
                              fontfamily: "Open Sans",
                              color: "grey"
                          }}
                      >
              Interval: Every
                      </span>
                      <div className="gridCol" style={{ width: 30 }}>
                          <FormItem>
                              {getFieldDecorator("taskArray[" + index + "].Interval", {
                                  rules: [
                                      {
                                          required: true,
                                          message: "Integer!"
                                      }
                                  ]
                              })(
                                  <Input
                                      placeholder="Task Interval(Months) "
                                      className="textInputSchedule"
                                      min={1}
                                      disabled={this.props.disabled}
                                  />
                              )}
                          </FormItem>
                      </div>
                      <span
                          className="gridCol"
                          style={{
                              width: 70,
                              marginTop: 6,
                              marginLeft: -20,
                              textAlign: "left",
                              fontSize: 13,
                              fontfamily: "Open Sans",
                              color: "grey"
                          }}
                      >
              months
                      </span>
                      {this.props.edit ? (
                          <div className="gridCol" style={{ marginTop: 2, width: 30 }}>
                              <FormItem>
                                  <span
                                      style={{
                                          cursor: "pointer",
                                          fontSize: 15,
                                          color: "red",
                                          paddingLeft: 15
                                      }}
                                      onClick={() => this.remove(index)}
                                  >
                                      <Icon type="close" />
                                  </span>
                              </FormItem>
                          </div>
                      ) : (
                          ""
                      )}
                  </div>
              )
      );
  }
  render() {
      return <div className="App">{this.formItems()}</div>;
  }
}

ScheduleTasks.propTypes = {
    taskArray: PropTypes.object,
    form: PropTypes.object,
    edit: PropTypes.object,
    remove: PropTypes.object,
    disabled: PropTypes.bool
};
