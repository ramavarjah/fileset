import React, { Component } from "react";
import { Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { observer } from "mobx-react";
import { observable } from "mobx";
import Functions from "./../../api/Functions";
import UIFunctions from "./../../helpers/UIFunctions";
import addAssetsStore from "./../../stores/addAssetsStore";
import tabModelStore from "../../stores/tabModelStore";
import ScheduleTasks from "./ScheduleTasks";
import "../../helpers/Antd/antd.css"; // new line of code
import { Button, Form, Card } from "antd";
import moment from "moment";
import request from "../../api/request";
import URL from "../../api/Urls";
import permissionStore from "../../stores/permissionStore";
import scheduledTaskStore from "../../stores/scheduledTaskStore";
import ScheduleTaskDetails from "./ScheduleTaskDetails";
import _ from "lodash";
// import 'moment/locale/en-gb';
// moment.locale('en-gb');
import Waypoint from "react-waypoint";

//segments
import Identification from "../AssetCommons/Identification";
import Configuration from "../AssetCommons/Configuration";
import Attachments from "../AssetCommons/Attachments";
import OrderingAndRecieving from "../AssetCommons/OrderingAndRecieving";
import Inventory from "../AssetCommons/Inventory";
import Valuation from "../AssetCommons/Valuation";
import SystemIntegration from "../AssetCommons/SystemIntegration";
import Services from "../AssetCommons/Services";
import History from "../AssetCommons/History";
import userStore from "src/stores/userStore";
var serverData = [];
var scheduleTasksCount = 0;

const dates = [
  "ReplacementDate",
  "CalibrationDate",
  "CalibrationDueDate",
  "LastServiceDate",
  "ServiceDueDate",
  "PlannedDisposalDate",
  "OrderDate",
  "ReceivedDate",
  "BookValueDate",
  "InventoryDate",
  "LastUpdate"
];

@observer
class AssetDetails extends Component {
  @observable formLoaded;
  @observable renderer;
  @observable orgTreeData;
  @observable locTreeData;
  state = {
    size: "default"
  };

  constructor(props) {
    super(props);
    //this.createRows();
    //  this.AssetcreateRows();
    //this.ServicecreateRows();
    //this.ChangecreateRows();
    this.formLoaded = false;
    this._Servicecolumns = [
      { key: "EquipmentNo", name: "Equipment Number" },
      { key: "Manufacturer", name: "Manufacturer" },
      { key: "ModelNo", name: "ModelNo" },
      { key: "SerialNo", name: "Serial Number" },
      { key: "Description", name: "Description" },
      { key: "CalibrationDueDate", name: "CalibrationDueDate" }
    ];
    this._Syscolumns = [
      { key: "EquipmentNo", name: "Equipment Number" },
      { key: "Manufacturer", name: "Manufacturer" },
      { key: "ModelNo", name: "ModelNo" },
      { key: "SerialNo", name: "Serial Number" },
      { key: "Description", name: "Description" },
      { key: "CalibrationDueDate", name: "CalibrationDueDate" }
    ];

    this._Assetcolumns = [
      { key: "name", name: "Name" },
      { key: "path", name: "Path" },
      { key: "downloadLink", name: "Download Link" },
      { key: "size", name: "Size" },
      {
        name: "Actions",
        key: "$delete",
        getRowMetaData: row => row,
        formatter: ({ dependentValues }) => (
          <span>
            <a
              href="javascript:;"
              onClick={() => this.deleteRows(dependentValues)}
            >
              Delete
            </a>
          </span>
        )
      }
    ];
    this._Changecolumns = [
      { key: "Timestamp", name: "Last Changed Date" },
      { key: "Description", name: "Details" },
      { key: "EditedBy", name: "Edited By" }
    ];

    this.toggleModal = this.toggleModal.bind(this);
    this.toggleModalWithoutConfirm = this.toggleModalWithoutConfirm.bind(this);
    this.activeFinder = this.activeFinder.bind(this);

    this.state = {
      taskArray: [],
      noData: false,
      modal: true,
      activeTab: "Identification",
      value: undefined,
      ParentSystemNameList: [],
      renderedTree: null,
      ChooseTemplate: null,
      EquipmentNo: "",
      AssetDetailsTitle: "",
      Manufacturer: "",
      AltManufacturerName: "",
      ModelNo: "",
      SerialNo: "",
      AssetNo: "",
      Barcode: "",
      Description: "",
      TaskName: "",
      ProductCategory: null,
      ReplacedBy: null,
      Borrowable: false,
      UtilizationCategory: null,
      AssetFiles: "",
      LoanDailyCost: 0,
      Currency: null,
      StickyNotes: "",
      EquipmentType: null,
      FirmwareRevision: "",
      HardwareVersion: "",
      Accessories: "",
      Options: "",
      SoftwareRevision: "",
      SystemParent: false,
      SystemName: "",
      SystemChild: false,
      ParentSystemName: null,
      PartOfSystemCalibration: false,
      SystemComponents: "",
      LastReportedCondition: null,
      LastUpdate: null,
      InventoryDate: null,
      CalibrationProvider: null,
      ServiceLogistics: null,
      CalibrationType: null,
      CalibrationInterval: 0,
      ServiceInterval: 0,
      ServiceCost: 0,
      RepairProvider: null,
      UseProviderCalibrationType: false,
      UseProviderCalibrationSchedule: false,
      OwnershipStatus: null,
      OwningCompany: "",
      OrderNumber: "",
      PurchasePrice: 0,
      InvoiceNumber: "",
      LifeCycleStage: null,
      Depreciation: 0,
      BookValue: 0,
      Organization: null,
      Location: null,
      Coordinator: null,
      User: null,
      CustomerId: null,
      editval: true,
      ThingName: "",
      OrderDate: null,
      CalibrationDate: null,
      ReceivedDate: null,
      LoanAutoCalculate: true,

      SysComponentList: [],
      CustomerAssetList: [],
      AssetFilesList: [],
      ChangeLog: [],
      taskDetails: [],
      showGridHeading: false
    };
    this.orgTreeData = [];
    this.locTreeData = [];
    this.renderer = null;
    this.checkAndSetLoanDailyCost = this.checkAndSetLoanDailyCost.bind(this);
    this.baseState = {
      noData: false,
      modal: true,
      activeTab: "Identification",
      value: undefined,
      Organization: undefined,
      ParentSystemNameList: [],
      Location: undefined,
      renderedTree: null,
      ChooseTemplate: null,
      EquipmentNo: "",
      Manufacturer: "",
      AltManufacturerName: "",
      ModelNo: "",
      SerialNo: "",
      AssetNo: "",
      Barcode: "",
      Description: "",
      TaskName: "",
      ProductCategory: null,
      ReplacedBy: null,
      Borrowable: false,
      UtilizationCategory: null,
      AssetFiles: "",
      LoanDailyCost: 0,
      Currency: null,
      StickyNotes: "",
      EquipmentType: null,
      FirmwareRevision: "",
      HardwareVersion: "",
      Accessories: "",
      Options: "",
      SoftwareRevision: "",
      SystemParent: false,
      SystemName: "",
      SystemChild: false,
      ParentSystemName: null,
      PartOfSystemCalibration: false,
      SystemComponents: "",
      LastReportedCondition: null,
      LastUpdate: null,
      InventoryDate: null,
      CalibrationProvider: null,
      ServiceLogistics: null,
      CalibrationType: null,
      CalibrationInterval: 0,
      ServiceInterval: 0,
      ServiceCost: 0,
      RepairProvider: null,
      UseProviderCalibrationType: false,
      UseProviderCalibrationSchedule: false,
      OwnershipStatus: null,
      OwningCompany: "",
      OrderNumber: "",
      PurchasePrice: 0,
      InvoiceNumber: "",
      LifeCycleStage: null,
      Depreciation: 0,
      BookValue: 0,
      Coordinator: null,
      User: null,
      CustomerId: "",
      editval: true,
      ThingName: "",
      OrderDate: null,
      CalibrationDate: null,
      ReceivedDate: null,
      LoanAutoCalculate: true,
      SysComponentList: [],
      CustomerAssetList: [],
      AssetFilesList: [],
      ChangeLog: [],
      taskDetails: [],
      showGridHeading: false
    };
    scheduleTasksCount = 0;
    addAssetsStore.setMode("DETAILS");
  }

  deleteRows(value) {
    request({
      method: "post",
      url: URL.deleteAssetFiles,
      data: { AssetEqNum: this.state.EquipmentNo, SeletedFile: value.name }
      // "startDate" : 1507261485588,
      // "endDate" :  1507876485588}
    }).then(resp => {
      // alert(resp.data.message);
      // alert("ModelNoList response"+resp.data.details[0].DropDownValues);
      if (resp.data.success == true) {
        var index = this.state.AssetFilesList.indexOf(value);
        if (index > -1) {
          this.state.AssetFilesList.splice(index, 1);
        }
      }
    });
  }

  validateUncheckChild() {
    // alert("test validate"+URL.validateSystemChildUncheck)
    request({
      method: "post",
      url: URL.validateSystemChildUncheck
      //data: { "Manufacturter":this.state.Manufacturer  }s
      // "startDate" : 1507261485588,
      // "endDate" :  1507876485588}
    }).then(resp => {
      // alert(resp.data.message);
      // alert("ModelNoList response"+resp.data.details[0].DropDownValues);
      if (resp.data.isValid == false) {
        <div>
          <label className="formLabels" htmlFor="validationMessage">
            {resp.message}
          </label>
        </div>;
      }
    });
  }
  SysrowGetter = i => {
    var rtn = this.state.SysComponentList;
    return rtn[i];
  };
  onOrgTreeChange = value => {
    //console.log("onOrgTreeChange", arguments, value);
    addAssetsStore.addToFieldStateFromCode({ Organization: value });
    Functions.GetAllUsersForCustomer(value, "").then(resp => {
      //console.log('GetAllUsersForCustomer', resp.data.UserList);
      addAssetsStore.setUsersForCustomer(resp.data.UserList);
    });
  };
  onLocTreeChange = value => {
    //console.log("onlocTreeChange", arguments, value);
    addAssetsStore.addToFieldStateFromCode({ Location: value });
  };
  getModelNo() {
    if (
      this.state.Manufacturer.value != null ||
      this.state.Manufacturer.value != undefined ||
      this.state.Manufacturer.value != ""
    )
      request({
        method: "post",
        url: URL.getModelNoList,
        data: { Manufacturer: this.state.Manufacturer }
        // "startDate" : 1507261485588,
        // "endDate" :  1507876485588}
      }).then(resp => {
        if (resp.data.details.length > 0) {
          // alert("ModelNoList response"+resp.data.details[0].DropDownValues);
          var optionList;
          var finallist = [];
          for (var i = 0; i < resp.data.details[0].length; i++) {
            // console.log("**Resp**", resp.data.details[0][i])
            //  var temp = finallist;
            Array.prototype.push.apply(finallist, resp.data.details[0][i]);
          }
          optionList = finallist.map(function(val) {
            return { label: val, value: val };
          });
          addAssetsStore.addToFieldStateFromCode({
            ModelNoList: optionList
          });
        }
        //alert("ManufacturerList"+this.state.ManufacturerList.length);
      });
  }

  AssetrowGetter = i => {
    var rtn = this.state.AssetFilesList;
    return rtn[i];
  };
  ServicerowGetter = i => {
    var rtn = this.state.SysComponentList;
    return rtn[i];
  };

  ChangerowGetter = i => {
    var rtn = this.state.ChangeLog;
    return rtn[i];
  };

  toggleNew() {
    function close() {
      if (self.state.modal) {
        self.setState({ modal: false });
        addAssetsStore.setAddAssetsOpen(false);
        // self.setState({ addAssetsStore.usersForCustomer: false });
        addAssetsStore.setUsersForCustomer(false);
        //clearing Asset Store
        addAssetsStore.addToFieldStateFromCode(self.baseState);
        addAssetsStore.setEntriesAssetFileList([]);
      } else {
        self.setState({ modal: true });
      }
    }
    var self = this;
    // console.log("editting", addAssetsStore.editting)
    addAssetsStore.editting
      ? UIFunctions.ShowConfirm({
          zIndex: 2000,
          title:
            "'Oops, you have some unsaved work! Press 'Yes' to discard or 'No' to continue!'",
          okText: "Yes",
          cancelText: "No",
          onOk() {
            // console.log('OK');
            // console.log("entered toggle")
            addAssetsStore.toggleAssetDetailsModal();
            addAssetsStore.setDoubleClick(false);
            addAssetsStore.setDoubleClickedUniqueID("");
            addAssetsStore.setEntriesAssetFileList([]);
            addAssetsStore.setRowData("");
            //addAssetsStore.clearAssetFileUploadList();
            // console.log("entered toggle")
            addAssetsStore.addToFieldState(self.baseState);
            addAssetsStore.dashboardClearCheck();
            addAssetsStore.setAssetFileDeleteList([]);
            // console.log("after clear", addAssetsStore.assetFileUploadList)
            close();
          },
          onCancel() {
            // console.log('Cancel');
          }
        })
      : close();
  }
  toggleModal() {
    function close() {
      var currentUrl = window.location.href;
      if (currentUrl.includes("#")) {
        var toUrl = currentUrl.split("#");
        history.pushState({}, null, toUrl[0]);
      }
      // console.log('OK');
      // console.log("entered toggle")
      addAssetsStore.toggleAssetDetailsModal();
      addAssetsStore.setDoubleClick(false);
      addAssetsStore.setDoubleClickedUniqueID("");
      addAssetsStore.setRowData("");
      addAssetsStore.setEntriesAssetFileList([]);
      addAssetsStore.addToFieldStateFromCode(self.baseState);
      addAssetsStore.dashboardClearCheck();
      //addAssetsStore.clearAssetFileUploadList();
    }
    if (scheduledTaskStore.editable) {
      var self = this;
      addAssetsStore.editting
        ? UIFunctions.ShowConfirm({
            zIndex: 2000,
            title: "Do you want to discard changes?",
            okText: "Yes",
            cancelText: "No",
            onOk() {
              close();
            },
            onCancel() {}
          })
        : close();
    } else {
      close();
    }
  }
  toggleModalWithoutConfirm() {
    addAssetsStore.toggleAssetDetailsModal();
    addAssetsStore.setDoubleClick(false);
    addAssetsStore.setDoubleClickedUniqueID("");
    addAssetsStore.dashboardClearCheck();
    addAssetsStore.addToFieldStateFromCode(this.baseState);
  }

  activeFinder(component) {
    return component === this.state.activeTab
      ? "breadcrumb-item active"
      : "breadcrumb-item";
  }

  parseTree(data, type) {
    // console.log("parse stree start", data)
    var original;
    var length;
    var duplicate;
    var location;
    if (type == "org") {
      var NewOrg = data.split(addAssetsStore.OrganizationTree[0].value); //Split based on top Node
      var test;
      if (NewOrg.length > 1)
        test = addAssetsStore.OrganizationTree[0].value + NewOrg[1];
      else test = addAssetsStore.OrganizationTree[0].value;

      original = test.split(">");
      length = original.length;
      duplicate = [];
      location = [];
      duplicate.push(test);
    } else {
      original = data.split(">");
      length = original.length;
      duplicate = [];
      location = [];
      duplicate.push(data);
    }
    for (var i = 0; i < length - 1; i++) {
      original.pop();
      duplicate.push(original.join(">").trim());
    }
    location = duplicate.reverse();
    return location;
  }
  parseAndMakeForForm(json) {
    var rtn = json;
    var loc = this.parseTree(rtn.Location, "loc");
    var org = this.parseTree(rtn.Organization, "org");
    rtn.Location = loc;
    rtn.Organization = org;
    var IntegerFields = addAssetsStore.IntegerFields;
    for (var fields of IntegerFields) {
      if (rtn[fields] && rtn[fields] == -999999) {
        rtn[fields] = "";
      }
    }
    for (var currentPicker of dates) {
      if (rtn[currentPicker]) {
        // console.log("item", currentPicker, rtn[currentPicker]);
        rtn[currentPicker] = moment(rtn[currentPicker]);
      }
    }

    return rtn;
  }

  componentDidMount() {
    addAssetsStore.setEditting(false);
    addAssetsStore.setSubmitting(false);
    var self = this;
    tabModelStore.setAssetDetails({});
    scheduledTaskStore.setEditable(false);
    var uniqId =
      addAssetsStore.doubleClickedUniqueID != ""
        ? addAssetsStore.doubleClickedUniqueID
        : addAssetsStore.dashboardChecked[0]; //TODO: Get actual value

    var pageTitle = addAssetsStore.rowData
      ? JSON.parse(addAssetsStore.rowData).EquipmentNo
      : addAssetsStore.rowArrayData[0].EquipmentNo;
    //this.setState({ EquipmentNo: pageTitle });
    this.setState({ AssetDetailsTitle: pageTitle });
      this.baseState.EquipmentNo = pageTitle;
      var newId = uniqId.split(/_(.+)/)[0];
      /* new code ends here */
     userStore.userDetails.CustomerId == "" ?
      addAssetsStore.getAllApi("CreateAsset", newId):''      
      /* new code ends here */
      Functions.fetchAssetDetailsValues(uniqId).then(resp => {
        var values = resp.data.AssetDetails;
        //setting the data to server variable
        serverData = resp.data.ScheduledTasks.data;
        //checking the serverdata is coming from server or not
        //As using it for both create as well as View || Edit
        if (serverData.length > 0) {
          // changing the date format of the Server Data
          scheduleTasksCount = serverData.length;
          for (var i = 0; i < serverData.length; i++) {
            serverData[i].DueDate = moment(serverData[i].DueDate);
          }
        }
        //setting the Server Data to the Loacl State Array
        this.setState({ taskArray: serverData });

        tabModelStore.setAssetDetails(resp.data.AssetDetails);
        values.data.SystemName2 = values.data.SystemName;
        values.data.SystemParent2 = values.data.SystemParent;
        addAssetsStore.addToFieldStateFromCode(values.data);
        addAssetsStore.addToFieldStateFromCode({
          ThingName: resp.data.AssetDetails.data.thingName
        });
        // console.log("this.state", self.state)
        addAssetsStore.clearEntriesAssetFileList();

        //  Functions.GetScheduledTasks(resp.data.data.thingName).then(response => {
        //  scheduledTaskStore.setScheduledTasks(JSON.stringify(response.data.data));
        //addAssetsStore.addToFieldStateFromCode({ taskDetails: response.data.data });
        // Functions.GetSystemComponents(resp.data.data.SystemName, resp.data.data.SystemParent).then((resp) => {
        // console.log(resp.data.rows[0].result)
        // if (resp.data.success)
        addAssetsStore.addToFieldStateFromCode({
          SysComponentList: resp.data.SystemComponents.SystemComponents
        });
        addAssetsStore.setSystemComponents(
          resp.data.SystemComponents.SystemComponents
        );
        // var state = self.state;
        // console.log("fieldState", addAssetsStore.fieldState);
        for (var j = 0; j < dates.length; j++) {
          var date = dates[j];
          if (addAssetsStore.fieldState[date] === "1970-01-01T00:00:00.000Z")
            addAssetsStore.fieldState[date] = null;
        }

        // Functions.GetAssetFiles(uniqId).then((resp) => {
        var x = JSON.parse(values.data.History);
        x.forEach(item => {
          item.Timestamp = moment(item.Timestamp).format("YYYY-MM-DD HH:mm:ss");
        });
        addAssetsStore.addToFieldStateFromCode({ ChangeLog: x });
        // console.log(resp.data.data)
        addAssetsStore.setAssetFileUploadList([]);
        if (resp.data.AssetFiles.data) {
          var dataVal = resp.data.AssetFiles.data;
          var temprows = [];
          for (var k = 0; k < dataVal.length; k++) {
            temprows.push({
              downloadLink: dataVal[k].downloadLink,
              name: dataVal[k].name,
              lastModifiedDate: moment(dataVal[k].lastModifiedDate).format(
                "YYYY-MM-DD HH:mm:ss"
              )
            });
            addAssetsStore.addToFieldState({ AssetFilesList: temprows });
            addAssetsStore.setAssetFileUploadList(temprows);
          }
        }

        // Functions.GetCustomerAssets(customerId) .then((resp) => {
        // var assets = resp.data.CustomerAssets.data;
        // var lastAsset = assets[+assets.length - 1];
        // addAssetsStore.setCustomerAssets(resp.data.CustomerAssets.data);
        self.state.CustomerAssetList = addAssetsStore.getCustomerAssets;

        // addAssetsStore.setLastAsset(lastAsset);
        //  Functions.GetLicenseInfo(uniqId).then((resp) => {
        addAssetsStore.addToFieldStateFromCode({
          Licences: resp.data.License.License
        });
        // Functions.GetAllUsersForCustomer(addAssetsStore.fieldState.Organization, "").then((resp) => {
        addAssetsStore.setUsersForCustomer(
          resp.data.AllUsersForCustomer.UserList
        );
        //  Functions.GetServiceHistory(uniqId).then((resp) => {
        addAssetsStore.setServiceHistory(resp.data.ServiceHistory.data);
        //addAssetsStore.setO(resp.data.ServiceHistory.data);
        var data = _.cloneDeep(addAssetsStore.fieldState);
        this.props.form.setFieldsValue(this.parseAndMakeForForm(data));
        self.formLoaded = true;
      });
    // });
  }

  checkAndSetLoanDailyCost() {
    var LoanDailyCost = 0;
    var BookValue = addAssetsStore.fieldState.BookValue
      ? addAssetsStore.fieldState.BookValue
      : 0;
    var LoanDailyRate = addAssetsStore.fieldState.LoanDailyRate
      ? addAssetsStore.fieldState.LoanDailyRate
      : 0;
    var LoanAutoCalculate = addAssetsStore.fieldState.LoanAutoCalculate
      ? addAssetsStore.fieldState.LoanAutoCalculate
      : false;
    LoanDailyCost =
      BookValue < 0 || LoanDailyRate < 0 || BookValue * LoanDailyRate / 100 < 0
        ? -999999
        : BookValue * LoanDailyRate / 100;
    if (LoanAutoCalculate) {
      addAssetsStore.addToFieldState({ LoanDailyCost });
      if (LoanDailyCost >= 0) this.props.form.setFieldsValue({ LoanDailyCost });
      else this.props.form.setFieldsValue({ LoanDailyCost: "" });
    }
  }
  add = () => {
    scheduleTasksCount++;
    let taskArray = this.state.taskArray;
    let item = {};
    item["Description"] = "";
    item["TaskName"] = "";
    item["Interval"] = null;
    item["Id"] = "";
    item["isExisting"] = false;
    item["DueDate"] = "";
    item["Action"] = "ADD";
    // item["ThingName"] = "1_10000032";
    taskArray.push(item);
    this.setState({ taskArray });
  };
  addToExisting = data => {
    scheduleTasksCount++;
    let taskArray = this.state.taskArray;
    let item = {};
    item["TaskName"] = data.TaskName;
    item["Description"] = data.Description;
    item["Interval"] = data.Interval;
    item["Id"] = "";
    item["isExisting"] = true;
    item["DueDate"] = data.DueDate;
    item["Action"] = "ADD";
    taskArray.push(item);
    this.setState({ taskArray });
    setTimeout(() => {
      this.props.form.setFieldsValue({ taskArray });
    }, 500);
    //  this.add();
  };
  //it hides the array element from the array with setting action to "Delete"
  remove = k => {
    scheduleTasksCount--;
    let newkeys = [];
    this.state.taskArray.map((item, index) => {
      let obj = item;
      if (index == k) {
        obj["Action"] = "DELETE";
      }
      newkeys.push(obj);
    });
    this.setState({ taskArray: newkeys });
  };
  //it checks the the server data has chnaged are not if yes, changes action from "Details" to "Edit"
  //then it sets the fiels value to array
  getArray = () => {
    let values = this.props.form.getFieldValue("taskArray");
    if (values != undefined) {
      if (this.state.taskArray.length > 0) {
        let newkeys = [];
        this.state.taskArray.map((item, index) => {
          let obj = item;
          if (
            obj["Action"] === "DETAILS" &&
            (obj["Description"] !== values[index].Description ||
              obj["TaskName"] !== values[index].TaskName ||
              obj["DueDate"] !== values[index].DueDate ||
              obj["Interval"] !== values[index].Interval)
          ) {
            obj["Action"] = "EDIT";
          }
          obj["Description"] =
            values[index] == undefined
              ? obj["Description"]
              : //using regex  == to remove space bewteen words and trim to remove space between start and end
                values[index].Description.replace(/\s\s+/g, " ").trim();
          obj["DueDate"] =
            values[index] == undefined ? obj["DueDate"] : values[index].DueDate;
          obj["TaskName"] =
            values[index] == undefined
              ? obj["TaskName"]
              : values[index].TaskName;
          obj["Interval"] =
            values[index] == undefined
              ? obj["Interval"]
              : values[index].Interval;
          newkeys.push(obj);
        });
        this.setState({ taskArray: newkeys });
      }
    }
  };
  saveAsset() {
    this.props.form.validateFieldsAndScroll(err => {
      let changed = [];
      if (!err) {
        if (addAssetsStore.maintenanceTaskInput == "unsave") {
          UIFunctions.ShowConfirm({
            zIndex: 2000,
            title: "You have unsaved Maintenance Task.Do you want to continue?",
            okText: "Yes",
            cancelText: "No",
            onOk() {
              addAssetsStore.maintenanceTaskInput = "save";
              close();
            },
            onCancel() {
              return;
            }
          });
        }
        if (addAssetsStore.maintenanceTaskInput !== "unsave") {
          addAssetsStore.maintenanceTaskInput = "save";
          this.getArray();
          let result = this.state.taskArray.slice();
          changed = result.map(item => {
            let obj = item;      
            if (obj.Action == "DELETE" && obj.Id == "") {
              return;
            }
            return item;
          });
          let finalArray = changed.filter(k => k != undefined);  
          for (var i = 0; i < finalArray.length; i++) {
            finalArray[i].DueDate = moment(finalArray[i].DueDate).toISOString();
          }
          addAssetsStore.addToFieldState({ taskArray: finalArray });    
          addAssetsStore.setSubmitting(true);
          this.saveToServer();
        }
      }
    });
  }
  saveToServer() {
    var payload = JSON.parse(JSON.stringify(addAssetsStore.fieldState));
    if (Array.isArray(payload.Organization)) {
      payload.Organization =
        payload.Organization[payload.Organization.length - 1];
    }
    if (Array.isArray(payload.Location)) {
      payload.Location = payload.Location[payload.Location.length - 1];
    }
    if (payload.SystemParent == false) {
      payload.SystemName = "";
    }
    if (payload.SystemChild == false) {
      payload.ParentSystemName = "";
    }
    // console.log("payload", payload)

    if (!payload.ModelNo.replace(/\s/g, "").length || !payload.Manufacturer.replace(/\s/g, "").length || !payload.SerialNo.replace(/\s/g, "").length) {
			UIFunctions.ShowError({
				zIndex: 2000,
				title: "Please Fill All The Mandatory Fields"
      });
      addAssetsStore.setSubmitting(false);
			return;
    }
    else{
      Functions.EditAsset({ Input: payload })
      .then(response => {
        addAssetsStore.setSubmitting(false);
        var EqNum = addAssetsStore.fieldState.ThingName;
        // console.log("response" + response);
        if (response.data.success == true) {
          // console.log("resp.data" + response.data.success);

          this.toggleModalWithoutConfirm();
          tabModelStore.reRenderGrid();
          // console.log("EqNum", EqNum)
          addAssetsStore.entriesAssetFileList.forEach(item => {
            var r = new FileReader();
            var data = item.originFileObj;
            r.onload = function() {
              Functions.UploadFileForAsset(
                EqNum.split("_")[1],
                item.name,
                r.result
              );
            };
            r.readAsDataURL(data);
            addAssetsStore.setAssetFileUploadList([]);
          });
          UIFunctions.Toast(response.data.message, "success");
          addAssetsStore.dashboardClearCheck();
        } else {
          UIFunctions.Toast(response.data.message, "error");
        }
        if (addAssetsStore.assetFileDeleteList.length != 0) {
          Functions.DeleteUploadedFiles(
            EqNum.split("_")[1],
            addAssetsStore.assetFileDeleteList
          );
          addAssetsStore.setAssetFileDeleteList([]);
        }
      })
      .catch(() => {
        addAssetsStore.setSubmitting(false);

        UIFunctions.Toast("Error", "error");
      });
    }
  }
  componentWillUnmount() {
    addAssetsStore.clearFieldState();
  }
  dateParsingFn(dateToFormat) {
    let defaultDate = "02-08-1991";
    if (dateToFormat != undefined)
      defaultDate = new Date(dateToFormat).toLocaleString().split(",")[0];
    return defaultDate;
  }

  changeDateFormat(dateToFormat) {
    var inputDate = new Date(dateToFormat);
    var year = inputDate.getFullYear();

    var month = (1 + inputDate.getMonth()).toString();
    month = month.length > 1 ? month : "0" + month;
    var day = inputDate.getDate().toString();
    day = day.length > 1 ? day : "0" + day;
    return month + "-" + day + "-" + year;
  }
  /*********** Functions for SchedulingTask START *******/
  addTaskFunction() {
    let newTaskDetails = scheduledTaskStore.scheduledTasks.slice();
    let ipRange = {};
    ipRange["Description"] = "";
    ipRange["TaskName"] = "";
    ipRange["Status"] = "";
    ipRange["Interval"] = 0;
    ipRange["isNew"] = true;
    ipRange["dataAdded"] = false;

    newTaskDetails.push(ipRange);

    scheduledTaskStore.setScheduledTasks(JSON.stringify(newTaskDetails));
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll(err => {
      if (!err) {
        this.saveAsset();
      }
    });
  };
  saveTaskRange(id, taskname, description, status, interval, clickState) {
    let newTaskDetails = scheduledTaskStore.scheduledTasks.slice();
    let ipRange = newTaskDetails[id];
    ipRange.Description = description;
    ipRange.TaskName = taskname;
    ipRange.Status = status;
    ipRange.Interval = interval;
    ipRange.dataAdded = clickState;
    ipRange.isNew = clickState;
    newTaskDetails.push(ipRange);
    scheduledTaskStore.setScheduledTasks(JSON.stringify(newTaskDetails));
  }

  removeTaskRange(id) {
    let newTaskDetails = scheduledTaskStore.scheduledTasks.slice();
    newTaskDetails.splice(id, 1);
    scheduledTaskStore.setScheduledTasks(JSON.stringify(newTaskDetails));
  }

  /*********** Functions for SchedulingTask End *******/
  _handleWaypointLeave() {
    // console.log("Le")
  }
  setScrollState(obj) {
    setTimeout(() => {
      this.setState(obj);
    }, 10);
  }
  handleEditBtn = () => {
    addAssetsStore.setMode("EDIT");
    setTimeout(() => {
      this.setState({ editval: false });
    }, 500);
    addAssetsStore.getAllApi("edit");
    scheduledTaskStore.setEditable(true);
  };

  render() {
    const disabledStyles = addAssetsStore.submitting
      ? {
          cursor: "not-allowed",
          background: "rgba(204,208,216,0.4)",
          borderColor: "rgba(204,208,216,0.2)"
        }
      : {};
    // const formItemLayout = {
    //   labelCol: {
    //     xs: { span: 50 },
    //     sm: { span: 50 },
    //   },
    //   wrapperCol: {
    //     xs: { span: 50 },
    //     sm: { span: 50 },
    //   },
    // };
    // var uniqId = addAssetsStore.doubleClickedUniqueID != "" ? addAssetsStore.doubleClickedUniqueID : addAssetsStore.dashboardChecked[0];//TODO: Get actual value
    // console.log("doubleClick", uniqId)

    // console.log("Book value date String" + this.state.BookValueDate);
    //console.log("Book value date" + new Date(this.state.BookValueDate))
    // const { size } = this.state;
    // console.log("this.state", this.state)
    return (
      <Form onSubmit={this.handleSubmit} autoComplete="off">
        <Modal
          style={{ maxWidth: "1000px" }}
          isOpen={addAssetsStore.assetDetailModalOpen}
          className="modal-dialog modal-lg"
          id="createAssetModal"
        >
          {tabModelStore.assetDetails.data && addAssetsStore.lastAsset ? (
            <div>
              <ModalHeader
                className="row modalHeader"
                style={{ borderBottom: "1px solid #ccd0d8" }}
              >
                {this.state.editval ? (
                  <span className="createAssetLabel">
                    {" "}
                    Asset Details-
                    {this.state.AssetDetailsTitle}
                  </span>
                ) : (
                  <span className="createAssetLabel">
                    {" "}
                    Edit Asset-
                    {this.state.AssetDetailsTitle}
                  </span>
                )}
                <span
                  onClick={addAssetsStore.submitting ? "" : this.toggleModal}
                  style={{ cursor: "pointer" }}
                >
                  <i className="icon-close" />
                </span>
              </ModalHeader>
              <ModalBody
                style={{ paddingLeft: 0, paddingRight: 0, paddingBottom: 0 }}
              >
                <nav className="breadcrumb" id="createAssetNav">
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Identification" });
                    }}
                    className={this.activeFinder("Identification")}
                    href="#Identification"
                  >
                    Identification
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Configuration" });
                    }}
                    className={this.activeFinder("Configuration")}
                    href="#Configuration"
                  >
                    Configuration
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Attachments" });
                    }}
                    className={this.activeFinder("Attachments")}
                    href="#Attachments"
                  >
                    Attachments
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "SystemIntegration" });
                    }}
                    className={this.activeFinder("SystemIntegration")}
                    href="#SystemIntegration"
                  >
                    System Integration
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Services" });
                    }}
                    className={this.activeFinder("Services")}
                    href="#Services"
                  >
                    Service
                  </a>
                  {addAssetsStore.mode == "DETAILS" ? (
                    <a
                      onClick={() => {
                        this.setScrollState({ activeTab: "History" });
                      }}
                      className={this.activeFinder("History")}
                      href="#History"
                    >
                      History
                    </a>
                  ) : (
                    ""
                  )}
                  <a
                    onClick={() => {
                      this.setScrollState({
                        activeTab: "OrderingAndRecieving"
                      });
                    }}
                    className={this.activeFinder("OrderingAndRecieving")}
                    href="#OrderingAndRecieving"
                  >
                    Ordering & Receiving
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Valuation" });
                    }}
                    className={this.activeFinder("Valuation")}
                    href="#Valuation"
                  >
                    Valuation
                  </a>
                  <a
                    onClick={() => {
                      this.setScrollState({ activeTab: "Inventory" });
                    }}
                    className={this.activeFinder("Inventory")}
                    href="#Inventory"
                  >
                    Inventory
                  </a>
                </nav>
                <div
                  className="addAssetBody"
                  style={{ paddingLeft: 25, height: window.innerHeight - 210 }}
                >
                  {/*'IDENTIFICATION' */}
                  <div id="Identification">
                    <fieldset className="fieldsetHeading">
                      <legend>Identification </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "Identification" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    {this.state.editval ? (
                      <Identification
                        {...this.props}
                        mode="EDIT"
                        checkAndSetLoanDailyCost={this.checkAndSetLoanDailyCost}
                      />
                    ) : (
                      <Identification
                        {...this.props}
                        mode="DETAILS"
                        checkAndSetLoanDailyCost={this.checkAndSetLoanDailyCost}
                      />
                    )}
                  </div>
                  <br />
                  {/* 'Configuration' */}
                  <div id="Configuration">
                    <fieldset className="fieldsetHeading">
                      <legend> Configuration</legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "Configuration" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    {this.state.editval ? (
                      <Configuration {...this.props} mode="EDIT" />
                    ) : (
                      <Configuration {...this.props} mode="DETAILS" />
                    )}
                  </div>
                  {/* 'Attachments' */}
                  <div id="Attachments">
                    <fieldset className="fieldsetHeading">
                      <legend> Attachments</legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "Attachments" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    {this.state.editval ? (
                      <Attachments {...this.props} mode="EDIT" />
                    ) : (
                      /* <div></div> :<div></div>}*/
                      <Attachments {...this.props} mode="DETAILS" />
                    )}
                  </div>
                  {/*'system Integration' */}
                  <div id="SystemIntegration">
                    <fieldset className="fieldsetHeading">
                      <legend>System Integration </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() =>
                        this.setState({ activeTab: "SystemIntegration" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    {this.state.editval ? (
                      <SystemIntegration {...this.props} mode="EDIT" />
                    ) : (
                      <SystemIntegration {...this.props} mode="DETAILS" />
                    )}
                  </div>
                  {/*'service' */}
                  <div id="Services">
                    <fieldset className="fieldsetHeading">
                      <legend>Service </legend>
                    </fieldset>
                    <Waypoint
                      onEnter={() => this.setState({ activeTab: "Services" })}
                      onLeave={this._handleWaypointLeave}
                    />
                    {this.state.editval ? (
                      <Services {...this.props} mode="EDIT" />
                    ) : (
                      <Services {...this.props} mode="DETAILS" />
                    )}
                  </div>
                  {/*<div style={{ marginBottom: 20 }}>
                {this.state.editval ? '' : <Button className='addTaskMain' onClick={this.addTaskFunction.bind(this)} href='javaScript: void(0)'>Add Task</Button>}
                <div className='gridRow gridRowHeading'>
                  <div className='gridCol'>Description</div>
                  <div className='gridCol'>Due date</div>
                  <div className='gridCol'>Interval</div>
                  <div className='gridCol'>Action</div>
                </div>
                {
                  scheduledTaskStore.scheduledTasks.map((tasks, key) => {
                    return <SchedulingTask key={tasks.Id} index={tasks.Id} tasks={tasks} editVal={this.state.editval} saveTaskRange={this.saveTaskRange.bind(this)} removeTaskRange={this.removeTaskRange.bind(this)} addTaskRange={this.addTaskFunction.bind(this)} totalTask={this.state.taskDetails.length} />
                  })
                }
              </div><br />*/}
                  <div
                    className="gridCol"
                    style={{ marginBottom: "6px", color: "grey" }}
                  >
                    Maintenance Tasks:
                  </div>

                  <div>
                    {scheduleTasksCount < 1 ? (
                      <div>
                        <p
                          className="scheduleTask_p"
                          style={{ textAlign: "center" }}
                        >
                          {" "}
                          No Maintenance Tasks Added Yet
                        </p>
                      </div>
                    ) : (
                      <div className="scheduleTaskDetails">
                        <ScheduleTasks
                          {...this.props}
                          edit={!(addAssetsStore.mode == "DETAILS")}
                          addToExisting={this.addToExisting}
                          add={this.add}
                          taskArray={this.state.taskArray}
                          remove={this.remove}
                          disabled={addAssetsStore.mode == "DETAILS"}
                        />
                      </div>
                    )}
                    {addAssetsStore.mode == "DETAILS" ? "" : <hr />}

                    {addAssetsStore.mode == "DETAILS" ? (
                      ""
                    ) : (
                      <ScheduleTaskDetails
                        {...this.props}
                        edit={!(addAssetsStore.mode == "DETAILS")}
                        taskArray={this.state.taskArray}
                        addToExisting={this.addToExisting}
                        add={this.add}
                        remove={this.remove}
                        disabled={addAssetsStore.mode == "DETAILS"}
                      />
                    )}
                    <br />

                    {addAssetsStore.mode == "DETAILS" ? (
                      <div id="History">
                        <fieldset className="fieldsetHeading">
                          <legend> History</legend>
                        </fieldset>
                        <Waypoint
                          onEnter={() =>
                            this.setState({ activeTab: "History" })}
                          onLeave={this._handleWaypointLeave}
                        />
                        {this.state.editval ? (
                          <History {...this.props} mode="EDIT" />
                        ) : (
                          <History {...this.props} mode="DETAILS" />
                        )}
                      </div>
                    ) : (
                      ""
                    )}

                    {/*'Order Recieve' */}
                    <div id="OrderingAndRecieving">
                      <fieldset className="fieldsetHeading">
                        <legend>Ordering & Receiving</legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() =>
                          this.setState({ activeTab: "OrderingAndRecieving" })}
                        onLeave={this._handleWaypointLeave}
                      />
                      {this.state.editval ? (
                        <OrderingAndRecieving {...this.props} mode="EDIT" />
                      ) : (
                        <OrderingAndRecieving {...this.props} mode="DETAILS" />
                      )}
                    </div>
                    <div id="Valuation">
                      <fieldset className="fieldsetHeading">
                        <legend>Valuation </legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() =>
                          this.setState({ activeTab: "Valuation" })}
                        onLeave={this._handleWaypointLeave}
                      />
                      {this.state.editval ? (
                        <Valuation
                          {...this.props}
                          mode="EDIT"
                          checkAndSetLoanDailyCost={
                            this.checkAndSetLoanDailyCost
                          }
                        />
                      ) : (
                        <Valuation
                          {...this.props}
                          mode="DETAILS"
                          checkAndSetLoanDailyCost={
                            this.checkAndSetLoanDailyCost
                          }
                        />
                      )}
                    </div>
                    {/*ËœËœËœËœËœËœËœËœËœËœËœËœËœËœËœ 'Inventory' ËœËœËœËœËœËœËœËœËœËœËœËœËœËœËœ*/}
                    <div id="Inventory">
                      <fieldset className="fieldsetHeading">
                        <legend>Inventory </legend>
                      </fieldset>
                      <Waypoint
                        onEnter={() =>
                          this.setState({ activeTab: "Inventory" })}
                        onLeave={this._handleWaypointLeave}
                      />
                      {this.state.editval ? (
                        <Inventory {...this.props} mode="EDIT" />
                      ) : (
                        <Inventory {...this.props} mode="DETAILS" />
                      )}
                    </div>
                  </div>
                </div>
              </ModalBody>
              <ModalFooter>
                {/* 'Create Asset Fixed Footer' */}
                <nav className="modalFooter navbar" style={{ padding: 10 }}>
                  {/* 'Footer Buttons' */}
                  <div
                    className="modalFooterBtnGroup"
                    id="createAssetFooterButtons"
                  >
                    {this.state.editval &&
                    permissionStore.permissions.icons.CreateAsset ? (
                      <button
                        type="button"
                        className="aaSmallBtn btn btn-primary btn-sm"
                        disabled={
                          !permissionStore.permissions.icons.CreateAsset
                        }
                        onClick={this.handleEditBtn}
                        id="submitBtn"
                      >
                        Edit Asset
                      </button>
                    ) : (
                      ""
                    )}

                    {!this.state.editval ? (
                      <Button
                        type="Button"
                        loading={addAssetsStore.submitting}
                        className="aaSmallBtn btn btn-primary btn-sm"
                        onClick={this.saveAsset.bind(this)}
                        id="submitBtn"
                        htmlType="submit"
                        style={{ marginRight: "10px" }}
                      >
                        Save Asset
                      </Button>
                    ) : (
                      ""
                    )}

                    <Button
                      disabled={addAssetsStore.submitting}
                      style={disabledStyles}
                      type="button"
                      onClick={this.toggleModal}
                      className="aaSmallBtn btn btn-primary btn-sm"
                    >
                      Close
                    </Button>
                  </div>
                </nav>
              </ModalFooter>
            </div>
          ) : this.state.noData ? (
            <div>
              <ModalHeader>No Data Found</ModalHeader>
              <ModalFooter>
                <div
                  className="modalFooterBtnGroup"
                  id="createAssetFooterButtons"
                >
                  <button
                    type="button"
                    onClick={this.toggleModal}
                    Asset
                    className="aaSmallBtn btn btn-primary btn-sm"
                  >
                    Close
                  </button>
                </div>
              </ModalFooter>
            </div>
          ) : (
            <div>
              <ModalHeader
                className="row modalHeader"
                style={{ borderBottom: "1px solid #ccd0d8" }}
              >
                <span className="createAssetLabel">
                  Asset Details-
                  {this.state.AssetDetailsTitle}
                </span>
                <span
                  onClick={addAssetsStore.submitting ? "" : this.toggleModal}
                  style={{ cursor: "pointer" }}
                >
                  <i className="icon-close" />
                </span>
              </ModalHeader>
              <Card loading>Whatever content</Card>
            </div>
          )}
        </Modal>
      </Form>
    );
  }
}

const WrappedRegistrationForm = Form.create()(AssetDetails);

export default WrappedRegistrationForm;
