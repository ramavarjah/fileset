import React from "react";
import moment from "moment";
import addAssetsStore from "./../../stores/addAssetsStore";
import { Form, Input, Icon, DatePicker } from "antd";
import PropTypes from "prop-types";
const FormItem = Form.Item;
var dueDateValidation = false;

export default class ScheduleTaskDetails extends React.Component {
    constructor() {
        super();
        this.state = {
            TaskName: "",
            Description: "",
            DueDate: "",
            Interval: "",
            errors: {
                TaskName: "",
                Description: "",
                DueDate: "",
                Interval: ""
            }
        };
    }

  onChange = e => {
      if (moment.isMoment(e)) {
          dueDateValidation = true;
          this.setState({ DueDate: e });
      } else if (e == null) {
          dueDateValidation = false;
          this.setState({ DueDate: "" });
      } else {
          this.setState({ [e.target.name]: e.target.value });
      }
      var TaskName = document.getElementsByName("TaskName")[0].value;
      var Description = document.getElementsByName("Description")[0].value;
      var Interval = document.getElementsByName("Interval")[0].value;

      var maintenanceTaskInput = false;
      if (
          TaskName.length == 0 &&
      Description.length == 0 &&
      Interval.length == 0 &&
      dueDateValidation == false
      ) {
          maintenanceTaskInput = true;
      }
      if (!maintenanceTaskInput) {
          addAssetsStore.setMaintenanceTaskInput("unsave");
      } else {
          addAssetsStore.setMaintenanceTaskInput("save");
      }
  };

  add = e => {
      e.preventDefault();
      const { TaskName, Description, Interval, DueDate } = this.state;
      //manual error handling
      let errors = {};
      if (TaskName == "") errors["TaskName"] = "error";
      if (Description == "") errors["Description"] = "error";
      if (Interval == "") errors["Interval"] = "error";
      if (isNaN(Interval)) errors["Interval"] = "error";
      if (DueDate == "") errors["DueDate"] = "error";
      // break if errors are there
      if (Object.keys(errors).length > 0) return this.setState({ errors });

      var taskName = TaskName;
      var description = Description;
      var interval = Interval;
      var dueDate = DueDate;

      var task = {};
      task.TaskName = taskName;
      task.Description = description;
      task.Interval = interval;
      task.DueDate = dueDate;
      task.isExisting = true;
      this.props.addToExisting(task);
      this.setState({
          TaskName: "",
          Description: "",
          DueDate: "",
          Interval: "",
          errors: {
              TaskName: "",
              Description: "",
              DueDate: "",
              Interval: ""
          }
      });
      addAssetsStore.setMaintenanceTaskInput("save");
  };

  formItems() {
      const { errors } = this.state;
      return (
          <div
              className="gridRowNew"
              style={{
                  marginBottom: 0,
                  padding: "5px 10px 5px 10px",
                  borderLeftWidth: 0,
                  borderRightWidth: 0
              }}
          >
              <div className="gridColNew">
                  <FormItem
                      validateStatus={errors.TaskName}
                      help={errors.TaskName ? "Please Enter Task Name" : ""}
                  >
                      <Input
                          className="textInputScheduleNew"
                          name="TaskName"
                          value={this.state.TaskName}
                          onChange={this.onChange}
                          placeholder="Task Name..."
                          autosize={{ minRows: 2 }}
                          disabled={this.props.disabled}
                      />
                  </FormItem>
              </div>
              <div className="gridColNew" style={{ width: 300 }}>
                  <FormItem
                      validateStatus={errors.Description}
                      help={errors.Description ? "Please Enter Description" : ""}
                  >
                      <Input
                          className="textInputScheduleNew"
                          name="Description"
                          value={this.state.Description}
                          onChange={this.onChange}
                          placeholder="Description..."
                          autosize={{ minRows: 2 }}
                          disabled={this.props.disabled}
                      />
                  </FormItem>
              </div>
              <div className="gridColNew" style={{ marginBottom: 5 }}>
                  <FormItem
                      className="textInputScheduleNew"
                      validateStatus={errors.DueDate}
                      help={errors.DueDate ? "Please Select DueDate" : ""}
                  >
                      <DatePicker
                          style={{
                              borderColor: "transparent"
                          }}
                          className="textInputScheduleNew"
                          id="DueDate"
                          name="DueDate"
                          value={this.state.DueDate}
                          onChange={this.onChange}
                          disabled={this.props.disabled}
                          format="MM/DD/YYYY"
                          placeholder="First Due Date"
                      />
                  </FormItem>
              </div>

              <div className="gridColNew" style={{ width: 160 }}>
                  <FormItem
                      validateStatus={errors.Interval}
                      help={errors.Interval ? "Please Enter Integer" : ""}
                  >
                      <Input
                          placeholder="Task Interval(Months) "
                          name="Interval"
                          value={this.state.Interval}
                          onChange={this.onChange}
                          className="textInputScheduleNew"
                          min={1}
                          disabled={this.props.disabled}
                      />
                  </FormItem>
              </div>

              <FormItem>
                  <span
                      style={{ cursor: "pointer", fontSize: 15 }}
                      onClick={this.add.bind(this)}
                  >
                      <Icon
                          type="plus-circle-o"
                          style={{
                              width: "8%",
                              marginLeft: 10,
                              height: 25,
                              color: "#448fff"
                          }}
                      />
                  </span>
              </FormItem>
          </div>
      );
  }
  render() {
      return <div className="App">{this.formItems()}</div>;
  }
}

ScheduleTaskDetails.propTypes = {
    addToExisting: PropTypes.func,
    disabled: PropTypes.bool
};
