import { observable, action, computed } from "mobx";
import GREY from "../../assets/images/health_icons/grey_dot.svg";
import health_green from "../../assets/images/health_icons/green_dot.svg";
import health_green_fade from "../../assets/images/health_icons/green_dot_fade.svg";
import health_red from "../../assets/images/health_icons/red_dot.svg";
import health_red_fade from "../../assets/images/health_icons/red_dot_fade.svg";
import health_yellow from "../../assets/images/health_icons/yellow_dot.svg";
import health_yellow_fade from "../../assets/images/health_icons/yellow_dot_fade.svg";
import {} from "react-data-grid-addons";
import moment from "moment";
import HealthCellRenderer from "../views/Dashboard/ag/HealthCellRenderer";
import Functions from "../api/Functions";
import _ from "lodash";
import dateArray from "moment-array-dates";
import permissionStore from "./permissionStore";
import addAssetsStore from "./addAssetsStore";
import UIFunctions from "../helpers/UIFunctions";
import mobx from "mobx";
import React from "react";

class TabModelStore {
  @observable
  tabs;
  models = [];

  //pagination stuffs
  @observable
  currentPage;
  @observable
  currentDensity;
  @observable
  tabCheck;
  @observable
  curentStartingItem;
  @observable
  curentLimit;
  @observable
  hideHeader;
  @observable
  isAssetListView;
  @observable
  isChartView;
  @observable
  isVisible;
  @observable
  showToolTip;
  //current screen table data json
  @observable
  currentScreenData;
  @observable
  currentScreenDataArray;
  @observable
  currentScreenDataArrayLength;
  @observable
  currentScreenDataLoading;
  @observable
  currentTabColoumns;
  @observable
  currentTabColoumnsArray;
  @observable
  activeTab;
  @observable
  dataLoaded;
  @observable
  chartConfig;
  @observable
  getDataContext;
  @observable
  assetDetails;
  @observable
  datacontext;
  @observable
  datacontextState;
  @observable
  datacontextStartDate;
  @observable
  datacontextEndDate;
  @observable
  errMessage;
  @observable
  filterModalOpen;
  @observable
  preset;
  @observable
  tabStartDate;
  @observable
  tabEndDate;
  @observable
  activeCategoryId;
  @observable
  chartId;
  @observable
  chartLoading;

  @observable
  serviceStartDate;
  @observable
  serviceEndDate;
  @observable
  serviceColumns;
  @observable
  serviceDataArray;
  @observable
  serviceLoading;
  @observable
  gridOptions;
  @observable
  workingHours;
  @observable
  trendPreset;
  @observable
  trendBucketType;
  @observable
  errorsList;
  @observable
  warningsList;
  @observable
  errorNWarningslistsLoaded;
  @observable
  chartBucketType;
  @observable
  trendLoadingMask;
  @observable
  loanPoolNotificationCount;
  @observable
  IssueLogNotificationCount;
  @observable
  ServiceRequestNotificationCount;
  @observable
  OOTNotificationCount;

  @observable
  isHealthVsTime;
  @observable
  buttonLoading;
  @observable
  createButtonLoading;
  @observable
  remaneButtonLoading;
  @observable
  previousChartConfig;
  @observable
  backButtonVisibility;
  @observable
  onChartActive;
  @observable
  onTabActive;

  constructor() {
    this.onChartActive = false;
    this.onTabActive = false;
    this.isAssetListView = true;
    this.isChartView = false;
    this.isVisible = false;
    this.showToolTip = true;
    this.hideHeader = false;
    this.isHealthVsTime = false;
    this.filterModalOpen = false;
    this.datacontext = {};
    this.datacontextState = "step1";
    this.datacontextStartDate = moment()
      .startOf("day")
      .toISOString();
    this.datacontextEndDate = moment()
      .endOf("day")
      .toISOString();
    this.models = [];
    this.tabs = null;
    this.currentPage = 1;
    (this.currentDensity = ""), (this.currentStartingItem = 0);
    this.currentLimit = "";
    this.currentScreenData = null;
    this.currentScreenDataArray = null;
    this.currentScreenDataLoading = false;
    this.currentTabColoumns = null;
    this.currentTabColoumnsArray = null;
    this.activeTab = null;
    this.dataLoaded = true;
    this.dataReloading = false;
    this.columnArray = [];
    this.currentScreenDataArrayLength = null;
    this.chartCategoryData = [];
    this.chartViewData = [];
    this.chartConfig = {};
    (this.errMessage = ""),
      (this.chartId = ""),
      (this.activeCategoryId = ""),
      (this.tabStartDate = moment()
        .startOf("day")
        .toISOString());
    this.chartLoading = false;
    this.tabEndDate = moment()
      .endOf("day")
      .toISOString();
    this.backButtonVisibility = false;
    this.previousChartConfig = [];
    this.isHealthCount = true;
    this.isSubLevel = false;
    this.preset = "";
    this.trendPreset = "Today";
    this.chartMessage = "";
    this.workingHours = 0;
    this.trendBucketType = "Hours";
    this.errorsList = [];
    this.warningsList = [];
    this.errorNWarningslistsLoaded = false;
    this.chartBucketType = "View By Hours";
    this.trendLoadingMask = true;
    this.loanPoolNotificationCount = 0;
    this.IssueLogNotificationCount = 0;
    this.ServiceRequestNotificationCount = 0;
    this.OOTNotificationCount = 0;
    this.buttonLoading = false;
    this.createButtonLoading = false;
    this.remaneButtonLoading = false;

    this.assetDetails = {
      data: {
        ParentSystemName: "",
        UniqueID: "10_10010039",
        UtilizationCategory: "",
        LastUpdate: "1970-01-01T00:00:00.000Z",
        AssetNo: "300013002298",
        CalibrationDueDate: "1970-01-01T00:00:00.000Z",
        LastServiceDate: "1970-01-01T00:00:00.000Z",
        BorrowereReturnDate: "2017-09-27T16:53:52.561Z",
        OrderNumber: "",
        LifeCycleStage: "",
        UseProviderCalibrationType: false,
        History:
          '[{"Description":"AssetNo changed from 300013002298.00 to 300013002298","Timestamp":"2017-08-13T12:54:21.680Z","Property":"AssetNo","EditedBy":"ke@sprdadmin.com"},{"Description":"LoanDailyCost changed from 11.36383562 to 11.36","Timestamp":"2017-08-13T12:54:21.681Z","Property":"LoanDailyCost","EditedBy":"ke@sprdadmin.com"},{"Description":"Accessories changed from \'\' to PLUM connected","Timestamp":"2017-08-16T14:57:07.125Z","Property":"Accessories","EditedBy":"ken@sprdadmin.com"}]',
        UseProviderCalibrationSchedule: false,
        EquipmentType: "",
        RepairProvider: "",
        ServiceAgreement: "",
        ReplacedBy: "",
        CalibrationProvider: "",
        Currency: "($)USD",
        ServiceInterval: 12,
        Manufacturer: "Anritsu",
        BorrowerStartDate: "2017-09-27T16:53:52.561Z",
        InvoiceNumber: "",
        PlannedDisposalDate: "1970-01-01T00:00:00.000Z",
        AltManufacturerName: "",
        Status: "",
        InventoryDate: "1970-01-01T00:00:00.000Z",
        SerialNo: "6201465521",
        ServiceEndDate: "1970-01-01T00:00:00.000Z",
        HealthStatus: "GREEN",
        SoftwareRevision: "",
        homeMashup: "",
        WorkFlowState: "",
        HardwareVersion: "",
        LastReportedCondition: "Out of Spec",
        tags: [
          {
            vocabulary: "ITC-DEV",
            vocabularyTerm: "BatchImport"
          },
          {
            vocabulary: "ITC-DEV",
            vocabularyTerm: "KeysightData"
          },
          {
            vocabulary: "Keysight-Customer",
            vocabularyTerm: "10"
          }
        ],
        Depreciation: 20.0,
        ReceivedDate: "2015-07-22T16:00:00.000Z",
        Barcode: "",
        OrganizationUnit: "undefined",
        name: "10_10010039",
        ProductCategory: "",
        OwnershipStatus: "",
        Options: "",
        LoanpoolStatus: "Available",
        Description: "Radio Communication Analyzer",
        Organization:
          "Spreadtrum Communications > Global Hardware Engineering Division > CS",
        User: "Donglin.Xu@spreadtrum.com",
        SystemParent: "",
        BookValueDate: "1970-01-01T00:00:00.000Z",
        description: "",
        ReplacementDate: "1970-01-01T00:00:00.000Z",
        PurchasePrice: 0.0,
        PartOfSystemCalibration: false,
        Information: {
          OS: [
            {
              information_type: "information",
              message: "EMS Agent Version: P.01.02.12"
            },
            {
              information_type: "information",
              message: "br0 192.168.0.1 eth0 10.29.228.19   "
            },
            {
              information_type: "information",
              message: "SN: CN0024000117"
            },
            {
              information_type: "information",
              message: "FW Version: #1 PREEMPT Mon Jul 17 09:35:30 CST 2017"
            }
          ]
        },
        CalibrationDate: "1970-01-01T00:00:00.000Z",
        isSystemObject: false,
        Accessories: "PLUM connected",
        AssetLocation: {
          latitude: 0.0,
          longitude: 0.0,
          elevation: 0.0,
          defaultValue: true
        },
        SystemChild: false,
        RemoteThing: "10_10010039-EMS",
        ServiceStartDate: "1970-01-01T00:00:00.000Z",
        SystemComponents: "",
        SystemName: "",
        DepreciationRateInNoOfYear: 0.0,
        EquipmentNo: "10010039",
        Borrowable: false,
        IsUtilization: true,
        OwningCompany: "",
        ServiceDueDate: "2017-11-10T16:00:00.000Z",
        Borrower: "",
        ServiceLogistics: "",
        Request: "",
        thingName: "10_10010039",
        avatar: "/Thingworx/Things/10_10010039/Avatar",
        Coordinator: "fred.ren@spreadtrum.com",
        RequestorEmail: "",
        OrderDate: "2015-05-23T16:00:00.000Z",
        IsIndexed: true,
        ModelNo: "MT8820C",
        UseDefaultProvider: false,
        BookValue: 0.0,
        LoanDailyCost: 11.36,
        ServiceCost: 0,
        CalibrationType: "",
        FirmwareRevision: "",
        IsConnected: false,
        Location:
          "Spreadtrum Communications > SH > YaXin Park > Building A > 1st Floor > ANN",
        StickyNotes: ""
      },
      success: true
    };
    this.gridOptions = {
      //We register the react date component that ag-grid will use to render
      // dateComponentFramework: DateComponent,
      // this is how you listen for events using gridOptions

      defaultColDef: {
        headerComponentParams: {
          menuIcon: "fa-bars"
        }
      },
      // this is a simple property
      rowBuffer: 10, // no need to set this, the default is fine for almost all scenarios,
      //  floatingFilter: true
      rowHeight: 30
    };

    this.serviceStartDate = moment().format("YYYY/MM/DD");
    this.serviceEndDate = moment()
      .add(30, "days")
      .format("YYYY/MM/DD");
    this.serviceColumns;
    this.serviceLoading = true;
    this.serviceDataArray = [];
  }
  @action setCreateButtonLoading = bool => {
    this.createButtonLoading = bool;
  };
  @action setRemaneButtonLoading = bool => {
    this.remaneButtonLoading = bool;
  };
  @action
  setChartLoading(bool) {
    this.chartLoading = bool;
  }
  @action
  setServiceDueDateArray(array) {
    this.serviceDataArray = array;
  }
  @action
  fetchServiceDueDateData() {
    if (this.gridOptions.api) {
      this.gridOptions.api.setRowData(this.serviceDataArray);
      this.gridOptions.api.hideOverlay();
    }

    this.serviceLoading = false;
  }
  parseColor() {
    return "#aaffaa";
  }
  @action
  setServiceDueDateRanges(date) {
    this.serviceLoading = true;
    this.serviceStartDate = date[0].startOf("day").toISOString();
    this.serviceEndDate = date[1].endOf("day").toISOString();
    this.reRenderServiceDueDates();
  }
  @action
  reRenderServiceDueDates() {
    this.generateDateColumns();
    this.fetchServiceDueDateData();
  }
  @action
  setServiceDueChartLoading(bool) {
    this.serviceLoading = bool;
  }

  @action
  generateDateColumns() {
    var columns = [];
    var isSame = moment(this.tabEndDate).isSame(this.tabStartDate, "days");
    var dates = [];
    isSame
      ? dates.push(moment(this.tabStartDate).format("MM-DD-YYYY"))
      : (dates = dateArray.range(
          this.tabStartDate,
          this.tabEndDate,
          "MM-DD-YYYY",
          true
        ));
    for (var dateItem of dates) {
      var item = {};
      var res = dateItem.split("-");
      item.year = res[2];
      item.date = res[1];
      item.month = res[0];
      item.width = 50;
      item.field = dateItem;
      item.headerName = res[1];
      item.suppressFilter = true;
      item.suppressSorting = true;
      item.suppressMenu = true;
      item.suppressResize = true;
      item.suppressMovable = true;

      item.cellStyle = params => {
        if (params.value === "#2CB0C7")
          return {
            backgroundColor: "#2CB0C7",
            color: "#2CB0C7",
            border: "1px solid #caccd0",
            marginTop: "0"
          };
        else if (params.value === "#FF325C")
          return {
            backgroundColor: "#FF325C",
            color: "#FF325C",
            border: "1px solid #caccd0",
            marginTop: "0"
          };
        else if (params.value === "#666666")
          return {
            backgroundColor: "#666666",
            color: "#666666",
            border: "1px solid #caccd0",
            marginTop: "0"
          };
        else
          return {
            backgroundColor: params.value,
            color: params.value,
            border: "1px solid #caccd0",
            marginTop: "0",
            background: "transparent"
          };
      };
      columns.push(item);

      var years = [];
      years = _.groupBy(columns, function(b) {
        return b.year;
      });
      var array = [];
      array.push({
        field: "EquipmentNo",
        headerName: "Equipment Number",
        width: 180,
        minWidth: 50,
        suppressFilter: true,
        suppressSorting: true,
        suppressMenu: true,
        suppressResize: true,
        suppressMovable: true
      });
      array.push({
        headerName: "",
        width: 50,
        minWidth: 50,
        headerCheckboxSelection: true,
        checkboxSelection: true,
        suppressMovable: true,
        suppressFilter: true,
        suppressSorting: true,
        suppressMenu: true,
        suppressResize: true
      });
      for (var i = 0; i < Object.keys(years).length; i++) {
        var child = {};
        child.headerName = Object.keys(years)[i];
        child.children = this.parseMonth(Object.values(years)[i]);

        array.push(child);
      }

      this.columnDefs = array;
    }
  }
  parseMonth(data) {
    var months = [];
    months = _.groupBy(data, function(b) {
      return b.month;
    });
    data.length == 364;
    var beforeparse = [];
    for (var i = 0; i < Object.keys(months).length; i++) {
      var item = {};
      item.index = [Object.keys(months)[i]];
      item.value = Object.values(months)[i];
      beforeparse.push(item);
    }
    data.length == 364;
    beforeparse.sort(function(a, b) {
      if (a.index > b.index) {
        return 1;
      }
      if (a.index < b.index) {
        return -1;
      }
      return 0;
    });
    data.length == 364;
    var array = [];
    for (let i = 0; i < beforeparse.length; i++) {
      var child = {};
      child.headerName = moment(beforeparse[i].index, "MM").format("MMMM");
      child.children = beforeparse[i].value;
      array.push(child);
      data.length == 364;
    }
    return array;
  }

  @computed
  get getDataContext() {
    alert(this.datacontext);
    return this.datacontext;
  }

  @computed
  get getTabs() {
    return this.tabs;
  }
  @computed
  get getcurrentLimit() {
    return this.currentLimit;
  }
  @computed
  get getcurrentStartingItem() {
    return this.currentStartingItem;
  }
  @computed
  get getCurrentPage() {
    return this.currentPage;
  }
  @computed
  get getcurrentDensity() {
    return this.currentDensity;
  }
  @computed
  get getActiveTab() {
    return this.activeTab;
  }
  @computed
  get getCurrentTabColoumns() {
    return this.currentTabColoumns;
  }
  @computed
  get getCurrentTabColoumnsArray() {
    return this.currentTabColoumnsArray;
  }
  @computed
  get getCurrentScreenDataArray() {
    return this.currentScreenDataArray;
  }
  @computed
  get getChartCategoryData() {
    return this.chartCategoryData;
  }
  @computed
  get getActiveChartCategory() {
    function findActive(data) {
      return data.Active === true;
    }
    return this.chartCategoryData.find(findActive).CategoryId;
  }
  @computed
  get getChartViewData() {
    return this.chartViewData;
  }
  @computed
  get getChartConfig() {
    return this.chartConfig;
  }
  @computed
  get getChartId() {
    return this.chartId;
  }
  @computed
  get getActiveCategoryId() {
    return this.activeCategoryId;
  }
  @computed
  get getTabStartDate() {
    return this.tabStartDate;
  }
  @computed
  get getTabEndDate() {
    return this.tabEndDate;
  }
  @computed
  get getBackButtonVisibility() {
    return this.backButtonVisibility;
  }
  @computed
  get getPreviousChartConfig() {
    return this.previousChartConfig;
  }
  @computed
  get getIsHealthCount() {
    return this.isHealthCount;
  }
  @computed
  get getIsSubLevel() {
    return this.isSubLevel;
  }
  @computed
  get getPreset() {
    return this.preset;
  }
  @computed
  get getTrendPreset() {
    return this.trendPreset;
  }
  @computed
  get getTrendBucketType() {
    return this.trendBucketType;
  }
  @computed
  get getChartBucketType() {
    return this.chartBucketType;
  }
  @action
  reRenderGrid() {
    this.dataLoaded = false;
    addAssetsStore.setEditting(false);
    return Functions.InitializeApplication()
      .then(resp => {
        if (resp.data.success) {
          var response = resp.data;
          var inputData = {};
          inputData.data = {};
          inputData.data.data = response.gridDataModel;
          this.setCurrentTabColoumns(inputData);
          inputData.data = {};
          inputData.data = response.completeGridData; // TODO validate the Performance
          this.setCurrentScreenDataJson(inputData);
          this.setCurrentScreenDataLoading(false);
          this.dataLoaded = true;
          document.getElementById("root").classList.remove("hidden");
          document.getElementById("divCenter").classList.add("hidden");
        }
        this.dataLoaded = true;
      })
      .catch(() => {});
  }

  @action
  setFilterModalopen = bool => {
    this.filterModalOpen = bool;
  };
  @action
  setTabsJson = tabs => {
    this.tabs = null;
    this.tabs = tabs;
    var obj = JSON.parse(tabs);
    var needle = true;

    // iterate over each element in the array
    for (var i = 0; i < obj.length; i++) {
      // look for the entry with a matching `code` value
      if (obj[i].Active == needle) {
        this.activeTab = obj[i];
      }
    }
  };
  @action
  setActiveTab = tab => {
    this.activeTab = tab;
  };
  @action
  setCurrentScreenDataJson = json => {
    this.currentScreenData = json.data;
    var renderer = json.data.data;
    let rows = [];
    for (let i = 0; i < renderer.length; i++) {
      var item = renderer[i];
      item.OrderDate =
        item.OrderDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.OrderDate).format("YYYY/MM/DD");
      item.ReceivedDate =
        item.ReceivedDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.ReceivedDate).format("YYYY/MM/DD");
      item.InventoryDate =
        item.InventoryDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.InventoryDate).format("YYYY/MM/DD");
      item.BookValueDate =
        item.BookValueDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.BookValueDate).format("YYYY/MM/DD");
      item.PlannedDisposalDate =
        item.PlannedDisposalDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.PlannedDisposalDate).format("YYYY/MM/DD");
      item.ReplacementDate =
        item.ReplacementDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.ReplacementDate).format("YYYY/MM/DD");
      item.ServiceDueDate =
        item.ServiceDueDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.ServiceDueDate).format("YYYY/MM/DD");
      item.LastUpdate =
        item.LastUpdate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.LastUpdate).format("YYYY/MM/DD");
      item.CalibrationDate =
        item.CalibrationDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.CalibrationDate).format("YYYY/MM/DD");
      item.CalibrationDueDate =
        item.CalibrationDueDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.CalibrationDueDate).format("YYYY/MM/DD");
      item.LastServiceDate =
        item.LastServiceDate == "1970-01-01T00:00:00.000Z"
          ? null
          : moment(item.LastServiceDate).format("YYYY/MM/DD");
      item.BookValue = item.BookValue == -999999 ? "" : item.BookValue;
      item.LoanDailyCost =
        item.LoanDailyCost == -999999 ? "" : item.LoanDailyCost;
      item.CalibrationInterval =
        item.CalibrationInterval == -999999 ? "" : item.CalibrationInterval;
      item.ServiceCost = item.ServiceCost == -999999 ? "" : item.ServiceCost;
      item.PurchasePrice =
        item.PurchasePrice == -999999 ? "" : item.PurchasePrice;
      item.Depreciation = item.Depreciation == -999999 ? "" : item.Depreciation;
      if (item.IsUtilization) {
        if (renderer[i].HealthStatus == "GREEN") {
          item.formatter = "ImageFormatter";
          item.HealthCode = "GREEN";
          item.IsConnected
            ? (item.HealthStatus = (
                <img
                  src={health_green}
                  width={24}
                  height={24}
                  title={"GREEN"}
                />
              ))
            : (item.HealthStatus = (
                <img
                  src={health_green_fade}
                  width={24}
                  height={24}
                  title={"GREEN"}
                />
              ));
        } else if (renderer[i].HealthStatus == "YELLOW") {
          item.formatter = "ImageFormatter";
          item.HealthCode = "YELLOW";
          item.IsConnected
            ? (item.HealthStatus = (
                <img
                  src={health_yellow}
                  width={24}
                  height={24}
                  title={"YELLOW"}
                />
              ))
            : (item.HealthStatus = (
                <img
                  src={health_yellow_fade}
                  width={24}
                  height={24}
                  title={"YELLOW"}
                />
              ));
        } else if (renderer[i].HealthStatus == "RED") {
          item.formatter = "ImageFormatter";
          item.HealthCode = "RED";
          item.IsConnected
            ? (item.HealthStatus = (
                <img src={health_red} width={24} height={24} title={"RED"} />
              ))
            : (item.HealthStatus = (
                <img
                  src={health_red_fade}
                  width={24}
                  height={24}
                  title={"RED"}
                />
              ));
        } else {
          item.formatter = "ImageFormatter";
          item.HealthCode = "GREY";
          item.HealthStatus = (
            <img src={GREY} width={24} height={24} title={"GREY"} />
          );
        } //else put some grey icon
      } else {
        item.formatter = "ImageFormatter";
        item.HealthCode = "GREY";
        item.HealthStatus = (
          <img src={GREY} width={24} height={24} title={"GREY"} />
        );
      }

      rows.push(item);
    }
    this.currentScreenDataArray = rows;
    this.currentScreenDataArrayLength = renderer.length;
  };
  @action
  setCurrentDensity = currentDensity => {
    this.currentDensity = currentDensity;
    this.activeTab.DisplayDensity = currentDensity;
    Functions.SetDisplayDensity(currentDensity, this.activeTab.TabId);
  };
  @action
  setPinnedColumn = json => {
    var payload = {};
    payload.data = json;
    payload.TabId = this.activeTab.TabId;
    let activeTab = mobx.toJS(this.activeTab);
    activeTab.PinColumn = JSON.parse(payload.data);
    this.activeTab = mobx.toJS(activeTab);
    Functions.SetPinnedColumn(payload);
  };
  @action
  setCurrentPage = page => {
    this.currentPage = page;
    document.getElementById("pageInput")
      ? (document.getElementById("pageInput").value = page ? page : "")
      : "";
  };
  @action
  setCurrentScreenDataArray = data => {
    this.currentScreenDataArray = data;
    this.currentScreenDataArrayLength = data.length;
  };
  @action
  setDataContext = datacontext => {
    this.datacontext = datacontext;
  };

  @action
  setDataContextState = state => {
    this.datacontextState = state;
  };
  @action
  setDataContextStartDate = dateInput => {
    this.datacontextStartDate = dateInput;
  };
  @action
  setDataContextEndDate = dateInput => {
    this.datacontextEndDate = dateInput;
  };

  @action
  setCurrentStart = page => {
    this.currentStartingItem = page;
  };
  @action
  setCurrentLimit = data => {
    this.currentLimit = data;
  };
  @action
  setPagination = data => {
    this.currentLimit = data;
    this.activeTab.Pagination = data;
    Functions.SetPagination(data, this.activeTab.TabId);
  };
  @action
  setCurrentScreenDataLoading = bool => {
    this.currentScreenDataLoading = bool;
  };
  @action
  setCurrentTabColoumns = json => {
    var renderer = json.data.data;
    let rows = [
      {
        headerName: "",
        width: 40,
        minWidth: 40,
        maxWidth: 40,
        hide: false,
        headerCheckboxSelection: true,
        checkboxSelection: true,
        suppressMovable: true,
        suppressFilter: true,
        suppressSorting: true,
        suppressResize: true,
        suppressToolPanel: true,
        lockPinned: true,
        pinned: "left",
        menuTabs: []
      }
    ];
    for (let i = 0; i < renderer.length; i++) {
      var item = {
        field: renderer[i].dataIndex,
        headerName: renderer[i].text, // + "&nbsp &nbsp &nbsp &nbsp &nbsp", please don't add it here
        width: +renderer[i].width,
        minWidth: 100,
        hide: renderer[i].hidden
      };
      if (renderer[i].dataIndex == "HealthStatus") {
        item.cellRendererFramework = HealthCellRenderer;
      }
      for (
        let j = 0;
        j < this.activeTab.PinColumn.PinnedColumn.pinleft.length;
        j++
      ) {
        if (
          this.activeTab.PinColumn.PinnedColumn.pinleft[j].colId ==
          renderer[i].dataIndex
        ) {
          item.pinned = "left";
        }
      }
      for (
        let j = 0;
        j < this.activeTab.PinColumn.PinnedColumn.pinright.length;
        j++
      ) {
        if (
          this.activeTab.PinColumn.PinnedColumn.pinright[j].colId ==
          renderer[i].dataIndex
        ) {
          item.pinned = "right";
        }
      }
      rows.push(item);
    }
    this.currentTabColoumnsArray = rows;
  };
  @action
  setDataLoaded = bool => {
    this.dataLoaded = bool;
  };
  @action
  setDataReloading = bool => {
    this.dataReloading = bool;
  };

  @action
  setChartCategoryData = categoryOptions => {
    this.chartCategoryData = JSON.parse(categoryOptions);
  };
  @action
  setChartViewData = chartOptions => {
    this.chartViewData = JSON.parse(chartOptions);
  };
  @action
  setChartConfig = data => {
    this.chartLoading = false;
    permissionStore.setChartLoading(false);
    this.chartConfig = data;
  };

  @action
  setAssetDetails = data => {
    this.assetDetails = data;
  };

  @action
  setHideColumn = () => {};
  @action
  setShowColumn = data => {
    this.assetDetails = data;
  };
  @action
  setLockColumn = data => {
    this.assetDetails = data;
  };
  @action
  setUnlockColumn = data => {
    this.assetDetails = data;
  };
  @computed
  get getErrorMessage() {
    return this.errMessage;
  }
  @action
  setErrorMessage = string => {
    this.errMessage = string;
  };
  @action
  setChartId = string => {
    this.chartId = string;
  };
  @action
  setActiveCategoryId = string => {
    this.activeCategoryId = string;
  };
  @action
  setTabStartDate = data => {
    data ? (this.tabStartDate = data) : "";
  };
  @action
  setTabEndDate = data => {
    data ? (this.tabEndDate = data) : "";
  };
  @action
  setBackButtonVisibility = bool => {
    this.backButtonVisibility = bool;
  };
  @action
  clearPreviousChartConfig = () => {
    this.previousChartConfig = [];
  };
  @action
  addToPrevConfig = () => {
    var isExist = false;
    this.previousChartConfig.map(item => {
      item.dataProvider[0].propertyName ==
      this.chartConfig.dataProvider[0].propertyName
        ? (isExist = true)
        : "";
    });
    isExist ? "" : this.previousChartConfig.push(this.chartConfig);
  };
  @action
  drillUpPreviousChartConfig = () => {
    var prevConfig = mobx.toJS(this.previousChartConfig);
    prevConfig.splice(-1, 1);
    this.previousChartConfig = prevConfig;
  };
  @action
  setPreviousChartConfig = data => {
    if (data.length != 0) {
      this.previousChartConfig = data;
    }
    return;
  };
  @action
  setIsHealthCount = bool => {
    this.isHealthCount = bool;
  };
  @action
  setIsSubLevel = bool => {
    this.isSubLevel = bool;
  };
  @action
  setPreset = string => {
    this.preset = string;
  };
  @action
  setTrendPreset = string => {
    this.trendPreset = string;
  };
  @action
  setTrendBucketType = string => {
    this.trendBucketType = string;
  };
  @action
  setChartBucketType = string => {
    this.chartBucketType = string;
  };
  @action
  setchartMessage = string => {
    this.chartMessage = string;
  };
  @action
  setWorkingHours = data => {
    this.workingHours = data;
  };
  @action
  setWarnings = data => {
    this.warningsList = data;
  };
  @action
  setErrors = data => {
    this.errorsList = data;
  };
  @action
  setErrorsNWarningsLoading = bool => {
    this.errorNWarningslistsLoaded = bool;
  };
  @action
  setTrendLoadingMask = bool => {
    this.trendLoadingMask = bool;
  };
  @action
  setColumnOrder = json => {
    var payload = {};
    payload.data = json;
    payload.TabId = this.activeTab.TabId;
    Functions.SetColumnOrder(payload);
  };
  @action
  setColumnWidth = json => {
    var payload = {};
    payload.data = json;
    payload.TabId = this.activeTab.TabId;
    Functions.SetColumnWidth(payload);
  };
  @action
  renameTab = (Name, tabId) => {
    this.buttonLoading = true;
    return Functions.renameTab(Name, tabId).then(resp => {
      this.buttonLoading = false;
      resp.data.success
        ? UIFunctions.ShowSuccess({
            zIndex: 2000,
            title: "Asset group renamed successfully!"
          })
        : UIFunctions.ShowError({
            zIndex: 2000,
            title: "Asset group rename failed!"
          });
    });
  };
  @action
  clearStore = () => {
    this.dataLoaded = false;
    this.filterModalOpen = false;
    this.datacontext = {};
    this.datacontextState = "step1";
    this.datacontextStartDate = new Date(
      new Date().setHours(0, 0, 0, 0)
    ).toISOString();
    this.datacontextEndDate = new Date(
      new Date().setHours(23, 59, 59, 999)
    ).toISOString();
    this.models = [];
    this.tabs = null;
    this.currentPage = 1;
    this.currentDensity = "";
    this.currentStartingItem = 0;
    this.currentLimit = 25;
    this.currentScreenData = null;
    this.currentScreenDataArray = null;
    this.currentScreenDataLoading = false;
    this.currentTabColoumns = null;
    this.currentTabColoumnsArray = null;
    this.activeTab = null;
    this.dataLoaded = true;
    this.dataReloading = false;
    this.columnArray = [];
    this.currentScreenDataArrayLength = null;
    this.chartCategoryData = [];
    this.chartViewData = [];
    this.chartConfig = {};
    (this.errMessage = ""),
      (this.previousChartConfig = []),
      (this.assetDetails = {
        data: {
          ParentSystemName: "",
          UniqueID: "10_10010039",
          UtilizationCategory: "",
          LastUpdate: "1970-01-01T00:00:00.000Z",
          AssetNo: "300013002298",
          BorrowereReturnDate: "2017-09-27T16:53:52.561Z",
          OrderNumber: "",
          LifeCycleStage: "",
          UseProviderCalibrationType: false,
          History:
            '[{"Description":"AssetNo changed from 300013002298.00 to 300013002298","Timestamp":"2017-08-13T12:54:21.680Z","Property":"AssetNo","EditedBy":"ke@sprdadmin.com"},{"Description":"LoanDailyCost changed from 11.36383562 to 11.36","Timestamp":"2017-08-13T12:54:21.681Z","Property":"LoanDailyCost","EditedBy":"ke@sprdadmin.com"},{"Description":"Accessories changed from \'\' to PLUM connected","Timestamp":"2017-08-16T14:57:07.125Z","Property":"Accessories","EditedBy":"ken@sprdadmin.com"}]',
          UseProviderCalibrationSchedule: false,
          EquipmentType: "",
          RepairProvider: "",
          ServiceAgreement: "",
          ReplacedBy: "",
          CalibrationProvider: "",
          Currency: "($)USD",
          ServiceInterval: 12,
          Manufacturer: "Anritsu",
          BorrowerStartDate: "2017-09-27T16:53:52.561Z",
          InvoiceNumber: "",
          PlannedDisposalDate: "1970-01-01T00:00:00.000Z",
          AltManufacturerName: "",
          Status: "",
          InventoryDate: "1970-01-01T00:00:00.000Z",
          SerialNo: "6201465521",
          ServiceEndDate: "1970-01-01T00:00:00.000Z",
          HealthStatus: "GREEN",
          SoftwareRevision: "",
          homeMashup: "",
          WorkFlowState: "",
          HardwareVersion: "",
          LastReportedCondition: "Out of Spec",
          tags: [
            {
              vocabulary: "ITC-DEV",
              vocabularyTerm: "BatchImport"
            },
            {
              vocabulary: "ITC-DEV",
              vocabularyTerm: "KeysightData"
            },
            {
              vocabulary: "Keysight-Customer",
              vocabularyTerm: "10"
            }
          ],
          Depreciation: 20.0,
          ReceivedDate: "2015-07-22T16:00:00.000Z",
          Barcode: "",
          OrganizationUnit: "undefined",
          name: "10_10010039",
          ProductCategory: "",
          OwnershipStatus: "",
          Options: "",
          LoanpoolStatus: "Available",
          Description: "Radio Communication Analyzer",
          Organization:
            "Spreadtrum Communications > Global Hardware Engineering Division > CS",
          User: "Donglin.Xu@spreadtrum.com",
          SystemParent: "",
          BookValueDate: "1970-01-01T00:00:00.000Z",
          description: "",
          ReplacementDate: "1970-01-01T00:00:00.000Z",
          PurchasePrice: 0.0,
          PartOfSystemCalibration: false,
          Information: {
            OS: [
              {
                information_type: "information",
                message: "EMS Agent Version: P.01.02.12"
              },
              {
                information_type: "information",
                message: "br0 192.168.0.1 eth0 10.29.228.19   "
              },
              {
                information_type: "information",
                message: "SN: CN0024000117"
              },
              {
                information_type: "information",
                message: "FW Version: #1 PREEMPT Mon Jul 17 09:35:30 CST 2017"
              }
            ]
          },
          CalibrationDate: "1970-01-01T00:00:00.000Z",
          isSystemObject: false,
          Accessories: "PLUM connected",
          AssetLocation: {
            latitude: 0.0,
            longitude: 0.0,
            elevation: 0.0,
            defaultValue: true
          },
          SystemChild: false,
          RemoteThing: "10_10010039-EMS",
          ServiceStartDate: "1970-01-01T00:00:00.000Z",
          SystemComponents: "",
          SystemName: "",
          DepreciationRateInNoOfYear: 0.0,
          EquipmentNo: "10010039",
          Borrowable: false,
          IsUtilization: true,
          OwningCompany: "",
          ServiceDueDate: "2017-11-10T16:00:00.000Z",
          Borrower: "",
          ServiceLogistics: "",
          Request: "",
          thingName: "10_10010039",
          avatar: "/Thingworx/Things/10_10010039/Avatar",
          Coordinator: "fred.ren@spreadtrum.com",
          RequestorEmail: "",
          OrderDate: "2015-05-23T16:00:00.000Z",
          IsIndexed: true,
          ModelNo: "MT8820C",
          UseDefaultProvider: false,
          BookValue: 0.0,
          LoanDailyCost: 11.36,
          ServiceCost: 0,
          CalibrationType: "",
          FirmwareRevision: "",
          IsConnected: false,
          Location:
            "Spreadtrum Communications > SH > YaXin Park > Building A > 1st Floor > ANN",
          StickyNotes: ""
        },
        success: true
      });
    this.serviceStartDate = moment();
    this.serviceEndDate = moment().endOf("month");
  };

  @action
  setHealthVsTimeContext = bool => {
    this.isHealthVsTime = bool;
  };
  @action
  setHideHeader = bool => {
    this.hideHeader = bool;
  };
  @action
  setIsAssetListView = bool => {
    this.isAssetListView = bool;
  };
  @action
  setIsChartView = bool => {
    this.isChartView = bool;
  };
  @action
  setIsVisible = bool => {
    this.isVisible = bool;
  };
  @action
  setShowToolTip = bool => {
    this.showToolTip = bool;
  };
  @action setOnChartActive = bool => {
    this.onChartActive = bool;
  };
  @action setOnTabActive = bool => {
    this.onTabActive = bool;
  };
}

const tabModelStore = new TabModelStore();

export default tabModelStore;
