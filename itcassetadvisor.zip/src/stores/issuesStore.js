import { observable,action,computed } from 'mobx';

class IssuesStore {

    @observable issuesAssignedToMe;
    @observable issuesAssignedToMeLength;
    @observable issuesAssignedToMe;
    @observable issuesSubmittedByMeLength;
  
  constructor() {
    this.issuesAssignedToMe='';
    this.issuesAssignedToMeLength='';
    this.issuesSubmittedByMe='';
    this.issuesSubmittedByMeLength='';
  }
  @computed get getIssuesAssignedToMe(){
    return this.issuesAssignedToMe;
  }
    
  @action setIssuesAssignedToMe = (data) => {
    this.issuesAssignedToMe = data;
    this.issuesAssignedToMeLength = data.length;
  }    
  @computed get getIssuesSubmittedByMe(){
    return this.issuesSubmittedByMe;
  }
    
  @action setIssuesSubmittedByMe = (data) => {
      //console.log('setIssuesSubmittedByMe',data)
    this.issuesSubmittedByMe= data;
    this.issuesSubmittedByMeLength= data.length;
    //console.log('setIssuesSubmittedByMe',this.issuesSubmittedByMe,this.issuesSubmittedByMeLength)
}    
}

const issuesStore = new IssuesStore();

export default issuesStore;