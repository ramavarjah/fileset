import { observable, action, computed } from "mobx";
import Functions from "../api/Functions";
import React from "react";
import UIFunctions from "../helpers/UIFunctions";
import moment from "moment";
import _ from "lodash";
import { Icon, Tooltip, Button, Popconfirm } from "antd";
import tabModelStore from "../stores/tabModelStore";
var rr;
import mobx from "mobx";
// import userStore from "./userStore";

/* eslint-disable  */
class LoanPoolStoreV2 {
  @observable
  isLoanPool;
  @observable
  dataLoaded;
  @observable
  dataLoadedForAllLP;
  @observable
  dataLoadedForSTMLP;
  @observable
  dataLoadedForApprovalLP;
  @observable
  AddToRequestDataLoaded;
  @observable
  dropdownOptions;
  @observable
  borrowableAssets;
  @observable
  borrowableAssetsforAddToRequest;
  @observable
  completeBorrowableAssets;
  @observable
  queryOutputBorrowableAssets;
  @observable
  allLoanPoolRequests;
  @observable
  allLoanPoolRequests1;
  @observable
  reviewerMode;
  @observable
  startDateCheckAvailability;
  @observable
  endDateCheckAvailability;
  @observable
  startDateForAddToRequest;
  @observable
  endDateForAddToRequest;
  @observable
  normalViewMode;
  @observable
  initialNormalViewMode;
  @observable
  reviewerViewMode;
  @observable
  borrowableAssetsHeader;
  @observable
  borrowableAssetsHeaderForAddToRequest;
  @observable
  OrganizationTree;
  @observable
  LocationTree;
  @observable
  gridDataModel;
  @observable
  advancedSearchForm;
  @observable
  pageWiseDropDownValues;
  @observable
  usersForCustomer;
  @observable
  coordinatorsForCustomer;
  @observable
  lastAdvSearchData;
  @observable
  lastAddtoRequestSuggestion;
  @observable
  AddToRequestLastSearchData;
  @observable
  cartItems;
  @observable
  isModelModalOpen;
  @observable
  isRequestModelModalOpen;
  @observable
  externalRequestFormDetails;
  @observable
  newRequestFormDetails;
  @observable
  isNewRequestLoading;
  @observable
  isDailyLoanCost;
  @observable
  requestAwaitingModelOpen;
  @observable
  addItemToRequest;
  @observable
  addExternalRequestToRequest;
  @observable
  requestLogModelNoArray;
  @observable
  CheckAvailabiltySwitchState;
  @observable
  checkAvailabilityItems;
  @observable
  addingAvailabilityData;
  @observable
  currentPageCAAssets;
  @observable
  itemsToShowCheckAvailability;
  @observable
  filteredItemsToShowCheckAvailability;
  @observable
  loanStartDate;
  @observable
  loanEndDate;
  @observable
  requestStartChangeDate;
  @observable
  requestEndChangeDate;
  @observable
  cartAssets;
  @observable
  checkAvailabilityMode;
  @observable
  doNotUpdate;
  @observable
  doNotUpdateLPRequests;
  @observable
  caCheckboxedItems;
  @observable
  caPagination;
  @observable
  caPaginationLoader;
  @observable
  caAvailabilityLoader;
  @observable
  addToRequestPagination;
  @observable
  addToRequestPaginationLoader;
  @observable
  addToRequestStringSearch;
  @observable
  addItemToRequestLoading;
  @observable
  buttonEvent;
  @observable
  lpborrowableSelectedRows;
  @observable
  isRequestModalLoading;
  @observable
  selectedRowForDuplicateRequest;
  @observable
  getDataFromDuplicate;
  @observable
  manufacturerList;
  @observable
  LPcoordinator;
  @observable
  models;
  @observable
  imageLoader;
  @observable
  startDateAvailabilityData;
  @observable
  endDateAvailabilityData;
  @observable
  IsLPReviewer;
  @observable
  isSearchApiCalled;
  @observable
  isBackArrowVisible;
  @observable
  allBorrowableAssets;

  constructor() {
    this.imageLoader = false;
    this.doNotUpdate = false;
    this.doNotUpdateLPRequests = false;
    this.models = [];
    this.lpborrowableSelectedRows = [];
    this.LPcoordinator = "";
    this.IsLPReviewer = false;
    this.isSearchApiCalled = false;
    this.isBackArrowVisible = false;
    this.caPagination = {
      showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChange,
      pageNumber: 1,
      pageSize: 10
    };
    this.addToRequestPagination = {
      showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChangeAddToRequest,
      pageNumber: 1,
      pageSize: 10
    };
    this.selectedRowForDuplicateRequest = [];
    this.getDataFromDuplicate = false;
    this.isRequestModalLoading = false;
    this.caCheckboxedItems = [];
    this.caPaginationLoader = true;
    this.caAvailabilityLoader = 0;
    this.addToRequestPaginationLoader = true;
    this.addToRequestStringSearch = false;
    this.itemsToShowCheckAvailability = [];
    this.filteredItemsToShowCheckAvailability = [];
    this.CheckAvailabiltySwitchState = false;
    this.requestLogModelNoArray = [];
    this.checkAvailabilityItems = [];
    this.addingAvailabilityData = [];
    this.currentPageCAAssets = [];
    this.requestAwaitingModelOpen = false;
    this.addItemToRequest = false;
    this.addExternalRequestToRequest = false;
    this.isDailyLoanCost = true;
    this.cartAssets = [];
    this.externalRequestFormDetails = {
      startDate: moment()
        .startOf("day")
        .toISOString(),
      returnDate: moment()
        .add(1, "M")
        .startOf("day")
        .toISOString(),
      mobile: "",
      location: "",
      modelno: "",
      manufacturer: "",
      justification: "",
      description: "",
      notes: ""
    };
    this.newRequestFormDetails = {
      requestormobile: "",
      chargecode: null,
      location: "",
      justification: ""
    };
    this.startDateCheckAvailability = moment()
      .startOf("day")
      .toISOString();
    this.endDateCheckAvailability = moment()
      .add(1, "months")
      .endOf("day")
      .toISOString();
    this.startDateAvailabilityData = moment()
      .startOf("day")
      .toISOString();
    this.endDateAvailabilityData = moment()
      .add(2, "months")
      .endOf("day")
      .toISOString();
    this.loanStartDate = moment()
      .startOf("day")
      .toISOString();
    this.loanEndDate = moment()
      .add(1, "months")
      .endOf("day")
      .toISOString();
    this.requestStartChangeDate = moment()
      .startOf("day")
      .toISOString();
    this.requestEndChangeDate = moment()
      .add(1, "months")
      .endOf("day")
      .toISOString();
    this.startDateForAddToRequest = moment()
      .startOf("day")
      .toISOString();
    this.endDateForAddToRequest = moment()
      .add(1, "months")
      .endOf("day")
      .toISOString();
    this.isNewRequestLoading = false;
    this.isLoanPool = false;
    this.dataLoaded = false;
    this.AddToRequestDataLoaded = true;
    this.dataLoadedForAllLP = false;
    this.dataLoadedForSTMLP = false;
    this.showIcon = true;
    this.dropdownOptions = null;
    this.borrowableAssets = [];
    this.completeBorrowableAssets = [];
    this.allBorrowableAssets = [];
    this.borrowableAssetsforAddToRequest = [];
    this.queryOutputBorrowableAssets = [];
    this.allLoanPoolRequests = [];
    this.allLoanPoolRequests1 = [];
    this.reviewerMode = false;
    this.pageWiseDropDownValues = null;
    this.manufacturerList = null;
    this.isModelModalOpen = false;
    this.isRequestModelModalOpen = false;
    this.lastAddtoRequestSuggestion = "";
    this.lastAdvSearchData = {
      StartDate: moment()
        .startOf("day")
        .toISOString(),
      EndDate: moment()
        .add(1, "M")
        .startOf("day")
        .toISOString(),
      AvailabilityThreshold: "",
      ModelNo: "",
      ProductCategory: "",
      Manufacturer: "",
      EquipmentNo: "",
      EquipmentType: "",
      LastReportedCondition: "",
      Organization: "",
      Location: "",
      Coordinator: "",
      User: ""
    };
    this.addItemToRequestLoading = false;
    this.normalViewMode = "NORMAL";
    this.initialNormalViewMode = this.normalViewMode;
    this.reviewerViewMode = "NORMAL";
    this.gridDataModel = [];
    this.buttonEvent = "";
    this.dataLoadedForApprovalLP = false;
    var self = this;
    //setting Header / columns def for the two main grids
    this.borrowableAssetsHeader = [
      {
        dataIndex: "ModelNo",
        title: "MODEL NUMBER",
        width: 150
      },
      {
        dataIndex: "ProductCategory",
        title: "PRODUCT CATEGORY",
        width: 150,
        render: function(text) {
          if (text) {
            return (
              <Tooltip title={text}>
                <span>{text}</span>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip title={text}>
                <span>{text}</span>
              </Tooltip>
            );
          }
        }
      },
      {
        dataIndex: "Manufacturer",
        title: "MANUFACTURER",
        width: 200,
        render: function(text) {
          if (text) {
            return (
              <Tooltip title={text}>
                <span>{text}</span>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip title={text}>
                <span>{text}</span>
              </Tooltip>
            );
          }
        }
      },
      {
        dataIndex: "EquipmentNo",
        title: "EQUIPMENT NUMBER",
        width: 180,
        render: function(text) {
          if (text) {
            return (
              <Tooltip title={text}>
                <span>{text}</span>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip title={text}>
                <span>{text}</span>
              </Tooltip>
            );
          }
        }
      },
      {
        dataIndex: "Location",
        title: "LOCATION",
        width: 220,
        render: function(text) {
          let location = text;
          let temp = location.split(">");
          temp.reverse();
          let newLocation = temp.join(" < ");
          if (newLocation) {
            return (
              <Tooltip title={newLocation}>
                <span>{newLocation}</span>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip title={newLocation}>
                <span>{newLocation}</span>
              </Tooltip>
            );
          }
        }
      },
      {
        dataIndex: "CalibrationStatus",
        title: "CALIBRATION STATUS",
        width: 140,
        render: function(params) {
          if (params == "Calibrated") {
            return (
              <Tooltip title={params}>
                <span>
                  <Icon
                    style={{ color: "green" }}
                    type="check"
                    theme="outlined"
                  />
                  {params}
                </span>
              </Tooltip>
            );
          } else if (params == "Not Calibrated") {
            return (
              <Tooltip title={params}>
                <span>
                  <Icon
                    style={{ color: "red" }}
                    type="exclamation"
                    theme="outlined"
                  />
                  {params}
                </span>
              </Tooltip>
            );
          } else if (!params) {
            return (
              <Tooltip title={"N/A"}>
                <span>N/A</span>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip title={params}>
                <span>{params}</span>
              </Tooltip>
            );
          }
        }
      },
      {
        dataIndex: "",
        title: ""
      }
    ];
    this.borrowableAssetsHeaderForAddToRequest = [
      {
        dataIndex: "ModelNo",
        title: "Details",
        width: 420,
        render: function(text, record) {
          return (
            <span>
              {record.ModelNo}&nbsp;|&nbsp;Description:{record.Description}
              &nbsp;|&nbsp;Equipment&nbsp;No.{record.EquipmentNo}
              &nbsp;|&nbsp;Manufacturer:{record.Manufacturer}
              &nbsp;|&nbsp;Coordinator:{record.Coordinator}
            </span>
          );
        }
      },
      {
        dataIndex: "",
        title: "",
        width: 100,
        render: function() {
          return (
            <div
              className="plain-divider"
              style={{ float: "right", marginLeft: 0, marginRight: 15, top: 2 }}
            />
          );
        }
      },
      {
        dataIndex: "conflict",
        title: "Conflicts",
        width: 10,
        render: function(params) {
          if (params == "Requested") {
            return (
              <Tooltip title={`Requested`}>
                <span>
                  <Icon type="info-circle" style={{ color: "#FFAE1C" }} />
                </span>
              </Tooltip>
            );
          } else if (params == "Loaned") {
            return (
              <Tooltip title={`Loaned`}>
                <span>
                  <Icon type="info-circle" style={{ color: "#FF3232" }} />
                </span>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip title={`Available`}>
                <span>
                  <Icon type="check-circle" style={{ color: "#42DA81" }} />
                </span>
              </Tooltip>
            );
          }
        }
      },
      {
        dataIndex: "UniqueID",
        title: "",
        width: 10,
        render: (text, record) => (
          <span>
            <Tooltip title={"Add"}>
              <Popconfirm
                placement="top"
                title={this.message}
                onConfirm={e => this.addItem(e, record)}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  icon="plus"
                  style={{
                    color: "#5D646A",
                    border: "none",
                    backgroundColor: "transparent"
                  }}
                  onClick={e => this.addevent(e, record)}
                />
              </Popconfirm>
            </Tooltip>
          </span>
        )
      }
    ];
    this.cartItems = [];
    this.message = "Are you sure you want to add this item to request?";
  }
  @action
  resetAdvSearchData() {
    this.lastAdvSearchData = {
      StartDate: moment()
        .startOf("day")
        .toISOString(),
      EndDate: moment()
        .add(1, "M")
        .startOf("day")
        .toISOString(),
      AvailabilityThreshold: "",
      ModelNo: "",
      ProductCategory: "",
      Manufacturer: "",
      EquipmentNo: "",
      EquipmentType: "",
      LastReportedCondition: "",
      Organization: "",
      Location: "",
      Coordinator: "",
      User: ""
    };
    function parseDataForForm(dataa) {
      let data = dataa;
      data.Location ? (data.Location = this.parseTree(data.Location)) : "";
      data.Organization
        ? (data.Organization = this.parseTree(data.Organization))
        : "";
      return data;
    }
    if (this.advancedSearchForm) {
      this.advancedSearchForm.setFieldsValue(
        parseDataForForm(this.lastAdvSearchData)
      );
    }
  };
  @action
  setIsLPReviewer = input => {
    this.IsLPReviewer = input;
  };
  @action
  setIsRequestModalLoading = input => {
    this.isRequestModalLoading = input;
  };
  @action
  setLpborrowableSelectedRows = input => {
    this.lpborrowableSelectedRows = input;
  };
  @action
  setAdvancedSearchForm = form => {
    this.advancedSearchForm = form;
  };
  @action
  setIsBackArrowVisible = input => {
    this.isBackArrowVisible = input;
  };
  @action
  setIsSearchApiCalled = input => {
    this.isSearchApiCalled = input;
  };
  addevent = (e, record) => {
    this.buttonEvent = e.target;
    // this.addItem(e, record);
  };
  addItem = (e, record) => {
    const elementTarget = this.buttonEvent;
    const allElements = document.querySelectorAll(".ant-table-tbody button");
    [...allElements].map(element => {
      element.setAttribute("disabled", "true");
    });
    this.addItemToRequestLoading = true;
    this.isRequestModalLoading = true;
    this.loadingMask(elementTarget, true);
    let inputJson = {
      EndDate: this.endDateForAddToRequest,
      StartDate: this.startDateForAddToRequest,
      RequestId: this.requestAwaitingModelOpen.requestId,
      UniqueId: record.UniqueID,
      Justification: this.requestAwaitingModelOpen.Justification,
      Requestor: this.requestAwaitingModelOpen.assets[0].Requestor
    };
    Functions.AppendNewAssetToRequest(inputJson)
      .then(response => {
        setTimeout(() => (this.addItemToRequestLoading = false), 5000);
        if (response.data.success) {
          this.rerenderRequests(true, true).then(() => {
            this.setDoNotUpdateLPRequests(false);
            this.rerenderAddToRequest().then(() => {
              UIFunctions.Toast("Asset Added Successfully!", "success");
              const element = document.getElementById("loadingBtn");
              this.loadingMask(element, false);
              this.isRequestModalLoading = false;
            });
          });
        } else {
          const allElements = document.querySelectorAll(
            ".ant-table-tbody button"
          );
          [...allElements].map(element => {
            element.removeAttribute("disabled", "true");
          });
          UIFunctions.Toast("Asset Cannot Be Added", "error");
          this.isRequestModalLoading = false;
        }
      })
      .catch(() => {
        const allElements = document.querySelectorAll(
          ".ant-table-tbody button"
        );
        [...allElements].map(element => {
          element.removeAttribute("disabled", "true");
        });
        this.addItemToRequestLoading = false;
        this.isRequestModalLoading = false;
      });
    // function  onCancel() { }
  };
  // loading mask
  loadingMask = (e, bool) => {
    //vanila js for loading mask
    if (e) {
      const removeChild = e.querySelector("i");
      removeChild.parentNode.removeChild(removeChild);
      const addChild = document.createElement("i");
      if (bool) {
        e.setAttribute("id", "loadingBtn");
        addChild.setAttribute("class", "anticon anticon-spin anticon-loading");
      } else {
        e.removeAttribute("id", "loadingBtn");

        addChild.setAttribute("class", "anticon anticon-plus");

        addChild.style.color = "#42da81";
        e.removeAttribute("loading", "true");
        const allElements = document.querySelectorAll(
          ".ant-table-tbody button"
        );
        [...allElements].map(element =>
          element.removeAttribute("disabled", "true")
        );
      }
      e.appendChild(addChild);
      // addChild.parentElement.setAttribute("disabled", "true");
    }
  };
  onModelClick = record => {
    this.ref.LoanPoolBorrowableAssets.onCellClicked(record);
  };
  @action onShowSizeChange = (current, pageSize) => {
    this.caPagination.pageSize = pageSize;
  };
  @action onShowSizeChangeAddToRequest = (current, pageSize) => {
    this.addToRequestPagination.pageSize = pageSize;
  };
  @action
  setIsLoanPool = bool => {
    this.isLoanPool = bool;
  };

  @action
  setIsDailyLoanCost = bool => {
    this.isDailyLoanCost = bool;
  };
  @action
  setIsNewRequestLoading = bool => {
    this.isNewRequestLoading = bool;
  };
  @action
  setDataLoaded = bool => {
    this.dataLoaded = bool;
  };
  @action
  setManufacturerList = bool => {
    this.manufacturerList = bool;
  };
  @action
  setAddToRequestDataLoaded = bool => {
    this.AddToRequestDataLoaded = bool;
  };
  @action
  setRequestAwaitingModelOpen = data => {
    this.requestAwaitingModelOpen = data;
  };
  @action
  setAddItemToRequest = data => {
    this.addItemToRequest = data;
  };
  @action
  setAddExternalRequestToRequest = data => {
    this.addExternalRequestToRequest = data;
  };
  @action
  setIsRequestModelModalOpen = data => {
    this.isRequestModelModalOpen = data;
  };
  @action
  setDropdownOptions = options => {
    this.dropdownOptions = options;
  };
  @action
  setShowIcon = bool => {
    this.showIcon = bool;
  };
  @action
  setGridDataModel = data => {
    let rows = [];
    for (let i = 0; i < data.length; i++) {
      if (!data[i].hidden) {
        var item = {
          key: data[i].dataIndex,
          sortable: data[i].sortable,
          name: data[i].text,
          width: +data[i].width + 2,
          resizable: true
        };
        rows.push(item);
      }
    }
    // form  the item headerRenderer: <HeaderMenu headerName={data[i].text} />
    this.gridDataModel = rows;
  };
  @action parseTree(data) {
    if (data != null) {
      var original = data.split(">");
      var length = original.length;
      var duplicate = [];
      var location = [];
      duplicate.push(data);

      for (var i = 0; i < length - 1; i++) {
        original.pop();
        duplicate.push(original.join(">").trim());
      }
      location = duplicate.reverse();
      return location;
    }
  }
  @action parseDataForForm = dataa => {
    let data = dataa;
    data.StartDate && data.EndDate
      ? (data.LoanDateRange = [moment(data.StartDate), moment(data.EndDate)])
      : (data.LoanDateRange = [
          moment().startOf("day"),
          moment()
            .add(1, "M")
            .startOf("day")
        ]);
    data.Location ? (data.Location = this.parseTree(data.Location)) : "";
    data.Organization
      ? (data.Organization = this.parseTree(data.Organization))
      : "";
    return data;
  };
  @action
  loanableAssetsAdvancedSearch = input => {
    this.dataLoaded = false;
    if (Array.isArray(input.Location)) {
      input.Location = input.Location[input.Location.length - 1];
    }
    if (Array.isArray(input.Organization)) {
      input.Organization = input.Organization[input.Organization.length - 1];
    }
    this.lastAdvSearchData = input;
    this.initialNormalViewMode = this.normalViewMode;
    Functions.GetLoanableAssetsDataForAdvancedSearch(input)
      .then(resp => {
        let borrowableAssets = this.borrowableAssets;
        let queryOutputBorrowableAssets = this.queryOutputBorrowableAssets;
        let tempBorrowableAssets = resp.data.gridData.data;
        let result = tempBorrowableAssets.filter(o1 =>
          queryOutputBorrowableAssets.some(o2 => o1.UniqueID === o2.UniqueID)
        );
        this.borrowableAssets = result;
        this.caCheckboxedItems = result;

        this.dataLoaded = true;
        this.loanStartDate = resp.data.inputQuery.StartDate;
        this.loanEndDate = resp.data.inputQuery.EndDate;
        this.startDateCheckAvailability = this.loanStartDate;
        this.endDateCheckAvailability = this.loanEndDate;

        setTimeout(() => {
          if (this.advancedSearchForm) {
            this.advancedSearchForm.setFieldsValue(
              this.parseDataForForm(resp.data.inputQuery)
            );
          }
        }, 0);
      })
      .catch(() => {
        this.dataLoaded = true;
      });
  };

  @action
  loanableAssetsDirectSearch = input => {
    function makeData(input) {
      var data = {
        AvailabilityThreshold: "",
        Coordinator: "",
        EquipmentNo: "",
        EquipmentType: "",
        LastReportedCondition: "",
        Location: "",
        Manufacturer: "",
        ModelNo: "",
        Organization: "",
        ProductCategory: "",
        User: "",
        StartDate: moment().startOf("day"),
        EndDate: moment()
          .add(1, "M")
          .startOf("day")
      };
      data = _.assign(data, input);
      return data;
    }
    function parseDataForForm(dataa) {
      let data = dataa;
      data.StartDate && data.EndDate
        ? (data.LoanDateRange = [moment(data.StartDate), moment(data.EndDate)])
        : (data.LoanDateRange = [
            moment().startOf("day"),
            moment()
              .add(1, "M")
              .startOf("day")
          ]);
      data.Location ? (data.Location = this.parseTree(data.Location)) : "";
      data.Organization
        ? (data.Organization = this.parseTree(data.Organization))
        : "";
      return data;
    }
    this.dataLoaded = false;
    var processedInput = makeData(input);
    this.lastAdvSearchData = processedInput;

    Functions.GetLoanableAssetsDataForAdvancedSearch(processedInput)
      .then(resp => {
        this.borrowableAssets = [];
        this.queryOutputBorrowableAssets = [];
        this.borrowableAssets = resp.data.gridData.data;
        this.queryOutputBorrowableAssets = resp.data.gridData.data;
        this.caCheckboxedItems = resp.data.gridData.data;
        this.dataLoaded = true;
        this.loanStartDate = resp.data.inputQuery.StartDate;
        this.loanEndDate = resp.data.inputQuery.EndDate;
        this.startDateCheckAvailability = this.loanStartDate;
        this.endDateCheckAvailability = this.loanEndDate;
        setTimeout(() => {
          if (this.advancedSearchForm) {
            this.advancedSearchForm.setFieldsValue(
              this.parseDataForForm(resp.data.inputQuery)
            );
          }
        }, 0);
      })
      .catch(() => {
        this.dataLoaded = true;
      });
  };
  @action
  loanableAssetsDirectSearchForAddToRequest = input => {
    let self = this;
    function makeData(input) {
      var data = {
        Coordinator: "",
        EquipmentNo: "",
        EquipmentType: "",
        LastReportedCondition: "",
        Location: "",
        Manufacturer: "",
        ModelNo: "",
        Organization: "",
        ProductCategory: "",
        User: "",
        StartDate: self.startDateForAddToRequest,
        EndDate: self.endDateForAddToRequest
      };
      data = _.assign(data, input);
      return data;
    }
    this.lastAddtoRequestSuggestion = input;
    this.addToRequestPaginationLoader = false;
    var processedInput = makeData(input);
    //chnange with GetLoanableAssetForAddToRequest

    Functions.GetLoanableAssetForAddToRequest(
      processedInput,
      this.addToRequestPagination
    )
      .then(resp => {
        this.borrowableAssetsforAddToRequest = [];
        this.borrowableAssetsforAddToRequest = resp.data.gridData.data;
        this.addToRequestPagination["total"] = resp.data.total;
        this.addToRequestPaginationLoader = true;
      })
      .catch(() => {
        this.addToRequestPaginationLoader = true;
      });
  };
  @action
  approveLoanRequest = record => {
    this.setIsRequestModalLoading(true);
    return Functions.SetApprovalOnLoanPoolRequest(
      "Approved",
      record.workFlowId || record.assets[0].workFlowId,
      record.RequestID || record.requestId,
      record.Requestor || record.RequestorName
    ).then(response => {
      if (response.data.success) {
        this.addingAvailabilityData = [];
        this.rerenderRequests(true, true).then(() => {
          UIFunctions.Toast("Request updated successfully!", "success");
          this.setIsRequestModalLoading(false);
        });
        this.setDoNotUpdateLPRequests(false);
      } else {
        UIFunctions.Toast(
          "The approval process could not be completed",
          "error"
        );
      }
    });
  };
  @action
  disapproveLoanRequest = (record, bool = false) => {
    this.setIsRequestModalLoading(true);
    return Functions.SetApprovalOnLoanPoolRequest(
      "Rejected",
      record.workFlowId || record.assets[0].workFlowId,
      record.RequestID || record.requestId,
      record.Requestor || record.RequestorName
    ).then(response => {
      if (response.data.success) {
        this.addingAvailabilityData = [];
        this.rerenderRequests(true, true).then(() =>{
          UIFunctions.Toast("Request updated successfully!", "success");
          this.setIsRequestModalLoading(false);
         });
        this.setDoNotUpdateLPRequests(false);
      } else {
        UIFunctions.Toast(
          "The Rejection process could not be completed",
          "error"
        );
      }
    });
  };
  @action
  cancelLoanRequest = (record, bool = false) => {
    this.setIsRequestModalLoading(true);
    return Functions.SetApprovalOnLoanPoolRequest(
      "Cancelled",
      record.workFlowId || record.assets[0].workFlowId,
      record.RequestID || record.requestId,
      record.Requestor || record.RequestorName
    ).then(response => {
      if (response.data.success) {
        if(this.reviewerMode)
        {
          this.rerenderRequests(true, true).then(() => {
            UIFunctions.Toast("Request updated successfully!", "success");
            this.setIsRequestModalLoading(false);
           });
        }
        else
        {
          this.rerenderRequests1(true, true).then(() =>{
            UIFunctions.Toast("Request updated successfully!", "success");
            this.setIsRequestModalLoading(false);

          }
          );
        }
        this.addingAvailabilityData = [];
        this.setDoNotUpdateLPRequests(false);
      } else {
        UIFunctions.Toast(
          "The Cancelation process could not be completed",
          "error"
        );
      }
    });
  };
  @action
  approveEquipmentRequest = record => {
    return Functions.SetEquipmentRequestApproval(
      "Approved",
      record.StreamId
    ).then(response => {
      if (response.data.success) {
        this.rerenderRequests(true, true).then(() =>
          UIFunctions.Toast("Request updated successfully!", "success")
        );
      } else {
        UIFunctions.Toast(
          "The approval process could not be completed",
          "error"
        );
      }
      this.addingAvailabilityData = [];
    });
  };
  @action
  disapproveEquipmentRequest = record => {
    return Functions.SetEquipmentRequestApproval(
      "Rejected",
      record.StreamId
    ).then(response => {
      if (response.data.success) {
        this.addingAvailabilityData = [];
        this.rerenderRequests(true, true).then(() =>
          UIFunctions.Toast("Request updated successfully!", "success")
        );
      } else {
        UIFunctions.Toast(
          "The disapproval process could not be completed",
          "error"
        );
      }
    });
  };
  @action
  markAsReturned = (record, date, bool = false) => {
    return Functions.MarkLoanedAssetAsReturned(record.workFlowId, date).then(
      response => {
        if (response.data.success) {
          bool
            ? this.rerenderRequests1(true, true).then(() =>
                UIFunctions.Toast("Asset has been returned", "success")
              )
            : this.rerenderRequests(true, true).then(() =>
                UIFunctions.Toast("Asset has been returned", "success")
              );
        } else {
          UIFunctions.Toast(
            "The return process could not be completed",
            "error"
          );
        }
      }
    );
  };
  //data filtering

  @action processLogRequest = data => {
    const dataa = data
    const request = JSON.parse(JSON.stringify(dataa)).map((i, index) => {
      i.key = "_" + index;
      return i;
    });
    return request
      .map(i => {
        if (i.assets.length > 0) {
          i.assets.map((i, index) => {
            i.key = "__" + index;
            return i;
          });
          i["children"] = i.assets;
        }
        return i;
      })
      .filter(i =>
        i.DisplayRequestId.startsWith("LP")
          ? i
          : ""
      );
  };

  //data filtering

  @action processAwaitingRequest = data => {
    const dataa = data.filter(
      i => i.status == "Open" || i.status == "Requested"
    );
    const request = JSON.parse(JSON.stringify(dataa)).map((i, index) => {
      i.key = "_" + index;
      return i;
    });
    return request
      .map(i => {
        if (i.assets.length > 0) {
          i.assets.map((i, index) => {
            i.key = "__" + index;
            return i;
          });
          i["children"] = i.assets.filter(e => e.status == "Requested");
        }
        return i;
      })
      .filter(i =>
        i.DisplayRequestId.startsWith("LP") &&
        i.assets.filter(status => status["status"] == "Requested").length > 0
          ? i
          : ""
      );
  };
  @action requestSubmittedToMe = (dataLoaded = false) => {
    this.dataLoadedForAllLP = dataLoaded;
    this.dataLoadedForApprovalLP = dataLoaded;
    if (this.doNotUpdateLPRequests) {
      this.dataLoadedForAllLP = true;
      this.dataLoadedForApprovalLP = true;
    } else {
      return Functions.GetAllLoanPoolRequests("SubmittedToMe").then(resp => {
        this.allLoanPoolRequests = [];
        this.allLoanPoolRequests = resp.data.allRequests;
        this.dataLoadedForAllLP = true;
        this.dataLoadedForApprovalLP = true;
      });
    }
  };
  @action setDoNotUpdateLPRequests = input => {
    this.doNotUpdateLPRequests = input;
  };
  @action
  rerenderRequests1 = (dataLoaded = false, approvalDataLoaded = false) => {
    this.dataLoadedForAllLP = dataLoaded;
    this.dataLoadedForSTMLP = dataLoaded;
    this.dataLoadedForApprovalLP = approvalDataLoaded;
    return Functions.GetAllLoanPoolRequests("SubmittedByMe").then(resp => {
      this.allLoanPoolRequests1 = [];
      var allLoanPoolRequests = [];
      allLoanPoolRequests = resp.data.allRequests;

      this.allLoanPoolRequests1 = allLoanPoolRequests;
      if (this.requestAwaitingModelOpen) {
        let awaitingRequest = this.processAwaitingRequest(
          this.allLoanPoolRequests1
        );
        this.requestAwaitingModelOpen = _.find(awaitingRequest, item => {
          return item.requestId == this.requestAwaitingModelOpen.requestId;
        });
      }
      if (this.isRequestModelModalOpen) {
        let requestModelModalOpen = this.processLogRequest(
          this.allLoanPoolRequests1
        );

        this.isRequestModelModalOpen = _.find(requestModelModalOpen, item => {
          return item.requestId == this.isRequestModelModalOpen.requestId;
        });
      }
      this.dataLoadedForAllLP = true;
      this.dataLoadedForSTMLP = true;
      this.dataLoadedForApprovalLP = true;
    });
  };

  @action
  rerenderRequests = (dataLoaded = false, approvalDataLoaded = false) => {
    this.dataLoadedForAllLP = dataLoaded;
    this.dataLoadedForSTMLP = dataLoaded;
    this.dataLoadedForApprovalLP = approvalDataLoaded;
    return Functions.GetAllLoanPoolRequests("SubmittedToMe").then(resp => {
      this.allLoanPoolRequests = [];
      var allLoanPoolRequests = [];
      allLoanPoolRequests = resp.data.allRequests;

      this.allLoanPoolRequests = allLoanPoolRequests;
      if (this.requestAwaitingModelOpen) {
        let awaitingRequest = this.processAwaitingRequest(
          this.allLoanPoolRequests
        );
        this.requestAwaitingModelOpen = _.find(awaitingRequest, item => {
          return item.requestId == this.requestAwaitingModelOpen.requestId;
        });
      }
      if (this.isRequestModelModalOpen) {
        let requestModelModalOpen = this.processLogRequest(
          this.allLoanPoolRequests
        );

        this.isRequestModelModalOpen = _.find(requestModelModalOpen, item => {
          return item.requestId == this.isRequestModelModalOpen.requestId;
        });
      }
      this.dataLoadedForAllLP = true;
      this.dataLoadedForSTMLP = true;
      this.dataLoadedForApprovalLP = true;
      Functions.BadgeCounterForApprover().then(response => {
        tabModelStore.loanPoolNotificationCount =
          response.data.notificationCount;
      });
    });
  };

  @action
  initializeLoanPool = (dataLoaded = false) => {
    this.dataLoaded = dataLoaded;
    this.dataLoadedForSTMLP = dataLoaded;
    if (this.doNotUpdate) {
      this.dataLoaded = true;
      this.dataLoadedForSTMLP = true;
      this.caPaginationLoader = false;
      this.getFilteredCheckAvailabiltyData();
    } else {
      this.caPaginationLoader = false;
      return Functions.GetLoanPoolDataModel().then(resp => {
        this.setGridDataModel(resp.data.data);
       
        Functions.GetLoanableAssetsDataForAdvancedSearch({
          StartDate: moment()
            .startOf("day")
            .toISOString(),
          EndDate: moment()
            .add(1, "M")
            .startOf("day")
            .toISOString(),
          AvailabilityThreshold: "",
          ModelNo: "",
          ProductCategory: "",
          Manufacturer: "",
          EquipmentNo: "",
          EquipmentType: "",
          LastReportedCondition: "",
          Organization: "",
          Location: "",
          Coordinator: "",
          User: ""
        }).then(resp => {
          this.borrowableAssets = resp.data.gridData.data;
          this.completeBorrowableAssets = resp.data.gridData.data;
          this.allBorrowableAssets = this.borrowableAssets;
          this.queryOutputBorrowableAssets = resp.data.gridData.data;
          this.caPaginationLoader = true;
          Functions.GetCartItems()
            .then(resp => {
              this.cartItems = resp.data.cartItems;
              let cartAssets = [];
              this.cartItems.map(i => {
                const { RequestedStartDate, RequestedEndDate, ...newdata } = i;
                let RequestDateRange = [RequestedStartDate, RequestedEndDate];

                cartAssets.push({
                  asset: i.UniqueID,
                  startDate: RequestedStartDate,
                  endDate: RequestedEndDate
                });
                newdata["RequestDateRange"] = RequestDateRange;
                i = newdata;
              });
              this.cartAssets = cartAssets;
              this.dataLoaded = true;
            })
            .then(() => {
              return Functions.GetAllLoanPoolRequests("SubmittedByMe").then(
                resp => {
                  this.allLoanPoolRequests1 = [];
                  this.allLoanPoolRequests1 = resp.data.allRequests;
                  this.dataLoadedForSTMLP = true;
                  
                  // let requestLogModelArray = [];
                  //   resp.data.allRequests
                  //     .map(i => i.assets)
                  //     .map(e => requestLogModelArray.push(...e));
                  //   const models = requestLogModelArray.map(i => i.ModelNo);
                  //   this.models = models;
                  //   this.dataLoadedForAllLP = true;
                  //   });
                  // })
                  // .then(() => {
                  //   const models = this.models;
                  //   Functions.GetModelDetails({
                  //     InputParams: { models }
                  //   }).then(resp => {
                  //     this.requestLogModelNoArray = resp.data.data;
                  //     this.dataLoadedForAllLP = true;
                  //   });
                }
              );
            });
        });
       
        // return Functions.GetCheckAvailabilityData(
        //   this.startDateAvailabilityData,
        //   this.endDateAvailabilityData,
        //   this.caPagination
        // )
        //   .then(resp => {
        //     this.checkAvailabilityItems = resp.data.availabilityData;
        //     this.currentPageCAAssets = resp.data.assets;
        //     this.caPagination["total"] = resp.data.total;
        //     this.getFilteredCheckAvailabiltyData();
        //     //this.caPaginationLoader = true;
        //   })
            if (this.manufacturerList) return true;
            return Functions.GetAdvancedSearchDropdownValues().then(resp => {
              var Orgjson = resp.data.GetOrganizationTree.tree;
              rr = null;
              this.process(Orgjson, "0", "0", false);
              var orgdta = "[" + rr + "]";
              var orgtdta = JSON.parse(orgdta);
              this.OrganizationTree = orgtdta;

              var Locjson = resp.data.GetLocationTree.tree;
              rr = null;
              this.process(Locjson, "0", "0", false);
              var locdta = "[" + rr + "]";
              var loctdta = JSON.parse(locdta);
              this.LocationTree = loctdta;

              var pagewisedata = resp.data.GetPageWiseDropDownValue.details;
              this.setPageWiseDropDownValues(pagewisedata);
              var manufacturerListData = resp.data.ManufacturerList;
              this.setManufacturerList(manufacturerListData);
              var usersForCustomerjson = resp.data.UserList;
              this.setUsersForCustomer(usersForCustomerjson);

              var coordinatorsForCustomerjson = resp.data.UserListCoordinators;
              this.setCoordinatorsForCustomer(coordinatorsForCustomerjson);
            });
          });
    }
  };
  @action
  rerenderCheckAvailability = () => {
    this.caPaginationLoader = false;
    const Assets = this.caCheckboxedItems.map(e => e.UniqueID);
    return Functions.GetCheckAvailabilityData(
      this.startDateAvailabilityData, //startDateAvailabilityData
      this.endDateAvailabilityData, //endDateAvailabilityData
      this.caPagination,
      Assets
    ).then(resp => {
      this.checkAvailabilityItems = resp.data.availabilityData;
      this.currentPageCAAssets = resp.data.assets;
      this.caPagination["total"] = resp.data.total;
      this.getFilteredCheckAvailabiltyData();
      this.caPaginationLoader = true;
    });
  };

  @action
  rerenderCheckAvailabilityCalender = () => {
    this.caAvailabilityLoader += 1;
    const Assets = this.caCheckboxedItems.map(e => e.UniqueID);
    Functions.GetCheckAvailabilityData(
      this.startDateAvailabilityData, //startDateAvailabilityData
      this.endDateAvailabilityData, //endDateAvailabilityData
      this.caPagination,
      Assets
    ).then(resp => {
      this.checkAvailabilityItems = resp.data.availabilityData;
      this.currentPageCAAssets = resp.data.assets;
      this.caPagination["total"] = resp.data.total;
      this.getFilteredCheckAvailabiltyData();
      this.caAvailabilityLoader -= 1;
    });
  };
  @action
  rerenderAddToRequest = () => {
    var self = this;
    this.addToRequestPaginationLoader = false;
    let input = this.lastAddtoRequestSuggestion;
    function makeData(input) {
      var data = {
        Coordinator: "",
        EquipmentNo: "",
        EquipmentType: "",
        LastReportedCondition: "",
        Location: "",
        Manufacturer: "",
        ModelNo: "",
        Organization: "",
        ProductCategory: "",
        User: "",
        StartDate: self.startDateForAddToRequest,
        EndDate: self.endDateForAddToRequest
      };
      data = _.assign(data, input);
      return data;
    }
    var processedInput = makeData(input);
    return Functions.GetLoanableAssetForAddToRequest(
      processedInput,
      this.addToRequestPagination
    )
      .then(resp => {
        this.borrowableAssetsforAddToRequest = [];
        this.borrowableAssetsforAddToRequest = resp.data.gridData.data;
        this.addToRequestPagination["total"] = resp.data.total;
        this.addToRequestPaginationLoader = true;
      })
      .catch(() => {
        this.addToRequestPaginationLoader = true;
      });
  };
  @action
  assetProgressUpdate = (text, record) => {
    try {
      this.dataLoadedForAllLP = false;
      Functions.SetProgressStatusForRequest(text, record.requestId)
        .then(response => {
          if (response.data.success) {
            setTimeout(() => {
              this.rerenderRequests(false, true).then(() => {
                this.dataLoadedForAllLP = true;
                this.setDoNotUpdateLPRequests(false);
                UIFunctions.Toast("Request updated successfully!", "success");
              });
            }, 200);
          } else {
            UIFunctions.Toast(
              "The request process could not be completed",
              "error"
            );
            this.dataLoadedForAllLP = true;
          }
        })
        .catch(err => (this.dataLoadedForAllLP = true));
    } catch (err) {
      this.dataLoadedForAllLP = true;
    }
  };

  process(json, tag, pos, currentValue) {
    var currentVal = currentValue;
    var toadd;
    if (json.text) {
      toadd =
        '{"label":"' +
        json.text +
        '",' +
        '"key":"' +
        tag +
        "-" +
        pos +
        '",' +
        '"value":"' +
        json.text +
        '",';
      if (currentVal) {
        toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          currentVal +
          " > " +
          json.text +
          '",';
        currentVal = currentVal + " > " + json.text;
      } else {
        currentVal = json.text;
      }
      if (rr) {
        rr = rr + toadd;
      } else {
        rr = toadd;
      }
    }
    if (json.expanded) {
      if (json.text) {
        toadd = '"children":[';
        rr = rr + toadd;
      }

      json.children.map((item, index) => {
        var poss = index + 1;
        this.process(item, tag + "-" + pos, poss, currentVal);
        toadd = ",";
        rr = rr + toadd;
      });
      rr = rr.slice(0, -1);
      if (json.text) {
        toadd = "]";
        rr = rr + toadd;
      }
    } else {
      rr = rr.slice(0, -1);
    }
    if (json.text) {
      toadd = "}";
      rr = rr + toadd;
    }

    return true;
  }

  @action
  setExternalRequestFormDetails = data => {
    this.externalRequestFormDetails = data;
  };

  @action
  setNewRequestFormDetails = data => {
    this.newRequestFormDetails = data;
  };
  @action
  setAvailabilityDates = data => {
    this.startDateCheckAvailability = data[0].toISOString();
    this.endDateCheckAvailability = data[1].endOf("day").toISOString();
    this.caPaginationLoader = false;
    // this.rerenderCheckAvailability();
  };

  @action
  setReviewerMode = bool => {
    this.reviewerMode = bool;
  };
  @action
  setIsModelModalOpen = data => {
    this.isModelModalOpen = data;
  };
  @computed
  get getDataLoaded() {
    return this.dataLoaded;
  }
  @action
  setInitialNormalViewMode = data => {
    this.initialNormalViewMode = data;
  };
  @action
  setNormalViewMode = data => {
    this.normalViewMode = data;
  };
  @action
  setReviewerViewMode = data => {
    this.reviewerViewMode = data;
  };
  @action
  setLastSelectedSuggestion = data => {
    this.lastSelectedSuggestion = data;
  };
  @action
  getPageWiseDropDownValues = dropDownName => {
    if (this.pageWiseDropDownValues) {
      const index = this.pageWiseDropDownValues.findIndex(
        obj => obj.DropdownName === dropDownName
      );
      return JSON.parse(
        JSON.stringify(this.pageWiseDropDownValues[index].DropDownValues)
      );
    } else {
      return ["error"];
    }
  };
  @action
  getManufacturerList = () => {
    return this.manufacturerList != null ? this.manufacturerList : ["error"];
  };
  @computed
  get getUsersForCustomer() {
    return this.usersForCustomer;
  }
  @computed
  get getCoordinatorForCustomer() {
    return this.coordinatorsForCustomer;
  }
  @action
  setCompleteBorrowableAssets = input => {
    this.completeBorrowableAssets = input;
  };
  @action
  setPageWiseDropDownValues = json => {
    this.pageWiseDropDownValues = json;
  };
  @action
  setUsersForCustomer = json => {
    this.usersForCustomer = json;
  };
  @action
  setCoordinatorsForCustomer = json => {
    this.coordinatorsForCustomer = json;
  };
  @action
  clearStore = () => {
    this.pageWiseDropDownValues = null;
    this.usersForCustomer = null;
  };
  @action
  setQueryOutputBorrowableAssets = data => {
    this.queryOutputBorrowableAssets = data;
  };
  @action
  addToCart = item => {
    // Functions. this has to be implemented after developing api
    return Functions.AddToCart(item).then(resp => {
      if (!resp.data.success) {
        return UIFunctions.Toast("Oops ! Something went wrong.", "error");
      }
      this.cartItems = resp.data.cartItems.cartItems;
      UIFunctions.Toast("Asset added to cart successfully!", "success");
      return resp;
    });
  };
  @action
  updateCartItems = item => {
    // Functions. this has to be implemented after developing api
    return Functions.UpdateCartItems(item).then(resp => {
      if (!resp.data.success) {
        return UIFunctions.Toast("Oops ! Something went wrong.", "error");
      }
      this.cartItems = resp.data.cartItems.cartItems;
      UIFunctions.Toast(
        "Asset Details in cart updated successfully!",
        "success"
      );
      return resp;
    });
  };
  @action
  removeFromCart = item => {
    // Functions. this has to be implemented after developing api
    return Functions.RemoveFromCart(item).then(resp => {
      if (!resp.data.success) {
        return UIFunctions.Toast("Oops ! Something went wrong.", "error");
      }
      this.cartItems = resp.data.cartItems.cartItems;
      UIFunctions.Toast("Asset removed from cart successfully!", "success");
      return resp;
    });
  };

  //to claer cart after request complete
  @action
  clearCart = () => {
    return Functions.ClearCart().then(resp => {
      if (!resp.data.success) {
        return UIFunctions.Toast("Oops ! Something went wrong.", "error");
      }
    });
  };
  @action
  setCheckAvailabiltySwitchState = bool => {
    this.CheckAvailabiltySwitchState = bool;
  };
  @action
  getFilteredCheckAvailabiltyData = () => {
    const checkAvailabilityItems = mobx.toJS(this.checkAvailabilityItems);
    let addingAvailabilityData = mobx.toJS(this.addingAvailabilityData);
    let filteredItemsToShowCheckAvailability = mobx.toJS(
      this.filteredItemsToShowCheckAvailability
    );
    let currentPageCAAssets = mobx.toJS(this.currentPageCAAssets);
    let itemsToShowCheckAvailability = [];
    filteredItemsToShowCheckAvailability = [];
    let itemsThisPage = [];
    // let newarray = [];
    // Object.keys(checkAvailabilityItems).map(i => {
    //   console.log("itemmm",i);
    //   i=i.substring(0, i.indexOf('-'));
    //   console.log("slice",i);
    //   newarray.push(i);
    // })
    // let unique = [...new Set(newarray)];
    this.borrowableAssets.map(i => {
      currentPageCAAssets.map(element => {
        if (element == i.UniqueID) {
          itemsThisPage.push(i);
        }
      });
    });
    addingAvailabilityData.push(checkAvailabilityItems);
    itemsToShowCheckAvailability.push(itemsThisPage);
    itemsToShowCheckAvailability.push(addingAvailabilityData);
    this.addingAvailabilityData = addingAvailabilityData;
    this.itemsToShowCheckAvailability = [];
    this.itemsToShowCheckAvailability = itemsToShowCheckAvailability;
    this.filteredItemsToShowCheckAvailability = [];
    this.filteredItemsToShowCheckAvailability = itemsToShowCheckAvailability;
    this.caPaginationLoader = true;
  };
}

const loanPoolStoreV2 = new LoanPoolStoreV2();

export default loanPoolStoreV2;
