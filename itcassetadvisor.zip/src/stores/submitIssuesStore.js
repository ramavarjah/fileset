import { observable, action, computed } from "mobx";

class SubmitIssuesStore {
  // @observable addAssetsOpen;
  // @observable pageWiseDropDownValues;
  // @observable orgs;
  // @observable equipmentNumberSequence;
  // @observable OrganizationTree;
  // @observable renderedOrganizationTree;
  // @observable locationTree;
  // @observable customerAssets;
  // @observable templates;
  // @observable orgTree;
  // @observable lastAsset;
  // @observable usersForCustomer;
  // @observable healthModalOpen;
  // @observable assetDetailModalOpen;
  // @observable singleClick;
  // @observable doubleClick;
  // @observable setRowData;
  // @observable setHealthClassName;
  // @observable testField;
  @observable
  issuesSubmittedByMe;
  @observable
  issuesAssignedToMe;
  @observable
  selectedIssueData;
  @observable
  openIssueForm;
  @observable
  isSubmitNewIssue;
  @observable
  isSubmittedByMeTabActive;
  @observable
  editing;
  @observable
  SpinFlag;
  @observable
  submitting;
  constructor() {
    this.issuesAssignedToMe = [];
    this.issuesSubmittedByMe = [];
    this.selectedIssueData = {};
    this.openIssueForm = false;
    this.isSubmitNewIssue = false;
    this.isSubmittedByMeTabActive = false;
    this.editing = false;
    this.SpinFlag = false;
    this.submitting = false;
    // this.testField='';
    // this.addAssetsOpen=false;
    // this.healthModalOpen=false;
    // this.rowData=null;
    // this.singleClick=false;
    // this.pageWiseDropDownValues = null;
    // this.orgs = null;
    // this.equipmentNumberSequence = null;
    // this.OrganizationTree=null;
    // this.renderedOrganizationTree=null;
    // this.locationTree=null;
    // this.customerAssets=null;
    // this.templates=null;
    // this.orgTree=[];
    // this.lastAsset=null;
    // this.usersForCustomer=null;
    // this.assetDetailModalOpen = false;
  }
  // @action getPageWiseDropDownValues=(dropDownName)=>{
  //   //   console.log("Finding",dropDownName,"on",JSON.stringify(this.pageWiseDropDownValues));
  //   if(this.pageWiseDropDownValues){
  //     const index = this.pageWiseDropDownValues.findIndex(obj => obj.DropdownName === dropDownName);
  //     return JSON.parse(JSON.stringify(this.pageWiseDropDownValues[index].DropDownValues));
  //   }else {
  //       return ["error"]
  //   }
  //   }
  // @computed get getOrgs(){
  //     return this.orgs;
  //   }
  // @computed get getOrgTree(){
  //     return this.orgTree;
  //   }
  // @computed get getEquipmentNumberSequence(){
  //     return this.equipmentNumberSequence;
  //   }
  // @computed get getOrganizationTree(){
  //     return this.OrganizationTree;
  //   }
  // @computed get getRenderedOrganizationTree(){
  //     return this.OrganizationTree;
  //   }
  // @computed get getLocationTree(){
  //     return this.locationTree;
  //   }
  // @computed get getCustomerAssets(){
  //     return this.customerAssets;
  //   }
  // @computed get getLastCustomerAssets(){
  //     var assets=this.lastAsset;
  //   }
  // @computed get getTemplates(){
  //     return this.templates;
  //   }
  // @computed get getUsersForCustomer(){
  //   return this.usersForCustomer;
  // }
  // @action setTestField = (bool) => {
  //   this.testField = bool;
  // }
  // @action setHealthModalOpen = (bool) => {
  //   this.healthModalOpen = bool;
  // }
  // @action setSingleClick = (bool) => {
  //   this.singleClick = bool;
  // }
  // @action setDoubleClick = (bool) => {
  //   this.doubleClick = bool;
  // }
  // @action setRowData = (json) => {
  //   this.rowData = json;
  // }
  // @action setHealthClassName = (json) => {
  //   this.healthClassName = json;
  // }
  // @action setAddAssetsOpen = (bool) => {
  //   this.addAssetsOpen = bool;
  // }
  // @action setPageWiseDropDownValues = (json) => {
  //   this.pageWiseDropDownValues = json;
  // }
  // @action setOrgs = (json) => {
  //   this.orgs = json;
  // }
  // @action addOrgTree = (json) => {
  //   this.orgTree.pus
  // }
  // @action setEquipmentNumberSequence = (json) => {
  //   this.equipmentNumberSequence= json;
  // }
  // @action setOrganizationTree = (json) => {
  //   this.OrganizationTree= json;
  // }
  // @action setUsersForCustomer = (json) => {
  //   this.usersForCustomer= json;
  // }
  // @action setRenderedOrganizationTree = (json) => {
  //   this.RenderedOrganizationTree= json;
  // }
  // @action setLocationTree = (json) => {
  //   this.locationTree= json;
  // }
  // @action setCustomerAssets = (json) => {
  //   this.customerAssets= json;
  // }
  // @action setLastAsset = (json) => {
  //   this.lastAsset= json;
  // }
  // @action setTemplates = (json) => {
  //   this.templates = json;
  // }
  @action
  setIssuesAssignedToMe = bool => {
    var AssignedIssues = [];
    bool.map(item => {
      item.Type = "Assigned to Me";
      AssignedIssues.push(item);
    });
    this.issuesAssignedToMe = AssignedIssues;
  };
  @action
  setIssuesSubmittedByMe = bool => {
    var SubmittedIssues = [];
    bool.map(item => {
      item.Type = "Submitted by Me";
      SubmittedIssues.push(item);
    });
    this.issuesSubmittedByMe = SubmittedIssues;
  };
  @action
  setSpinFlag(bool) {
    this.SpinFlag = bool;
  }
  @action
  setIsSubmitNewIssue = bool => {
    this.isSubmitNewIssue = bool;
  };
  @action
  setEditing = bool => {
    this.editing = bool;
  };
  @action
  setSubmitting = bool => {
    this.submitting = bool;
  };
  @computed
  get getIsSubmitNewIssue() {
    return this.isSubmitNewIssue;
  }
  @action
  getRowIssuesAssignedToMe = i => this.issuesAssignedToMe[i];
  @action
  getRowIssuesSubmittedByMe = i => this.issuesSubmittedByMe[i];
  @action
  setSelectedIssueData = data => {
    this.selectedIssueData = data;
  };
  @action
  toggleOpenIssueForm = () => {
    this.openIssueForm = !this.openIssueForm;
  };
  @action
  setIsSubmittedByMeTabActive = bool => {
    this.isSubmittedByMeTabActive = bool;
  };
  @action
  addToSelectedIssueData = ss => {
    this.editing = true;
    var currentState = this.selectedIssueData;
    for (var i = 0; i < Object.keys(ss).length; i++) {
      currentState[Object.keys(ss)[i]] = Object.values(ss)[i];
    }
    this.selectedIssueData = currentState;
  };

  @action
  addToSelectedIssueDataFromCode = ss => {
    var currentState = this.selectedIssueData;
    for (var i = 0; i < Object.keys(ss).length; i++) {
      currentState[Object.keys(ss)[i]] = Object.values(ss)[i];
    }
    this.selectedIssueData = currentState;
  };
  @action
  markAsReadAssignedToMe = row => {
    var newArray = [];
    this.issuesAssignedToMe.map(item => {
      var newGriddata = item;
      if (item.IssueId == row.IssueId) {
        item.read = true;
      }
      newArray.push(newGriddata);
    });
    this.issuesAssignedToMe = newArray;
    return true;
  };
  @action
  markAsReadSubmittedByMe = row => {
    var newArray = [];
    this.issuesSubmittedByMe.map(item => {
      var newGriddata = item;
      if (item.IssueId == row.IssueId) {
        item.read = true;
      }
      newArray.push(newGriddata);
    });
    this.issuesSubmittedByMe = newArray;
    return true;
  };
}

const submitIssuesStore = new SubmitIssuesStore();

export default submitIssuesStore;
