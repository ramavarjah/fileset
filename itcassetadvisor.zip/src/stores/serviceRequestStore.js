import { observable, action } from "mobx";
import moment from "moment";
import React from "react";
import _ from "lodash";
import Functions from "../api/Functions";
import tabModelStore from "./tabModelStore";
import mobx from "mobx";

import GREY from "../../assets/images/health_icons/grey_dot.svg";

import health_green from "../../assets/images/health_icons/green_dot.svg";
import health_green_fade from "../../assets/images/health_icons/green_dot_fade.svg";
import health_red from "../../assets/images/health_icons/red_dot.svg";
import health_red_fade from "../../assets/images/health_icons/red_dot_fade.svg";
import health_yellow from "../../assets/images/health_icons/yellow_dot.svg";
import health_yellow_fade from "../../assets/images/health_icons/yellow_dot_fade.svg";

// import addAssetsStore from './addAssetsStore';

class ServiceRequestStore {
	@observable
	requestDummyData;
	@observable
	rowSelectedAssetsData;
	@observable
	serviceRequestfilterModalOpen;
	@observable
	startDate;
	@observable
	endDate;
	@observable
	dataLoaded;
	@observable
	editRowData;
	@observable
	serviceRequestHistory;
	@observable
	servicerequestsLoading;
	@observable
	serviceRequestsCheckAvailability;
	@observable
	ServiceRequestAssetsData;
	@observable
	newReq_SrItems;
	@observable
	responseData;
	@observable
	response_confirmation;
	@observable
	editFlag;

	@observable
	lastPayload;
	@observable
	formDropDownData;
	@observable
	serviceRequestFilter;
	@observable
	gridDataModel;

	constructor() {
		this.newReq_SrItems = [];
		this.rowSelectedAssetsData = [];
		this.requestDummyData = [];
		this.ServiceRequestAssetsData = [];
		this.serviceRequestfilterModalOpen = false;
		this.editRowData = {};
		this.servicerequestsLoading = true;
		this.serviceRequestHistory = [];
		this.serviceRequestsCheckAvailability = [];
		this.serviceRequestFilter = "";
		this.gridDataModel = [];
		this.responseData = {
			result: {
				sritems: []
			}
		};
		this.editFlag = true;
		this.SelectedAssetsGridColumn = [
			{ field: "EquipmentNo", headerName: "Equipment Number" },
			{ field: "Manufacturer", headerName: "Manufacturer" },
			{ field: "ModelNo", headerName: "Model Number" },
			{ field: "SerialNo", headerName: "Serial Number" },
			{ field: "CalibrationType", headerName: "Calibration Type" },
			{ field: "CalibrationInterval", headerName: "Calibration Interval" },
			{ field: "CalibrationDueDate", headerName: "Calibration Due Date" }
		];
		this.SelectAssetsGridColumn = [
			{
				headerName: "",
				width: 50,
				minWidth: 50,
				headerCheckboxSelection: true,
				checkboxSelection: true,
				suppressMovable: true,
				suppressFilter: true,
				suppressSorting: true,
				suppressMenu: true,
				suppressResize: true
			},
			{ field: "EquipmentNo", headerName: "Equipment Number" },
			{ field: "Manufacturer", headerName: "Manufacturer" },
			{ field: "ModelNo", headerName: "Model Number" },
			{ field: "SerialNo", headerName: "Serial Number" },
			{ field: "Description", headerName: "Description" },
			{ field: "CalibrationInterval", headerName: "Calibration Interval" },
			{ field: "CalibrationDueDate", headerName: "Calibration Due Date" },
			{ field: "LifeCycleStage", headerName: "Life Cycle Stage" },
			{ field: "LastReportedCondition", headerName: "Last Reported Condition" },
			{ field: "CalibrationProvider", headerName: "Calibration Provider" },
			{ field: "ServiceLogistics", headerName: "Service Logistics" },
			{ field: "CalibrationType", headerName: "Calibration Type" },
			{ field: "LastCalibrationDate", headerName: "Last Calibration Date" },
			{ field: "ServiceCost", headerName: "Service Cost" },
			{ field: "RepairProvider", headerName: "Repair Provider" }
		];
		this.response_confirmation = {
			result: {
				sritems: []
			}
		};
		this.gridOptions = {
			defaultColDef: {
				//  headerComponentFramework: SortableHeaderComponent,
				headerComponentParams: {
					menuIcon: "fa-bars"
				}
			},
			// this is a simple property
			rowBuffer: 10, // no need to set this, the default is fine for almost all scenarios,
			//  floatingFilter: true
			rowHeight: 30
		};
		this.startDate = moment();
		this.endDate = moment().add(1, "months");
		this.NewReq_basepayload = {
			permissionkey: "hydraxtest",
			reqprefix: "",
			reqlastname: "",
			reqfirstname: "",
			reqemail: "",
			reqphone: "",
			reqfax: "",
			reqline1: "",
			reqline2: "",
			reqline3: "",
			reqline4: "",
			reqcompanyname: "",
			reqstate: "",
			reqpostalcode: "",
			reqcity: "",
			reqcountry: "",
			biladdresscontact: "",
			biladdressphone: "",
			biladdresscompanyname: "",
			biladdressline1: "",
			biladdressline2: "",
			biladdressline3: "",
			biladdresscity: "",
			biladdresspostalcode: "",
			biladdressstate: "",
			biladdresscountry: "",
			biladdressvatid: "",
			pickupoption: "",
			pickupcontact: "",
			pickupphone: "",
			pickupcompanyname: "",
			pickupline1: "",
			pickupline2: "",
			pickupline3: "",
			pickupline4: "",
			pickupcity: "",
			pickuppostalcode: "",
			pickupprovince: "",
			pickupstate: "",
			pickupcountry: "",
			returnoption: "",
			returncontact: "",
			returnphone: "",
			returncompanyname: "",
			returnline1: "",
			returnline2: "",
			returnline3: "",
			returnline4: "",
			returncity: "",
			returnpostalcode: "",
			returnprovince: "",
			returnstate: "",
			returncountry: "",
			sritems: []
		};
		this.lastPayload = this.NewReq_basepayload;
		this.formDropDownData = {};
	}
	@action
	setResponseData = row => {
		this.responseData = row;
	};
	@action
	setEditRowData = row => {
		this.editRowData = row;
	};
	@action
	setEditFlag = boolean => {
		this.editFlag = boolean;
	};
	@action
	clearEditRowData = () => {
		this.editRowData = {};
	};
	@action
	setServiceRequestFilter = rows => {
		this.serviceRequestFilter = rows;
	};

	@action
	serviceRequestNewAddCheck = rows => {
		this.rowSelectedAssetsData = rows;
	};
	@action
	serviceRequestAddNewItem = row => {
		this.rowSelectedAssetsData.push(row);
		return;
	};
	@action
	setServiceRequestLoading = bool => {
		this.servicerequestsLoading = bool;
	};

	@action
	serviceRequestInitDummyData = rows => {
		this.requestDummyData = rows;
	};

	@action
	setServiceRequestFilterModalopen = bool => {
		this.serviceRequestfilterModalOpen = bool;
	};

	@action
	setNewReq_basepayload = (key, val) => {
		this.NewReq_basepayload[key] = val;
	};

	@action
	setGridDataModel = data => {
		let rows = [];
		for (let i = 0; i < data.length; i++) {
			if (!data[i].hidden) {
				var item = {
					key: data[i].dataIndex,
					sortable: data[i].sortable,
					name: data[i].text
				};
				rows.push(item);
			}
		}
		this.gridDataModel = rows;
	};

	@action
	initializeData = () => {
		this.setServiceRequestLoading(true);
		return Functions.GetCustomerServiceRequests()
			.then(resp => {
				this.setServiceRequestHistory(resp.data.data);
				this.setServiceRequestLoading(false);
			})
			.catch(() => {
				this.setServiceRequestLoading(false);
			});
	};

	@action
	setRange = data => {
		this.startDate = data[0].toISOString();
		this.endDate = data[1].toISOString();
		var date = moment(this.startDate);
		var now = moment();
		//86400000
		if (date.isBefore(now, "day")) {
			this.dateValidator = {
				message: "Start date should not be a past day",
				valid: false,
				mode: "warning"
			};
		} else {
			this.dateValidator = {
				message: "",
				valid: true,
				mode: "success"
			};
			this.servicerequestsLoading = true;
			return this.initializeDataNewRequest().then(() => {
				return Functions.GetServiceDueDateData(
					tabModelStore.getActiveTab.TabId
				).then(resp => {
					this.serviceRequestsCheckAvailability = resp.data.data;
					this.servicerequestsLoading = false;
					return true;
				});
			});
		}
	};
	@action
	setStartDate = data => {
		this.startDate = data;
		var date = moment(this.startDate);
		var now = moment();
		if (date.isBefore(now, "day")) {
			this.dateValidator = {
				message: "Start date should not be a past day",
				valid: false,
				mode: "warning"
			};
		} else {
			this.dateValidator = {
				message: "",
				valid: true,
				mode: "success"
			};
			this.dataLoaded = false;
		}
	};

	@action
	generateDateColumns() {
		if (this.gridOptions.api) {
			this.gridOptions.api.hideOverlay();
			this.gridOptions.api.sizeColumnsToFit();
		}
	}
	parseMonth(data) {
		var months = [];
		months = _.groupBy(data, function(b) {
			return b.month;
		});
		var array = [];
		for (var i = 0; i < Object.keys(months).length; i++) {
			var child = {};
			child.headerName = moment(Object.keys(months)[i], "MM").format("MMMM");
			child.children = Object.values(months)[i];
			array.push(child);
		}
		return array;
	}

	@action
	setEndDate = data => {
		this.endDate = data;
	};

	@action
	setServiceRequestHistory = data => {
		this.serviceRequestHistory = data;
	};
	@action
	setServiceRequestAssetsData = data => {
		this.ServiceRequestAssetsData = data;
	};
	@action
	updateSritems = inputItem => {
		//input from the form which keyts are starting with capital letter
		inputItem.updatedFlag = true;
		this.rowSelectedAssetsData.map((item, index) => {
			if (
				inputItem.ModelNo == item.ModelNo &&
				inputItem.SerialNo == item.SerialNo
			) {
				var mergedItem = Object.assign(item, inputItem);
				this.rowSelectedAssetsData[index] = mergedItem;
			}
		});
	};
	@action
	updateSritemsold = inputItem => {
		//input from the form which keyts are starting with capital letter
		var existingItem = false;
		this.newReq_SrItems.map((item, index) => {
			if (
				inputItem.ModelNo == item.ModelNo &&
				inputItem.SerialNo == item.SerialNo
			) {
				this.newReq_SrItems[index] = inputItem;
				existingItem = true;
			}
		});
		if (!existingItem) {
			var temp = mobx.toJS(this.newReq_SrItems);
			temp.push(inputItem);
			this.newReq_SrItems = temp;
		}
	};

	@action
	initializeDataNewRequest = () => {
		this.servicerequestsLoading = true;
		return Functions.GetGridDataModel("1").then(resp => {
			this.setGridDataModel(resp.data.data);
			Functions.GetCompleteGridData("1").then(resp => {
				var renderer = resp.data.data;
				let rows = [];
				for (let i = 0; i < renderer.length; i++) {
					var item = renderer[i];
					item.OrderDate =
						item.OrderDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.OrderDate).format("YYYY/MM/DD");
					item.ReceivedDate =
						item.ReceivedDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.ReceivedDate).format("YYYY/MM/DD");
					item.InventoryDate =
						item.InventoryDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.InventoryDate).format("YYYY/MM/DD");
					item.BookValueDate =
						item.BookValueDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.BookValueDate).format("YYYY/MM/DD");
					item.PlannedDisposalDate =
						item.PlannedDisposalDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.PlannedDisposalDate).format("YYYY/MM/DD");
					item.ReplacementDate =
						item.ReplacementDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.ReplacementDate).format("YYYY/MM/DD");
					item.ServiceDueDate =
						item.ServiceDueDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.ServiceDueDate).format("YYYY/MM/DD");
					item.LastUpdate =
						item.LastUpdate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.LastUpdate).format("YYYY/MM/DD");
					item.CalibrationDate =
						item.CalibrationDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.CalibrationDate).format("YYYY/MM/DD");
					item.CalibrationDueDate =
						item.CalibrationDueDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.CalibrationDueDate).format("YYYY/MM/DD");
					item.LastServiceDate =
						item.LastServiceDate == "1970-01-01T00:00:00.000Z"
							? null
							: moment(item.LastServiceDate).format("YYYY/MM/DD");
					item.BookValue = item.BookValue == -999999 ? "" : item.BookValue;
					item.LoanDailyCost =
						item.LoanDailyCost == -999999 ? "" : item.LoanDailyCost;
					item.CalibrationInterval =
						item.CalibrationInterval == -999999 ? "" : item.CalibrationInterval;
					item.ServiceCost =
						item.ServiceCost == -999999 ? "" : item.ServiceCost;
					item.PurchasePrice =
						item.PurchasePrice == -999999 ? "" : item.PurchasePrice;
					item.Depreciation =
						item.Depreciation == -999999 ? "" : item.Depreciation;
					if (item.IsUtilization) {
						if (renderer[i].HealthStatus == "GREEN") {
							item.formatter = "ImageFormatter";
							item.HealthCode = "GREEN";
							item.IsConnected
								? (item.HealthStatus = (
										<img src={health_green} width={24} title={"GREEN"} />
								  ))
								: (item.HealthStatus = (
										<img src={health_green_fade} width={24} title={"GREEN"} />
								  ));
						} else if (renderer[i].HealthStatus == "YELLOW") {
							item.formatter = "ImageFormatter";
							item.HealthCode = "YELLOW";
							item.IsConnected
								? (item.HealthStatus = (
										<img src={health_yellow} width={24} title={"YELLOW"} />
								  ))
								: (item.HealthStatus = (
										<img src={health_yellow_fade} width={24} title={"YELLOW"} />
								  ));
						} else if (renderer[i].HealthStatus == "RED") {
							item.formatter = "ImageFormatter";
							item.HealthCode = "RED";
							item.IsConnected
								? (item.HealthStatus = (
										<img src={health_red} width={24} title={"RED"} />
								  ))
								: (item.HealthStatus = (
										<img src={health_red_fade} width={24} title={"RED"} />
								  ));
						} else {
							item.formatter = "ImageFormatter";
							item.HealthCode = "GREY";
							item.HealthStatus = <img src={GREY} width={24} title={"GREY"} />;
						} //else put some grey icon
					} else {
						item.formatter = "ImageFormatter";
						item.HealthCode = "GREY";
						item.HealthStatus = <img src={GREY} width={24} title={"GREY"} />;
					}

					rows.push(item);
				}
				return Functions.GetFilters("1").then(resp => {
					this.setServiceRequestFilter(resp.data.baseQuery);
					this.setServiceRequestAssetsData(rows);
					this.servicerequestsLoading = false;
					return true;
				});
			});
		});
	};
	@action
	clearServiceRequestFilter = () => {
		Functions.ClearFilters(1).then(() => {
			this.initializeDataNewRequest();
		});
	};

	@action
	reRenderGrid = () => {
		this.initializeData();
	};
	parseSRItems = () => {
		var sritems = [];
		this.rowSelectedAssetsData.map(item => {
			var sritem = {};
			sritem.manufacturer = item.Manufacturer ? item.Manufacturer : ""; //todo field names has to be cross verified
			sritem.modelno = item.ModelNo ? item.ModelNo : "";
			sritem.serialno = item.SerialNo ? item.SerialNo : "";
			sritem.custassetno = item.AssetNo ? item.AssetNo : "";
			sritem.calcycle = item.CalibrationInterval
				? item.CalibrationInterval
				: "";
			sritem.agreementno = item.agreementno ? item.agreementno : "";
			sritem.paymentmethod = item.paymentmethod ? item.paymentmethod : "";
			sritem.purchaseorderno = item.purchaseorderno ? item.purchaseorderno : "";
			sritem.attachpurchaseorderfilename = item.attachpurchaseorderfilename
				? item.attachpurchaseorderfilename
				: "";
			sritem.attachpurchaseorderfile = item.attachpurchaseorderfile
				? item.attachpurchaseorderfile
				: "";
			sritem.attachfaultreportfilename = item.attachfaultreportfilename
				? item.attachfaultreportfilename
				: "";
			sritem.attachfaultreportfile = item.attachfaultreportfile
				? item.attachfaultreportfile
				: "";
			sritem.requestedservice = item.requestedservice
				? item.requestedservice
				: "";
			sritem.preferreddate = item.preferreddate ? item.preferreddate : "";
			sritem.fault = item.fault ? item.fault : "";
			sritems.push(sritem);
		});
		return sritems;
	};

	@action
	conformBudgetaryQuote = () => {
		this.servicerequestsLoading = true;
		let params = {};
		params.permissionkey = "hydraxtest";
		params.csrid = this.responseData.result.csrid
			? this.responseData.result.csrid
			: "";
		return Functions.serviceRequest(params, "SRCreateRequest").then(resp => {
			this.response_confirmation = resp.data.details;
			this.servicerequestsLoading = false;
		});
	};
	@action
	markAsRead = row => {
		var newArray = [];
		this.serviceRequestHistory.map(item => {
			var newGriddata = item;
			if (item.ServiceRequestID == row.ServiceRequestID) {
				item.read = true;
			}
			newArray.push(newGriddata);
		});
		this.serviceRequestHistory = newArray;
		return true;
	};

	@action
	getBudgetaryQuote = payload => {
		this.servicerequestsLoading = true;
		var actualPayload = payload;
		actualPayload.sritems = this.parseSRItems();
		this.lastPayload = actualPayload; //taking backup if edit is needed in budgetary confirmation page we can reuse this only have to change the sritems
		return Functions.serviceRequest(actualPayload, "SRValidateRequest").then(
			resp => {
				this.servicerequestsLoading = false;
				serviceRequestStore.setResponseData(resp.data.details);
				return resp.data.details;
			}
		);
	};
	@action
	refreshBudgetaryQuote = () => {
		this.servicerequestsLoading = true;
		var actualPayload = this.lastPayload;
		actualPayload.sritems = this.parseSRItems();
		this.lastPayload = actualPayload; //taking backup if edit is needed in budgetary confirmation page we can reuse this only have to change the sritems
		return Functions.serviceRequest(actualPayload, "SRValidateRequest").then(
			resp => {
				serviceRequestStore.setResponseData(resp.data.details);
				this.servicerequestsLoading = false;
			}
		);
	};
	@action
	removeFromSRItems(data) {
		var newSritems = [];
		this.rowSelectedAssetsData.map(item => {
			const itm = mobx.toJS(item);
			data.modelno == itm.ModelNo && data.serialno == itm.SerialNo
				? "" //dont push to new items (delete operation)
				: newSritems.push(item);
		});
		this.rowSelectedAssetsData = newSritems;
		return this.refreshBudgetaryQuote();
	}
	@action
	getFormDropDownData() {
		var permissionkey = "hydraxtest";
		var isocode = "US";
		var req = {
			permissionkey: permissionkey,
			isocode: isocode
		};

		return Functions.serviceRequest(req, "SRGetCountryInfo").then(resp => {
			this.formDropDownData = resp.data.details.result;
			return resp;
		});
	}
}

const serviceRequestStore = new ServiceRequestStore();

export default serviceRequestStore;
