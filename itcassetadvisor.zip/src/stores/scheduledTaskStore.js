import { observable, action, computed } from 'mobx';

class ScheduledTaskStore {

  @observable scheduledTasks;
  @observable editable;

  constructor() {
    this.scheduledTasks = [];
    this.editable = false;
  }

  @computed get getScheduledTasks() {
    return this.scheduledTasks;
  }

  @computed get getEditable() {
   return this.editable;
  }

  @action setEditable = (editable) => {
   this.editable = editable;
  }

  @action setScheduledTasks = (scheduledTasks) => {
    this.scheduledTasks = JSON.parse(scheduledTasks);
  }
}

const scheduledTaskStore = new ScheduledTaskStore();

export default scheduledTaskStore;
