import { observable, action } from "mobx";

class ForgotPasswordStore {
  @observable
  assetDetailModalOpen;
  @observable
  emailid;

  constructor() {
    this.assetDetailModalOpen = false;
    this.emailid = null;
  }
  @action
  toggleModal = () => {
    this.assetDetailModalOpen = !this.assetDetailModalOpen;
  };
}

const ForgotPasswordStore1 = new ForgotPasswordStore();
export default ForgotPasswordStore1;
