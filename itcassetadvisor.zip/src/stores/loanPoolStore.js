import { observable, action, computed } from "mobx";
import Functions from "../api/Functions";
import userStore from "./userStore";
import dateArray from "moment-array-dates";
import UIFunctions from "../helpers/UIFunctions";
import moment from "moment";
import _ from "lodash";

class LoanPoolStore {
  //notification screen
  @observable
  allLoanPoolRequests;
  @observable
  allLoanPoolRequestsDataLoaded;

  @observable
  initialized;
  @observable
  dataLoaded;
  @observable
  submitEnabled;

  //pagination
  @observable
  currentPage;
  @observable
  currentStartingItem;
  @observable
  currentLimit;
  @observable
  startDate;
  @observable
  endDate;
  @observable
  dateValidator;

  @observable
  startDateCheckAvailability;
  @observable
  endDateCheckAvailability;

  @observable
  selectedAssets;
  @observable
  selectedAssetsFull;
  @observable
  gridDataModel;
  @observable
  gridDataModelLoaded;
  @observable
  enableEquipmentRequest;

  @observable
  gridOrgs;
  @observable
  gridOrgsLoaded;

  @observable
  loanPoolFilter;
  @observable
  loanPoolFilterLoaded;

  @observable
  loanableAssetsForCustomer;
  @observable
  loanableAssetsForCustomerLoaded;
  @observable
  loanableAssetsForCustomerLength;

  @observable
  loanableAssetsForCustomerLoanpoolGrid;
  @observable
  loanableAssetsForCustomerLoanpoolGridLoaded;
  @observable
  loanableAssetsForCustomerLoanpoolGridLength;
  @observable
  loanableAssetsForCustomerLoanpoolGridTotal;

  @observable
  justification;
  @observable
  location;
  @observable
  mobile;
  @observable
  currentStep;
  @observable
  modelNumber;
  @observable
  manufacturer;
  @observable
  description;
  @observable
  notes;
  @observable
  ChargeBack;
  @observable
  loanPoolfilterModalOpen;
  @observable
  dataLoaded;
  @observable
  activeTab;
  @observable
  gridOptions;

  @observable
  notificationSelected;
  @observable
  columnDefs;
  @observable
  loanPoolNotificationLoading;
  @observable
  loanPoolFilterQuery;
  @observable
  isButtonDisabled;
  @observable
  isLoading;
  @observable
  submittingReject;
  @observable
  submittingApprove;

  constructor() {
    this.loanPoolfilterModalOpen = false;
    this.currentStep = "step1";
    this.selectedAssets = [];
    this.selectedAssetsFull = [];
    this.enableEquipmentRequest = false;
    this.initialized = false;
    this.dataLoaded = false;
    this.submitEnabled = true;
    this.currentPage = 1;
    this.currentStartingItem = 0;
    this.currentLimit = 25;
    this.dataLoaded = true;
    this.startDate = moment();
    this.endDate = moment().add(1, "months");
    this.startDateCheckAvailability = moment()
      .startOf("day")
      .toISOString();
    this.endDateCheckAvailability = moment()
      .add(1, "months")
      .endOf("day")
      .toISOString();
    this.activeTab = null;
    this.gridDataModel = "";
    this.gridDataModelLoaded = false;
    this.columnDefs = [];
    this.gridOrgs = "";
    this.gridOrgsLoaded = false;
    this.loanPoolFilter = "";
    this.loanPoolFilterLoaded = false;
    this.isButtonDisabled = false;
    this.isLoading = false;
    this.submittingReject = false;
    this.submittingApprove = false;
    this.loanableAssetsForCustomer = "";
    this.loanableAssetsForCustomerLoaded = false;
    this.loanableAssetsForCustomerLength = "";

    this.loanableAssetsForCustomerLoanpoolGrid = "";
    this.loanableAssetsForCustomerLoanpoolGridLength = "";
    this.loanableAssetsForCustomerLoanpoolGridLoaded = false;
    this.loanableAssetsForCustomerLoanpoolGridTotal = "";
    this.loanPoolNotificationLoading = false;
    this.dateValidator = {
      mode: "",
      message: "",
      valid: false
    };
    this.justification = "";
    this.location = "";
    this.mobile = "";
    this.modelNumber = "";
    this.manufacturer = "";
    this.description = "";
    this.notes = "";
    //notification screen
    this.allLoanPoolRequests = [];
    this.allLoanPoolRequestsDataLoaded = false;
    this.loanPoolFilterQuery = "";
    this.notificationSelected = null;
    this.ChargeBack = "";
    this.AssetGridColumnDefs = [
      {
        field: "",
        headerName: "",
        width: 70,
        checkboxSelection: true,
        headerCheckboxSelection: true
      },
      { field: "EquipmentNo", headerName: "Equipment number", width: 220 },
      { field: "Manufacturer", headerName: "Manufacturer", width: 220 },
      {
        field: "AltManufacturerName",
        headerName: "Alternative Manufacturer Name",
        width: 330
      },
      { field: "ModelNo", headerName: "Model number", width: 200 },
      { field: "SerialNo", headerName: "Serial number", width: 200 },
      { field: "Description", headerName: "Description", width: 278 },
      { field: "Accessories", headerName: "Accessories", width: 200 },
      { field: "Options", headerName: "Options", width: 200 },
      { field: "SystemParent", headerName: "System parent", width: 200 },
      { field: "SystemName", headerName: "System name", width: 200 },
      { field: "SystemChild", headerName: "System child", width: 200 },
      {
        field: "ParentSystemName",
        headerName: "Parent system name",
        width: 250
      },
      {
        field: "CalibrationDate",
        headerName: "Last calibration date",
        width: 250,
        valueFormatter: this.dateFormatter
      },
      //{ field: "ServiceDueDate", headerName: "Service Due Date ", width: 200 ,valueFormatter: this.dateFormatter},
      { field: "LoanDailyCost", headerName: "Loan daily cost", width: 200 }
    ];
    this.gridOptions = {
      //We register the react date component that ag-grid will use to render
      // dateComponentFramework: DateComponent,
      // this is how you listen for events using gridOptions
      onModelUpdated: function() {
        // console.log('event onModelUpdated received');
      },
      defaultColDef: {
        //  headerComponentFramework: SortableHeaderComponent,
        headerComponentParams: {
          menuIcon: "fa-bars"
        }
      },
      // this is a simple property
      rowBuffer: 10, // no need to set this, the default is fine for almost all scenarios,
      //  floatingFilter: true
      rowHeight: 30
    };
  }
  dateFormatter = params => {
    var date = moment(params.value).format("YYYY-MM-DD");
    if (date == "1970-01-01") {
      return "";
    } else {
      return date;
    }
  };
  parseMonth(data) {
    var months = [];
    months = _.groupBy(data, function(b) {
      return b.month;
    });
    // console.log('years', months)
    var array = [];
    for (var i = 0; i < Object.keys(months).length; i++) {
      var child = {};
      child.headerName = moment(Object.keys(months)[i], "MM").format("MMMM");
      child.children = Object.values(months)[i];
      // console.log(Object.keys(months)[i], Object.values(months)[i]);
      array.push(child);
    }
    return array;
  }
  @action
  generateDateColumns() {
    // var columns = [];
    // console.log("tabStartDate", this.startDate, this.endDate)
    // var dates = dateArray.range(moment(this.startDate), moment(this.endDate), 'MM-DD-YYYY', true);
    // for (var dateItem of dates) {
    //     var item = {};
    //     var res = dateItem.split("-");
    //     item.year = res[2];
    //     item.date = res[1];
    //     item.month = res[0];
    //     item.field = dateItem;
    //     item.headerName = res[1];
    //     item.minWidth = 30;
    //     item.width = 30;
    //     // item.cellStyle = {backgroundColor: "green"};
    //     item.cellStyle = (params) => {
    //         // console.log('params', params);
    //         var color = "#34a853"
    //         if (params.value === "GREEN")
    //             return {
    //                 backgroundColor: "green",
    //                 color: "green"
    //             }
    //         else if (params.value === "RED")
    //             return {
    //                 backgroundColor: "red",
    //                 color: "red"
    //             }
    //         else if (params.value === "YELLOW")
    //             return {
    //                 backgroundColor: "yellow",
    //                 color: "yellow"
    //             }
    //         else
    //             return {
    //                 backgroundColor: params.value,
    //                 color: params.value
    //             }
    //     }
    //     columns.push(item)
    //     // console.log('dates', dates);
    //     var years = [];
    //     years = _.groupBy(columns, function (b) { return b.year });
    //     // console.log('years', years, JSON.stringify(years))
    //     var array = []
    //     array.push({ field: 'EquipmentNo', headerName: 'Equipment Number', width: 500, minWidth: 500, headerCheckboxSelection: true, checkboxSelection: true, });
    //     // array.push({
    //     //     headerName: '',
    //     //     width: 200,
    //     //     headerCheckboxSelection: true,
    //     //     checkboxSelection: true,
    //     // });
    //     for (var i = 0; i < Object.keys(years).length; i++) {
    //         var child = {};
    //         child.headerName = Object.keys(years)[i];
    //         child.children = this.parseMonth(Object.values(years)[i]);
    //         // console.log(Object.keys(years)[i], Object.values(years)[i]);
    //         array.push(child);
    //     }
    //     console.log("array", array);
    //     this.columnDefs = array;
    // }
    // console.log("this.columnDefs", this.columnDefs);
    if (this.gridOptions.api) {
      this.gridOptions.api.setRowData(this.loanableAssetsForCustomer);
      this.gridOptions.api.hideOverlay();
      // this.gridOptions.api.sizeColumnsToFit();
    }
  }

  //test Field additional observer for testing dev testing purpose
  @computed
  get getTestFiled() {
    return this.selectedAssets;
  }
  @action
  getAllLoanPoolRequests = () => {
    this.allLoanPoolRequests = [];
    this.loanPoolNotificationLoading = true;
    Functions.GetAllLoanPoolRequests().then(resp => {
      resp.data.allRequests.map((item, index) => {
        item.index = index;
        item.width = 50;
        item.minWidth = 50;
        item.maxWidth = 50;
        item.suppressMovable = true;
        item.suppressFilter = true;
        item.suppressSorting = true;
        item.suppressMenu = true;
        item.suppressResize = true;

        item.type == "External Asset Request - Submitted By Me" ||
        item.type == "External Asset Request - Submitted To Me"
          ? (item.expanded = false)
          : (item.expanded = "COLLAPSED");
        this.allLoanPoolRequests.push(item);
      });
      this.loanPoolNotificationLoading = false;
    });
  };
  @action
  setLoanPoolFilterModalopen = bool => {
    this.loanPoolfilterModalOpen = bool;
  };

  @action
  setSubmittingApprove = bool => {
    this.submittingApprove = bool;
  };
  @action
  setSubmittingReject = bool => {
    this.submittingReject = bool;
  };
  @action
  getUserDetails = () => {
    Functions.GetUserDetails().then(resp => {
      //console.log("got UserTabs:", resp);
      if (resp.data.success) {
        var response = resp.data;
        var userDetails = response.userDetails;
        userStore.setUserDetails(userDetails);
        userStore.setbaseUserDetails(userDetails);
        userStore.setMe(userDetails);
        userStore.setPreferences(userDetails.preferences);
        userStore.setbasePreferences(userDetails.preferences);
      }
    });
  };
  @action
  clearLoanPoolFilter = () => {
    this.initialized = false;
    this.dataLoaded = false;
    var tabId = 0;
    Functions.ClearFilters(tabId).then(() => {
      this.initializeData();
    });
  };

  @action
  initializeData = () => {
    this.initialized = false;
    this.dataLoaded = false;
    // var initData = "";
    // if (true)//for testing
    return Functions.GetLoanPoolDataModel().then(resp => {
      //   console.log("GetGridData", resp.data.data);
      this.setGridDataModel(resp.data.data);
      return Functions.GetOrgs().then(resp => {
        this.setGridOrgs(resp.data.orgDetails);
        // console.log("GetOrgs", resp.data.orgDetails);
        return Functions.GetLoanableAssetsData(
          this.endDateCheckAvailability,
          this.startDateCheckAvailability,
          this.currentLimit,
          this.currentStartingItem,
          this.currentPage
        ).then(resp => {
          //   console.log("resp", resp);
          //   initData = resp.data;
          var ss = [];
          for (var itemm in resp.data.availabilityData) {
            // console.log("item", item);
            var item = resp.data.availabilityData[itemm];
            var newObj = {};
            newObj.EquipmentNo = item.EquipmentNo;
            newObj.ThingName = item.ThingName;
            Object.keys(item).map((i, index) => {
              var itemsnew = moment(i).format("MM-DD-YYYY");
              if (newObj[itemsnew] == undefined)
                newObj[itemsnew] = Object.values(item)[index];
              else {
                if (newObj[itemsnew] == "#0000")
                  newObj[itemsnew] = Object.values(item)[index];
              }
            });
            ss.push(newObj);
          }
          for (let i = 0; i < resp.data.gridData.data.length; i++) {
            resp.data.gridData.data[i].LoanDailyCost =
              resp.data.gridData.data[i].LoanDailyCost == -999999
                ? ""
                : resp.data.gridData.data[i].LoanDailyCost;
          }
          this.setLoanableAssetsForCustomerLoanpoolGrid(
            resp.data.gridData.data
          );
          this.loanPoolFilter = resp.data.baseQuery;
          //   console.log("loanPoolFilterInStore", this.loanPoolFilter);
          this.setLoanableAssetsForCustomerNewApi(ss);
          this.loanableAssetsForCustomerLoanpoolGridTotal =
            resp.data.gridData.totalCount;
          this.initialized = true;
          this.dataLoaded = true;
        });
      });
    });
  };
  @action
  setLoanPoolQuery = data => {
    this.loanPoolFilterQuery = data;
    // console.log("loanPoolFilterQuery", this.loanPoolFilterQuery);
  };
  @action
  setselectedAssets = data => {
    this.selectedAssets = data;
  };
  @action
  setCurrentStep = data => {
    this.currentStep = data;
  };
  @action
  setRange = data => {
    this.startDate = data[0].toISOString();
    this.endDate = data[1].toISOString();
    // console.log("rangeIs", this.startDate, this.endDate);
    // var date = moment(this.startDate);
    // var now = moment();
    // console.log("diff", date.diff(now));
    //86400000
    // if (date.isBefore(now, 'day')) {
    //     this.dateValidator = {
    //         message: "Start date should not be a past day",
    //         valid: false,
    //         mode: "warning"
    //     }
    //     console.log("date is past");
    // } else {
    // console.log("date is future");
    this.dateValidator = {
      message: "",
      valid: true,
      mode: "success"
    };
    this.dataLoaded = false;
    return this.reRenderLoanPool();
    // }
  };
  @action
  setStartDate = data => {
    this.startDate = data;
    var date = moment(this.startDate);
    var now = moment();
    //console.log('diff', date.diff(now))
    //86400000
    if (date.isBefore(now, "day")) {
      this.dateValidator = {
        message: "Start date should not be a past day",
        valid: false,
        mode: "warning"
      };
      //   console.log("date is past");
    } else {
      //   console.log("date is future");
      this.dateValidator = {
        message: "",
        valid: true,
        mode: "success"
      };
      // this.dataLoaded = false;
      // this.reRenderLoanPool();
    }
  };
  @action
  setEndDate = data => {
    this.endDate = data;
  };
  @action
  setRangeCheckAvailability = data => {
    this.startDateCheckAvailability = data[0].toISOString();
    this.endDateCheckAvailability = data[1].toISOString();
    this.dateValidator = {
      message: "",
      valid: true,
      mode: "success"
    };
    this.dataLoaded = false;
    return this.reRenderLoanPool();
    // }
  };
  @action
  setStartDateCheckAvailability = data => {
    // console.log("rangeIs_ setStartDateCheckAvailability", data);
    this.startDateCheckAvailability = data;
    var date = moment(this.startDateCheckAvailability);
    var now = moment();
    //console.log('diff', date.diff(now))
    //86400000
    if (date.isBefore(now, "day")) {
      this.dateValidator = {
        message: "Start date should not be a past day",
        valid: false,
        mode: "warning"
      };
      //   console.log("date is past");
    } else {
      //   console.log("date is future");
      this.dateValidator = {
        message: "",
        valid: true,
        mode: "success"
      };
      this.dataLoaded = false;
      this.reRenderLoanPool();
    }
  };
  @action
  setEndDateCheckAvailability = data => {
    this.endDateCheckAvailability = data;
  };
  @action
  setDataLoaded = bool => {
    this.dataLoaded = bool;
    //console.log("setDataLoaded", this.dataLoaded,
    //   this.currentScreenDataArrayLength, this.currentTabColoumnsArray
    //)
  };
  //GridDataModel all column information
  @computed
  get getGridDataModel() {
    return this.gridDataModel;
  }
  @action
  setGridDataModel = data => {
    // console.log("setGridDataModel-length", data.length, typeof data);
    let rows = [];
    for (let i = 0; i < data.length; i++) {
      if (!data[i].hidden) {
        var item = {
          key: data[i].dataIndex,
          sortable: data[i].sortable,
          name: data[i].text,
          width: +data[i].width + 2,
          resizable: true
        };
        rows.push(item);
      }
    }
    // form  the item headerRenderer: <HeaderMenu headerName={data[i].text} />
    //console.log('renderer', rows);
    this.gridDataModel = rows;
  };

  //orgs info
  @computed
  get getGridOrgs() {
    return this.gridOrgs;
  }
  @action
  setGridOrgs = data => {
    this.gridOrgs = data;
  };

  //LoanPoolFilter info
  @computed
  get getLoanPoolFilter() {
    return this.loanPoolFilter;
  }
  @action
  setLoanPoolFilter = data => {
    this.loanPoolFilter = data;
  };

  //LoanableAssetsForCustomer info
  @computed
  get getLoanableAssetsForCustomer() {
    return this.loanableAssetsForCustomer;
  }
  @action
  setLoanableAssetsForCustomerNewApi = data => {
    let rows = [];
    for (let i = 0; i < data.length; i++) {
      var item = data[i];
      rows.push(item);
    }
    var rowArray = rows;
    // console.log("rowArray", rowArray);
    this.loanableAssetsForCustomer = rowArray;
    this.loanableAssetsForCustomerLength = rowArray.length;
  };
  @action
  setLoanableAssetsForCustomer = data => {
    var inputVar = data.rows;
    // console.log(inputVar, typeof inputVar);
    var rowArray = [];
    var datesArray;
    for (var a of inputVar) {
      var rowItem = a;
      //   console.log("a", rowItem);
      if (rowItem.dates.length > 0) {
        for (var j of rowItem.dates) {
          //getting each date slots
          var dateItem = j;
          //   console.log("dateItem", dateItem);
          if (dateItem.RequestEndDate && dateItem.RequestStartDate) {
            // console.log(
            //   "RequestEndDate",
            //   dateItem.RequestStartDate,
            //   dateItem.RequestEndDate
            // );
            if (dateItem.RequestEndDate === dateItem.RequestStartDate) {
              rowItem[k] = "REQUEST";
            } else {
              datesArray = dateArray.range(
                dateItem.RequestStartDate,
                dateItem.RequestEndDate,
                "MMM DD YYYY",
                true
              );
              //   console.log("dateArray", datesArray);
              for (var k of datesArray) {
                rowItem[k] = "REQUEST";
              }
            }
          }
          if (dateItem.LoanEndDate && dateItem.LoanStartDate) {
            if (dateItem.LoanEndDate === dateItem.LoanStartDate) {
              rowItem[k] = "LOAN";
            } else {
              datesArray = dateArray.range(
                dateItem.LoanStartDate,
                dateItem.LoanEndDate,
                "MMM DD YYYY",
                true
              );
              for (var l of datesArray) {
                rowItem[l] = "LOAN";
              }
            }
          }
        }
      }
      rowArray.push(rowItem);
      //   console.log("rowItem", rowItem);
    }
    // console.log("rowArray", rowArray);
    this.loanableAssetsForCustomer = rowArray;
    this.loanableAssetsForCustomerLength = rowArray.length;
    // console.log("loanableAssetsForCustomer", this.loanableAssetsForCustomer);
  };
  //LoanableAssetsForCustomer info
  @computed
  get getLoanableAssetsForCustomerLoanpoolGrid() {
    return this.loanableAssetsForCustomerLoanpoolGrid;
  }
  @action
  setLoanableAssetsForCustomerLoanpoolGrid = data => {
    this.loanableAssetsForCustomerLoanpoolGrid = data;
    this.loanableAssetsForCustomerLoanpoolGridLength = data.length;
    if (this.gridOptions.api) {
      this.gridOptions.api.setRowData(this.serviceDataArray);
      this.gridOptions.api.hideOverlay();
      this.gridOptions.api.sizeColumnsToFit();
    }
  };
  @action
  dashboardAddCheck = rows => {
    this.selectedAssets = this.selectedAssets.concat(
      rows.map(r => r.row.EquipmentNo)
    );
  };
  @action
  dashboardRemoveCheck = (rows, rowIds) => {
    this.selectedAssets = this.selectedAssets.filter(
      i => rowIds.indexOf(i) === -1
    );
  };
  @action
  dashboardAddCheckFull = rows => {
    /*this.selectedAssetsFull = this.selectedAssetsFull.concat(
            rows.map(r => r.row)
        );*/
    if (rows != null) {
      this.selectedAssetsFull = rows;
      {
        /*if (rows.length > 0) {
                this.enableEquipmentRequest = true;
            } else {
                this.enableEquipmentRequest = false;
            }*/
      }
    } else {
      this.selectedAssetsFull = [];
      // {/*this.enableEquipmentRequest = false;*/ }
    }
  };
  @action
  dashboardRemoveCheckFull = rows => {
    this.selectedAssetsFull = this.selectedAssetsFull.filter(
      i => rows.indexOf(i) === -1
    );
  };
  @action
  setDataLoaded = bool => {
    this.dataLoaded = bool;
  };
  @action
  setCurrentPage = page => {
    this.currentPage = page;
  };
  @action
  setJustification = page => {
    this.justification = page;
  };
  @action
  setModelNumber = page => {
    this.modelNumber = page;
  };
  @action
  setManufacturer = page => {
    this.manufacturer = page;
  };
  @action
  setDescription = page => {
    this.description = page;
  };
  @action
  setNotes = page => {
    this.notes = page;
  };
  @action
  setLocation = page => {
    this.location = page;
  };
  @action
  setMobile = page => {
    this.mobile = page;
  };
  @action
  setCurrentStart = page => {
    this.currentStartingItem = page;
  };
  @action
  setCurrentLimit = data => {
    this.currentLimit = JSON.parse(data);
  };
  @action
  handlePageSize = currentLimit => {
    // console.log("currentLimit", currentLimit);
    this.setCurrentLimit(currentLimit);
    this.setDataLoaded(false);
    this.setCurrentStart(0);
    this.setCurrentPage(1);
    this.reRenderLoanPool();
  };
  @action
  handleNextpage = () => {
    var currentPage = this.currentPage;
    //console.log('currentPage', currentPage);
    // var currentScreenData = this.currentScreenData;
    var totalItems = this.loanableAssetsForCustomerLoanpoolGridTotal;
    // var currentPage = this.currentPage;
    var currentLimit = this.currentLimit;
    // var currentStartingItem = this.currentStartingItem;
    var totalPages = parseInt(totalItems / currentLimit);
    var remainder = totalItems % currentLimit;
    if (remainder > 0) {
      totalPages = totalPages + 1;
    }
    currentPage = currentPage + 1;
    var currentStart = currentPage * currentPage;
    if (currentPage != totalPages) {
      this.setDataLoaded(false);
      this.setCurrentPage(currentPage);
      this.setCurrentStart(currentStart);

      this.setCurrentPage(+currentPage);
      this.reRenderLoanPool();
    }
  };
  @action
  handleLastPage = () => {
    var currentPage = this.currentPage;
    //console.log('currentPage', currentPage);
    // var currentScreenData = this.currentScreenData;
    var totalItems = this.loanableAssetsForCustomerLoanpoolGridTotal;
    // var currentPage = this.currentPage;
    var currentLimit = this.currentLimit;
    // var currentStartingItem = this.currentStartingItem;
    var totalPages = parseInt(totalItems / currentLimit);
    var remainder = totalItems % currentLimit;
    if (remainder > 0) {
      totalPages = totalPages + 1;
    }
    currentPage = totalPages;
    var currentStart = currentPage * currentPage;
    //		if (currentPage != totalPages) {
    this.setCurrentPage(currentPage);
    this.setCurrentStart(currentStart);
    this.dataLoaded = false;
    this.reRenderLoanPool();
  };
  @action
  handleFirstPage = () => {
    var currentPage = this.currentPage;
    //console.log('currentPage', currentPage);
    // var currentScreenData = this.currentScreenData;
    var totalItems = this.loanableAssetsForCustomerLoanpoolGridTotal;
    // var currentPage = this.currentPage;
    var currentLimit = this.currentLimit;
    // var currentStartingItem = this.currentStartingItem;
    var totalPages = parseInt(totalItems / currentLimit);
    var remainder = totalItems % currentLimit;
    if (remainder > 0) {
      totalPages = totalPages + 1;
    }
    currentPage = 1;
    var currentStart = currentPage * currentPage;
    if (currentPage != totalPages) {
      this.setCurrentPage(currentPage);
      this.setCurrentStart(currentStart);

      this.setCurrentPage(+currentPage);
      this.dataLoaded = false;
      this.reRenderLoanPool();
    }
  };
  @action
  handlePrevPage = () => {
    var currentPage = this.currentPage;
    //console.log('currentPage', currentPage);
    // var currentScreenData = this.currentScreenData;
    var totalItems = this.loanableAssetsForCustomerLoanpoolGridTotal;
    // var currentPage = this.currentPage;
    var currentLimit = this.currentLimit;
    // var currentStartingItem = this.currentStartingItem;
    var totalPages = parseInt(totalItems / currentLimit);
    var remainder = totalItems % currentLimit;
    if (remainder > 0) {
      totalPages = totalPages + 1;
    }
    currentPage = currentPage - 1;
    var currentStart = currentPage * currentPage;
    if (currentPage != totalPages) {
      this.setCurrentPage(currentPage);
      this.setCurrentStart(currentStart);
      this.setCurrentPage(+currentPage);
      this.setDataLoaded(false);
      this.reRenderLoanPool();
    }
  };

  @action
  reRenderLoanPool = () => {
    return Functions.GetLoanableAssetsData(
      this.endDateCheckAvailability,
      this.startDateCheckAvailability,
      this.currentLimit,
      this.currentStartingItem,
      this.currentPage
    ).then(resp => {
      //   console.log("resp", resp);
      this.setLoanableAssetsForCustomerLoanpoolGrid(resp.data.gridData.data);
      this.setLoanPoolFilter(resp.data.baseQuery);
      this.setLoanPoolQuery(resp.data.baseQuery);
      var ss = [];
      for (var itemm in resp.data.availabilityData) {
        // console.log("item", item);
        var item = resp.data.availabilityData[itemm];
        var newObj = {};
        newObj.EquipmentNo = item.EquipmentNo;
        newObj.ThingName = item.ThingName;
        Object.keys(item).map((i, index) => {
          if (
            !(
              Object.values(item)[index] == "EquipmentNo" ||
              Object.values(item)[index] == "ThingName"
            )
          ) {
            var itemsnew = moment(i).format("MM-DD-YYYY");
            if (newObj[itemsnew] == undefined)
              newObj[itemsnew] = Object.values(item)[index];
            else {
              if (newObj[itemsnew] == "#0000")
                newObj[itemsnew] = Object.values(item)[index];
            }
          }
        });
        ss.push(newObj);
      }
      this.setLoanableAssetsForCustomerNewApi(ss);
      this.loanableAssetsForCustomerLoanpoolGridTotal =
        resp.data.gridData.totalCount;
      this.initialized = true;
      this.dataLoaded = true;
      if (resp.data.availabilityData) return ss;
      return false;
    });
  };
  @action
  clearStore = () => {
    this.startDate = moment();
    this.endDate = moment();
  };
  @action
  submitNewrequest = data => {
    var assetsArray = this.selectedAssetsFull.map(e => e.UniqueID);
    if (assetsArray.length == 0) return;
    // var assets = assetsArray.join(";");
    this.submitEnabled = false;
    this.isButtonDisabled = true;
    // Functions.ValidateLoanPoolRequest(data.startValue, data.endValue, userStore.userDetails.CustomerId, assets)
    //     .then((resp) => {
    //         console.log('validationStatus', resp);
    // if (resp.data.isValid) {
    // if (resp.data.showMessage) {
    //     UIFunctions.Toast(resp.data.message, "warn");
    // }
    //var mobile = userStore.userDetails.mobile;
    //if (!mobile) mobile = " "
    return Functions.CreateNewLoanPoolRequest(
      data.startValue,
      data.endValue,
      userStore.CustomerId,
      data.justification,
      data.Location,
      this.ChargeBack,
      data.mobile,
      assetsArray
    )
      .then(resp => {
        this.isButtonDisabled = false;
        this.currentStep = "step1";
        this.dashboardAddCheckFull();
        //this.initializeData();
        if (resp.data.success) {
          //   console.log("step loanpool", this.currentStep);
          this.currentStep = "finished";
          UIFunctions.Toast("Loan Request Submitted Successfully!", "success");
        } else UIFunctions.Toast("Loan Request Creation Failed!", "error");
      })
      .catch(() => {
        // console.log("validationStatus Error", resp);
        this.currentStep = "step1";
        UIFunctions.Toast("Loan Request Creation Failed!", "error");
      });
  };
  @action
  addExternalAssetRequest = () => {
    // Functions.AddExternalAssetRequest(this.endDate,this.startDate," ",this.location,this.justification," ",)
    // var assets = this.selectedAssetsFull.map(e => e.UniqueID);
    // console.log("submitNewrequest", assets);
    if (!this.dateValidator.valid) {
      var validator = this.dateValidator;
      validator.mode = "error";
      if (!validator.message)
        validator.message = "Please Select Valid Start Date and End Date";
      return (this.dateValidator = validator);
    }
    this.submitEnabled = false;
    Functions.AddExternalAssetRequest(
      this.endDate,
      this.startDate,
      this.notes,
      this.location,
      this.justification,
      this.description,
      this.modelNumber,
      this.manufacturer
    )
      .then(resp => {
        // console.log("Created", resp);
        this.currentStep = "step1";
        if (resp.data.success)
          UIFunctions.Toast("Loan Request Submitted Successfully!", "success");
        else UIFunctions.Toast("Loan Request Creation Failed!", "error");
      })
      .catch(() => {
        this.submitEnabled = true;
        UIFunctions.Toast("Loan Request Validation Failed!", "error");
        // console.log("validationStatus Error", resp);
      });
  };

  @action
  setChargeBack = data => {
    this.ChargeBack = data;
  };

  @computed
  get getChargeBack() {
    return this.ChargeBack;
  }

  @action
  setNotificationSelected = row => {
    this.notificationSelected = row;
  };

  @action
  setEnableEquipmentRequest = bool => {
    this.enableEquipmentRequest = bool;
  };
  @action
  markAsRead = row => {
    var newArray = [];
    this.allLoanPoolRequests.map(e => {
      var newGriddata = e;
      var assets = [];
      var allread = true;
      e.assets &&
        e.assets.map(item => {
          if (item.EquipmentNo == row.EquipmentNo) {
            item.read = true;
          }
          if (!item.read) allread = false;
          assets.push(item);
        });
      newGriddata.read = allread;
      newGriddata.assets = assets;
      newArray.push(newGriddata);
    });
    this.allLoanPoolRequests = newArray;
    return true;
  };
  @action
  markAsReadMasterRow = row => {
    var newArray = [];
    this.allLoanPoolRequests.map(item => {
      var newGriddata = item;
      if (item.requestId == row.requestId) {
        item.read = true;
      }
      newArray.push(newGriddata);
    });
    this.allLoanPoolRequests = newArray;
    return true;
  };
}

const loanPoolStore = new LoanPoolStore();

export default loanPoolStore;
