import { observable, action, computed } from "mobx";
import tabModelStore from "./tabModelStore";
import userStore from "./userStore";
import Functions from "./../api/Functions";

import _ from "lodash";
class AddAssetsStore {
  @observable
  addAssetsOpen;
  @observable
  bulkEditOpen;
  @observable
  pageWiseDropDownValues;
  @observable
  orgs;
  @observable
  equipmentNumberSequence;
  @observable
  OrganizationTree;
  @observable
  renderedOrganizationTree;
  @observable
  locationTree;
  @observable
  customerAssets;
  @observable
  templates;
  @observable
  orgTree;
  @observable
  lastAsset;
  @observable
  usersForCustomer;
  @observable
  healthModalOpen;
  @observable
  assetDetailModalOpen;
  @observable
  singleClick;
  @observable
  doubleClick;
  @observable
  setRowData;
  @observable
  setEditRowData;
  @observable
  dashboardChecked;
  @observable
  setHealthClassName;
  @observable
  testField;
  @observable
  doubleClickedUniqueID;
  @observable
  fieldState;
  @observable
  mode;
  @observable
  maintenanceTaskInput;
  @observable
  rowArrayData;
  @observable
  newReqItem;

  @observable
  submitting;
  @observable
  requestRowSelected;
  @observable
  entriesAssetFileList;
  @observable
  assetFileUploadList;
  @observable
  assetFileDeleteList;

  @observable
  systemComponents;
  @observable
  editting;
  @observable
  serviceHistory;

  @observable
  dataForBulkEdit;

  @observable
  isDashboardSelected;
  @observable
  isServiceChartDashboardSelected;
  constructor() {
    this.dataForBulkEdit = [];
    this.rowArrayData = [];
    this.isDashboardSelected = false;
    this.isServiceChartDashboardSelected = false;
    this.newReqItem = {
      paymentmethod: "",
      attachpurchaseorderfilename: "",
      attachpurchaseorderfile: "",
      attachfaultreportfilename: "",
      attachfaultreportfile: "",
      requestedservice: "",
      preferreddate: "",
      fault: ""
    };
    this.mode = "";
    this.maintenanceTaskInput = "";
    this.testField = true;
    this.addAssetsOpen = false;
    this.bulkEditOpen = false;
    this.healthModalOpen = false;
    this.rowData = null;
    this.editRowData = null;
    this.singleClick = false;
    this.pageWiseDropDownValues = null;
    this.orgs = null;
    this.equipmentNumberSequence = null;
    this.OrganizationTree = null;
    this.renderedOrganizationTree = null;
    this.locationTree = null;
    this.customerAssets = null;
    this.templates = null;
    this.orgTree = [];
    this.lastAsset = null;
    this.usersForCustomer = null;
    this.assetDetailModalOpen = false;
    this.dashboardChecked = [];
    this.doubleClickedUniqueID = "";
    this.requestRowSelected = null;
    this.submitting = false;
    this.entriesAssetFileList = [];
    this.assetFileUploadList = [];
    this.assetFileDeleteList = [];
    this.systemComponents = [];
    this.editting = false;
    this.serviceHistory = [];
    this.ManufacturerList = [];
    this.fieldState = {
      ChooseTemplate: null,
      EquipmentNo: "",
      Manufacturer: "",
      AltManufacturerName: "",
      ModelNo: "",
      SerialNo: "",
      AssetNo: "",
      Barcode: "",
      Description: "",
      ProductCategory: null,
      ReplacedBy: null,
      Borrowable: false,
      UtilizationCategory: null,
      LoanDailyCost: -999999,
      Currency: null,
      StickyNotes: "",
      EquipmentType: null,
      Project: "",
      FirmwareRevision: "",
      HardwareVersion: "",
      Accessories: "",
      Options: "",
      SoftwareRevision: "",
      SystemParent: false,
      SystemName: "",
      SystemChild: false,
      ParentSystemName: "",
      PartOfSystemCalibration: false,
      SystemComponents: "",
      LastReportedCondition: null,
      CalibrationProvider: null,
      ServiceLogistics: null,
      CalibrationType: null,
      ServiceInterval: -999999,
      CalibrationInterval: -999999,
      ServiceCost: -999999,
      RepairProvider: null,
      UseProviderCalibrationType: false,
      UseProviderCalibrationSchedule: false,
      OwnershipStatus: null,
      OwningCompany: "",
      OrderNumber: "",
      PurchasePrice: -999999,
      LoanAutoCalculate: true,
      InvoiceNumber: "",
      LifeCycleStage: null,
      Depreciation: -999999,
      BookValue: -999999,
      Organization: null,
      LoanDailyRate: 4,
      Location: null,
      Coordinator: null,
      User: "",
      CustomerId: null,
      ServiceDueDate: null,
      InventoryDate: null,
      ReceivedDate: "",
      OrderDate: null,
      PlannedDisposalDate: "",
      DepreciationRate: -999999,
      LastUpdate: null,
      //"BookValue":'',
      BookValueDate: "",
      ReplacementDate: "",
      CalibrationDate: "",
      CalibrationDueDate: "",
      LastServiceDate: ""
    };
    this.IntegerFields = [
      "LoanDailyCost",
      "PurchasePrice",
      "Depreciation",
      "BookValue",
      "DepreciationRate",
      "ServiceInterval",
      "CalibrationInterval",
      "ServiceCost"
    ];
    //if anyone adds new item please add the same on clearStore
  }
  @action
  setMode = data => {
    this.mode = data;
  };
  @action
  setMaintenanceTaskInput = data => {
    this.maintenanceTaskInput = data;
  };
  @action
  getPageWiseDropDownValues = dropDownName => {
    if (this.pageWiseDropDownValues) {
      const index = this.pageWiseDropDownValues.findIndex(
        obj => obj.DropdownName === dropDownName
      );

      return JSON.parse(
        JSON.stringify(this.pageWiseDropDownValues[index].DropDownValues)
      );
    } else {
      return ["error"];
    }
  };

  @action
  getAllApi = (mode, CustomerId =  userStore.userDetails.CustomerId ) =>{
    var rr,locTree;
    rr = null;
    locTree = null;
    var self = this;
   return Functions.GetAllApiResult(
      CustomerId,
      mode
    ).then(resp => {
      var response = resp.data;

      /* GetParentSystemName */
      self.addToFieldStateFromCode({
        ParentSystemNameList: response.GetSystemNamesDropdown.data
      });

      /* GetOrgs */
      self.setOrgs(response.GetOrgs.orgDetails[0]);

      
      if (mode == "CreateAsset") {
        /* Defaulting Coordinator */
        self.addToFieldStateFromCode({
          Coordinator: userStore.userDetails.UserName
        });
        /* GetEquipmentNumberSequence */
        self.setUsersForCustomer([userStore.userDetails.UserName]);
          self.setEquipmentNumberSequence(
          response.GetEquipmentNumberSequence.sequence
        );
        self.addToFieldStateFromCode({
          EquipmentNo: +response.GetEquipmentNumberSequence.sequence
        });
      }
      // this.baseState.EquipmentNo = this.state.EquipmentNo;
      // var customerId = userStore.userDetails.CustomerId;
      // this.setState({ CustomerId: customerId });
      // self.addToFieldStateFromCode({ CustomerId: customerId });
      /* GetOrganizationTree */
      var json = response.GetOrganizationTree.tree;
      processOrg(json, "0", "0", false);
      var dta = "[" + rr + "]";
      var tdta = JSON.parse(dta);
      // this.orgTreeData = tdta;
      self.setOrganizationTree(tdta);

      /* GetLocationTree */
      processLocTree(response.GetLocationTree.tree, "0", "0", false);
      dta = "[" + locTree + "]";
      tdta = JSON.parse(dta);
      // this.locTreeData = tdta;
      self.setLocationTree(tdta);

      /* CustomerAssets */
      var assets = response.GetCustomerAssets.data;
      var lastAsset = assets[+assets.length - 1];
      self.setCustomerAssets(response.GetCustomerAssets.data);
      self.setLastAsset(lastAsset);
      // console.log('lastAsset', lastAsset);

      /* GetTemplates */
      self.setTemplates(response.GetTemplates.data);
      self.formLoaded = true;
    });
    function processOrg(json, tag, pos, currentValue) {
      //console.log('to parse', json)
      //console.log('tag,pos', tag, pos)
      var currentVal = currentValue;

      if (json.text) {
        var toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          json.text +
          '",';
        if (currentVal) {
          //console.log('currentVal', currentVal, json.text);
          toadd =
            '{"label":"' +
            json.text +
            '",' +
            '"key":"' +
            tag +
            "-" +
            pos +
            '",' +
            '"value":"' +
            currentVal +
            " > " +
            json.text +
            '",';
          currentVal = currentVal + " > " + json.text;
        } else {
          //console.log('currentVal else', currentVal, json.text);
          currentVal = json.text;
        }
        if (rr) {
          rr = rr + toadd;
        } else {
          rr = toadd;
        }
      }
      if (json.expanded) {
        if (json.text) {
          var toaddd = '"children":[';
          rr = rr + toaddd;
        }

        json.children.map((item, index) => {
          //console.log("index:", index, arr)
          var poss = index + 1;
          processOrg(item, tag + "-" + pos, poss, currentVal);
          var toadd = ",";
          rr = rr + toadd;
        });
        rr = rr.slice(0, -1);
        if (json.text) {
          var toadd_ = "]";
          rr = rr + toadd_;
        }
      } else {
        rr = rr.slice(0, -1);
      }
      if (json.text) {
        var toadd__ = "}";
        rr = rr + toadd__;
      }

      return true;
    }

    function processLocTree(json, tag, pos, currentValue) {
      //console.log('to parse', json)
      //console.log('tag,pos', tag, pos)
      //console.log("Marker", json);
      var currentVal = currentValue;

      if (json.text) {
        var toadd =
          '{"label":"' +
          json.text +
          '",' +
          '"key":"' +
          tag +
          "-" +
          pos +
          '",' +
          '"value":"' +
          json.text +
          '",';
        if (currentVal) {
          //console.log('currentVal', currentVal, json.text);
          toadd =
            '{"label":"' +
            json.text +
            '",' +
            '"key":"' +
            tag +
            "-" +
            pos +
            '",' +
            '"value":"' +
            currentVal +
            " > " +
            json.text +
            '",';
          currentVal = currentVal + " > " + json.text;
        } else {
          //console.log('currentVal else', currentVal, json.text);
          currentVal = json.text;
        }
        if (locTree) {
          locTree = locTree + toadd;
        } else {
          locTree = toadd;
        }
      }
      if (json.expanded) {
        if (json.text) {
          var _toadd = '"children":[';
          locTree = locTree + _toadd;
        }

        json.children.map((item, index) => {
          //console.log("index:", index, alocTree)
          var poss = index + 1;
          processLocTree(item, tag + "-" + pos, poss, currentVal);
          var toadd = ",";
          locTree = locTree + toadd;
        });
        locTree = locTree.slice(0, -1);
        if (json.text) {
          var toadD = "]";
          locTree = locTree + toadD;
        }
      } else {
        locTree = locTree.slice(0, -1);
      }
      if (json.text) {
        locTree = locTree + "}";
      }

      return true;
      //  //console.log("processed till",JSON.stringify(rr))
    }
  };

  @computed
  get getOrgs() {
    return this.orgs;
  }
  @computed
  get getOrgTree() {
    return this.orgTree;
  }
  @computed
  get getEquipmentNumberSequence() {
    return this.equipmentNumberSequence;
  }
  @computed
  get getOrganizationTree() {
    return this.OrganizationTree;
  }
  @computed
  get getRenderedOrganizationTree() {
    return this.OrganizationTree;
  }
  @computed
  get getLocationTree() {
    return this.locationTree;
  }
  @computed
  get getCustomerAssets() {
    return this.customerAssets;
  }
  @computed
  get getTemplates() {
    return this.templates;
  }
  @computed
  get getUsersForCustomer() {
    return this.usersForCustomer;
  }
  @action
  setEditting = bool => {
    this.editting = bool;
  };

  @action
  addToFieldState = ss => {
    /* eslint-disable  */
    console.log("select TRUE");
    this.editting = true;
    var currentState = this.fieldState;
    for (var i = 0; i < Object.keys(ss).length; i++) {
      currentState[Object.keys(ss)[i]] = Object.values(ss)[i];
    }
    this.fieldState = currentState;
  };
  @action
  removeFromFieldState = ss => {
    
    this.editting = true;
    var currentState = this.fieldState;
    for (var i = 0; i < Object.keys(ss).length; i++) {
      delete currentState[Object.keys(ss)[i]];
    }
    this.fieldState = currentState;
  };
  @action
  addToFieldStateFromCode = ss => {
    var currentState = this.fieldState;
    for (var i = 0; i < Object.keys(ss).length; i++) {
      currentState[Object.keys(ss)[i]] = Object.values(ss)[i];
    }
    this.fieldState = currentState;
  };
  @action
  setSubmitting = bool => {
    this.submitting = bool;
  };
  @action
  clearFromFieldState = ss => {
    this.fieldState[ss] = "";
  };
  @action
  setTestField = bool => {
    this.testField = bool;
  };
  @action
  setHealthModalOpen = bool => {
    this.healthModalOpen = bool;
  };
  @action
  setSingleClick = bool => {
    this.singleClick = bool;
  };
  @action
  setDoubleClick = bool => {
    this.doubleClick = bool;
  };
  @action
  setBudgatoryResp = json => {
    this.budgatoryResp = json;
  };
  @action
  setReqConfirmation = json => {
    this.reqConfirmation = json;
  };

  @action
  setRowData = json => {
    this.rowData = json;
  };
  @action
  setEditRowData = json => {
    this.editRowData = json;
  };
  @action
  setDataForBulkEdit = row => {
    this.dataForBulkEdit = row.map(e => e);
  };
  @action
  setHealthClassName = json => {
    this.healthClassName = json;
  };
  @action
  setAddAssetsOpen = bool => {
    this.addAssetsOpen = bool;
  };
  @action
  setBulkEditOpen = bool => {
    this.bulkEditOpen = bool;
  };
  @action
  setPageWiseDropDownValues = json => {
    this.pageWiseDropDownValues = json;
  };
  @action
  setOrgs = json => {
    this.orgs = json;
  };
  @action
  addOrgTree = () => {
    this.orgTree.pus;
  };
  @action
  setEquipmentNumberSequence = json => {
    this.equipmentNumberSequence = json;
  };
  @action
  setOrganizationTree = json => {
    this.OrganizationTree = json;
  };
  @action
  setUsersForCustomer = json => {
    /*eslint-disable*/
    console.log("setting ",json)
    this.usersForCustomer = json;
  };
  @action
  setRenderedOrganizationTree = json => {
    this.RenderedOrganizationTree = json;
  };
  @action
  setLocationTree = json => {
    this.locationTree = json;
  };
  @action
  setCustomerAssets = json => {
    this.customerAssets = json;
  };
  @action
  setLastAsset = json => {
    this.lastAsset = json;
  };
  @action
  setTemplates = json => {
    this.templates = json;
  };
  @action
  toggleAssetDetailsModal = () => {
    this.assetDetailModalOpen = !this.assetDetailModalOpen;
  };
  @action
  setIsDashboardSelected = bool => {
    this.isDashboardSelected = bool;
  };
  @action
  setIsServiceChartDashboardSelected = bool => {
    this.isServiceChartDashboardSelected = bool;
  };

  @action
  dashboardAddCheck = rows => {
    //commenting for perfomance enhancement if anything not working put it back
    this.rowArrayData = rows.map(r => {
      return {
        EquipmentNo: r.EquipmentNo,
        Manufacturer: r.Manufacturer,
        SerialNo: r.SerialNo,
        AssetNo: r.AssetNo,
        SrRequest: "no data",
        CalibrationInterval: r.CalibrationInterval,
        PreferredDate: "no data",
        Coverage: "no data",
        ModelNo: r.ModelNo,
        OrderNumber: r.OrderNumber,
        Action: "edit | remove"
      };
    });

    this.dashboardChecked = rows.map(r => r.UniqueID);
  };
  @action
  dashBoardAddCheckByKey = rows => {
    var result = [];
    var dashboardChecked = [];
    _.forEach(tabModelStore.currentScreenDataArray, function(n) {
      _.forEach(rows, function(n2) {
        if (n.EquipmentNo === n2.EquipmentNo) {
          result.push(n);
          dashboardChecked.push(n.UniqueID);
        }
      });
    });
    this.dashboardChecked = dashboardChecked;
    this.rowArrayData = result;
  };
  @action
  dashboardRemoveCheck = (rows, rowIds) => {
    this.dashboardChecked = this.dashboardChecked.filter(
      i => rowIds.indexOf(i) === -1
    );
  };
  @action
  dashboardClearCheck = () => {
    this.dashboardChecked = [];
  };
  @action
  setDoubleClickedUniqueID = uniqueID => {
    this.doubleClickedUniqueID = uniqueID;
  };
  @action
  setRequestRowSelected = row => {
    this.requestRowSelected = row;
  };
  @action
  clearEntriesAssetFileList = () => {
    this.entriesAssetFileList = [];
  };
  @action
  setEntriesAssetFileList = data => {
    this.entriesAssetFileList = [];
    data.map(item => {
      this.entriesAssetFileList.push(item);
    });
  };
  @action
  setAssetFileUploadList = data => {
    this.assetFileUploadList = [];
    data.map(item => {
      this.assetFileUploadList.push(item);
    });
  };
  @action
  removeAssetFileUploadList = data => {
    this.assetFileUploadList.splice(this.assetFileUploadList.indexOf(data), 1);
  };

  @action
  setAssetFileDeleteList = data => {
    if (data.length == 0) {
      this.assetFileDeleteList = [];
    } else {
      var payload = [];
      data.map(item => {
        payload.push(item);
      });
      this.assetFileDeleteList = payload;
    }
  };
  @action
  removeEntriesAssetFileList = data => {
    this.entriesAssetFileList.splice(
      this.entriesAssetFileList.indexOf(data),
      1
    );
  };
  @action
  setSystemComponents = data => {
    this.systemComponents = data;
  };
  @action
  clearSystemComponents = () => {
    this.systemComponents = [];
  };
  @action
  clearFieldState = () => {
    this.fieldState = {};
  };
  @action
  setServiceHistory = data => {
    this.serviceHistory = data;
  };
  @action
  clearServiceHistory = () => {
    this.serviceHistory = [];
  };
  @action
  clearStore = () => {
    this.testField = "";
    this.addAssetsOpen = false;
    this.bulkEditOpen = false;
    this.healthModalOpen = false;
    this.rowData = null;
    this.budgatoryResp = null;
    this.reqConfirmation = null;
    this.editRowData = null;
    this.singleClick = false;
    this.pageWiseDropDownValues = null;
    this.orgs = null;
    this.equipmentNumberSequence = null;
    this.OrganizationTree = null;
    this.renderedOrganizationTree = null;
    this.locationTree = null;
    this.customerAssets = null;
    this.templates = null;
    this.orgTree = [];
    this.lastAsset = null;
    this.usersForCustomer = null;
    this.assetDetailModalOpen = false;
    this.dashboardChecked = [];
    this.doubleClickedUniqueID = "";
    this.requestRowSelected = null;
    this.systemComponents = [];
    this.editting = false;
    this.ManufacturerList = [];
  };
  @action
  setManufacturerList = data => {
    this.ManufacturerList = data;
  };
  @action getDropDownValues = () => {
    Functions.GetDropDownData().then(resp => {
      var response = resp.data;
      /* GetFinalListManfacturer */
      var optionList;
      var finallist = [];
      for (
        var i = 0;
        i < response.GetFinalListManfacturer.details[0].length;
        i++
      ) {
        Array.prototype.push.apply(
          finallist,
          response.GetFinalListManfacturer.details[0][i]
        );
      }
      optionList = finallist.map(function(val) {
        return { label: val, value: val };
      });
      addAssetsStore.setManufacturerList(optionList);

      /* GetPageWiseDropDownValue */
      var data = response.GetPageWiseDropDownValue.details;
      addAssetsStore.setPageWiseDropDownValues(data);
    });
  };
}

const addAssetsStore = new AddAssetsStore();

export default addAssetsStore;
