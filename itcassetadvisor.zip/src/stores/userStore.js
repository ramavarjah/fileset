import { observable, action, computed } from "mobx";
import Functions from "../api/Functions";
import tabModelStore from "../stores/tabModelStore";
import addAssetsStore from "../stores/addAssetsStore";
import UIFunctions from "../helpers/UIFunctions";
import moment from "moment";
class UserStore {
	@observable me;
	@observable userDetails;
	@observable baseUserDetails;
	@observable preferences;
	@observable basePrefences;
	@observable userDetailsModalOpen;
	@observable editFlag;
	@observable editing;
	@observable lastPath;
	@observable waitForRequest;
	@observable signOutLoading;

	@observable warningQuery;
	constructor() {
		this.me = null;
		this.baseUserDetails = null;
		this.userDetails = null;
		this.preferences = null;
		this.basePrefences = null;
		this.userDetailsModalOpen = false;
		this.editFlag = true;
		this.editing = false;
		this.waitForRequest = false;
		this.lastPath = "/dashboard";
		this.warningQuery = null;
		this.signOutLoading = false;
	}
	@action SignOutLoading = bool => {
		this.signOutLoading = bool;
	};
	@action setMe = me => {
		this.me = me;
		localStorage.setItem("user", me);
		var d = new Date();
		var n = d.getTime();
		localStorage.setItem("lastLogggedAt", n);
		//console.log("userFromLocalStorage:", localStorage.getItem('user'), localStorage.getItem('lastLogggedAt'));
	};
	@action setLogout = () => {
		this.me = false;
		this.userDetails = false;
		localStorage.removeItem("user");
		localStorage.removeItem("lastLogggedAt");
		localStorage.removeItem("tabPreference");
	};
	@action
	setUserDetails = me => {
		this.userDetails = JSON.parse(JSON.stringify(me));
	};
	@action
	reloadUserDetails = () => {
		return Functions.GetUserDetails().then(resp => {
			//eslint-disable-next-line
			console.log("userDetails>>", resp.data);
			this.userDetails = resp.data.userDetails;
			return true;
		});
	};
	@action setWaitForRequest = bool => {
		this.waitForRequest = bool;
	};
	@action
	setlastPath = lastPath => {
		this.lastPath = lastPath;
	};
	@action
	setbaseUserDetails = me => {
		this.baseUserDetails = JSON.parse(JSON.stringify(me));
	};
	@action
	seteditFlag = me => {
		this.editFlag = me;
	};
	@action
	setEditing = me => {
		this.editing = me;
	};
	@action
	setPreferences = me => {
		this.preferences = JSON.parse(JSON.stringify(me));
	};
	@action
	setbasePreferences = me => {
		this.basePrefences = JSON.parse(JSON.stringify(me));
	};
	@action
	setUserDetailsModalopen = bool => {
		this.userDetailsModalOpen = bool;
	};
	@action
	addToPreference = ss => {
		this.editing = true;
		var currentState = this.preferences;
		for (var i = 0; i < Object.keys(ss).length; i++) {
			currentState[Object.keys(ss)[i]] = Object.values(ss)[i];
		}

		this.preferences = currentState;
	};

	@action
	addToUserDetails = ss => {
		this.editing = true;
		var currentState = this.userDetails;
		for (var i = 0; i < Object.keys(ss).length; i++) {
			currentState[Object.keys(ss)[i]] = Object.values(ss)[i];
		}
		this.userDetails = currentState;
	};
	@action
	addToUserDetailsFromCode = ss => {
		var currentState = this.baseUserDetails;
		for (var i = 0; i < Object.keys(ss).length; i++) {
			currentState[Object.keys(ss)[i]] = Object.values(ss)[i];
		}
		this.baseUserDetails = currentState;
	};

	@action
	changeAssetGroups = (ss, flag) => {
		this.editing = true;
		var currentState = this.preferences.NotificationAssetGroups;
		// console.log('setFieldState', ss);
		if (flag === "add") {
			if (currentState.indexOf(ss) < 0) currentState.push(ss);
		} else if (flag === "delete") {
			const index = currentState.indexOf(ss);
			currentState.splice(index, 1);
		}
		//   console.log("currentState", currentState);
		this.preferences.NotificationAssetGroups = currentState;
	};
	@action
	initializeApplication = () => {
		Functions.InitializeApplication().then(resp => {
			//console.log("got UserTabs:", resp);
			if (resp.data.success) {
				var response = resp.data;

				var userDetails = response.userDetails;
				this.setUserDetails(userDetails);
				this.setbaseUserDetails(userDetails);
				this.setMe(userDetails);
				this.setPreferences(userDetails.preferences);
				this.setbasePreferences(userDetails.preferences);

				var tabs = response.userTabs;
				tabModelStore.setTabsJson(JSON.stringify(tabs));
				var inputData = {};
				inputData.data = {};
				inputData.data.data = response.gridDataModel;

				tabModelStore.setCurrentTabColoumns(inputData);
				inputData.data = response.completeGridData; // TODO validate the Performance
				tabModelStore.setCurrentScreenDataJson(inputData);
				// tabModelStore.setCurrentScreenDataLoading(false);
				tabModelStore.setChartCategoryData(JSON.stringify(response.viewNames));
				tabModelStore.setChartViewData(JSON.stringify(response.subViewOptions));
				tabModelStore.setActiveCategoryId(
					tabModelStore.getActiveTab.ChartCategoryId
				);
				tabModelStore.setChartId(tabModelStore.getActiveTab.ChartViewId);
				tabModelStore.setWorkingHours(
					tabModelStore.getActiveTab.NoOfWorkingHours
				);
				tabModelStore.setPreset(tabModelStore.getActiveTab.DatePreset);
				UIFunctions.setPreset(tabModelStore.getActiveTab.DatePreset);
				tabModelStore.setTabStartDate(
					moment(tabModelStore.getActiveTab.ChartStartDate)
				);
				tabModelStore.setTabEndDate(
					moment(tabModelStore.getActiveTab.ChartEndDate)
				);
				addAssetsStore.getDropDownValues();
				userStore.userDetails.CustomerId == ""
					? ""
					: addAssetsStore.getAllApi("CreateAsset");
			}
		});
	};
	@action
	setWarningQuery = () => {
		var tabPreference = JSON.parse(localStorage.getItem("tabPreference"));
		var activeTab = tabModelStore.getActiveTab.TabId;
		tabPreference[activeTab] = true;
		localStorage.setItem("tabPreference", JSON.stringify(tabPreference));
	};
	@computed
	get getQueryMode() {
		var tabPreference = JSON.parse(localStorage.getItem("tabPreference"));
		var activeTab = tabModelStore.getActiveTab.TabId;
		var warningQuery = tabPreference[activeTab] ? "proceed" : "warn";
		return warningQuery;
	}
}

const userStore = new UserStore();

export default userStore;
export { UserStore };
