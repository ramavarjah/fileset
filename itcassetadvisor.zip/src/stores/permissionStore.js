import { observable, action, computed } from 'mobx';

class PermissionStore {
  @observable permissions;
  @observable bulkEditPermissions;
  @observable validator;
  @observable chartLoading;


  constructor() {

    this.permissions = {};
    this.bulkEditPermissions = {};
    this.chartLoading = false;
  }
  @action clearPermissions = () => {
    this.permissions = {};
    this.bulkEditPermissions = {};
    this.chartLoading = false;

  }
  @action setChartLoading = (bool) => {
    // console.log("setChartLoading");
    this.chartLoading = bool;
  }

  @computed get getpermissions() {
    return this.permissions;
  }
  @action setValidator = (item, message) => {
    var data = this.validator;
    data[item] = message;
    this.validator = data;
  }
  @action setPermissions = (permissions) => {
    this.permissions = JSON.parse(permissions);
    // console.log("permissions", this.permissions)
  }

  @computed get getBulkEditPermissions() {
    return this.bulkEditPermissions;
  }

  @action setBulkEditPermissions = (permissions) => {
    this.bulkEditPermissions = permissions;
  }
  @action clear = () => {
    this.bulkEditPermissions = null;
  }
}

const permissionStore = new PermissionStore();

export default permissionStore;
