import { observable, action, computed } from "mobx";
import Functions from "../api/Functions";
import UIFunctions from "../helpers/UIFunctions";
import moment from "moment";

class oOStore {
  @observable
  rowData;
  @observable
  dataLoaded;

  @observable
  columns;
  @observable
  dataArray;
  @observable
  selectedRow;

  //entries
  @observable
  entriesRowData;
  @observable
  entriesDataLoaded;
  @observable
  entriesColumns;
  @observable
  entriesDataArray;
  @observable
  entireData;
  @observable
  entriesSelectedRow;
  @observable
  equipmentNumbers;
  @observable
  ootcasenum;
  @observable
  investigators;
  @observable
  currentStep;
  @observable
  isCaseSelected;
  @observable
  isEntrySelected;
  @observable
  entriesFileList;
  @observable
  filterQuickTag;
  @observable
  showDiv;
  @observable
  ModelNo;
  @observable
  SerialNo;
  @observable
  Manufacturer;

  constructor() {
      this.rowData = {};
      this.entriesRowData = {};
      this.dataLoaded = false;
      this.entriesDataLoaded = false;
      this.showDiv = false;
      this.columns = [
          {
              field: "CaseId",
              headerName: "Case Number",
              cellRenderer: this.caseNumberCellRenderer,
              width: 100,
              cellStyle: { "text-align": "left" }
          },
          {
              field: "CreatedOn",
              headerName: "Date Opened",
              valueFormatter: this.dateFormatter
          },
          { field: "Status", headerName: "Out of Tolerance Status" },
          { field: "Investigator", headerName: "Investigator" }
      ];
      this.dataArray = [];
      this.selectedRow = {};

      this.entriesColumns = [
          { field: "EntryId", headerName: "Entry Number" },
          {
              field: "CreatedOn",
              headerName: "Entry Date",
              valueFormatter: this.dateFormatter
          },
          { field: "Investigator", headerName: "Investigator" },
          {
              field: "QuickTag",
              headerName: "Quick tag",
              cellRenderer: this.quickTagCellRenderer
          }
      ];
      this.entriesDataArray = [];
      this.entireData = [];
      this.entriesSelectedRow = {};
      this.equipmentNumbers = [];
      this.investigators = [];
      this.currentStep = "step1";
      this.isCaseSelected = false;
      this.isEntrySelected = false;
      this.entriesFileList = [];
      this.ootcasenum = "";
      this.ModelNo = "";
      (this.SerialNo = ""), (this.Manufacturer = "");
  }
  @action
  setselectedRow = data => {
      // console.log(data);
      this.selectedRow = data;
  };
  @action
  setEntriesSelectedRow = data => {
      // console.log(data);
      this.entriesSelectedRow = data;
  };
  @action
  getData = () => {
      //change this code and get the data from server (instead of timeout make api call)
      Functions.GetAllCases().then(response => {
          this.dataArray = response.data.cases;
          this.dataLoaded = true;
      });
  };
  @action
  getEntriesData = () => {
      //change this code and get the data from server (instead of timeout make api call)
      Functions.GetAllEntries(this.selectedRow.CaseId).then(response => {
          this.entriesDataArray = response.data.entries;
          this.entireData = response.data.entries;
          this.entriesDataLoaded = true;
      });
  };
  @action
  submitNewCase = data => {
      Functions.GetAssetInfo(data.equipmentNo).then(response => {
          if (response.data.success) {
              this.ModelNo = response.data.data[0].ModelNo;
              this.Manufacturer = response.data.data[0].Manufacturer;
              this.SerialNo = response.data.data[0].SerialNo;
              Functions.CreateNewCase(
                  data.caseNumber,
                  data.investigator,
                  data.status,
                  data.impact,
                  data.action,
                  data.description,
                  data.note,
                  data.equipmentNo,
                  this.Manufacturer,
                  this.ModelNo,
                  this.SerialNo
              ).then(response => {
                  if (response.data.success) {
                      UIFunctions.Toast(
                          "New case has been created successfully",
                          "success"
                      );
                  } else {
                      UIFunctions.Toast(
                          "There was an error in creating the new case",
                          "error"
                      );
                  }
              });
          } else {
              UIFunctions.Toast(
                  "There was an error in creating the new case",
                  "error"
              );
          }
      });
  };
  //dummy function to generate dummy data
  @action
  createRows = () => {
      let rows = [];
      for (let i = 1; i < 100; i++) {
          rows.push({
              CaseNumber: i,
              Investigator: "Investigator " + i,
              Status: "Status " + i,
              Impact: i,
              Action: i,
              Description: "Description " + i,
              Updated: "Updated " + i,
              Note: "Note " + i
          });
      }
      this.dataArray = rows;
      this.dataLoaded = true;
  };
  //dummy function to generate dummy data
  @action
  createEntriesRows = () => {
      let rows = [];
      for (let i = 1; i < 100; i++) {
          rows.push({
              CaseNumber: i,
              Investigator: "Investigator " + i,
              Status: "Status " + i,
              Impact: i,
              Action: i,
              Description: "Description " + i,
              Updated: "Updated " + i,
              Note: "Note " + i
          });
      }
      this.entriesDataArray = rows;
      this.entriesDataLoaded = true;
      // console.log("generating oot data done")
  };

  @action
  setRowJson = data => {
      this.rowData = data;
  };
  @action
  setDataLoaded = bool => {
      this.dataLoaded = bool;
  };
  @computed
  get getRowJson() {
      return this.rowData;
  }

  @action
  setEquipmentNumbers = () => {
      Functions.GetEquipmentNumbersForOOT().then(response => {
          this.equipmentNumbers = response.data.data;
      });
  };

  @action
  setOotCaseNumber = () => {
      Functions.GetOotCaseNumberSequence().then(response => {
          this.ootcasenum = response.data.sequence;
      });
  };

  @action
  setInvestigators = equipment => {
      Functions.GetAllUsersForCustomer("", equipment).then(response => {
          this.investigators = response.data.UserList;
      // console.log("investigators : ",this.investigators);
      });
  };

  @action
  setCurrentStep = step => {
      this.currentStep = step;
  };

  @action
  dateFormatter = params => {
      return moment(params.value).format("YYYY-MM-DD");
  };

  @action
  setIsCaseSelected = data => {
      // console.log(data);
      this.isCaseSelected = data;
  };

  @action
  setIsEntrySelected = data => {
      // console.log(data);
      this.isEntrySelected = data;
  };

  @action
  setEntriesFileList = data => {
      // console.log(data);
      this.entriesFileList = data;
  };

  @action
  linkFormatter = params => {
      var eDiv = document.createElement("div");
      eDiv.innerHTML =
      "<a href='" + params.value + "'" + " target='_blank'>Download</a>";
      return eDiv;
  };
  @action
  caseNumberCellRenderer = params => {
      const status = params.data.Status.replace(/\s+/g, "").toLowerCase();
      let statusCell = document.createElement("div");
      statusCell.innerHTML =
      '<div class="caseLogCaseNumberColumn ' +
      status +
      '"><label class="' +
      status +
      '"> ' +
      params.value +
      " </label></div>";
      return statusCell;
  };
  @action
  quickTagCellRenderer = params => {
      let tagCell = document.createElement("div");
      tagCell.innerHTML =
      '<div class="ootEntriesQuickTagColumn"><label class="quickTagLabel"> ' +
      params.value +
      " </label></div>";
      tagCell.addEventListener("click", () => {
          this.applyQuickTagFilter(params.value);
      });

      return tagCell;
  };

  @action
  markAsReadMasterRow = row => {
      var newArray = [];
      this.dataArray.map(item => {
          var newGriddata = item;
          if (item.CaseId == row.CaseId) {
              item.read = true;
          }
          newArray.push(newGriddata);
      });
      this.dataArray = newArray;
      return true;
  };

  @action
  applyQuickTagFilter = quicktag => {
      if (quicktag != undefined) {
          this.filterQuickTag = quicktag;
          this.showDiv = true;
          const filteredRowData = this.entriesDataArray.filter(
              r => r.QuickTag == quicktag
          );
          this.entriesDataArray = filteredRowData;
      } else {
          this.entriesDataArray = this.entireData;
          this.showDiv = false;
      }
      //entireData
  };
}
const ooStore = new oOStore();

export default ooStore;
