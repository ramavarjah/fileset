import { observable, action, computed } from "mobx";
import Functions from "../api/Functions";
import moment from "moment";
import UIFunctions from "../helpers/UIFunctions";
import userStore from "./userStore";
import _ from "lodash";

const editInfoFormKeys = [
  "assetNumber",
  "calReport",
  "calInterval",
  "serviceAgreement",
  "orderNumber",
  "attachPurchaseOrder",
  "comments",
  "attachfaultreportfilename",
  "attachpurchaseorderfilename"
];

const defaultReqBasePayload = {
  permissionkey: "hydraxtest",
  reqprefix: "",
  reqlastname: "",
  reqfirstname: "",
  reqemail: "",
  reqphone: "",
  reqfax: "",
  reqline1: "",
  reqline2: "",
  reqline3: "",
  reqline4: "",
  reqcompanyname: "",
  reqstate: "",
  reqpostalcode: "",
  reqcity: "",
  reqcountry: "",
  biladdresscontact: "",
  biladdressphone: "",
  biladdresscompanyname: "",
  biladdressline1: "",
  biladdressline2: "",
  biladdressline3: "",
  biladdresscity: "",
  biladdresspostalcode: "",
  biladdressstate: "",
  biladdresscountry: "",
  biladdressvatid: "",
  pickupoption: "",
  pickupcontact: "",
  pickupphone: "",
  pickupcompanyname: "",
  pickupline1: "",
  pickupline2: "",
  pickupline3: "",
  pickupline4: "",
  pickupcity: "",
  pickuppostalcode: "",
  pickupprovince: "",
  pickupstate: "",
  pickupcountry: "",
  returnoption: "",
  returncontact: "",
  returnphone: "",
  returncompanyname: "",
  returnline1: "",
  returnline2: "",
  returnline3: "",
  returnline4: "",
  returncity: "",
  returnpostalcode: "",
  returnprovince: "",
  returnstate: "",
  returncountry: "",
  sritems: [
    {
      manufacturer: "",
      modelno: "",
      serialno: "",
      custassetno: "",
      calcycle: "",
      agreementno: "",
      purchaseorderno: "",
      paymentmethod: "",
      attachpurchaseorderfilename: "",
      attachpurchaseorderfile: "",
      attachfaultreportfilename: "",
      attachfaultreportfile: "",
      requestedservice: "",
      preferreddate: "",
      fault: ""
    }
  ]
};

class SRStore {
  @observable srGridLoading;
  @observable sRequests;
  @observable SRMode;
  @observable SRDueDateMode;
  @observable middleGridPagination;
  @observable SelectedAssetsPagination;
  @observable sddGridLoading;
  @observable sddData;
  @observable sddPagination;
  @observable localSearchValue;
  @observable srOptionStatus;
  @observable srGetCartItems;
  @observable cartItems;
  @observable sddRequests;
  @observable PastDue;
  @observable AddAll;
  @observable navigationArrows;
  @observable AddingCartItem;
  @observable loadingIcon;
  @observable loadingState;
  @observable proceedCheckout;
  @observable customSelected;
  @observable formDropDownData;
  @observable isServiceRequest;
  @observable dropDownServices;
  @observable dropdown;
  @observable bgData;
  @observable editInfoOpen;
  @observable editInfoData;
  @observable editInfoData1;
  @observable requestedService;
  @observable dummyData;
  @observable showImage;
  @observable InfolineResponse;
  @observable currentSrStep;
  @observable removeAllButton;
  @observable countryCode;
  @observable editInfoContent;
  @observable srPaymentMethods;
  @observable faultReportUploadFile;
  @observable serviceRequestConfirmation;
  @observable rowSelectedAssetsData;
  @observable currentIndex;
  @observable nextIndex;
  @observable previousIndex;
  @observable editInfoFieldsChange;
  @observable disableNextAssetButton;
  @observable disablePreviousAssetButton;
  @observable dynamicContactDetails;
  @observable dynamicInfoDetails;
  @observable cartItemsLoaded;
  @observable isCreditCardPayment;

  constructor() {
    this.cartItemsLoaded = false;
    this.dynamicContactDetails = 0;
    this.dynamicInfoDetails - 0;
    this.disableNextAssetButton = false;
    this.disablePreviousAssetButton = false;
    this.editInfoFieldsChange = false;
    this.previousIndex = 0;
    this.nextIndex = 0;
    this.currentIndex = 0;
    this.serviceRequestConfirmation = false;
    this.faultReportUploadFile = [];
    this.srPaymentMethods = [];
    this.editInfoContent = {};
    this.removeAllButton = false;
    this.currentSrStep = "step1";
    this.showImage = false;
    this.InfolineResponse = {};
    this.calReportUpload = false;
    this.purchaseOrderUpload = false;
    this.requestedService = {};
    this.editInfoData = {};
    this.editInfoData1 = {};
    this.dummyData = {};
    this.editInfoOpen = false;
    this.bgData = false;
    this.dropDownServices = [];
    this.shippingDetails = {};
    this.cartItems = {};
    this.dropdown = {};
    this.srGridLoading = true;
    this.AddingCartItem = true;
    this.ItemDisable = false;
    this.sddGridLoading = true;
    this.SRMode = "SR_Min";
    this.SRDueDateMode = "SR_DD_Min";
    this.sRequests = [];
    this.SRDueDataDAta = [];
    this.sddData = [];
    this.srOptionStatus = "open";
    this.localSearchValue = "";
    this.PastDue = false;
    this.AddAll = true;
    this.navigationArrows = false;
    this.proceedCheckout = false;
    this.loadingIcon = false;
    this.loadingState = false;
    this.customSelected = false;
    this.isServiceRequest = false;
    this.isCreditCardPayment = false;
    this.countryCode = "";
    this.SelectedAssetsPagination = {
      showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChange2,
      current: 1,
      pageNumber: 1,
      defaultPageNumber: 1,
      pageSize: 10,
      defaultPageSize: 10
    };
    this.middleGridPagination = {
      showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChange,
      current: 1,
      pageNumber: 1,
      defaultPageNumber: 1,
      pageSize: 10,
      defaultPageSize: 10
    };
    this.sddRequests = {
      startDate: moment().startOf("day"),
      endDate: moment()
        .add(30, "day")
        .endOf("day")
    };
    this.sddPagination = {
      showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChange1,
      current: 1,
      pageNumber: 1,
      defaultPageNumber: 1,
      pageSize: 10,
      defaultPageSize: 10
    };
    this.formDropDownData = {};
    this.NewReq_basepayload = JSON.parse(JSON.stringify(defaultReqBasePayload));
    this.rowSelectedAssetsData = [];
  }

  @action setNewReq_basepayload = data => {
    this.NewReq_basepayload = data;
  };

  @action setIsCreditCardPayment = data => {
    this.isCreditCardPayment = data;
  };

  @action clearNewReq_basepayload = () => {
    this.NewReq_basepayload = JSON.parse(JSON.stringify(defaultReqBasePayload));
  };

  @action disableRemoveAllButton = bool => {
    this.removeAllButton = bool;
  };
  @action setDummyData = data => {
    this.dummyData = data;
  };
  @action updateServiceRequestConfirmation = bool => {
    this.serviceRequestConfirmation = bool;
  };
  @action nextAsset = () => {
    const keys = Object.keys(this.cartItems);
    if (this.currentIndex == keys.length - 1) {
      this.disableNextAssetButton = true;
    } else {
      this.nextIndex = ++this.currentIndex;
      this.updateEditInfoContent(
        this.cartItems[keys[this.nextIndex]][0].UniqueID
      );
    }
  };
  @action updateDynamicContactDetails = height => {
    this.dynamicContactDetails = height;
  };
  @action updateDynamicInfoDetails = height => {
    this.dynamicInfoDetails = height;
  };
  @action previousAsset = () => {
    const keys = Object.keys(this.cartItems);
    this.editInfoFieldsChange;
    if (this.currentIndex == 0) {
      this.disablePreviousAssetButton = true;
    } else {
      this.previousIndex = --this.currentIndex;
      this.updateEditInfoContent(
        this.cartItems[keys[this.previousIndex]][0].UniqueID
      );
    }
  };
  @action updateEditInfoFieldsChange = bool => {
    this.editInfoFieldsChange = bool;
  };
  @action updateEditInfoContent = (UniqueID, mode = "save") => {
    const keys = Object.keys(this.cartItems);
    this.currentIndex = keys.indexOf(UniqueID);
    if (this.currentIndex == 0) {
      if (this.currentIndex == keys.length - 1) {
        this.disableNextAssetButton = true;
        this.disablePreviousAssetButton = true;
      } else {
        this.disableNextAssetButton = false;
        this.disablePreviousAssetButton = true;
      }
    } else if (this.currentIndex == keys.length - 1) {
      this.disableNextAssetButton = true;
      this.disablePreviousAssetButton = false;
    } else {
      this.disableNextAssetButton = false;
      this.disablePreviousAssetButton = false;
    }
    if (mode == "save") {
      this.editInfoContent = this.cartItems[UniqueID][0];
    } else if (mode == "clear") {
      this.setRequestedService("");
      delete this.cartItems[UniqueID][0].requestedService;
      this.editInfoContent = this.cartItems[UniqueID][0];
      editInfoFormKeys.map(i => (this.editInfoContent[i] = ""));
      this.editInfoContent.paymentMethod = undefined;
      this.editInfoContent.preferredDate = "";
    } else {
      ("");
    }
  };
  @action setEditInfoFormValues = () => {
    let { editInfoContent } = this;
    editInfoFormKeys.map(
      i => (editInfoContent[i] = editInfoContent[i] ? editInfoContent[i] : "")
    );
    editInfoContent["requestedService"] = editInfoContent["requestedService"]
      ? editInfoContent["requestedService"] == ""
        ? undefined
        : editInfoContent["requestedService"]
      : undefined;
    editInfoContent["purchaseOrderUpload"] = editInfoContent[
      "purchaseOrderUpload"
    ]
      ? editInfoContent["purchaseOrderUpload"] == ""
        ? undefined
        : editInfoContent["purchaseOrderUpload"]
      : undefined;
    editInfoContent["calRep"] = editInfoContent["calRep"]
      ? editInfoContent["calRep"] == ""
        ? undefined
        : editInfoContent["calRep"]
      : undefined;
    editInfoContent["paymentMethod"] =
      editInfoContent.paymentMethod == ""
        ? undefined
        : editInfoContent.paymentMethod;
    editInfoContent["preferredDate"] =
      editInfoContent.preferredDate == ""
        ? ""
        : editInfoContent.preferredDate
        ? editInfoContent.preferredDate
        : moment().add(1, "day");
  };
  @action updateFaultReportUpload = file => {
    var self = this;
    if (file.fileList[0]) {
      file.fileList[0].status = "done";
      var r = new FileReader();
      var data = file.fileList[0].originFileObj;
      r.onerror = function() {
        return UIFunctions.Toast("Error in uploading the file", "error");
      };
      r.onload = function() {
        self.editInfoContent["calReport"] = r.result;
        self.editInfoContent["attachfaultreportfilename"] = data.name;
      };
      r.readAsDataURL(data);
    }
  };
  @action updatePurchaseOrderUpload = file => {
    var self = this;
    if (file.fileList[0]) {
      file.fileList[0].status = "done";
      var r = new FileReader();
      var data = file.fileList[0].originFileObj;
      r.onerror = function() {
        return UIFunctions.Toast("Error in uploading the file", "error");
      };
      r.onload = function() {
        self.editInfoContent["attachPurchaseOrder"] = r.result;
        self.editInfoContent["attachpurchaseorderfilename"] = data.name;
      };
      r.readAsDataURL(data);
    }
  };
  @action setEditInfoOpen = bool => {
    this.editInfoOpen = bool;
  };
  @action sddRangeChange = dateStrings => {
    this.sddRequests.startDate = dateStrings[0];
    this.sddRequests.endDate = dateStrings[1];

    if (this.sddRequests.startDate > moment().subtract(1, "day")) {
      this.PastDue = false;
    }
    this.fetchSddRequests(
      this.sddRequests.startDate,
      this.sddRequests.endDate,
      this.sddPagination.pageNumber,
      this.sddPagination.pageSize,
      this.localSearchValue,
      this.PastDue
    );
  };

  @action updateServieRequestStatus = step => {
    this.currentSrStep = step;
  };
  @action setShowImage = bool => {
    this.showImage = bool;
  };
  @action parseCartItems = (
    record,
    requestedService,
    editInfoFormValues = {}
  ) => {
    const values = {
      SerialNo: record.SerialNo ? record.SerialNo : "",
      UniqueID: record.UniqueID ? record.UniqueID : "",
      assetNumber: record.assetNumber ? record.assetNumber : "",
      attachPurchaseOrder: record.attachPurchaseOrder
        ? record.attachPurchaseOrder
        : "",
      calInterval: record.calInterval ? record.calInterval : "",
      calReport: record.calReport ? record.calReport : "",
      comments: record.comments ? record.comments : "",
      Manufacturer: record.Manufacturer ? record.Manufacturer : "",
      ModelNo: record.ModelNo ? record.ModelNo : "",
      orderNumber: record.orderNumber ? record.orderNumber : "",
      paymentMethod: record.paymentMethod ? record.paymentMethod : "",
      preferredDate: record.preferredDate
        ? record.preferredDate
        : this.editInfoContent.preferredDate == ""
        ? ""
        : moment().add(1, "day"),
      requestedService: requestedService,
      serviceAgreement: record.serviceAgreement ? record.serviceAgreement : ""
    };
    if (
      !_.isEmpty(editInfoFormValues) &&
      _.isEmpty(editInfoFormValues.calRep)
    ) {
      editInfoFormValues.calReport = "";
      editInfoFormValues.attachfaultreportfilename = "";
    }
    if (
      !_.isEmpty(editInfoFormValues) &&
      _.isEmpty(editInfoFormValues.purchaseOrderUpload)
    ) {
      editInfoFormValues.attachPurchaseOrder = "";
      editInfoFormValues.attachpurchaseorderfilename = "";
    }
    const keys = Object.keys(this.cartItems);
    let updatedCartItems = keys.map(i => this.cartItems[i][0]);
    if (
      editInfoFormValues.serviceAgreement ||
      editInfoFormValues.orderNumber ||
      editInfoFormValues.paymentMethod
    ) {
      updatedCartItems.forEach(function(key) {
        if (!key.serviceAgreement) {
          key.serviceAgreement = editInfoFormValues.serviceAgreement;
        }
        if (!key.orderNumber) {
          key.orderNumber = editInfoFormValues.orderNumber;
        }
        if (!key.paymentMethod) {
          key.paymentMethod = editInfoFormValues.paymentMethod;
        }
      });
    }
    this.cartItems[record.UniqueID][0] = Object.assign(
      this.cartItems[record.UniqueID][0],
      values,
      editInfoFormValues
    );
  };
  @action setSrPaymentMethods = data => {
    this.srPaymentMethods = data ? data : [];
  };

  @action setRequestedService = (record, e) => {
    this.requestedService[record.UniqueID] = e;
  };
  @action setIsServiceRequest = bool => {
    this.isServiceRequest = bool;
  };
  @action setnavigationArrows = bool => {
    this.navigationArrows = bool;
  };
  @action
  setProceedCheckout = bool => {
    this.proceedCheckout = bool;
  };
  @action
  setDropdownOptions = options => {
    this.dropdownOptions = options;
  };
  @action onShowSizeChange = (current, pageSize) => {
    this.middleGridPagination.pageSize = pageSize;
  };
  @action onShowSizeChange1 = (current, pageSize) => {
    this.sddPagination.pageSize = pageSize;
  };
  @action onShowSizeChange2 = (current, pageSize) => {
    this.SelectedAssetsPagination.pageSize = pageSize;
  };
  @action setloading = srGridLoading => {
    this.srGridLoading = srGridLoading;
  };
  @action setPastDue = bool => {
    this.PastDue = bool;
  };
  @action setAddAll = bool => {
    this.AddAll = bool;
  };
  @action LoadingState = bool => {
    this.loadingState = bool;
  };
  @action
  setSRMode = bool => {
    this.SRMode = bool;
  };
  @action
  setSRDueDatesMode = bool => {
    this.SRDueDateMode = bool;
  };

  @action fetchSRequests = (
    Type,
    PageSize,
    PageNumber,
    date,
    localSearchValue
  ) => {
    if (this.loadingState) {
      this.loadingIcon = true;
    }
    this.srGridLoading = true;
    return Functions.GetAllServiceRequests(
      Type,
      PageSize,
      PageNumber,
      date,
      localSearchValue
    ).then(resp => {
      this.loadingIcon = false;
      this.loadingState = false;
      this.sRequests = resp.data.data;
      this.middleGridPagination["total"] = resp.data.total;
      this.srGridLoading = false;
    });
  };
  @action
  getFormDropDownData() {
    var permissionkey = "hydraxtest";
    let isocode = userStore.userDetails.Country
      ? userStore.userDetails.Country
      : "US";
    var req = {
      permissionkey: permissionkey,
      isocode: isocode
    };
    return Functions.serviceRequest(req, "SRGetCountryInfo").then(resp => {
      this.formDropDownData = resp.data.details.result;
      return resp;
    });
  }
  @action srGetAllCartItems = () => {
    this.sddGridLoading = true;
    this.cartItemsLoaded=false;
    return Functions.GetAllCartItems().then(resp => {
      if (resp.data) {
        this.setCartItems(resp.data.cartItems);
        this.cartItemsLoaded = true;
        this.fetchSddRequests(
          this.sddRequests.startDate,
          this.sddRequests.endDate,
          this.sddPagination.pageNumber,
          this.sddPagination.pageSize,
          this.localSearchValue,
          this.PastDue
        );
      } else {
        this.cartItemsLoaded = true;
        this.sddGridLoading = false;
        this.setCartItems({});
      }
    });
  };
  @action srAddItemsToCart = data => {
    this.sddGridLoading = true;
    return Functions.AddItemsToCart(data)
      .then(resp => {
        if (resp.data.success) {
          UIFunctions.Toast("Asset added to the cart!", "success");
          this.fetchSddRequests(
            this.sddRequests.startDate,
            this.sddRequests.endDate,
            this.sddPagination.pageNumber,
            this.sddPagination.pageSize,
            this.localSearchValue,
            this.PastDue
          );
        }
        this.setCartItems(resp.data.cartItems);
      })
      .catch(() => {
        this.sddGridLoading = false;
        return false;
      });
  };
  @action setCartItems = data => {
    this.cartItems = data;
  };
  @action updateInfoCartItems = inputItem => {
    Object.keys(this.cartItems).map(item => {
      let reqService = this.requestedService;
      let cartItms = this.cartItems;
      if (
        inputItem.modelno == this.cartItems[item][0].ModelNo &&
        inputItem.serialno == this.cartItems[item][0].SerialNo
      ) {
        cartItms[item][0].requestedService = inputItem.requestedservice;
        reqService[item] = inputItem[item];
      }
      this.requestedService = reqService;
      this.cartItems = cartItms;
      return true;
    });
  };
  @action setEditInfoCartItems = () => {
    this.cartItems[this.editInfoData1.UniqueID][0] = Object.assign(
      this.cartItems[this.editInfoData1.UniqueID][0],
      this.editInfoData1
    );
  };

  @action setInfolineResponse = data => {
    this.InfolineResponse = data;
    return true;
  };
  @action setdropdown = data => {
    this.dropdown = data;
  };
  @action srDeleteItemsFromCart = (
    UniqueId,
    modelno,
    serialno,
    mode = "any"
  ) => {
    return Functions.DeleteItemsFromCart(UniqueId, modelno, serialno).then(
      resp => {
        if (resp.data.success) {
          UIFunctions.Toast("Asset removed from the cart! ", "success");
          var newCartItems = resp.data.cartItems;
          let updatedCartItems = {};
          if (mode == "selectedassets") {
            Object.keys(this.cartItems).map(i => {
              if (newCartItems[i]) {
                updatedCartItems[i] = this.cartItems[i];
              }
            });
            this.setCartItems(updatedCartItems);
          } else {
            this.setCartItems(newCartItems);
          }

          return mode != "selectedassets"
            ? this.fetchSddRequests(
                this.sddRequests.startDate,
                this.sddRequests.endDate,
                this.sddPagination.pageNumber,
                this.sddPagination.pageSize,
                this.localSearchValue,
                this.PastDue
              )
            : "";
        }
      }
    );
  };
  @action srAddAllItemsToCart = (StartDate, EndDate, Filter, PastDue) => {
    this.sddGridLoading = true;
    Functions.AddAllItemsToCart(StartDate, EndDate, Filter, PastDue).then(
      resp => {
        if (resp.data) {
          UIFunctions.Toast("All Assets added to the cart!", "success");
          this.setCartItems(resp.data.cartItems);
          this.fetchSddRequests(
            this.sddRequests.startDate,
            this.sddRequests.endDate,
            this.sddPagination.pageNumber,
            this.sddPagination.pageSize,
            this.localSearchValue,
            this.PastDue
          );
        }
        else {
          UIFunctions.Toast("Something went wrong", "error");
          this.sddGridLoading = false;
        }
      }
    );
  };
  @action removeAllCartItems = () => {
    this.disableRemoveAllButton(true);
    Functions.RemoveAllCartItems().then(resp => {
      if (resp.data.success == true) {
        this.disableRemoveAllButton(false);
        this.setCartItems(resp.data.cartItems);
        UIFunctions.Toast("All Assets Removed from the Cart! ", "success");
        this.fetchSddRequests(
          this.sddRequests.startDate,
          this.sddRequests.endDate,
          this.sddPagination.pageNumber,
          this.sddPagination.pageSize,
          this.localSearchValue,
          this.PastDue
        );
      } else {
        this.disableRemoveAllButton(false);
      }
    });
  };
  @action fetchSddRequests = (
    StartDate,
    EndDate,
    pageNumber,
    pageSize,
    localSearchValue,
    PastDue,
    Presets = moment().startOf("day")
  ) => {
    if (this.loadingState) {
      this.loadingIcon = true;
    }
    this.sddGridLoading = true;

    return Functions.FetchCalibrationDateAssets(
      StartDate,
      EndDate,
      pageNumber,
      pageSize,
      localSearchValue,
      PastDue,
      Presets
    )
      .then(resp => {
        this.loadingIcon = false;
        this.loadingState = false;
        this.sddData = resp.data.data;
        this.sddPagination["total"] = resp.data.total;
        this.cartItemsLoaded ? this.sddGridLoading = false : "";
        this.bgData = resp.data.total ? true : false;
        return true;
      })
      .catch(() => {
        this.sddGridLoading = false;
        return false;
      });
  };

  @action
  parseSRItems = () => {
    const cartItems = [];

    const keys = Object.keys(this.cartItems);
    keys.map(e => cartItems.push(...this.cartItems[e]));

    const sritems = [];
    cartItems.map(item => {
      const sritem = {};
      sritem.manufacturer = item.Manufacturer ? item.Manufacturer : ""; //todo field names has to be cross verified
      sritem.modelno = item.ModelNo ? item.ModelNo : "";
      sritem.serialno = item.SerialNo ? item.SerialNo : "";
      sritem.custassetno = item.AssetNo ? item.AssetNo : "";
      sritem.calcycle = item.CalibrationInterval
        ? item.CalibrationInterval
        : "";
      sritem.agreementno = item.serviceAgreement ? item.serviceAgreement : "";
      sritem.paymentmethod = item.paymentMethod ? item.paymentMethod : "";
      sritem.purchaseorderno = item.orderNumber ? item.orderNumber : "";
      sritem.attachpurchaseorderfilename = item.attachpurchaseorderfilename
        ? item.attachpurchaseorderfilename
        : "";
      sritem.attachpurchaseorderfile = item.attachPurchaseOrder
        ? item.attachPurchaseOrder
        : "";
      sritem.attachfaultreportfilename = item.attachfaultreportfilename
        ? item.attachfaultreportfilename
        : "";
      sritem.attachfaultreportfile = item.calReport ? item.calReport : "";
      sritem.requestedservice = item.requestedService
        ? item.requestedService
        : "";
      sritem.preferreddate = item.preferredDate
        ? item.preferredDate.format("YYYY-MM-DD")
        : "";
      sritem.fault = item.comments ? item.comments : "";
      sritems.push(sritem);
    });
    return sritems;
  };

  @action
  getShippingDetails = payload => {
    var actualPayload = payload;
    return Functions.serviceRequest(actualPayload, "SRValidateRequest").then(
      resp => {
        this.servicerequestsLoading = false;
        return resp.data.details;
      }
    );
  };
  @action setDropDownServices = data => {
    this.dropDownServices = data ? data : [];
  };
  @action
  serviceRequestNewAddCheck = rows => {
    this.rowSelectedAssetsData = rows;
  };
  @action
  updateSritems = (inputItem, mode = "edit") => {
    //inputItem=obj,mode="edit"||"delete"
    let srItems = this.NewReq_basepayload.sritems;
    srItems.map((item, index) => {
      if (
        inputItem.modelno == item.modelno &&
        inputItem.serialno == item.serialno
      ) {
        if (mode == "delete") {
          srItems.splice(index, 1);
        } else {
          srItems[index] = inputItem;
        }
      }
    });
    this.NewReq_basepayload.sritems = srItems;
    var payload = this.NewReq_basepayload;
    return this.getShippingDetails(payload).then(result => {
      if (result.result) {
        return this.setInfolineResponse(result);
      } else return false;
    });
  };

  @computed
  get getsrGridLoading() {
    return this.srGridLoading;
  }
  @action LocalSearchValue = value => {
    this.localSearchValue = value;
  };
  @action SrOptionStatus = optionStatus => {
    this.srOptionStatus = optionStatus;
  };
  @action OnHomeButton() {
    this.customSelected = false;
    this.localSearchValue = "";
    this.SRMode = "SR_Min";
    this.SRDueDateMode = "SR_DD_Min";
    this.srOptionStatus = "open";
    this.middleGridPagination.pageNumber = 1;
    this.middleGridPagination.pageSize = 10;
    this.middleGridPagination.current = 1;
    this.sddPagination.pageNumber = 1;
    this.sddPagination.pageSize = 10;
    this.sddPagination.current = 1;
    this.PastDue = false;
    this.AddAll = false;
    this.sddRequests.startDate = moment().startOf("day");
    this.sddRequests.endDate = moment()
      .add(30, "day")
      .endOf("day");
  }
}

const srStore = new SRStore();

export default srStore;
export { srStore };
