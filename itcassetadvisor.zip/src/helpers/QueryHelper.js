import tabModelStore from "./../stores/tabModelStore";
import * as mobx from "mobx";
import _ from "lodash";
import moment from "moment";

export function getDatapoints(
    chartId,
    startDate,
    endDate,
    bucketType,
    inputVal
) {
    var tabStartDate = tabModelStore.tabStartDate;
    var tabEndDate = tabModelStore.tabEndDate;
    var activeBucketType = tabModelStore.chartBucketType;
    var utilizationAssets = [];
    var validAssetCount = 0;
    var dataPoints = 0;

    startDate ? (tabStartDate = startDate) : "";
    endDate ? (tabEndDate = endDate) : "";
    bucketType ? (activeBucketType = bucketType) : "";

    tabModelStore.currentScreenDataArray.map(item => {
        item.IsUtilization ? utilizationAssets.push(mobx.toJS(item)) : "";
    });
    validAssetCount = minifyAssetsByChartID(chartId, utilizationAssets);
    var totalDays =
    moment(tabStartDate).diff(moment(tabEndDate), "days") * -1 + 1;
    var bucketMultiplier = activeBucketType == "View By Hours" ? 24 : 1;
    dataPoints = totalDays * bucketMultiplier * validAssetCount;

    var returnObj = {
        dataPoints: dataPoints,
        validAssetCount: validAssetCount,
        activeBucketType: activeBucketType,
        totalDays: totalDays,
        inputVal: inputVal
    };
    return returnObj;

    function minifyAssetsByChartID(chartId, utilizationAssets) {
        var chartQueryTag = getChartQueryTag(chartId);
        var finalAssetsCount = 0;
        if (chartQueryTag) {
            finalAssetsCount = getChartQueryResult(chartQueryTag, utilizationAssets)
                .length;
        } else {
            finalAssetsCount = utilizationAssets.length;
        }
        return finalAssetsCount;
    }
    function getChartQueryTag(chartId) {
        if (chartId === "17") return "Project";
        if (chartId === "9") return "Location";
        if (chartId === "14") return "SerialNo";
        if (chartId === "13") return "Organization";
        if (chartId === "12") return "ModelNo";
        else return false; //means all assets are considered
    }
    function getChartQueryResult(chartQueryTag, utilizationAssets) {
        var queriedUtilizationArray = [];
        utilizationAssets.map(item => {
            queriedUtilizationArray.push(item[chartQueryTag]);
        });
        queriedUtilizationArray = _.uniq(queriedUtilizationArray);
        return queriedUtilizationArray;
    }
}

const QueryHelper = {
    getDatapoints: getDatapoints
};

export default QueryHelper;
