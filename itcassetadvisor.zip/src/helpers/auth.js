import axios from 'axios'
import userStore from './../stores/userStore';
import tabModelStore from './../stores/tabModelStore';
import addAssetsStore from './../stores/addAssetsStore';
import permissionStore from '../stores/permissionStore';
import request from './../api/request'
import URL from './../api/Urls'
var client = axios.create({
  baseURL: URL.hostUrl
});



const onSuccess = function (response) {
  userStore.setMe(null);//todo change to token¸
  userStore.setLogout();//todo change to token
  tabModelStore.clearStore();
  permissionStore.clearPermissions();
  addAssetsStore.clearStore();
  this.props.history.push("/");
  return response;
}

const onError = function (error) {
  return Promise.reject(error.response || error.message);
}

export function signOut() {
  return request({
    method: 'post',
    url: "Thingworx/Server/%2A/Services/Logout",
  })
    .then(onSuccess)
    .catch(onError)
}
export function signIn(data) {
  return client(data)
    .then((resp) => { return resp })
    .catch(onError)
}
