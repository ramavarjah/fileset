import tabModelStore from "./../stores/tabModelStore";
import Functions from "./../api/Functions";
import AmCharts from "@amcharts/amcharts3-react";
import chartConfig from "../views/Charts/chartConfig";
import { notification } from "antd";
// var color = ["#FAFF00", "#33FF00", "#3385FF", "#00FFFF", "#FF005C", "#FF00FF", "#8840FF", "#FF6020", "#99FFB6", "#FFC480", "#DD7693", "#C090FF"];
import { Modal, message } from "antd";
import moment from "moment";
const confirm = Modal.confirm;

export const Confirm = confirm;
export const ShowSuccess = Modal.success;
export const ShowInfo = Modal.info;
export const ShowError = Modal.error;
export const ShowWarning = Modal.warning;
export const ShowConfirm = Modal.confirm;
export const Toast = function(msg, mode) {
  if (mode == "success")
    notification.success({
      message: "Success",
      description: msg,
      style: {
        "z-Index": 1100
      }
    });
  else if (mode == "info")
    notification.info({
      message: "Notification",
      description: msg,
      style: {
        "z-Index": 1100
      }
    });
  else if (mode == "warn")
    notification.warn({
      message: "Warning",
      description: msg,
      style: {
        "z-Index": 1100
      }
    });
  else if (mode == "error")
    notification.error({
      message: "Error",
      description: msg,
      style: {
        "z-Index": 1100
      }
    });
  else
    notification.open({
      message: "Notification",
      description: msg,
      style: {
        "z-Index": 1100
      }
    });
};

export const setPreset = function(preset) {
  var tabId = tabModelStore.activeTab.TabId;
  var activeChartId = tabModelStore.getActiveTab.ChartViewId;
  var activeCategoryId = tabModelStore.getActiveTab.ChartCategoryId;
  var startDate, endDate;
  if (preset === "Today") {
    startDate = moment()
      .startOf("day")
      .toISOString();
    endDate = moment()
      .endOf("day")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Last Week") {
    startDate = moment()
      .subtract(1, "weeks")
      .startOf("week")
      .toISOString();
    endDate = moment()
      .subtract(1, "weeks")
      .endOf("week")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Last Month") {
    startDate = moment()
      .subtract(1, "month")
      .startOf("month")
      .toISOString();
    endDate = moment()
      .subtract(1, "month")
      .endOf("month")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Yesterday") {
    startDate = moment()
      .subtract(1, "days")
      .startOf("day")
      .toISOString();
    endDate = moment()
      .subtract(1, "days")
      .endOf("day")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "This Week-to-date") {
    startDate = moment()
      .startOf("week")
      .toISOString();
    endDate = moment()
      .endOf("day")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "This Month-to-date") {
    startDate = moment()
      .startOf("month")
      .toISOString();
    endDate = moment()
      .endOf("day")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Last Week-to-date") {
    startDate = moment()
      .subtract(1, "weeks")
      .startOf("week")
      .toISOString();
    endDate = moment()
      .endOf("day")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Last Month-to-date") {
    startDate = moment()
      .subtract(1, "months")
      .startOf("month")
      .toISOString();
    endDate = moment()
      .endOf("day")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "This Month") {
    startDate = moment()
      .startOf("month")
      .toISOString();
    endDate = moment()
      .endOf("month")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "This Quarter") {
    startDate = moment()
      .startOf("quarter")
      .toISOString();
    endDate = moment()
      .endOf("quarter")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "This Quarter-to-date") {
    startDate = moment()
      .startOf("quarter")
      .toISOString();
    endDate = moment()
      .endOf("day")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "This Year") {
    startDate = moment()
      .startOf("year")
      .toISOString();
    endDate = moment()
      .endOf("year")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Next Month") {
    startDate = moment()
      .add(1, "months")
      .startOf("month")
      .toISOString();
    endDate = moment()
      .add(1, "months")
      .endOf("month")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Next Quarter") {
    startDate = moment()
      .add(1, "quarters")
      .startOf("quarter")
      .toISOString();
    endDate = moment()
      .add(1, "quarters")
      .endOf("quarter")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Next Year") {
    startDate = moment()
      .add(1, "years")
      .startOf("year")
      .toISOString();
    endDate = moment()
      .add(1, "years")
      .endOf("year")
      .toISOString();
    tabModelStore.setTabStartDate(moment(startDate));
    tabModelStore.setTabEndDate(moment(endDate));
    Functions.SetDatesInTab(tabId, startDate, endDate).then(resp => {
      if (resp.data.success) {
        switchChart(activeCategoryId, activeChartId, tabId);
      }
    });
  } else if (preset === "Custom") {
    switchChart(activeCategoryId, activeChartId, tabId);
  }
};

export const switchChart = function(categoryId, chartId, tabId) {
  tabModelStore.clearPreviousChartConfig();
  // console.log('switchChart', categoryId, chartId);
  tabModelStore.setChartLoading(true);
  if (categoryId == 1) {
    //console.log('categoryId switched', categoryId, chartId);
    switch (chartId) {
      case "1":
        //console.log('chartSwitch', chartId);
        return Functions.GetAssetCountByLocation(tabId).then(resp => {
          var dataProvider = resp.data.data;
          var config = chartConfig.assetCountByLoc;

          config.dataProvider = dataProvider;
          //console.log("this is the respone : ", resp, config);
          //console.log('dataProviderFromUI', dataProvider)
          tabModelStore.setChartConfig(config);
          // tabModelStore.setPreviousChartConfig(config);
          // tabModelStore.setPreviousDataProvider(dataProvider);
          //console.log('chartData', resp);
        });
      case "2":
        //console.log('chartSwitch', chartId);
        return Functions.GetAssetCountByModelNo(tabId).then(resp => {
          //console.log('chartData', resp);
          var dataProvider = resp.data.data;
          var config = chartConfig.assetCountByModelNo;

          config.dataProvider = dataProvider;
          //console.log("this is the respone : ", resp, config);
          //console.log('dataProviderFromUI', dataProvider)
          tabModelStore.setChartConfig(config);
        });
      case "3":
        //console.log('chartSwitch', chartId);
        return Functions.GetAssetCountByOrganization(tabId).then(resp => {
          //console.log('chartData', resp);
          var dataProvider = resp.data.data;
          var config = chartConfig.assetCountByOrganization;

          config.dataProvider = dataProvider;
          //console.log("this is the respone : ", resp, config);
          tabModelStore.setChartConfig(config);
          // tabModelStore.setPreviousChartConfig(config);

          // tabModelStore.setPreviousDataProvider(dataProvider);
        });
      case "4":
        //console.log('chartSwitch', chartId);
        return Functions.GetAssetCountByManufacturer(tabId).then(resp => {
          //console.log('chartData', resp);
          var dataProvider = resp.data.data;
          var config = chartConfig.barChart;

          config.dataProvider = dataProvider;
          //console.log("this is the respone : ", resp, config);
          //console.log('dataProviderFromUI', dataProvider)
          tabModelStore.setChartConfig(config);
        });
      default:
        //console.log('chartSwitch', 'default', tabId);
        return Functions.GetAssetCountByLocation(tabId).then(resp => {
          //console.log('chartData', resp);
          var dataProvider = resp.data.data;
          var config = chartConfig.assetCountByLoc;

          config.dataProvider = dataProvider;
          //console.log("this is the respone : ", resp, config);
          //console.log('dataProviderFromUI', dataProvider)
          tabModelStore.setChartConfig(config);
          // tabModelStore.setPreviousChartConfig(config);
          // tabModelStore.setPreviousDataProvider(dataProvider);
        });
    }
  } else if (categoryId == 2) {
    //to be completed
    // console.log("categoryId switched", categoryId, chartId); //todo Pass ClientOffset
    switch (chartId) {
      case "5":
        return Functions.GetAssetHealthLocWise(tabId, "Location").then(resp => {
          var dataProvider = resp.data.subnodes;
          var config = chartConfig.assetHealthByCount;
          config.dataProvider = dataProvider;
          tabModelStore.setChartConfig(config);
        });
      case "6":
        return Functions.GetAssetHealthModelWise(
          tabId,
          "ModelNo"
        ).then(resp => {
          var dataProvider = resp.data.data;
          var config = chartConfig.assetHealthByCount;
          config.dataProvider = dataProvider;
          tabModelStore.setChartConfig(config);
        });
      case "7":
        return Functions.GetAssetHealthOrgWise(
          tabId,
          "Organization"
        ).then(resp => {
          var dataProvider = resp.data.subnodes;
          var config = chartConfig.assetHealthByCount;

          config.dataProvider = dataProvider;
          tabModelStore.setChartConfig(config);
        });
      case "8":
        return Functions.GetAssetHealthSerialWise(
          tabId,
          "SerialNo"
        ).then(resp => {
          var dataProvider = resp.data.data;
          var config = chartConfig.assetHealthByCount;
          config.dataProvider = dataProvider;
          tabModelStore.setChartConfig(config);
        });
      case "19":
        return Functions.GetAssetHealthSerialWise(
          tabId,
          "EquipmentNo"
        ).then(resp => {
          var dataProvider = resp.data.data;
          var config = chartConfig.assetHealthByCount;
          config.dataProvider = dataProvider;
          tabModelStore.setChartConfig(config);
        });
      case "20":
        return Functions.GetAssetHealthSerialWise(
          tabId,
          "AssetNo"
        ).then(resp => {
          var dataProvider = resp.data.data;
          var config = chartConfig.assetHealthByCount;
          config.dataProvider = dataProvider;
          tabModelStore.setChartConfig(config);
        });
      default:
        // console.log("chartSwitch", "default", tabId);
        return Functions.GetAssetHealthLocWise(tabId, "Location").then(resp => {
          var dataProvider = resp.data.subnodes;
          var config = chartConfig.assetHealthByCount;
          config.dataProvider = dataProvider;
          tabModelStore.setChartConfig(config);
        });
    }
  } else if (categoryId == 3) {
    return Functions.GetUtilizationViewData(
      tabId,
      tabModelStore.chartCategoryData,
      tabModelStore.chartBucketType
    ).then(resp => {
      //console.log('chartData', resp);
      var dataProvider = resp.data.data;

      var dataSet = resp.data;
      var graphCount = dataSet.graphs.length;
      var graphObj = [];
      for (var x = 0; x < graphCount; x++) {
        var graph = new AmCharts.AmGraph();
        graph.id = "AmGraph-" + x;
        graph.lineThickness = "2";
        graph.bullet = "round";
        graph.title = dataSet.graphs[x];
        graph.valueField = dataSet.graphs[x];
        graph.balloonText =
          "<span style='font-size: 15px;'><b>Value: [[value]]\n</span>Date: [[category]]\n</b> <span style='font-weight:400'><b>" +
          dataSet.graphs[x] +
          "</b></span>";
        graphObj.push(graph);
      }
      var config = chartConfig.assetUtilizationByLoc;
      // var utilizationMessage = resp.data.message;
      if (dataProvider.length < 1) {
        tabModelStore.setchartMessage(resp.data.message);
      } else {
        tabModelStore.setchartMessage("");
      }
      config.dataDateFormat = "";
      config.chartCursor.enabled = true;
      config.chartCursor.oneBalloonOnly = true;
      config.chartCursor.categoryBalloonDateFormat = dataSet.DateFormat;
      config.dataProvider = dataProvider;
      config.graphs = graphObj;
      config.categoryAxis.minPeriod = dataSet.minPeriod;
      tabModelStore.setChartConfig(config);
    });
  } else if (categoryId == 4) {
    tabModelStore.setServiceDueChartLoading(true);
    return Functions.GetServiceDueDateData(tabId).then(resp => {
      var config = chartConfig.assetUtilizationByLoc;

      config.dataProvider = "dataProvider";
      tabModelStore.setChartConfig(config);
      var ss = [];
      for (var itemm in resp.data.data) {
        //   console.log("item", item);
        var item = resp.data.data[itemm];
        var newObj = {};
        newObj.EquipmentNo = item.EquipmentNo;
        newObj.ThingName = item.ThingName;
        Object.keys(item).map((i, index) => {
          var itemsnew = moment(i).format("MM-DD-YYYY");

          if (newObj[itemsnew] == undefined)
            newObj[itemsnew] = Object.values(item)[index];
          else {
            if (newObj[itemsnew] == "#0000")
              newObj[itemsnew] = Object.values(item)[index];
          }
        });
        ss.push(newObj);
      }
      tabModelStore.setServiceDueDateArray(ss);
      tabModelStore.reRenderServiceDueDates();
    });
  } //else console.error("else_categoryId:", categoryId);
};
export const ReRenderGrid = function() {
  var activeTab = tabModelStore.getActiveTab;
  var currentPage = tabModelStore.getCurrentPage;
  var currentStartingItem = tabModelStore.getCurrentStartingItem;
  var currentLimit = tabModelStore.getCurrentLimit;
  var data = {
    TabId: tabModelStore.activeTab.TabId,
    limit: tabModelStore.currentLimit,
    page: tabModelStore.currentPage,
    start: tabModelStore.currentStartingItem
  };
  //   var dataModel = {
  //     TabId: tabModelStore.activeTab.TabId
  //   };
  if (currentPage && currentLimit && currentStartingItem)
    data = {
      TabId: tabModelStore.activeTab.TabId,
      limit: currentLimit,
      page: tabModelStore.getCurrentPage,
      start: currentStartingItem
    };
  //   dataModel = {
  //     TabId: tabModelStore.activeTab.TabId
  //   };
  const onSuccess = function(response) {
    return response;
  };

  const onError = function(error) {
    return Promise.reject(error);
  };

  return Functions.GetGridDataModel(activeTab.TabId)
    .then(resp => {
      tabModelStore.setCurrentTabColoumns(resp);
      return Functions.GetCompleteGridData(data.TabId)
        .then(respp => {
          tabModelStore.setCurrentScreenDataJson(respp);
          tabModelStore.setCurrentScreenDataLoading(false);
          tabModelStore.setDataLoaded(true);
          return onSuccess("success");
        })
        .catch(onError);
    })
    .catch(onError);
};

export const ReRenderChart = function() {
  const onError = function(error) {
    return Promise.reject(error);
  };

  return Functions.GetViewNames(tabModelStore.getActiveTab.TabId)
    .then(resp => {
      if (resp.data.success && resp.data.data) {
        tabModelStore.setChartCategoryData(JSON.stringify(resp.data.data));
      }
      tabModelStore.setActiveCategoryId(
        tabModelStore.getActiveTab.ChartCategoryId
      );
      tabModelStore.setChartId(tabModelStore.getActiveTab.ChartViewId);
      tabModelStore.setPreset(tabModelStore.getActiveTab.DatePreset);
      tabModelStore.setChartBucketType(tabModelStore.getActiveTab.BucketType);
      tabModelStore.setWorkingHours(
        tabModelStore.getActiveTab.NoOfWorkingHours
      );
      tabModelStore.setTabStartDate(
        moment(tabModelStore.getActiveTab.ChartStartDate)
      );
      tabModelStore.setTabEndDate(
        moment(tabModelStore.getActiveTab.ChartEndDate)
      );
      var previousConfig = [];
      tabModelStore.setPreviousChartConfig(previousConfig);
      return Functions.GetSubViewOptions(
        tabModelStore.getActiveTab.TabId,
        tabModelStore.getActiveTab.ChartCategoryId
      )
        .then(resp => {
          // tabModelStore.setChartId(tabModelStore.getActiveTab.ChartViewId);
          if (resp.data.data) {
            tabModelStore.setChartViewData(JSON.stringify(resp.data.data));
          }
          return setPreset(tabModelStore.getActiveTab.DatePreset);
          //switchChart(tabModelStore.getActiveChartCategory, tabModelStore.getActiveTab.ChartViewId, tabModelStore.getActiveTab.TabId)
        })
        .catch(onError);
    })
    .catch(onError);
};
export const isIE = function msieversion() {
  var ua = window.navigator.userAgent;
  var msie = ua.indexOf("MSIE ");

  if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv:11\./)) {
    // If Internet Explorer, return version number
    // console.log("isIE")
    var version = parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
    return version;
  } else {
    // If another browser, return 0
    // console.log("is NotIE")
    return false;
  }
};
export const Message = message;

const UIFunctions = {
  Toast: Toast,
  Message: Message,
  ReRenderGrid: ReRenderGrid,
  ReRenderChart: ReRenderChart,
  switchChart: switchChart,
  Confirm: Confirm,
  ShowSuccess: ShowSuccess,
  ShowInfo: ShowInfo,
  ShowError: ShowError,
  ShowWarning: ShowWarning,
  ShowConfirm: ShowConfirm,
  setPreset: setPreset,
  isIE: isIE
};

export default UIFunctions;
