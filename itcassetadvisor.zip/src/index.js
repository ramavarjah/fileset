import React from "react";
import ReactDOM from "react-dom";
import { LicenseManager } from "ag-grid-enterprise/main";
LicenseManager.setLicenseKey(
  "Keysight_Technologies_Hyrax_1Devs1_SaaS_4_January_2019__MTU0NjU2MDAwMDAwMA==d15ea7c4b887462459653e6c45186c1e"
);

import App from "./App";

import { Provider } from "mobx-react";
import userStore from "./stores/userStore";
import tabModelStore from "./stores/tabModelStore";
import addAssetsStore from "./stores/addAssetsStore";
import loanPoolStore from "./stores/loanPoolStore";
import loanPoolStoreV2 from "./stores/loanPoolStoreV2";
import submitIssuesStore from "./stores/submitIssuesStore";
import serviceRequestStore from "./stores/serviceRequestStore";
import newServiceRequestStore from "./stores/newServiceRequestStore";

import { AppContainer } from "react-hot-loader";
import "babel-polyfill";
import "./i18n";
const stores = {
  userStore,
  tabModelStore,
  submitIssuesStore,
  addAssetsStore,
  loanPoolStore,
  loanPoolStoreV2,
  serviceRequestStore,
  newServiceRequestStore
};
function renderApp(App, stores) {
  ReactDOM.render(
    <AppContainer>
      <Provider {...stores}>
        <App />
      </Provider>
    </AppContainer>,
    document.getElementById("root")
  );
}
renderApp(App, stores);
// Webpack Hot Module Replacement API
if (module.hot) {
  module.hot.accept("./App", () => {
    renderApp(App, stores);
  });
}
