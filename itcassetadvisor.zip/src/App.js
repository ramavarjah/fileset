import React, { Component } from "react";
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";
import { action, autorun } from "mobx";
import PropTypes from "prop-types";
import "font-awesome/css/font-awesome.min.css";
import "npm-font-open-sans/open-sans.css";
import "@cmyee/pushy/css/pushy.css";
import "bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css";
import "simple-line-icons/css/simple-line-icons.css";
import "../scss/style.scss";
import "../css/style.css";
//stores
import userStore from "./stores/userStore";
// Containers
import Full from "./containers/Full/";
// put moment into global space so hacky jQuery-QueryBuilder can use it...
import moment from "moment";
window.moment = moment;
// Views
import Login from "./views/Pages/Login/";
import RequestComponent from "./views/RequestComponent/";
import LoanPool from "./views/LoanPool/";
import UserDetails from "./views/UserDetails/";
import OOT from "./views/OOT/";
import SubmitIssue from "./views/SubmitIssue/";
import LoanPoolNotifications from "./views/LoanPoolNotifications/";

import { LocaleProvider } from "antd";
import enUS from "antd/lib/locale-provider/en_US";

function PrivateRoute({ component: Component, authed, ...rest }) {
  return (
    <Route
      {...rest}
      render={props =>
        authed === true ? (
          <Component {...props} authed={authed} />
        ) : (
          <Redirect
            to={{ pathname: "/login", state: { from: props.location } }}
          />
        )
      }
    />
  );
}

function PublicRoute({ component: Component, authed, ...rest }) {
  return (
    <Route
      {...rest}
      render={props =>
        authed === false ? (
          <Component {...props} />
        ) : (
          <Redirect to="/dashboard" />
        )
      }
    />
  );
}
class App extends Component {
  constructor(props) {
    super(props);
    autorun(() => {
      this.setLoggedIn(!!userStore.me);
    });
    this.setLoggedIn = this.setLoggedIn.bind(this);
    if (localStorage.getItem("user") && localStorage.getItem("lastLogggedAt")) {
      var lastLogin = localStorage.getItem("lastLogggedAt");
      var diff = new Date().getTime() - lastLogin;
      //check userid is valid and lastlogin within 30 minutes
      if (localStorage.getItem("user").length > 6 && diff < 1800000) {
        //todo do some verification ajax call here
        this.state = {
          authed: true,
          location: "dashboard"
        };
      } else
        this.state = {
          authed: false,
          location: "dashboard"
        };
    } else
      this.state = {
        authed: false,
        location: "dashboard"
      };
    var location = window.location.pathname;
    location != "/login" ? userStore.setlastPath(location) : "";
    //store the path which user tries to access before login
  }
  componentDidMount() {
    document.getElementById("root").classList.remove("hidden");
    document.getElementById("divCenter").classList.add("hidden");
  }

  @action
  setLoggedIn(me) {
    this.setState({
      authed: me
    });
  }
  //eslint-disable-next-line
  componentWillReceiveProps(nextProps) {
    if (nextProps.dataLoaded) {
      this.setState({
        authed: true
      });
    }
  }
  render() {
    return (
      <LocaleProvider locale={enUS}>
        <div>
          {/* <DevTools /> */}
          <BrowserRouter>
            <Switch>
              <PublicRoute
                authed={this.state.authed}
                path="/"
                exact
                component={Login}
              />
              <PublicRoute
                authed={this.state.authed}
                path="/login"
                component={Login}
              />
              <PublicRoute
                authed={this.state.authed}
                path="/register"
                component={Full}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/dashboard"
                component={Full}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/request"
                component={RequestComponent}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/loan-pool"
                component={LoanPool}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/user-details"
                component={UserDetails}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/out-of-tolerance"
                component={OOT}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/submit-issue"
                component={SubmitIssue}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/charts"
                component={Full}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/loan-pool-notifications"
                component={LoanPoolNotifications}
              />
              <PrivateRoute
                authed={this.state.authed}
                path="/reports"
                component={Full}
              />
            </Switch>
          </BrowserRouter>
        </div>
      </LocaleProvider>
    );
  }
}

export default App;

App.propTypes = {
  dataLoaded: PropTypes.func
};
