# Asset Advisor - React version


## System Requirements 
> npm and node js 

## Installation Instrucations

>npm install (for installing npm modules) 
>npm start (for master server to start, and access applicaiton at localhost:8080)

## Env Vars
- copy `.example.env` to `.env`
- file `.env` is for use locall and ignored by git
- BASE_SERVICE_URL=default resolves to `/`