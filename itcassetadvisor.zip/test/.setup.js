require('babel-register')({
    presets: ['env']
})

