from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request
)
from app import db
from app.models import Customer
customer = Blueprint('customer', __name__)

@customer.route('/', methods=['GET'])
def index():
    myCustomer = Customer.query.all()
    oneItem = Customer.query.filter_by(emailid="postgres").all()
    return render_template('customer/add_customer.html', myCustomer=myCustomer)

@customer.route('/post_customer', methods=['POST'])
def post_customer():
    if request.is_json:
        content = request.get_json()
    customer= Customer(content["emailid"], content["ExternalRequestIdSequence"],
                       content['HasHealth'], content['Description'],
                       content['Address'], content['CustomerInfolinePassword'],
                       content['IssueIdSequence'],
                       content['CustomerInfolineUserName'],
                       content['LPRequestIdSequence'],
                       content['UniqueIdSequence'],
                       content['HasLoanPool'], content['IsIndexed'],
                       content['HasBase'],
                       content['IsServiceRequestQueryOnAssetNo'],
                       content['PhoneNo'], content['OracleId'],
                       content['UtilizationAndHealthLicense'],
                       content['DisplayName'],content['LoanPoolLicense'],
                       content['CustomerName'],
                       content['TrackAndControlLicense'],
                       content["OotIdSequence"])
    db.session.add(customer)
    db.session.commit()
    return redirect(url_for('customer.index'))
