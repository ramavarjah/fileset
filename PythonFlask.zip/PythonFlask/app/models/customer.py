from .. import db


class Customer(db.Model):
    __tablename__ = 'customers'
    id = db.Column(db.Integer, primary_key=True)
    emailid = db.Column(db.String(), unique=False)
    ExternalRequestIdSequence = db.Column(db.Integer, unique=False)
    HasHealth = db.Column(db.Boolean)
    Description = db.Column(db.String(), unique=False)
    Address = db.Column(db.String(), unique=False)
    CustomerInfolinePassword = db.Column(db.String(), unique=False)
    IssueIdSequence = db.Column(db.Integer, unique=False)
    CustomerInfolineUserName = db.Column(db.String(), unique=False)
    LPRequestIdSequence = db.Column(db.Integer, unique=False)
    UniqueIdSequence = db.Column(db.Integer, unique=False)
    HasLoanPool = db.Column(db.Boolean)
    IsIndexed = db.Column(db.Boolean)
    HasBase = db.Column(db.Boolean)
    IsServiceRequestQueryOnAssetNo = db.Column(db.Boolean)
    PhoneNo = db.Column(db.String(), unique=False)
    OracleId = db.Column(db.String(), unique=False)
    UtilizationAndHealthLicense = db.Column(db.String(), unique=False)
    DisplayName = db.Column(db.String(), unique=False)
    LoanPoolLicense = db.Column(db.String(), unique=False)
    CustomerName = db.Column(db.String(), unique=False)
    TrackAndControlLicense = db.Column(db.String(), unique=False)
    OotIdSequence = db.Column(db.Integer, unique=False)

    def __init__(self, emailid, ExternalRequestIdSequence, HasHealth, Description, Address,
                 CustomerInfolinePassword, IssueIdSequence, CustomerInfolineUserName, LPRequestIdSequence,
                 UniqueIdSequence, HasLoanPool, IsIndexed, HasBase, IsServiceRequestQueryOnAssetNo, PhoneNo,
                 OracleId, UtilizationAndHealthLicense,DisplayName,LoanPoolLicense, CustomerName, TrackAndControlLicense,
                 OotIdSequence):
        self.emailid = emailid
        self.ExternalRequestIdSequence= ExternalRequestIdSequence
        self.HasHealth = HasHealth
        self.Description = Description
        self.Address = Address
        self.CustomerInfolinePassword = CustomerInfolinePassword
        self.IssueIdSequence = IssueIdSequence
        self.CustomerInfolineUserName = CustomerInfolineUserName
        self.LPRequestIdSequence = LPRequestIdSequence
        self.UniqueIdSequence = UniqueIdSequence
        self.HasLoanPool = HasLoanPool
        self.IsIndexed = IsIndexed
        self.HasBase = HasBase
        self.IsServiceRequestQueryOnAssetNo = IsServiceRequestQueryOnAssetNo
        self.PhoneNo = PhoneNo
        self.OracleId = OracleId
        self.UtilizationAndHealthLicense = UtilizationAndHealthLicense
        self.DisplayName = DisplayName
        self.LoanPoolLicense = LoanPoolLicense
        self.CustomerName = CustomerName
        self.TrackAndControlLicense = TrackAndControlLicense
        self.OotIdSequence = OotIdSequence

    def __repr__(self):
        return '<Customer Name %r>' %  self.CustomerName