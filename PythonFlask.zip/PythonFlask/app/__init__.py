import os

from flask import Flask
from flask_assets import Environment
from flask_compress import Compress
from flask_login import LoginManager
from flask_mail import Mail
from flask_rq import RQ
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import CsrfProtect
from config import config

basedir = os.path.abspath(os.path.dirname(__file__))


db = SQLAlchemy()

# Set up Flask-Login
login_manager = LoginManager()
login_manager.session_protection = 'strong'
login_manager.login_view = 'account.login'


def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.debug= True
    # not using sqlalchemy event system, hence disabling it

    config[config_name].init_app(app)

    # Set up extensions

    db.init_app(app)
    login_manager.init_app(app)
    RQ(app)


    # Create app blueprints
    from .customer import customer as customer_blueprint
    app.register_blueprint(customer_blueprint, url_prefix='/customer')


    return app
