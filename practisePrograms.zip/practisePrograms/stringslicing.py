st = "Nokia Networks"
dst = st.split()
print(dst)
fst = st[0:2]
print(fst)
sst = st[6:8]
print(sst)
print(dst[0].replace(fst,sst)+" "+dst[1].replace(sst,fst))


txt = "welcome to the jungle"
x = txt.split()
print(x)


l1= [4,65,23,565,6,3,2,5,6,3,45,5]
l=len(l1)
print(l1[1:l:2])



student ={'name':'John','age':25,'courses': ['Maths','CompSci']}

# student['name']='Satya'
# student['phone']='9972910271'
student.update({'name':'Satya', 'age':47, 'phone':'9972910271'})
# print(student.get('phone','Not Found'))
# del student['age']
print(student.pop('age'))
print(student)
