mylist = ["a", "b", "a", "c", "c"]
mylist = list(dict.fromkeys(mylist))
print(mylist) 

k=[]
for i in mylist:
    if i not in k:
        k.append(i)

print(k)
