numbers = [1, 3, 4, 2] 

# Sorting list of Integers in descending 
numbers.sort(reverse = True) 

print(numbers) 
