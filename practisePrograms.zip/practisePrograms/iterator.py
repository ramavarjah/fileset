L=[1,2,3,4]
it=iter(L)
print(it)
print(next(it))

L = [('Italy', 'Rome'), ('France', 'Paris'), ('US', 'Washington DC')]
print(dict(iter(L)))

f = open('data.txt', 'r')
for i, line in enumerate(f):
    if line.strip() == '':
        print('Blank line at line #%i' % i)

line_list = ['line 1\n', 'line 2  \n']

# Generator expression -- returns iterator
stripped_iter = (line.strip() for line in line_list)
print(stripped_iter)

# List comprehension -- returns list
stripped_list = [line.strip() for line in line_list]
print(stripped_list)
