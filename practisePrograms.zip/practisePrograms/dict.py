def dispfun(origi_func):
    def wrapper(*args, **kwargs):
        print("Wrapper executed this before {}".format(origi_func.__name__))
        return dispfun(*args, **kwargs)
    return wrapper



@dispfun
def display():
    print("Display function")
    
display()



