#!/usr/bin/python3.5

#############################################################
# Filename: jobrun.py
#
# Description:  Wrapper object for database interface
#
#############################################################
import psycopg2
import json
from sqlops import SqlOps
from AppLogger import AppLogger
from TabConfig import TabConfig
from loadprops import LoadProps
from tabaction import TabAction

jobid=0
class JobRun(object):
    def __init__(self):
        self.tabaction=TabAction()
        self.sqlops=SqlOps()
        self.loadprops=LoadProps()
        self.config_data = TabConfig()
        self.BottleLog = AppLogger('jobrun')

    def SelectJobDetails(self,params):
        try:
            #self.tabaction.UpdatePriority()
            #params=self.loadprops.loadPropsfromFile()
            conn=self.sqlops.ConnectPostgres(params['LogPostgres']['database'],params['LogPostgres']['username'],params['LogPostgres']['password'],params['LogPostgres']['servername'])
        except psycopg2.OperationalError as e:
            self.BottleLog.logger.error('Unable to connect to database : %s ' %(e))
        self.BottleLog.logger.info('Connected to database : %s ' % (params['LogPostgres']['database']))
        sqlq = list(params['LogPostgres']['createJobTable'].split())
        try:
            self.sqlops.RunQuery(conn,params['LogPostgres']['createJobTable'])
        except psycopg2.ProgrammingError as e:
            self.BottleLog.logger.error('%s  Table already exists '%(sqlq[2]))

        self.sqlops.DisconnectPostgres(conn)


    def PrepareProps(self,params):
        global jobid
        jname= "ExtractPriority"
        parameter=params['TableauProstgres']['username']+' ,'+ params['TableauProstgres']['password']+' ,'+params['TableauProstgres']['updateTask']
        table="job_table"
        RunType="Daily"
        jobid=jobid+1
        with open('jobdetails.json', mode='a', encoding='utf-8') as feedsjson:
            entry = {}
            entry['job_id'] = (jobid)
            entry['job_name'] = (jname)
            entry['parameter'] = (parameter)
            entry['run_type'] = (RunType)
            feedsjson.seek(0)
            json.dump(entry, feedsjson, indent=4)
            feedsjson.write(',')
            feedsjson.write('\n')


    def UpdateJobTable(self,dictn):
        # conn = self.sqlops.ConnectPostgres(params['LogPostgres']['database'], params['LogPostgres']['username'],params['LogPostgres']['password'], params['LogPostgres']['servername'])
        # try:
        #     query="""insert into job_table (job_id,job_name,parameter,run_type) values (%(job_id)s, %(job_name)s,%(parameter)s,%(run_type)s)""",dictn
        # except psycopg2.ProgrammingError as e:
        #     self.BottleLog.logger.error(e)
        # self.sqlops.RunQueryJob(conn, query)
        # self.sqlops.DisconnectPostgres(conn)
        pass

    def UpdateJobRunSummary(self):
        #runquery(params)
        pass

    def UpdateJobRunDetails(self):
        #runquery(params)
        pass

if __name__=='__main__':
    jobrun=JobRun()
    tabaction=TabAction()
    params=jobrun.loadprops.loadPropsfromFile()
    jobrun.tabaction.UpdatePriority(params)
    jobrun.SelectJobDetails(params)
    jobrun.PrepareProps(params)
    #jobrun.UpdateJobTable(dictnory)
    #print(dictnory)
