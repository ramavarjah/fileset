import json

# with open('config.json', 'r+') as f:
#     data = json.load(f)
#     data['JobTableDetails']['job_id'] = 134 # <--- add `id` value.
#     f.seek(0)        # <--- should reset file position to the beginning.
#     json.dump(data, f, indent=4)


jname = "ExtractPriority"
parameter = ('madhu' + 'rama' + 'varshith' +'jaahnavi')
table = "job_table"
RunType = "Daily"
jobid =  1
with open('jobdetails.json', mode='a', encoding='utf-8') as feedsjson:
    entry = {}
    entry['job_id'] =(jobid)
    entry['job_name'] =(jname)
    entry['parameter']=(parameter)
    entry['run_type']=(RunType)
    feedsjson.seek(0)
    json.dump(entry, feedsjson,indent=4)
    feedsjson.write(',')
    feedsjson.write('\n')