#!#!/usr/bin/python3.5

import os

class TabConfig:
    
    def __init__(self):
        self.logfile = 'pqsl_log'
        self.statuslogfile = 'check_status_log'
      
   
if __name__=='__main__':    
    obj = TabConfig()
