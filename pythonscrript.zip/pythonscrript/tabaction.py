#!/usr/bin/python3.5

#############################################################
# Filename: tabaction.py
#
# Description:  Wrapper object for database interface
#
#############################################################
import psycopg2
import json
from AppLogger import AppLogger
from TabConfig import TabConfig
from loadprops import LoadProps
from sqlops import SqlOps
#from jobrun import JobRun

class TabAction(object):
    def __init__(self):
        #self.jobrun=JobRun()
        self.loadprops=LoadProps()
        self.sqlops=SqlOps()
        self.config_data = TabConfig()
        self.BottleLog = AppLogger('tabaction')

    def UpdatePriority(self,params):
        #global jobid
        try:
            #self.jobrun.SelectJobDetails()
            #params=self.loadprops.loadPropsfromFile()
            conn=self.sqlops.ConnectPostgres(params['TableauProstgres']['database'],params['TableauProstgres']['username'],params['TableauProstgres']['password'],params['TableauProstgres']['servername'])
        except psycopg2.OperationalError as e:
            self.BottleLog.logger.error('Unable to connect Database : %s' %(e))
        self.BottleLog.logger.info('Connected to database %s :' %(params['TableauProstgres']['database']))

        self.sqlops.RunQuery(conn,params['TableauProstgres']['updateTask'])
        rows=self.sqlops.SelectQuery(conn,params['TableauProstgres']['selectTask'])
        sqlq = list(params['TableauProstgres']['selectTask'].split())
        #jobid=jobid+1
        if rows!=0:
            self.BottleLog.logger.info("%s Rows Updated in %s Table" %(rows,sqlq[3]))
        #return rows
        #self.BottleLog.logger.info("Number of Rows Updated %s" % (rows))

        self.sqlops.DisconnectPostgres(conn)


if __name__=='__main__':
    tabaction=TabAction()
    #params=tabaction.loadprops.loadPropsfromFile()
    #tabaction.UpdatePriority(params)