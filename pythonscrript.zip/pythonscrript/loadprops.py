#!/usr/bin/python2.7

#############################################################
# Filename: loadprops.py
#
# Description:  Wrapper object for database interface
#
#############################################################
import psycopg2
import json
from AppLogger import AppLogger
from TabConfig import TabConfig
#from sqlops import SqlOps
#from tabaction import TabAction
#from jobrun import JobRun


class LoadProps(object):
    def __init__(self):
        self.config_data = TabConfig()
        self.BottleLog = AppLogger('loadprops')

    def loadPropsfromFile(self):
        try:
            with open("config.json") as data:
                parsed_jsondata = json.load(data)
                print(parsed_jsondata)
        except json.JSONDecodeError as e:
            self.BottleLog.logger.error('Unable to Parse Json %s' %(e))
        return parsed_jsondata


if __name__=='__main__':
    loadprops=LoadProps()
    #loadprops.loadPropsfromFile()