#!/usr/bin/python3.5

import logging
from TabConfig import TabConfig

class AppLogger():
    
    def __init__(self, logname):
        self.config_data = TabConfig()
        
        # create logger
        self.logger = logging.getLogger(logname)
        if not len(self.logger.handlers):
            self.logger.setLevel(logging.DEBUG)
            if 'checkstatus' in logname.lower() or 'threaded' in logname.lower():
                self.filehdlr = logging.FileHandler(self.config_data.statuslogfile)
            else:    
                self.filehdlr = logging.FileHandler(self.config_data.logfile)
            
            # create formatter
            self.formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            
            # add formatter to filehdlr
            self.filehdlr.setFormatter(self.formatter)
    
            # add filehdlr to logger
            self.logger.addHandler(self.filehdlr)
            

if __name__=='__main__':
    obj = AppLogger('psqllog')
