#!/usr/bin/python3.5

#############################################################
# Filename: errorlogging.py
#
# Description:  Wrapper object for database interface
#
#############################################################
import psycopg2
import yaml
from AppLogger import AppLogger
from TabConfig import TabConfig


class LoadProps(object):
    def __init__(self):
        self.config_data = TabConfig()
        self.BottleLog = AppLogger('errorlogging')

    def WriteLogs(self,logs):
        #return status
        pass
