#!/usr/bin/python3.5

#############################################################
# Filename: sql.py
#
# Description:  Wrapper object for database interface
#
#############################################################
import os.path
import psycopg2
from AppLogger import AppLogger
from TabConfig import TabConfig


class SQL(object):

    def __init__(self):
        self.config_data=TabConfig()
        self.BottleLog=AppLogger('sql')

    ######### Creating Jon Table Method ###########
    def createTable(self,conn,sql):
        cur =conn.cursor()
        try:
            cur.execute(sql)
        except psycopg2.ProgrammingError as e:
            self.BottleLog.logger.info('Jon Table Already Exist :%s'%(e))

    ######### Creating Jon Run Table Method ###########
    def createRunTable(self,conn,sql):
        cur=conn.cursor()
        try:
            cur.execute(sql)
        except psycopg2.InternalError as e:
            self.BottleLog.logger.info('Job Run Table Already Exist :%s' % (e))

    ########## Eecuting Select Query ##############
    def get_details(self, conn, sql):
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        if len(rows) != 0:
            return len(rows)


    ######## Executing Update query ##############

    def update_details(self, conn, sql):
        cur = conn.cursor()
        u=cur.execute(sql)
        conn.commit()
        return u


if __name__ == '__main__':
    sql = SQL()
    ########### Servername,Username,Password & Database ############
    try:
        servername = str(input("Enter Servernamne :"))
        username = str(input("Enter Username :"))
        password = str(input("Enter Password :"))
    except ValueError:
        print("Enter valid Data! Please try again....")

    ############ Update Database Name #####################
    database = 'testtb'
    servername='localhost'
    username='591030'

    ############ SQL queries ###################
    createJobTable="CREATE TABLE job_table(Job_ID INT PRIMARY KEY NOT NULL, Job_Name CHAR(15),Parameter CHAR(60),Run_Type CHAR(10))"
    createJobRun="CREATE TABLE Job_Run_Summary(Job_ID INT PRIMARY KEY REFERENCES JOB_TABLE(JOB_ID),RUN_ID INT ,START_TIME TIMESTAMP ,END_TIME TIMESTAMP ,SUMMARY_INFO CHAR(40))"
    selectdemo = "SELECT * FROM TASKS"
    selectSQL = "SELECT * FROM TASKS WHERE TYPE='IncrementExtractTask' AND PRIORITY!='50'"
    updateSQL = "update tasks set priority='25' where type='IncrementExtractTask' and PRIORITY!='50'"

    ########### Connecting to the Postgress ###############
    try:
        myconnection = psycopg2.connect(dbname=database, user=username, host=servername, password=password)

        ###### Creatting Job Table #########
        jobtab=sql.createTable(myconnection,createJobTable)
        sql.BottleLog.logger.info('Job Table created')

        ###### Creating Job run Tbale #########
        jobrun=sql.createRunTable(myconnection,createJobRun)
        sql.BottleLog.logger.info('Job Run Table created')

        ###### Select Query from Tasks table where type='IncrementExtractTask' and PRIORITY not equal to =50 ##############
        rows = sql.get_details(myconnection, selectSQL)
        sqlq = list(selectSQL.split())
        if rows != 0:
            sql.BottleLog.logger.info('Result set %s ' % (rows))
            sql.BottleLog.logger.info('From table: %s' % (sqlq[3]))

        ############### All incremental refresh   - change from default 50 to 25 ##########
        sql.update_details(myconnection, updateSQL)
        sql.BottleLog.logger.info('Total Number of Row Updated :%s' % (rows))
        myconnection.close()
    except psycopg2.OperationalError as e:
        sql.BottleLog.logger.error('Unable to connect to Database :%s' % (e))