#!/usr/bin/python3.5

#############################################################
# Filename: sqlops.py
#
# Description:  Wrapper object for database interface
#
#############################################################
import psycopg2
import json
from AppLogger import AppLogger
from TabConfig import TabConfig
from loadprops import LoadProps


class SqlOps(object):
    def __init__(self):
        self.config_data = TabConfig()
        self.BottleLog = AppLogger('sqlops')

    def ConnectPostgres(self,database,username,password,servername):
        myconnection=psycopg2.connect(dbname=database,user=username,password=password,host=servername)
        return myconnection

    def RunQuery(self,pgsqlsession,query):
        cur = pgsqlsession.cursor()
        result = cur.execute(query)
        pgsqlsession.commit()
        #cur.close()
        return result

    def SelectQuery(self,pgsqlsession,query):
        cur=pgsqlsession.cursor()
        cur.execute(query)
        rows=cur.fetchall()
        if len(rows)!= 0:
            return len(rows)

    def RunQueryJob(self,pgsqlsession,query):
        cur = pgsqlsession.cursor()
        result = cur.executemany(query)
        pgsqlsession.commit()
        #cur.close()
        return result


    def DisconnectPostgres(self,session):
        return session.close()

if __name__=='__main__':
    sqlops=SqlOps()



