#!/usr/bin/python

# Salvagnini export file format converter
# for PCU proof of concept usage
# 02.12.2019 // JPu
#
# v 0.2 with changed command line arguments
#
import os
import csv
import sys
import time
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import Element, SubElement, Comment, tostring
from xml.dom import minidom

#### XML file writing options ##########################################
outFilePath = ""  # if destination path defined it HAS to end with slash
#outFilePath = "C:/FlexNet File Processor/Input/" #ITC default
#outFileName = "SPM_" + time.strftime("%d%m%Y%H%M%S") + ".xml"
outDebug = False  # If 'True' then script will print to stdout
########################################################################

##### input txt file variable indexes, order on line base 0
idx_ID = 0
idx_DATEANDTIME = 3
idx_IDDESCRIPTION = 5
idx_PRODUCTIONBATCH = 6
idx_SALVAGNINIJOB = 7		# Guess, commented out
idx_SALVAGNININEST = 8
idx_KONERAWMATERIALCODE = 14
idx_QTYTOBEPRODUCED = 15
idx_QTYPRODUCED = 16
idx_KONEPRODUCTIOBATCH = 18	# Guess, commented out
##### eod txt file indexes #####################################

################## Do not alter below here! #####################

SkipRow = 0		#for future use if(when) ITC claims incremental upload needed

# Parse command line arguments
if len(sys.argv) != 3:
	print("\nusage: " + sys.argv[0] + " infile outfile") 
	exit()
else:
	f = open(sys.argv[1], "r")
	outFileName = sys.argv[2]
	
csv_f = csv.reader(f, delimiter = ';')
data = []

for row in csv_f:
    data.append(row)

####### Searching a file in a drirectory ######################
FileSearch = sys.argv[1]

items = FileSearch.split("\\")
listlenght = len(items)
dname = items[listlenght-2]
print("Directory Name",dname)

# Create XML root container 
x_root = ET.Element("Reports", xmlns="http://www.Apriso.com/SPM.xsd")
x_msg = ET.Element("Message", xmlns="")
x_root.append(x_msg)


# and start filling elements with values
for row in data[SkipRow:]:
    x_spm = SubElement(x_msg, "SPM")
    x_id = SubElement(x_spm, "ID")
    x_id.text =  dname +"_" + row[idx_ID]
    x_dateandtime = SubElement(x_spm, "dateandtime")
    x_dateandtime.text = row[idx_DATEANDTIME]
    x_iddescription = SubElement(x_spm, "IDDescription")
    x_iddescription.text = row[idx_IDDESCRIPTION]
    x_productionbatch = SubElement(x_spm, "productionbatch")
    x_productionbatch.text = row[idx_PRODUCTIONBATCH]
    x_salvagninijob = SubElement(x_spm, "Salvagninijob")
    #x_salvagninijob.text = row[idx_SALVAGNINIJOB]
    x_salvagnininest = SubElement(x_spm, "Salvagnininest")
    x_salvagnininest.text = row[idx_SALVAGNININEST]
    x_konerawmatericalcode = SubElement(x_spm, "KoneRawMatericalCode")
    x_konerawmatericalcode.text = row[idx_KONERAWMATERIALCODE]
    x_qtytobeproduced = SubElement(x_spm, "qtytobeproduced")
    x_qtytobeproduced.text = row[idx_QTYTOBEPRODUCED]
    x_qtyproduced = SubElement(x_spm, "qtyproduced")
    x_qtyproduced.text = row[idx_QTYPRODUCED]
    x_KoneProductionbatch = SubElement(x_spm, "KoneProductionbatch")
    #x_KoneProductionbatch.text = row[idx_KONEPRODUCTIOBATCH]



#Prettify XML for human reading
xmlstr = minidom.parseString(tostring(x_root)).toprettyxml(indent="  ")


# finally spit it out in desired way
if outDebug:
	print (xmlstr)
else:
    ofile = open(outFilePath + outFileName, "w")
    ofile.write(xmlstr)
    ofile.close()



# That's all, folks	

