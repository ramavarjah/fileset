""" import os
files_path = [os.path.abspath(x) for x in os.listdir()]
print(files_path) """

import os

thisdir = os.getcwd()
dname =[]
# r=root, d=directories, f = files
for r, d, f in os.walk(thisdir):
    for file in f:
        if "02012020.txt" in file:
            ppath = os.path.join(r, file)
            dname.append(r)

print(dname)
def listToString(s):
    str1 = " "
    # traverse in the string
    for ele in s:
        str1 += ele
    # return string
    return str1

# Driver code
x = listToString(dname)
items = x.split("\\")
listlenght = len(items)
dname = items[listlenght-1]
print(dname)

    





