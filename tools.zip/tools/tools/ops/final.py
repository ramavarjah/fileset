from xml.etree import ElementTree
root = ElementTree.parse("E:\Mohammed\\tools\\tools\\aaa.xml").getroot()
c = ElementTree.Element('Message xmlns=""')
c.text = " "
root.insert(2, c)
ElementTree.dump(root)