import os

from flask import Flask
from flask_login import LoginManager
from flask_marshmallow import Marshmallow
from flask_sqlalchemy import SQLAlchemy

import requests

#from app.models import apiData

from config import config

basedir = os.path.abspath(os.path.dirname(__file__))

db = SQLAlchemy()

# Set up Flask-Login
login_manager = LoginManager()
login_manager.session_protection = 'strong'
login_manager.login_view = 'account.login'

def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.debug= True
    app.config['SECURITY_REGISTERABLE']= True
    app.config['SECRET_KEY']='super-secret'
    # not using sqlalchemy event system, hence disabling it

    config[config_name].init_app(app)

    # Set up extensions
    db.init_app(app)
    login_manager.init_app(app)


    # Create app blueprints
    from .customer import customer as customer_blueprint
    app.register_blueprint(customer_blueprint, url_prefix='/customer')

    from .user import user as user_blueprint
    app.register_blueprint(user_blueprint, url_prefix='/user')

    from .modules import issuelog as issuelog_blueprint
    app.register_blueprint(issuelog_blueprint, url_prefix='/IssueLog')

    from .modules import thingworx as thingworx_blueprint
    app.register_blueprint(thingworx_blueprint, url_prefix='/Thingworx')
    return app


def FlaskSecurity():
    fapp = Flask(__name__)
    fapp.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    fapp.debug= True
    fapp.config['SECURITY_REGISTERABLE']= True
    fapp.config['SECRET_KEY']='super-secret'
    return fapp


def FlaskMarshmallow():
    mapp = Flask(__name__)
    mapp.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    ma = Marshmallow(mapp)
    return ma