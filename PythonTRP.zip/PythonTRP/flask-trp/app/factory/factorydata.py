import factory
from .. import models
from .. import db


class CustomerFactory(factory.Factory):
    class Meta:
        model = models.Customer

    emailid = factory.Faker('email')
    ExternalRequestIdSequence = factory.Faker('pyint')
    HasHealth = factory.Faker('boolean', chance_of_getting_true=50)
    Description = factory.Faker('sentences', nb=3, ext_word_list=None)
    Address = factory.Faker('address')
    CustomerInfolinePassword = factory.Faker('password', length=10, special_chars=True, digits=True, upper_case=True, lower_case=True)
    IssueIdSequence = factory.Faker('pyint')
    CustomerInfolineUserName = factory.Faker('first_name')
    LPRequestIdSequence = factory.Faker('pyint')
    UniqueIdSequence = factory.Faker('pyint')
    HasLoanPool = factory.Faker('boolean', chance_of_getting_true=50)
    IsIndexed = factory.Faker('boolean', chance_of_getting_true=50)
    HasBase = factory.Faker('boolean', chance_of_getting_true=50)
    IsServiceRequestQueryOnAssetNo = factory.Faker('boolean', chance_of_getting_true=50)
    PhoneNo = factory.Faker('phone_number')
    OracleId = factory.Faker('md5', raw_output=False)
    CustomerId = factory.Faker('md5', raw_output=False)
    UtilizationAndHealthLicense = factory.Faker('md5', raw_output=False)
    DisplayName = factory.Faker('first_name')
    CustomerName = factory.Faker('name')
    LoanPoolLicense = factory.Faker('md5', raw_output=False)
    TrackAndControlLicense = factory.Faker('md5', raw_output=False)
    OotIdSequence = factory.Faker('pyint')
    @factory.post_generation
    def create_docs(self, create, extracted, **kwargs):
        # print(self, create, extracted)
        if not create:
            db.session.add(self)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
            return
            
class UserFactory(factory.Factory):
    class Meta:
        model = models.User

    email = factory.Faker('email')
    AddressLine1 = factory.Faker('md5', raw_output=False)
    AddressLine2 = factory.Faker('md5', raw_output=False)
    AddressLine3 = factory.Faker('md5', raw_output=False)
    Avatar = factory.Faker('md5', raw_output=False)
    City = factory.Faker('md5', raw_output=False)
    CompanyName = factory.Faker('md5', raw_output=False)
    Country = factory.Faker('md5', raw_output=False)
    CurrentTabId = factory.Faker('md5', raw_output=False)
    CustomerId = factory.Faker('md5', raw_output=False)
    Department = factory.Faker('md5', raw_output=False)
    emailAddress = factory.Faker('email')
    Fax = factory.Faker('md5', raw_output=False)
    firstName = factory.Faker('first_name')
    HasSpotfireAccess = factory.Faker('boolean', chance_of_getting_true=50)
    HiddenColumns = factory.Faker('md5', raw_output=False)
    homePhone = factory.Faker('md5', raw_output=False)
    ImageProp = factory.Faker('md5', raw_output=False)
    infolinePassword = factory.Faker('md5', raw_output=False)
    infolineUserName = factory.Faker('md5', raw_output=False)
    JobTitle = factory.Faker('md5', raw_output=False)
    lastName = factory.Faker('last_name')
    LoanPoolBaseQuery = factory.Faker('md5', raw_output=False)
    LoanPoolQuery = factory.Faker('md5', raw_output=False)
    MailingAddress = factory.Faker('md5', raw_output=False)
    Manager = factory.Faker('md5', raw_output=False)
    middleName = factory.Faker('md5', raw_output=False)
    mobilePhone = factory.Faker('md5', raw_output=False)
    NoOfTabs = factory.Faker('md5', raw_output=False)
    NotificationAssetGroups = factory.Faker('md5', raw_output=False)
    Organization = factory.Faker('md5', raw_output=False)
    PostalCode = factory.Faker('md5', raw_output=False)
    ServiceRequestBaseQuery = factory.Faker('md5', raw_output=False)
    ServiceRequestQuery = factory.Faker('md5', raw_output=False)
    smsAddress = factory.Faker('md5', raw_output=False)
    solrQueryString = factory.Faker('md5', raw_output=False)
    SpotfirePassword = factory.Faker('md5', raw_output=False)
    SpotfireUserName = factory.Faker('md5', raw_output=False)
    State = factory.Faker('md5', raw_output=False)
    title = factory.Faker('md5', raw_output=False)
    workPhone = factory.Faker('phone_number')
    name = factory.Faker('first_name')
    description ='testing User '
    language = factory.Faker('md5', raw_output=False)
    tags = factory.Faker('md5', raw_output=False)
    lastConnection = '11/17/2017'
    password = factory.Faker('password', length=10, special_chars=True, digits=True, upper_case=True, lower_case=True)
    customer_id = '10000'
    active = factory.Faker('boolean', chance_of_getting_true=50)
    customer = factory.SubFactory(CustomerFactory)



    @staticmethod
    def generate_user(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        u = UserFactory.build()
        db.session.add(u)

        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()


class OrganizationFactory(factory.Factory):
    class Meta:
        model = models.Organization

    ParentBreadcrumb = factory.Faker('md5', raw_output=False)
    NodeLevel = factory.Faker('pyint')
    DisplayName = factory.Faker('pyint')
    Breadcrumb = factory.Faker('md5', raw_output=False)
    #CustomerId = 'A5567'
    name = factory.Faker('first_name')
    description = factory.Faker('sentences', nb=3, ext_word_list=None)
    thingTemplate = 'asset'
    tags = factory.Faker('md5', raw_output=False)
    customer_id = factory.Faker('pyint')
    customer = factory.SubFactory(CustomerFactory)



    @staticmethod
    def generate_organization(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        for i in range(count):
            o = OrganizationFactory.build(DisplayName=factory.Sequence(lambda n: 'Asset{0}'.format(n)),
                                          name=factory.Sequence(lambda n: 'bbb{0}'.format(n)))
            db.session.add(o)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()


class LocationFactory(factory.Factory):
    class Meta:
        model = models.Location

    ParentBreadcrumb = factory.Faker('md5', raw_output=False)
    NodeLevel = factory.Faker('pyint')
    DisplayName = factory.Faker('pyint')
    Breadcrumb = factory.Faker('md5', raw_output=False)
    #CustomerId = 'A5567'
    name = factory.Faker('first_name')
    description = factory.Faker('sentences', nb=3, ext_word_list=None)
    thingTemplate = 'asset'
    tags = factory.Faker('md5', raw_output=False)
    customer_id = factory.Faker('pyint')
    customer = factory.SubFactory(CustomerFactory)

    @staticmethod
    def generate_location(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        for i in range(count):
            l = LocationFactory.build(thingTemplate=factory.Sequence(lambda n: 'Asset{0}'.format(n)),
                                      name=factory.Sequence(lambda n: 'bbb{0}'.format(n)))
            db.session.add(l)

            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()

class TabFactory(factory.Factory):
    class Meta:
        model = models.Tab

    BaseQuery = factory.Faker('md5', raw_output=False)
    BaseString = factory.Faker('md5', raw_output=False)
    BucketType = factory.Faker('md5', raw_output=False)
    ColumnOrder = factory.Faker('md5', raw_output=False)
    ColumnWidth = factory.Faker('md5', raw_output=False)
    DashBoardChartName = factory.Faker('md5', raw_output=False)
    DashboardImage = factory.Faker('boolean', chance_of_getting_true=50)
    DatePreset = factory.Faker('boolean', chance_of_getting_true=50)
    DisplayDensity = factory.Faker('boolean', chance_of_getting_true=50)
    FilterQuery = factory.Faker('md5', raw_output=False)
    HiddenColumns = factory.Faker('md5', raw_output=False)
    NoOfWorkingHours = 5
    Pagination = factory.Faker('pyint')
    PinColumn = factory.Faker('pyint')
    SavedSearchId = factory.Faker('md5', raw_output=False)
    SortColumns = factory.Faker('boolean', chance_of_getting_true=50)
    # TabId = factory.Faker('md5', raw_output=False)
    TabName = factory.Faker('md5', raw_output=False)
    TabOrder = factory.Faker('pyint')
    UserName = factory.Faker('first_name')
    ViewCategoryId = factory.Faker('md5', raw_output=False)
    ViewEndDate = '11/17/2017'
    ViewStartDate = '11/17/2017'
    ViewTypeId = factory.Faker('md5', raw_output=False)
    user_id = factory.Faker('pyint')
    user = factory.SubFactory(UserFactory)

    @staticmethod
    def generate_tab(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        for i in range(count):
            t = TabFactory.build(UserName=factory.Sequence(lambda n: 'User{0}'.format(n)),
                                 TabId=factory.Sequence(lambda n: 'ASSSSS{0}'.format(n)))
            db.session.add(t)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()


class CharsubViewFactory(factory.Factory):
    class Meta:
        model = models.ChartSubView

    Active = factory.Faker('boolean', chance_of_getting_true=50)
    CategoryId = factory.Faker('md5', raw_output=False)
    ChartId = factory.Faker('md5', raw_output=False)
    EndDate = '28-Dec-2018'
    File = 'file'
    PropertyName = factory.Faker('md5', raw_output=False)
    StartDate = '01-Jan-2019'
    value = factory.Faker('pyint')
    tab_id = factory.Faker('pyint')
    tabs = factory.SubFactory(TabFactory)


    @staticmethod
    def generate_Charsubview(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        for i in range(count):
            cs = CharsubViewFactory.build(CategoryId=factory.Sequence(lambda n: 'Asset{0}'.format(n)),
                                          File=factory.Sequence(lambda n: 'File{0}'.format(n)))
            db.session.add(cs)

            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()


class CharviewFactory(factory.Factory):
    class Meta:
        model = models.ChartView

    CategoryId = factory.Faker('md5', raw_output=False)
    Active = factory.Faker('md5', raw_output=False)
    Date = factory.Faker('boolean', chance_of_getting_true=50)
    SubCategory = factory.Faker('boolean', chance_of_getting_true=50)
    Textbox = factory.Faker('boolean', chance_of_getting_true=50)
    ViewName = 'Charview'
    tab_id =factory.Faker('pyint')
    tabs = factory.SubFactory(TabFactory)

    @staticmethod
    def generate_Charview(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        for i in range(count):
            cv = CharviewFactory.build(CategoryId=factory.Sequence(lambda n: 'Asset{0}'.format(n)),
                                       ViewName=factory.Sequence(lambda n: 'Unit{0}'.format(n)))
            db.session.add(cv)

            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()


class GridDataModelFactory(factory.Factory):
    class Meta:
        model = models.GridDataModel

    dataIndex = factory.Faker('md5', raw_output=False)
    filter = factory.Faker('md5', raw_output=False)
    hidden = factory.Faker('boolean', chance_of_getting_true=50)
    hideable = factory.Faker('boolean', chance_of_getting_true=50)
    lockable = factory.Faker('boolean', chance_of_getting_true=50)
    locked = factory.Faker('boolean', chance_of_getting_true=50)
    renderer = factory.Faker('boolean', chance_of_getting_true=50)
    sortable = factory.Faker('boolean', chance_of_getting_true=50)
    text = factory.Faker('md5', raw_output=False)
    width = factory.Faker('md5', raw_output=False)
    xtype = factory.Faker('md5', raw_output=False)
    tab_id = factory.Faker('pyint')
    tabs = factory.SubFactory(TabFactory)

    @staticmethod
    def generate_Griddatamodel(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        for i in range(count):
            gm = GridDataModelFactory.build(filter=factory.Sequence(lambda n: 'Asset{0}'.format(n)),
                                            width=factory.Sequence(lambda n: '2{0}feet'.format(n)))
            db.session.add(gm)

            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()


class AssetFactory(factory.Factory):
    class Meta:
        model = models.Asset

    ParentSystemName = 'Keysight Tech.'
    UniqueID = factory.Faker('md5', raw_output=False)
    UtilizationCategory = 'active'
    CalibrationInterval = factory.Faker('pyint')
    LastUpdate = '11/17/2018'
    AssetNo = factory.Faker('pyint')
    BorrowereReturnDate = '11/17/2018'
    OrderNumber =  factory.Faker('md5', raw_output=False)
    LifeCycleStage =  factory.Faker('md5', raw_output=False)
    UseProviderCalibrationType = factory.Faker('boolean', chance_of_getting_true=50)
    History =  factory.Faker('md5', raw_output=False)
    UseProviderCalibrationSchedule = factory.Faker('boolean', chance_of_getting_true=50)
    EquipmentType =  factory.Faker('md5', raw_output=False)
    RepairProvider = factory.Faker('boolean', chance_of_getting_true=50)
    SubscribedUsers =  factory.Faker('md5', raw_output=False)
    ServiceAgreement =  factory.Faker('md5', raw_output=False)
    LastServiceDate = '11/17/2018'
    ReplacedBy =  factory.Faker('md5', raw_output=False)
    CalibrationProvider =  factory.Faker('md5', raw_output=False)
    OOTGroup =  factory.Faker('md5', raw_output=False)
    Currency =  factory.Faker('md5', raw_output=False)
    ServiceInterval = factory.Faker('pyint')
    BorrowerStartDate = factory.Faker('pyint')
    Manufacturer =  factory.Faker('md5', raw_output=False)
    InvoiceNumber =  factory.Faker('md5', raw_output=False)
    PlannedDisposalDate = '11/17/2018'
    AltManufacturerName =  factory.Faker('md5', raw_output=False)
    Status = 'Yes'
    InventoryDate = '11/17/2018'
    SerialNo = 'G7766'
    HealthStatus = 'enable'
    SoftwareRevision = '1.7'
    WorkFlowState = 'yes'
    HardwareVersion = '1.0'
    LastReportedCondition = 'SSSSSDD'
    Project = 'WWWW'
    Depreciation = 2.0
    ReceivedDate = '11/17/2018'
    Barcode = 'AWWWWW'
    OrganizationUnit = 'ZSSSSS'
    ProductCategory = 'WQWWW'
    LoanAutoCalculate = factory.Faker('boolean', chance_of_getting_true=50)
    OwnershipStatus = 'done'
    LoanpoolStatus = 'done'
    Options = '11/17/2018'
    Description = 'Keysight Tec'
    Organization = 'Nokia'
    # User = db.Column(db.String(), unique=False)
    LoanDailyRate = factory.Faker('pyint')
    InfolineAssetKey = 'hhhhh'
    SystemParent = factory.Faker('boolean', chance_of_getting_true=50)
    BookValueDate = '11/17/2018'
    ReplacementDate = '11/17/2018'
    PurchasePrice = factory.Faker('pyint')
    Information = 'development'
    PartOfSystemCalibration = factory.Faker('boolean', chance_of_getting_true=50)
    CalibrationDate = '11/17/2018'
    Accessories = factory.Faker('md5', raw_output=False)
    AssetLocation = 'Key Sight'
    OOTInvestigator = factory.Faker('md5', raw_output=False)
    SystemChild = factory.Faker('boolean', chance_of_getting_true=50)
    RemoteThing = 'LLLLL'
    CalibrationDueDate = '11/17/2018'
    SystemComponents = factory.Faker('md5', raw_output=False)
    SystemName = 'Key Sight'
    DepreciationRateInNoOfYear = factory.Faker('pyint')
    OOTStatus = factory.Faker('md5', raw_output=False)
    EquipmentNo = factory.Faker('md5', raw_output=False)
    Borrowable = factory.Faker('boolean', chance_of_getting_true=50)
    IsUtilization = factory.Faker('boolean', chance_of_getting_true=50)
    OOTReviewer = factory.Faker('md5', raw_output=False)
    Borrower = factory.Faker('md5', raw_output=False)
    OwningCompany = 'ITC'
    ServiceDueDate = '11/17/2018'
    ServiceLogistics = factory.Faker('md5', raw_output=False)
    Request = factory.Faker('md5', raw_output=False)
    Coordinator = factory.Faker('md5', raw_output=False)
    RequestorEmail =  factory.Faker('email')
    OrderDate = '11/17/2018'
    IsIndexed = factory.Faker('boolean', chance_of_getting_true=50)
    ModelNo = 'G666667'
    UseDefaultProvider = factory.Faker('boolean', chance_of_getting_true=50)
    BookValue = factory.Faker('pyint')
    LoanDailyCost = factory.Faker('pyint')
    ServiceCost = factory.Faker('pyint')
    CalibrationType = factory.Faker('md5', raw_output=False)
    FirmwareRevision = factory.Faker('md5', raw_output=False)
    IsConnected = factory.Faker('boolean', chance_of_getting_true=50)
    Location = factory.Faker('md5', raw_output=False)
    StickyNotes = factory.Faker('md5', raw_output=False)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    user = factory.SubFactory(UserFactory)

    @staticmethod
    def generate_asset(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        for i in range(count):
            gm = GridDataModelFactory.build(filter=factory.Sequence(lambda n: 'Asset{0}'.format(n)),
                                            width=factory.Sequence(lambda n: '2{0}feet'.format(n)))
            db.session.add(gm)

            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()