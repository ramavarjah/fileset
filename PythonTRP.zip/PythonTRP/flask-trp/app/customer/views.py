from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request
)
from flask_login import current_user
from app import db
from app.models import Customer
customer = Blueprint('customer', __name__)


@customer.route('/', methods=['GET'])
def index():
    myCustomer = Customer.query.all()
    oneItem = Customer.query.filter_by(emailid="postgres").all()
    return render_template('customer/add_customer.html', myCustomer=myCustomer)


@customer.route('/create_customer', methods=['POST'])
def create_customer():
    if request.is_json:
        content = request.get_json()
        if content["CustomerName"] is not '' and content["DisplayName"] is not '' and  content["PhoneNo"] \
                is not '' and content["emailid"] is not '' and content['Description'] is not '':
            customer = Customer(content["emailid"], content["ExternalRequestIdSequence"],
                                content['HasHealth'], content['Description'],
                                content['Address'], content['CustomerInfolinePassword'],
                                content['IssueIdSequence'],
                                content['CustomerInfolineUserName'],
                                content['LPRequestIdSequence'],
                                content['UniqueIdSequence'],
                                content['HasLoanPool'], content['IsIndexed'],
                                content['HasBase'],
                                content['IsServiceRequestQueryOnAssetNo'],
                                content['PhoneNo'], content['OracleId'],
                                content['UtilizationAndHealthLicense'],
                                content['DisplayName'], content['LoanPoolLicense'],
                                content['CustomerName'],
                                content['TrackAndControlLicense'],
                                content["OotIdSequence"])
            db.session.add(customer)
            db.session.commit()
            return redirect(url_for('customer.index'))
        else:
            return redirect(url_for('customer.index'))


@customer.route('/edit_customer', methods=['POST'])
def update_customer():
    if request.is_json:
        content = request.get_json()
        update_this = Customer.query.filter_by(CustomerName='Texas Instr').first()
        if content['CustomerName'] is not '':
            update_this.CustomerName = content['CustomerName']
            print(content['CustomerName'])
            db.session.commit()
            return redirect(url_for('customer.index'))
        else:
            return redirect(url_for('customer.index'))
