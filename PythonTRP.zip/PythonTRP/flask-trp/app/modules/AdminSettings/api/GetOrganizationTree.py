from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app.models import Organization
from app.models import OrganizationSchema

data = {"success":True,"tree":{"expanded":True,"children":[{"expanded":True,"children":[{"text":"D","leaf":True},{"text":"hello","leaf":True},{"text":"hi","leaf":True},{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"text":"Team A","leaf":True}],"text":"Dept 1"}],"text":"Program 1"},{"expanded":True,"children":[{"text":"Dept 1","leaf":True}],"text":"Program 2"}],"text":"EMS1"},{"text":"EMS2","leaf":True}],"text":"EMS"},{"expanded":True,"children":[{"text":"Automotive 1","leaf":True},{"expanded":True,"children":[{"text":"Program 1","leaf":True},{"expanded":True,"children":[{"expanded":True,"children":[{"text":"Team A","leaf":True},{"text":"Team B","leaf":True}],"text":"Design"},{"text":"NPI","leaf":True}],"text":"Program 2"}],"text":"Automotive 2"}],"text":"Automotive Group"},{"text":"Manage Group","leaf":True},{"expanded":True,"children":[{"text":"Wireless 2","leaf":True},{"text":"Wireless 3","leaf":True},{"expanded":True,"children":[{"text":"Program 1","leaf":True},{"expanded":True,"children":[{"expanded":True,"children":[{"text":"Team A","leaf":True},{"text":"Team B","leaf":True}],"text":"MFG"},{"text":"Development","leaf":True}],"text":"Program 2"}],"text":"Wireless 1"}],"text":"Wireless Group"},{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"text":"Team A","leaf":True},{"text":"Team B","leaf":True},{"text":"Team C","leaf":True}],"text":"NPI"},{"text":"Support","leaf":True}],"text":"Program 1"},{"expanded":True,"children":[{"text":"NPB","leaf":True}],"text":"Program 2"}],"text":"Satellite 2"},{"text":"Satellite 1","leaf":True}],"text":"Satellite Group"},{"text":"Robotic Group","leaf":True}],"text":"Asset Advisor Demo"}]}}

def getChidren(allNodes,currentNode):
    schema = OrganizationSchema()
    children=0
    for node in allNodes:
        if schema.dump(node).data['ParentNode'] == str(schema.dump(currentNode).data['id']):
            # print(schema.dump(node).data)
            children += 1
    # print(children,currentNode)
    if children == 0:
        if schema.dump(currentNode).data['ParentNode'] == "topNode":
            return []
        else:
            data = schema.dump(currentNode).data   
            del data["customer"]
            del data["Breadcrumb"]
            return data
    else:
        children =[]
        for nodes in allNodes:
            if schema.dump(nodes).data['ParentNode'] == str(schema.dump(currentNode).data['id']):
                # print(schema.dump(nodes).data)
                children.append(getChidren(allNodes,schema.dump(nodes).data))
        if schema.dump(currentNode).data['ParentNode'] == "topNode":
            return children
        else:
            data = schema.dump(currentNode).data      
            data['children'] = children
            del data["customer"]
            del data["Breadcrumb"]
            return data

def GetOrganizationTree():
    orgs=[]
    schema = OrganizationSchema()
    allNodes = Organization.query.filter_by(CustomerId=2).all()
    topNode=[]
    for node in allNodes:
        if node.ParentNode == "topNode":
            topNode=schema.dump(node).data
    topNode['children']=  getChidren(allNodes,topNode)
    del topNode["customer"]
    del topNode["Breadcrumb"]
    del topNode["ParentNode"]

    orgs.append(topNode)

    return jsonify(orgs)