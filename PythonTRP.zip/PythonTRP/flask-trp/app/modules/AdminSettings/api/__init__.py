from flask import request
from .GetOrganizationTree import GetOrganizationTree
from .GetOrganizationNodes import GetOrganizationNodes

def getAdminSettingsRoutes(thingworx):
    @thingworx.route('/Things/AdminSettings/Services/GetOrganizationTree', methods=['POST'])
    def getOrganizationTreeAdmin():
        return GetOrganizationTree()
    @thingworx.route('/Things/AdminSettings/Services/GetOrganizationNodes', methods=['POST'])
    def getOrganizationNodesAdmin():
        return GetOrganizationNodes(request)
        