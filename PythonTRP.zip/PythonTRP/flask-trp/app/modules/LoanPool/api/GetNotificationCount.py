from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"IssueLogNotificationCount":1.0,"success":True,"LoanPoolNotificationCount":13.0,"ServiceRequestNotificationCount":0.0,"OOTNotificationCount":2.0}
def GetNotificationCount():
 return jsonify(data)