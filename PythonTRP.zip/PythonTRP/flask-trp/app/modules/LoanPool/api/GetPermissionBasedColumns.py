from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"fields":{"ParentSystemName":True,"UniqueID":True,"UtilizationCategory":True,"CalibrationInterval":True,"LastUpdate":True,"AssetNo":True,"OrderNumber":True,"UseProviderCalibrationType":True,"LifeCycleStage":True,"UseProviderCalibrationSchedule":True,"RepairProvider":True,"EquipmentType":True,"ServiceAgreement":True,"ReplacedBy":True,"CalibrationProvider":True,"Currency":True,"Manufacturer":True,"InvoiceNumber":True,"PlannedDisposalDate":True,"AltManufacturerName":True,"InventoryDate":True,"SerialNo":True,"SoftwareRevision":True,"HealthStatus":True,"HardwareVersion":True,"LastReportedCondition":True,"Project":True,"Depreciation":True,"ReceivedDate":True,"OrganizationUnit":True,"Barcode":True,"ProductCategory":True,"LastCalibrationDate":True,"LoanAutoCalculate":True,"OwnershipStatus":True,"Options":True,"User":True,"Organization":True,"Description":True,"LoanDailyRate":True,"SystemParent":True,"BookValueDate":True,"ReplacementDate":True,"PurchasePrice":True,"PartOfSystemCalibration":True,"CalibrationDate":True,"Accessories":True,"SystemChild":True,"ServiceStartDate":True,"CalibrationDueDate":True,"SystemComponents":True,"SystemName":True,"EquipmentNo":True,"IsUtilization":True,"Borrowable":True,"OwningCompany":True,"ServiceLogistics":True,"thingName":True,"Coordinator":True,"OrderDate":True,"ModelNo":True,"UseDefaultProvider":True,"BookValue":True,"LoanDailyCost":True,"ServiceCost":True,"CalibrationType":True,"FirmwareRevision":True,"StickyNotes":True,"IsConnected":True,"Location":True},"icons":{"ServiceRequestIcon":True,"AssetDetailsIcon":True,"CreateAsset":True,"IssueLog":True,"EditAsset":True,"AdminSettingsIcon":True,"CreateTemplate":True,"BulkEdit":True,"LoanPool":True,"Dashboards":{"DashboardDemo":True},"LoanDetailsButton":True}}
def GetPermissionBasedColumns():
 return jsonify(data)