from .GetAllLoanPoolRequests import GetAllLoanPoolRequests
from .GetGridDataModel import GetGridDataModel
from .GetOrgs import GetOrgs
from .CreateNewLoanPoolRequest import CreateNewLoanPoolRequest
from .SetApprovalOnLoanPoolRequest import SetApprovalOnLoanPoolRequest
from .MarkNotificationAsRead import MarkNotificationAsRead
from .GetNotificationCount import GetNotificationCount
from .GetPermissionBasedColumns import GetPermissionBasedColumns
from .SetColumnSort import SetColumnSort
from .GetLoanableAssetsData import GetLoanableAssetsData


def getLoanPoolRoutes(thingworx):
    @thingworx.route('/Things/Keysight.LoanPool.Services/Services/GetAllLoanPoolRequests', methods=['POST'])
    def getAllLoanPoolRequests():
        return GetAllLoanPoolRequests()

    @thingworx.route('/Things/Keysight.Assets.LoanPool/Services/GetLoanableAssetsData', methods=['POST'])
    def getLoanableAssetsData():
        return GetLoanableAssetsData()

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetGridDataModel', methods=['POST'])
    def getGridDataModel():
        return GetGridDataModel()

    @thingworx.route('/Things/Keysight.Generic/Services/GetOrgs', methods=['POST'])
    def getOrgs():
        return GetOrgs()

    @thingworx.route('/Things/Keysight.LoanPool.Services/Services/CreateNewLoanPoolRequest', methods=['POST'])
    def createNewLoanPoolRequest():
        return CreateNewLoanPoolRequest()

    @thingworx.route('/Things/Keysight.LoanPool.Services/Services/SetApprovalOnLoanPoolRequest', methods=['POST'])
    def setApprovalOnLoanPoolRequest():
        return SetApprovalOnLoanPoolRequest()

    @thingworx.route('/Things/Keysight.BaseListing/Services/MarkNotificationAsRead', methods=['POST'])
    def markNotificationAsRead():
        return MarkNotificationAsRead()

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetNotificationCount', methods=['POST'])
    def getNotificationCount():
        return GetNotificationCount()

    @thingworx.route('/Things/Keysight.AssetManagement/Services/GetPermissionBasedColumns', methods=['POST'])
    def getPermissionBasedColumns():
        return GetPermissionBasedColumns()

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetColumnSort', methods=['POST'])
    def setColumnSort():
        return SetColumnSort()
