from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"orgDetails":[{"CustomerName":"Asset Advisor Demo","CustomerId":"2"}]}
def GetOrgs():
 return jsonify(data)