from flask import (
    Blueprint,
    request
)

from app.modules.UserManagement.api import getLoginRoutes
from app.modules.AssetManagement.BaseListing.api import getAssetBaseListingRoutes
from app.modules.AssetManagement.Charts.api import getAssetChartsRoutes
from app.modules.AssetManagement.CreateAsset.api import getCreateAssetRoutes
from app.modules.AssetManagement.EditAsset.api import getEditAssetRoutes
from app.modules.IssueLog.api import getIssueLogRoutes
from app.modules.AssetManagement.Common.api import getBaseListingFilterRoutes
from app.modules.AssetManagement.BulkEdit.api import getBulkEditRoutes
from app.modules.AssetManagement.HealthTrend.api import getHealthTrendRoutes
from app.modules.AssetManagement.UserSetting.api import getUserSettingRoutes
from app.modules.ServiceRequest.api import getServiceRequestRoutes
from app.modules.AdminSettings.api import getAdminSettingsRoutes

thingworx = Blueprint('Thingworx', __name__)
issuelog = Blueprint('issuelogs', __name__)

# Registering Routes for Module
getLoginRoutes(thingworx) # Login Routes
getAssetBaseListingRoutes(thingworx) #Baselisting Routes
getAssetChartsRoutes(thingworx) #Baselisting Routes
getCreateAssetRoutes(thingworx)
getEditAssetRoutes(thingworx)
getIssueLogRoutes(thingworx)
getBaseListingFilterRoutes(thingworx)
getBulkEditRoutes(thingworx)
getHealthTrendRoutes(thingworx)
getUserSettingRoutes(thingworx)
getServiceRequestRoutes(thingworx)
getAdminSettingsRoutes(thingworx)