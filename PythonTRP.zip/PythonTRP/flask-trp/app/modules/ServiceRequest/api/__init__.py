from .GetCustomerServiceRequests import GetCustomerServiceRequests
from .GetGridDataModel import GetGridDataModel
from .GetCompleteGridData import GetCompleteGridData
from .GetFilters import GetFilters
from .GetServiceRequestDetails import GetServiceRequestDetails

def getServiceRequestRoutes(thingworx):
    @thingworx.route('/Things/Keysight.AssetManagement/Services/GetCustomerServiceRequests', methods=['POST'])
    def getCustomerServiceRequests():
        return GetCustomerServiceRequests()

    # @thingworx.route('/Things/Keysight.BaseListing/Services/GetGridDataModel', methods=['POST'])
    # def getGridDataModel():
    #     return GetGridDataModel()

    # @thingworx.route('/Things/Keysight.BaseListing/Services/GetCompleteGridData', methods=['POST'])
    # def getCompleteGridData():
    #     return GetCompleteGridData()

    # @thingworx.route('/Things/Keysight.BaseListing/Services/GetFilters', methods=['POST'])
    # def getFilters():
    #     return GetFilters()

    @thingworx.route('/Things/Keysight.AssetManagement/Services/GetServiceRequestDetails', methods=['POST'])
    def getServiceRequestDetails():
        return GetServiceRequestDetails()