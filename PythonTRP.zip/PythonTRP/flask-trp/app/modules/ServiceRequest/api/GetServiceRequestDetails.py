from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"success":True,"details":{"result":{"biladdresscontact":"pDheerendra","pickupoption":"0","reqpostalcode":"","pickupphone":"","pickupcompanyname":"","reqcountry":"","returnline4":"","reqemail":"Dheerendra.Prajapati@ITCINFOTECH.COM","returnline3":"","returncountry":"","returnline2":"","returnline1":"","biladdressphone":"080-1234555","pickupprovince":"","biladdresspostalcode":"11253","returncity":"","reqlastname":"p","biladdressvatid":"","pickupcountry":"","pickuppostalcode":"","pickupstate":"","biladdresscountry":"","sritems":[{"attachfaultreportfile":"","requestedservice":"Repair (only)","attachfaultreportfilename":"","fault":"","modelno":"N5183A","purchaseorderno":"","preferreddate":"","manufacturer":"Rohde & Schwarz, Inc.","serialno":"Dummy","attachpurchaseorderfilename":"","agreementno":"","attachpurchaseorderfile":"","quoteditems":[{"coverage":"Covered by warranty","spn":"Repair ","item":"REPAIR","terms":" ","price":"Please contact us for pricing","currency":""}],"custassetno":"","calcycle":"","customerinstruction":"We will contact you to organize the pickup of your instrument."}],"csrid":"189360","reqprefix":"","biladdressstate":"","reqcompanyname":"","returncompanyname":"Asset Advisor Demo","biladdresscity":"Bangalore","reqstate":"","reqline1":"","reqcity":"","biladdresscompanyname":"Asset Advisor Demo","reqphone":"080-1234555","returnprovince":"","returnpostalcode":"","biladdressline3":"","returncontact":"","returnstate":"","pickupcity":"","reqfirstname":"Dheerendra","returnphone":"","reqline4":"","pickupcontact":"","reqline2":"","reqfax":"080-1234555","reqline3":"","pickupline4":"","pickupline1":"","biladdressline1":"345 wilson road","pickupline3":"","biladdressline2":"test","pickupline2":""},"headers":{"content-type":"application/json","accept":"application/json"},"method":"SRCreateRequest","id":"1234"}}
def GetServiceRequestDetails():
 return jsonify(data)