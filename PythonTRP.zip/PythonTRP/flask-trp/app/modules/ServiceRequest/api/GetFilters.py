from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Serial number","id":"SerialNo","type":"string","value":"D","operator":"begins_with"}]},"success":True}
def GetFilters():
 return jsonify(data)