from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"success":True,"message":"Issue 10000090 updated successfully"}
def UpdateSubmittedIssue():
 return jsonify(data)