from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"data":[{"downloadLink":"https://aa-r-qa2.ssgaa.usw2.amzn.keysight.com/Thingworx/FileRepositories/2-FileRepository/SubmitIssue/e47ab160-567c-439d-8de3-186ac6467611/2.PNG","lastModifiedDate":"2018-10-04T13:05:25.000Z","name":"2.PNG"}],"success":True}
def GetAttachments():
 return jsonify(data)