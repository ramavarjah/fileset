from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request
)


def home():
    return render_template('IssueLog/index.html')


