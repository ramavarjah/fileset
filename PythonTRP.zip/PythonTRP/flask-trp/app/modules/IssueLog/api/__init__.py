from .GetIssuesAssignedToMe import GetIssuesAssignedToMe
from .GetIssuesSubmittedByMe import GetIssuesSubmittedByMe
from .MarkNotificationAsRead import MarkNotificationAsRead
from .GetAttachments import GetAttachments
from .UpdateSubmittedIssue import UpdateSubmittedIssue
from .CreateIssue import CreateIssue
from .UploadFile import UploadFile

def getIssueLogRoutes(app):
    @app.route('/Things/Keysight.Issue/Services/GetIssuesAssignedToMe', methods=['POST'])
    def getIssuesAssignedToMe():
        return GetIssuesAssignedToMe()

    @app.route('/Things/Keysight.Issue/Services/GetIssuesSubmittedByMe', methods=['POST'])
    def getIssuesSubmittedByMe():
        return GetIssuesSubmittedByMe()

    @app.route('/Things/Keysight.BaseListing/Services/MarkNotificationAsRead', methods=['POST'])
    def markNotificationAsRead():
        return MarkNotificationAsRead()

    @app.route('/Things/Keysight.Issue/Services/GetAttachments', methods=['POST'])
    def getAttachments():
        return GetAttachments()

    @app.route('/Things/Keysight.Issue/Services/UpdateSubmittedIssue', methods=['POST'])
    def updateSubmittedIssue():
        return UpdateSubmittedIssue()

    @app.route('/Things/Keysight.Issue/Services/CreateIssue', methods=['POST'])
    def createIssue():
        return CreateIssue()

    @app.route('/Things/Keysight.Issue/Services/UploadFile', methods=['POST'])
    def uploadFile():
        return UploadFile()