from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request
)
from app import db
from app.models import IssueLog


def createisuue():
    if request.is_json:
        content = request.get_json()
        if content["IssueSummary"] is not '':
            issuelog = IssueLog(content["Status"], content["DateOpened"],
                                content['Category'], content['Description'],
                                content['NotificationId'], content['Customer'],
                                content['SubmittedBy'], content['Severity'],
                                content['CustomerId'], content['History'],
                                content['Implication'], content['AssignedTo'],
                                content['IssueSummary'], content['IssueId'],
                                content['description'], content['thingTemplate'],
                                content['tags'])
            db.session.add(issuelog)
            db.session.commit()

