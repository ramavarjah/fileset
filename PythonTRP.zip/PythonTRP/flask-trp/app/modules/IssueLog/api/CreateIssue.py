from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"success":True,"IssueId":"10000147","message":"Issue submitted successfully your Issue-Id is 10000147"}
def CreateIssue():
 return jsonify(data)