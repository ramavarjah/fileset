from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify
)

from app.models import IssueLog
from app import FlaskMarshmallow

ma = FlaskMarshmallow()

class issuelogSchema(ma.ModelSchema):
    class Meta:
        model = IssueLog

def getisuue():
    issuelog = IssueLog.query.first()
    issuelog_schema = issuelogSchema()
    output = issuelog_schema.dump(issuelog).data
    return jsonify({'issuelogs':output})
    #return render_template('IssueLog/getissue.html', IssueLog=IssueLog )