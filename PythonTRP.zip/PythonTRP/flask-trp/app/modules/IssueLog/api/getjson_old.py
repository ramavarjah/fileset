from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify
)


def getJSON():
    return jsonify(
        username='sooraj',
        email='sooraj.sanker@itcinfotech.com'
    )

