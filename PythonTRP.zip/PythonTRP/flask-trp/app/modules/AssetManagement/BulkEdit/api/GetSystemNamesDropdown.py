from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"data":[{"thingName":"2_ 10.145.89.137","SystemName":"CHRIS IS GREAT","equipmentNo":" 10.145.89.137"},{"thingName":"2_1000000202","SystemName":"Dell","equipmentNo":"1000000202"},{"thingName":"2_10001178","SystemName":"system","equipmentNo":"10001178"},{"thingName":"2_10001179","SystemName":"system1","equipmentNo":"10001179"},{"thingName":"2_10001206","SystemName":"Tempil-PN-2333","equipmentNo":"10001206"},{"thingName":"2_10001569","SystemName":"System name1","equipmentNo":"10001569"},{"thingName":"2_10001589","SystemName":"system test ","equipmentNo":"10001589"},{"thingName":"2_10001683","SystemName":"aditi","equipmentNo":"10001683"},{"thingName":"2_10001701","SystemName":"aditi12","equipmentNo":"10001701"},{"thingName":"2_10001742","SystemName":"test","equipmentNo":"10001742"},{"thingName":"2_10001802","SystemName":"Parent system name1","equipmentNo":"10001802"},{"thingName":"2_10001977","SystemName":"10001977","equipmentNo":"10001977"},{"thingName":"2_10002033","SystemName":"Spock","equipmentNo":"10002033"},{"thingName":"2_10002193","SystemName":"PC","equipmentNo":"10002193"},{"thingName":"2_10003152","SystemName":"System Name","equipmentNo":"10003152"},{"thingName":"2_100100104","SystemName":"system","equipmentNo":"100100104"},{"thingName":"2_100100105","SystemName":"System1","equipmentNo":"100100105"},{"thingName":"2_12","SystemName":"Test Parent","equipmentNo":"12"},{"thingName":"2_19064735","SystemName":"xcvbm","equipmentNo":"!#$$$ ^&*($*()$())*&&&"},{"thingName":"2_20524133","SystemName":"Fan1","equipmentNo":"10004856"},{"thingName":"2_31859072","SystemName":"@|!#*&&","equipmentNo":"Dheeru|234 %$?/ +23 (£)GBP (¥)RMB (¥)YEN  ($)USD"},{"thingName":"2_34668581","SystemName":"TEST12","equipmentNo":";:'\",<>.?/"},{"thingName":"2_42724777","SystemName":"System name top","equipmentNo":"~!@#$%^&*()_+`-={}|:\"<>?[]\\;',./AB12"},{"thingName":"2_53222550","SystemName":"System name","equipmentNo":"~!@#$%^&*()_+`-={}|:\"<>?[]\\;',./AB13"},{"thingName":"2_62776004","SystemName":"","equipmentNo":"321654987"},{"thingName":"2_67158471","SystemName":"System name","equipmentNo":"~!@#$%^&*()_+`-={}|:\"<>?[]\\;',./AB18"},{"thingName":"2_79743870","SystemName":"Fan","equipmentNo":"10004359"},{"thingName":"2_86511343","SystemName":"Addy","equipmentNo":"!@$%^&)*   )(*&**&?><:\"{}+_ "},{"thingName":"2_90364007","SystemName":"tweet","equipmentNo":"!!@#$%^&*()_+ <>????  \":{}\"+"},{"thingName":"2_AA10000029","SystemName":"CHRIS MONITOR IS GREAT","equipmentNo":"10000029"},{"thingName":"2_E7515BMY58120223","SystemName":"FMC","equipmentNo":"E7515BMY58120223"},{"thingName":"2_EQNUM12123","SystemName":"Dell12345674","equipmentNo":"EQNUM12123"},{"thingName":"2_EQNUM121234","SystemName":"Dell123456745","equipmentNo":"EQNUM121234"},{"thingName":"2_EQNUM123","SystemName":"Dell1","equipmentNo":"EQNUM123"},{"thingName":"2_EQNUM1234","SystemName":"Dell2","equipmentNo":"EQNUM1234"},{"thingName":"2_EQNUM12345","SystemName":"Dell21","equipmentNo":"EQNUM12345"},{"thingName":"2_MyTestNumber1","SystemName":"Test_Parent","equipmentNo":"MyTestNumber1"},{"thingName":"2_SC04","SystemName":"qwerty","equipmentNo":"SC04"}],"success":True}
def GetSystemNamesDropdown():
    from app.models import Asset
    from app.models import AssetSchema
    from flask_login import current_user
    from marshmallow import pprint
    # need to change this query once customer id i implemented correctly in assets
    assets = Asset.query.filter_by(user_id=current_user.get_id()).all()
    asset_dict= {}
    customerAssets= []
    customerAssets_dict ={}
    for asset in assets:
        asset_dict["EquipmentNo"]= asset.EquipmentNo
        asset_dict["UniqueID"]= asset.UniqueID
        asset_dict["SystemName"]= asset.SystemName
        customerAssets.append(asset_dict)

    customerAssets_dict["data"] = customerAssets
    customerAssets_dict["sucess"]= True
    return data