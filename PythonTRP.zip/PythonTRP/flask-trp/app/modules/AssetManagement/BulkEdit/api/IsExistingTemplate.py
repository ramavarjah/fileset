from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app.models import Template, TemplateSchema
from marshmallow import fields, Schema

class TempSchema(Schema):
    sucess = fields.Method("getSuccess")
    message = fields.Method("getMessage")
   
    def getSuccess(self, obj):
        return True

    def getMessage(self, obj):
        return "Do you want to save the template?"


#Request Payload : {"CustomerId":"2","TemplateName":"Test1"}
#Response : {"success":True,"message":"Do you want to save the template?"}
def IsExistingTemplate(request):
    if not request.json:
        return jsonify({'message': 'No input data provided '}), 400
    content = request.json
    gettemplates = Template.query.all()
    schema = TemplateSchema()
    tempTemplate = {}
    for item in gettemplates:
        tempdb = schema.dump(item).data["TemplateName"]
        if content["TemplateName"] == tempdb:
            tempTemplate["success"]=True
            tempTemplate["message"]="Do you want to save the template?"

    return jsonify(tempTemplate)