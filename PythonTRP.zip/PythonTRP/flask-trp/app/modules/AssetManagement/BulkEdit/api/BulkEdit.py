from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"success":True,"message":"Assets have been modified successfully."}
from marshmallow import fields, Schema

class BulkEditSchema(Schema):
    sucess = fields.Method("getSuccess")
    message = fields.Method("getMessage")
   
    def getSuccess(self, obj):
        return True

    def getMessage(self, obj):
        return "Do you want to save the template?"


def BulkEdit():
 return jsonify(data)