from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
    "success": True,
    "tree": {
      "expanded": True,
      "children": [
        {
          "expanded": True,
          "children": [
            {
              "expanded": True,
              "children": [
                {
                  "text": "Country1",
                  "leaf": True
                }
              ],
              "text": "Region1"
            },
            {
              "text": "Region2",
              "leaf": True
            }
          ],
          "text": "TestAA"
        }
      ]
    }
}

def GetLocationTree():
    return data