from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"success":True,"UserList":["aditi.sethi@itcinfotech.com","aimee@keysight.com","alyse@keysight.com","amanda.smith@keysight.com","ana_rivera@keysight.com","antonio_martinez@keysight.com","billm@keysight.com","bo.zhu@keysight.com","cedric_simon@assetadvisordemo.com","charlie_slater@keysight.com","ching-pu.wu@keysight.com","chris.schaefer@keysight.com","chris@keysight.com","christine_herring@keysight.com","christopher.tenhoeve@keysight.com","christopher_rich@keysight.com","cosmin.haims@non.keysight.com","cristhian.novais@keysight.com","dan@keysight.com","darlene_carpenter@non.keysight.com","david.delao@keysight.com","dheer@gmail.com","dheerendra.prajapati@itcinfotech.com","dheeru2@gmail.com","doug.smith@non.keysight.com","drew.reynaud@keysight.com","francisco_malpartida@keysight.com","frankpalmer129@outlook.com","garrick.lee@non.keysight.com","jitender.hooda@itcinfotech.com","joe.tester@aademo.com","john.semans@keysight.com","john_bishop@keysight.com","john_wilson3@keysight.com","john_wilson6@keysight.com","john_wilson7@keysight.com","john_wilson@keysight.com","kaushik.v@itcinfotech.com","kenk@keysight.com","kevin.whitehouse@keysight.com","ksf.cloud@keysight.com","lucia_abalos@keysight.com","mail@jainnikhil.com","manuel.medina@keysight.com","marc@keysight.com","mike.reid2@keysight.com","mike.reid@keysight.com","mindy_allen@keys.com","mohammed.muzahid@itcinfotech.com","neil_forcier@keysight.com","noone@nowhere.com","phil.stearns@keysight.com","russellstock@keysight.com","ryan.johnson@non.keysight.com","ryan.semans1@non.keysight.com","sandra.cipriani@keysight.com","sean_hubert@keysight.com","sindhu.vemireddy@itcinfotech.com","sooraj.sanker@itcinfotech.com","soumyaranjan.bej@itcinfotech.com","steve_duffy@keysight.com","stewart_forsyth@keysight.com","synthetic_tester@keysight.com","thomas.oliver@keysight.com","thomas.ryden@keysight.com","vishalm@aademo.com"]}
def GetAllUsersForCustomer():
 return jsonify(data)