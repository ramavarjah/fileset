from .GetBulkEditableFields import GetBulkEditableFields
from .GetFinalListManfacturer import GetFinalListManfacturer
from .GetOrgs import GetOrgs
from .GetOrganizationTree import GetOrganizationTree
from .GetLocationTree import GetLocationTree
#from .GetCustomerAssets import GetCustomerAssets
from .GetSystemNamesDropdown import GetSystemNamesDropdown
from .GetFinalListModelNo import GetFinalListModelNo
from .GetAllUsersForCustomer import GetAllUsersForCustomer
from .BulkEdit import BulkEdit
from .GetTemplates import GetTemplates
from .IsExistingTemplate import IsExistingTemplate


def getBulkEditRoutes(thingworx):
    @thingworx.route('/Things/Keysight.Asset/Services/GetBulkEditableFields', methods=['POST'])
    def getBulkEditableFields():
        return GetBulkEditableFields()

    @thingworx.route('/Things/Keysight.Asset/Services/GetFinalListManfacturer', methods=['POST'])
    def getFinalListManfacturer():
        return GetFinalListManfacturer()

    @thingworx.route('/Things/Keysight.Generic/Services/GetOrgs', methods=['POST'])
    def getOrgs():
        return GetOrgs()

    @thingworx.route('/Things/Keysight.Generic/Services/GetOrganizationTree', methods=['POST'])
    def getOrganizationTree():
        return GetOrganizationTree()

    @thingworx.route('/Things/Keysight.Generic/Services/GetLocationTree', methods=['POST'])
    def getLocationTree():
        return GetLocationTree()

    # @thingworx.route('/Things/Keysight.Login.Search/Services/GetCustomerAssets', methods=['POST'])
    # def getCustomerAssets():
    #     return GetCustomerAssets()

    @thingworx.route('/Things/Keysight.Asset/Services/GetSystemNamesDropdown', methods=['POST'])
    def getSystemNamesDropdown():
        return GetSystemNamesDropdown()

    @thingworx.route('/Things/Keysight.Asset/Services/GetFinalListModelNo', methods=['POST'])
    def getFinalListModelNo():
        return GetFinalListModelNo()

    @thingworx.route('/Things/Keysight.Generic/Services/GetAllUsersForCustomer', methods=['POST'])
    def getAllUsersForCustomer():
        return GetAllUsersForCustomer()

    @thingworx.route('/Things/Keysight.Asset/Services/BulkEdit', methods=['POST'])
    def bulkEdit():
        return BulkEdit()

    @thingworx.route('/Things/Keysight.Asset/Services/GetTemplates', methods=['POST'])
    def getTemplates():
        return GetTemplates()

    @thingworx.route('/Things/Keysight.Asset/Services/IsExistingTemplate', methods=['POST'])
    def isExistingTemplate():
        return IsExistingTemplate()