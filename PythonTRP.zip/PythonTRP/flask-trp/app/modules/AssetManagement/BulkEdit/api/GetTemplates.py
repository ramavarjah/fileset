from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)

from app.models import  Template, User

def GetTemplates(request):
    from app.models import TemplateSchema
    from flask_login import current_user
    from marshmallow import pprint
    gettemplates = Template.query.all()
    schema = TemplateSchema()
    template_dist= {}
    template_dist["data"] = []
    for item in gettemplates:
      tempTemplate = {}
      tempTemplate["templateName"] = schema.dump(item).data["TemplateName"]
      tempTemplate["values"] = schema.dump(item).data
      template_dist["data"].append(tempTemplate)

    template_dist["sucess"] = True
    if request == None:
      return template_dist
    return jsonify(template_dist)