from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"EditableFieldDetails":{"ParentSystemName":True,"UtilizationCategory":True,"CalibrationInterval":True,"OrderNumber":True,"UseProviderCalibrationType":True,"LifeCycleStage":True,"UseProviderCalibrationSchedule":True,"RepairProvider":True,"EquipmentType":True,"ReplacedBy":True,"CalibrationProvider":True,"Currency":True,"Manufacturer":True,"InvoiceNumber":True,"PlannedDisposalDate":True,"AltManufacturerName":True,"InventoryDate":True,"SoftwareRevision":True,"HardwareVersion":True,"LastReportedCondition":True,"Project":True,"Depreciation":True,"ReceivedDate":True,"ProductCategory":True,"LoanAutoCalculate":True,"OwnershipStatus":True,"Options":True,"Organization":True,"Description":True,"User":True,"LoanDailyRate":True,"SystemParent":True,"BookValueDate":True,"ReplacementDate":True,"PurchasePrice":True,"PartOfSystemCalibration":True,"CalibrationDate":True,"Accessories":True,"SystemChild":True,"CalibrationDueDate":True,"OwningCompany":True,"ServiceLogistics":True,"Coordinator":True,"OrderDate":True,"BookValue":True,"LoanDailyCost":True,"ServiceCost":True,"CalibrationType":True,"FirmwareRevision":True,"Location":True,"StickyNotes":True}}
def GetBulkEditableFields():
 return jsonify(data)