# from flask import (
#     Blueprint,
#     flash,
#     redirect,
#     render_template,
#     url_for,
#     request,
#     jsonify,
#     Response
# )

# from app.models import Asset
# def GetCustomerAssets():
#     from app.models import AssetSchema
#     from flask_login import current_user
#     from marshmallow import pprint
#     # need to change this query once customer id i implemented correctly in assets
#     assets = Asset.query.filter_by(user_id=current_user.get_id()).all()

#     schema = AssetSchema()
#     asset_dist= {}
#     asset_dist_arr = []
#     for asset in assets:
#         asset_dist_arr.append(asset.EquipmentNo)
#         asset_dist["data"]=asset_dist_arr

#     asset_dist["success"] = True
#     return asset_dist