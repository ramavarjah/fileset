from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
    "orgDetails": [
      {
        "CustomerName": "TestAA",
        "CustomerId": "2"
      }
    ]
  }
def GetOrgs():
 return data