from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app.models import Tab
from app import db
data={}

data = {"data":[{"SearchId":"1a9271d5-c3a7-4683-835e-a5304d8d8c66","baseQuery":{"valid":True,"condition":"OR","rules":[{"input":"text","field":"Equipment number","id":"EquipmentNo","type":"string","value":"10001040","operator":"equal"},{"input":"text","field":"Equipment number","id":"EquipmentNo","type":"string","value":"10001037","operator":"equal"}]},"SearchName":"Itc","selected":False,"filterQuery":{"filters":{"filters":[{"fieldName":"EquipmentNo","type":"EQ","value":"10001040"},{"fieldName":"EquipmentNo","type":"EQ","value":"10001037"}],"type":"OR"}}},{"SearchId":"51561e86-6d7b-42d1-adb9-2543385fc363","baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"radio","field":"Is connected","id":"IsConnected","type":"boolean","value":True,"operator":"equal"}]},"SearchName":"my filter","selected":False,"filterQuery":{"filters":{"fieldName":"IsConnected","type":"EQ","value":True}}},{"SearchId":"f7119bd2-39f3-4467-9f9e-8b6b3512c2de","baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Equipment number","id":"EquipmentNo","type":"string","value":"10001037 ","operator":"equal"},{"input":"text","field":"Equipment number","id":"EquipmentNo","type":"string","value":"10001040","operator":"equal"},{"input":"text","field":"Equipment number","id":"EquipmentNo","type":"string","value":"10001051","operator":"equal"}]},"SearchName":"Test","selected":False,"filterQuery":{"filters":{"filters":[{"fieldName":"EquipmentNo","type":"EQ","value":"10001037 "},{"fieldName":"EquipmentNo","type":"EQ","value":"10001040"},{"fieldName":"EquipmentNo","type":"EQ","value":"10001051"}],"type":"AND"}}}],"success":True}
def GetSavedSearch():
 return jsonify(data)