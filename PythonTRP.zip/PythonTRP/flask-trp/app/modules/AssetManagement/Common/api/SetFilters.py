from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)

from app.models import Tab
from app import db

data = {"success":True}
def SetFilters(request):
    """
    Author: Ayush Jain
    Description: save the filter query for current tab .
    :type request: json
    :param request:getting the request payload from client.

    :raises: exception if no i/p recieved from request payload/ the queried object returns None type or data cant be updated in the db.

    :rtype: json
    """
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400
    content = request.json
    if not content:
        return jsonify({'message': 'No input data provided'}), 400

    tab = Tab.get_active_tab()
    if tab== None:
        return jsonify({'message': 'The object is None type,possible reason may be TabId doesn\'t match'}), 400
    else:
        tab.baseQuery=content['baseQuery']
        print(tab.id)
        from sqlalchemy.exc import IntegrityError
        try:
            db.session.commit()
            print("succesfully saved column order")
        except IntegrityError:
            print("commiting column order failed")
            db.session.rollback()

    return jsonify(data)



