from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)

from random import seed, choice
from app import db
from app.models import User
from flask_login import current_user
from app.models import Tab

#data = {"success": True,"message":"Tab 123 created successfully","TabId":"05c75600-9539-45ce-a221-5a72d835c6c3"}


def CreateUserTab(request, **kwargs):
    from sqlalchemy.exc import IntegrityError
    content = request.json
    # print(content)
    # print(content['TabName'])
    user_dict = {}

    # c = Tab.query.filter_by(User_id = current_user.get_id()).first()
    user_dict['TabId'] = ' '
    user_dict['message'] = content['TabName'] + ' created successfully '
    user_dict['success'] = True

    currUser = User.get_current_user()
    

    u = Tab(
        baseQuery='{}',
        BaseString='{}',
        BucketType='{}',
        ColumnOrder='{}',
        ColumnWidth='{}',
        DatePreset='Today',
        DisplayDensity='default',
        FilterQuery={},
        HiddenColumns='{}',
        NoOfWorkingHours=1,
        Pagination=25,
        PinColumn={"PinnedColumn":{"pinright":[],"pinleft":[]}},
        SavedSearchId='{}',
        SortedColumns={"array":[]},
        # TabId=0,
        TabName=content['TabName'],
        TabOrder=1,
        UserName=currUser.email,
        ViewCategoryId='{}',
        ViewEndDate='1970-01-01 05:30:00.000',
        ViewStartDate='1970-01-01 05:30:00.000',
        ViewTypeId='{}',
        user=currUser,
        **kwargs)
    db.session.add(u)
    try:
        db.session.commit()
        # print("generate creatusertabs_Success")
    except IntegrityError:
        print("generate createusertabs_Failed")
        db.session.rollback()

    return jsonify(user_dict)
