from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)

from app.models import Tab
from app import db
data = {}
# data = {"baseQuery":{},"success":True}


def GetFilters():
    """ 
    Author: Ayush Jain
    Description: returning the filter values for the current tab.
        :raises: exception if  the queried object returns None type .

        :rtype: json
    """
    tab = Tab.get_active_tab()
    if tab == None:
        return jsonify({'message': 'The object is None type,possible reason may be TabId doesn\'t match'}), 400

    data["baseQuery"]=tab.baseQuery
    data["success"] = True
    return jsonify(data)
