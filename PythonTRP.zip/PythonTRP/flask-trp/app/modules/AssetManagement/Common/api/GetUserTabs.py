from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from flask_login import current_user
from app.models import Tab, User
from app.models import TabSchema
from marshmallow import pprint
data = {"success":True,"tabs":[{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Barcode/RFID","id":"Barcode","type":"string","value":"3415925D10000000000000C1","operator":"contains"}]},"PinColumn":{"PinnedColumn":{"pinright":[{}],"pinleft":[{}]}},"ChartStartDate":1.5423066E12,"SortedColumns":{"array":[]},"ChartEndDate":1.542392999999E12,"DatePreset":"Today","BucketType":"View By Hours","TabOrder":1,"ChartViewId":"16","Pagination":50,"Active":False,"ChartCategoryId":"3","DisplayDensity":"default","TabName":"This group created by KeysightDevgroupR","TabId":"2604cb4a-bbab-487b-9277-694445f3de7a","NoOfWorkingHours":8},{"baseQuery":{},"PinColumn":{"PinnedColumn":{"pinright":[{}],"pinleft":[{}]}},"ChartStartDate":1.5426522E12,"SortedColumns":{"array":[{"sort":"asc","colId":"EquipmentNo"}]},"ChartEndDate":1.542738599999E12,"DatePreset":"Yesterday","BucketType":"View By Hours","TabOrder":2,"ChartViewId":"9","Pagination":25,"Active":False,"ChartCategoryId":"3","DisplayDensity":"default","TabName":"Tab-1","TabId":"dc72a032-aaeb-4a79-b892-e34333d58210","NoOfWorkingHours":8},{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Equipment number","id":"EquipmentNo","type":"string","value":"10002126","operator":"equal"}]},"PinColumn":{"PinnedColumn":{"pinright":[],"pinleft":[{"colId":"0","fieldId":0}]}},"ChartStartDate":1.5436026E12,"SortedColumns":{"array":[]},"ChartEndDate":1.543688999999E12,"DatePreset":"Today","BucketType":"View By Hours","TabOrder":3,"ChartViewId":"10","Pagination":25,"Active":False,"ChartCategoryId":"4","DisplayDensity":"medium","TabName":"is connected True","TabId":"d7fe14a4-7d1f-42b3-a91d-27cd4a3a8c3b","NoOfWorkingHours":8},{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Health","id":"HealthStatus","type":"string","operator":"is_not_empty"}]},"PinColumn":{"PinnedColumn":{"pinright":[],"pinleft":[{"colId":"0","fieldId":0}]}},"ChartStartDate":1.5442938E12,"SortedColumns":{"array":[]},"ChartEndDate":1.545157799999E12,"DatePreset":"Last Week-to-date","BucketType":"View By Days","TabOrder":4,"ChartViewId":"16","Pagination":1000,"Active":False,"ChartCategoryId":"3","DisplayDensity":"default","TabName":"TabR","TabId":"21db2c55-49d5-4224-a029-68b406d11446","NoOfWorkingHours":8},{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Health","id":"HealthStatus","type":"string","operator":"is_not_empty"}]},"PinColumn":{"PinnedColumn":{"pinright":[],"pinleft":[{"colId":"0","fieldId":0}]}},"ChartStartDate":1.5424794E12,"SortedColumns":{"array":[]},"ChartEndDate":1.542997799999E12,"DatePreset":"This Week-to-date","BucketType":"View By Hours","TabOrder":6,"ChartViewId":"16","Pagination":100,"Active":False,"ChartCategoryId":"3","DisplayDensity":"medium","TabName":"This group created KeysightGroup","TabId":"cbe98957-c562-45d0-861d-18b70bb4f551","NoOfWorkingHours":8},{"baseQuery":{},"PinColumn":{"PinnedColumn":{"pinright":[],"pinleft":[{"colId":"0","fieldId":0}]}},"ChartStartDate":1.5427386E12,"SortedColumns":{"array":[]},"ChartEndDate":1.542824999999E12,"DatePreset":"Today","BucketType":"View By Hours","TabOrder":7,"ChartViewId":"1","Pagination":25,"Active":False,"ChartCategoryId":"1","DisplayDensity":"default","TabName":"WERT","TabId":"fd19b9bd-5097-482d-8ac6-914455fe9e80","NoOfWorkingHours":8},{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Health","id":"HealthStatus","type":"string","operator":"is_not_empty"}]},"PinColumn":{"PinnedColumn":{"pinright":[{}],"pinleft":[{}]}},"ChartStartDate":1.544985E12,"SortedColumns":{"array":[]},"ChartEndDate":1.545071399999E12,"DatePreset":"Today","BucketType":"View By Hours","TabOrder":99,"ChartViewId":"13","Pagination":25,"Active":False,"ChartCategoryId":"3","DisplayDensity":"default","TabName":"View By Hour C","TabId":"195e3f7f-747f-42b9-9291-fb2ad43fc360","NoOfWorkingHours":8},{"baseQuery":{},"PinColumn":{"PinnedColumn":{"pinright":[{}],"pinleft":[{}]}},"ChartStartDate":0,"SortedColumns":[],"ChartEndDate":0,"DatePreset":"Today","BucketType":"View By Hours","TabOrder":99,"ChartViewId":"1","Pagination":25,"Active":False,"ChartCategoryId":"1","DisplayDensity":"default","TabName":"Health Assets","TabId":"479540a6-e4ac-4517-971b-d98233838839","NoOfWorkingHours":8},{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Health","id":"HealthStatus","type":"string","operator":"is_not_empty"}]},"PinColumn":{"PinnedColumn":{"pinright":[{}],"pinleft":[{}]}},"ChartStartDate":1.544985E12,"SortedColumns":[],"ChartEndDate":1.545071399999E12,"DatePreset":"Today","BucketType":"View By Days","TabOrder":99,"ChartViewId":"13","Pagination":25,"Active":False,"ChartCategoryId":"3","DisplayDensity":"default","TabName":"VBH1","TabId":"a9eeb287-e318-4726-8938-46d270dc81f5","NoOfWorkingHours":8},{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Equipment number","id":"EquipmentNo","type":"string","value":"100000225","operator":"equal"}]},"PinColumn":{"PinnedColumn":{"pinright":[{}],"pinleft":[{}]}},"ChartStartDate":0,"SortedColumns":[],"ChartEndDate":0,"DatePreset":"Today","BucketType":"View By Hours","TabOrder":99,"ChartViewId":"1","Pagination":25,"Active":True,"ChartCategoryId":"1","DisplayDensity":"default","TabName":"Heath Asset","TabId":"6bb4c064-0a3b-4aa4-8e49-f4e4f4d385aa","NoOfWorkingHours":8},{"baseQuery":{},"PinColumn":{"PinnedColumn":{"pinright":[{"colId":"AltManufacturerName","fieldId":7}],"pinleft":[{"colId":"0","fieldId":0}]}},"ChartStartDate":1.5448986E12,"SortedColumns":{"array":[]},"ChartEndDate":1.545071399999E12,"DatePreset":"This Week-to-date","BucketType":"View By Months","TabOrder":99,"ChartViewId":"10","Pagination":5000,"Active":False,"ChartCategoryId":"4","DisplayDensity":"large","TabName":"View By Hour C1","TabId":"f5b15c3c-eee8-41a1-8639-31eab2447639","NoOfWorkingHours":8},{"baseQuery":{"valid":True,"condition":"AND","rules":[{"input":"text","field":"Health","id":"HealthStatus","type":"string","operator":"is_not_empty"}]},"PinColumn":{"PinnedColumn":{"pinright":[{}],"pinleft":[{}]}},"ChartStartDate":1.5448986E12,"SortedColumns":{"array":[]},"ChartEndDate":1.545071399999E12,"DatePreset":"This Week-to-date","BucketType":"View By Days","TabOrder":99,"ChartViewId":"16","Pagination":25,"Active":False,"ChartCategoryId":"3","DisplayDensity":"default","TabName":"View By Hour","TabId":"9a42bc74-0a31-4372-bcb2-49ba895a28ec","NoOfWorkingHours":8}]}
def GetUserTabs(request):
    try:
        currUser = User.get_current_user()
        activeUserTab = currUser.CurrentTabId
        userTabs = Tab.get_user_tabs()
        schema = TabSchema()
        result=[]
        for userTab in userTabs:
            tab=schema.dump(userTab).data
            tab['Active'] = False
            if userTab.TabId == num(activeUserTab):
                tab['Active'] = True
            result.append(tab)
        if request == None:
            return result
        return jsonify({'success':True,'tabs':result})
    except:
        return {'success':False,'message': 'error while retrieving the user tabs'}


def num(s):
    try:
        return int(s)
    except ValueError:
        return float(s)
