from .GetFilterValues import GetFilterValues
from .GetFilters import GetFilters
from .GetSavedSearch import GetSavedSearch
from .SetFilters import SetFilters
from .GetUserTabs import GetUserTabs
from .GetGridDataModel import GetGridDataModel
from .GetCompleteGridData import GetCompleteGridData
from .SetDisplayDensity import SetDisplayDensity
from .SetPagination import SetPagination
from .CreateUserTab import CreateUserTab
from .CloneTab import CloneTab
from .SetActiveTab import SetActiveTab
from .SetDisplayDensity import SetDisplayDensity
from .GetFilters import GetFilters

from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)


def getBaseListingFilterRoutes(thingworx):
    @thingworx.route('/Things/Keysight.BaseListing/Services/GetFilterValues', methods=['POST'])
    def getFilterValues():
        return GetFilterValues()

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetFilters', methods=['POST'])
    def getfilters():
        return GetFilters()

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetSavedSearch', methods=['POST'])
    def getSavedSearch():
        return GetSavedSearch()

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetFilters', methods=['POST'])
    def setFilters():
        return SetFilters(request)
    

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetUserTabs', methods=['POST'])
    def getUserTabs():
        return GetUserTabs()

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetGridDataModel', methods=['POST'])
    def getGridDataModel():
        return GetGridDataModel(request)

    @thingworx.route('/Things/Keysight.User/Services/SetDisplayDensity', methods=['POST'])
    def SetDisplaydensity():
        return SetDisplayDensity(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetCompleteGridData', methods=['POST'])
    def getCompleteGridData():
        return GetCompleteGridData(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetDisplayDensity', methods=['POST'])
    def setDisplaydensity():
        return SetDisplayDensity(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetPagination', methods=['POST'])
    def setPagination():
        return SetPagination(request)

    @thingworx.route('/Things/Keysight.User/Services/CreateUserTab', methods=['POST'])
    def createUserTab():
        return CreateUserTab(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/CloneTab', methods=['POST'])
    def cloneTab():
        return CloneTab(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetActiveTab', methods=['POST'])
    def setActiveTab():
        return SetActiveTab(request)
