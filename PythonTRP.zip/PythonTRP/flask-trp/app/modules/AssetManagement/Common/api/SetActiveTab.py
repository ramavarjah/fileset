from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app import db
from app.models import User, Tab


def SetActiveTab(request):
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400
    content = request.json
    if not content['TabId']:
        return jsonify({'message': 'No input data provided'}), 400
    currUser = User.get_current_user()
    currUser.CurrentTabId = content['TabId']
    try:
        db.session.commit()
    except:
        return jsonify({"success": False}), 400
    else:
        return jsonify({"success": True})
