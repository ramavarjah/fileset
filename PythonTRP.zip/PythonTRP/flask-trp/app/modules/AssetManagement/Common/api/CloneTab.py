from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app import db
from app.models import User, Tab
from flask_login import current_user

# def __init__(self, **kwargs):
#     super(Tab, self).__init__(**kwargs)


def CloneTab(request):
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400
    content = request.json
    if not content['TabName']:
        return jsonify({'message': 'No input data provided'}), 400

    row = Tab.get_active_tab()
    u = Tab(
        baseQuery=row.baseQuery,
        BaseString=row.BaseString,
        BucketType=row.BucketType,
        ColumnOrder=row.ColumnOrder,
        ColumnWidth=row.ColumnWidth,
        DatePreset=row.DatePreset,
        DisplayDensity=row.DisplayDensity,
        FilterQuery=row.FilterQuery,
        HiddenColumns=row.HiddenColumns,
        NoOfWorkingHours=row.NoOfWorkingHours,
        Pagination=row.Pagination,
        PinColumn=row.PinColumn,
        SavedSearchId=row.SavedSearchId,
        SortedColumns=row.SortedColumns,
        # TabId=row.TabId,
        TabName=content['TabName'],
        TabOrder=row.TabOrder,
        UserName=row.UserName,
        ViewCategoryId=row.ViewCategoryId,
        ViewEndDate=row.ViewEndDate,
        ViewStartDate=row.ViewStartDate,
        ViewTypeId=row.ViewTypeId,
        user=User.get_current_user())
    db.session.add(u)

    try:
        db.session.commit()
    except:
        return jsonify({"success": False}), 400
    else:
        return jsonify({"success": True})
