from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"sequence":1.0004857E7,"success":True,"isUnique":True}
def ValidateEquipmentNumber():
 return jsonify(data)