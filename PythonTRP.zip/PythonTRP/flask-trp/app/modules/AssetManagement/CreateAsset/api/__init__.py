from app.modules.AssetManagement.CreateAsset.api.GetFinalListModelNo import GetFinalListModelNo
from .CreateAsset import CreateAsset
from .GetAllUsersForCustomer import GetAllUsersForCustomer
from .GetSystemComponents import GetSystemComponents
from .UploadAssetFile import UploadAssetFile
from .ValidateEquipmentNumber import ValidateEquipmentNumber
from .ValidateSystemName import ValidateSystemName
from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)


def getCreateAssetRoutes(thingworx):
    @thingworx.route('/Things/Keysight.Asset/Services/ValidateSystemName', methods=['POST'])
    def validateSystemName():
        return ValidateSystemName()

    @thingworx.route('/Things/Keysight.Asset/Services/GetSystemComponents', methods=['POST'])
    def getSystemComponents():
        return GetSystemComponents()

    # @thingworx.route('/Things/Keysight.Generic/Services/GetAllUsersForCustomer', methods=['POST'])
    # def getAllUsersForCustomer():
    #     return GetAllUsersForCustomer()

    @thingworx.route('/Things/Keysight.Asset/Services/ValidateEquipmentNumber', methods=['POST'])
    def validateEquipmentNumber():
        return ValidateEquipmentNumber()

    @thingworx.route('/Things/Keysight.Asset/Services/CreateAsset', methods=['POST'])
    def createAsset():
        return CreateAsset(request)

    @thingworx.route('/Things/Keysight.Asset/Services/UploadAssetFile', methods=['POST'])
    def uploadAssetFile():
        return UploadAssetFile()
