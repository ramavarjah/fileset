from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)

def GetAllApiResult():
    returnDict = {} 
    #returnDict['GetEquipmentNumberSequence']=GetCompleteGridData()
    # returnDict['GetCustomerAssets'] = GetCustomerAssets()
    # returnDict['GetSystemNamesDropdown']=GetSystemNamesDropdown()
    #returnDict['GetLocationTree'] = GetSubViewOptions()['data']
    # #returnDict['GetOrganizationTree'] = GetUserDetails()
    #returnDict['GetOrgs']=GetUserDetails()
    #returnDict['success']=True
    #returnDict['GetSystemNamesDropdown'] = GetCompleteGridData()
    #returnDict['GetTemplates'] = [{"CategoryId":"3","Active":False,"Textbox":True,"SubCategory":True,"ViewName":"Utilization vs Time","NoOfWorkingHours":8,"Date":True},{"CategoryId":"2","Active":False,"Textbox":False,"SubCategory":True,"ViewName":"Health","Date":True},{"Active":False,"Textbox":False,"SubCategory":True,"Date":True},{"CategoryId":"1","Active":True,"Textbox":False,"SubCategory":True,"ViewName":"Asset Count","Date":False},{"CategoryId":"4","Active":False,"Textbox":False,"SubCategory":False,"ViewName":"Service Due","Date":True}]
    return jsonify(returnDict)
