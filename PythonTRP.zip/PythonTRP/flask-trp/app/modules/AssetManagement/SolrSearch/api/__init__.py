from .GetSolrSearchResult import GetSolrSearchResult

def getSolrSearchRoutes(thingworx):
    @thingworx.route('/Things/Keysight.Solr/Services/GetSolrSearchResult', methods=['POST'])
    def getSolrSearchResult():
        return GetSolrSearchResult()