from .SetUserProfile import SetUserProfile
from .ChangePassword import ChangePassword
#from .GetOrganizationTree import GetOrganizationTree
# from .GetLocationTree import GetLocationTree


def getUserSettingRoutes(thingworx):
    @thingworx.route('/Things/Keysight.UserProfile/Services/SetUserProfile', methods=['POST'])
    def setUserProfile():
        return SetUserProfile()

    @thingworx.route('/Things/Keysight.UserProfile/Services/ChangePassword', methods=['POST'])
    def changePassword():
        return ChangePassword()

    # @thingworx.route('/Things/Keysight.Generic/Services/GetOrganizationTree', methods=['POST'])
    # def getOrganizationTree():
    #     return GetOrganizationTree()

    # @thingworx.route('/Things/Keysight.Generic/Services/GetLocationTree', methods=['POST'])
    # def getLocationTree():
    #     return GetLocationTree()