from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"hasChanged":True,"success":True,"message":""}
def ChangePassword():
 return jsonify(data)