from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"success":True,"userDetails":{"lastName":"p","UserName":"dheerendra.prajapati@itcinfotech.com","Organization":"Asset Advisor Demo","manager":"undefined","infolinePassword":"keysight@123","PostalCode":"5600433","CustomerId":"2","City":"Bangalore","dashboardUserName":"dheerendra.prajapati@itcinfotech.com","JobTitle":"Tester","phoneNo":"080-1234555","AddressLine3":"","firstName":"Dheerendra","AddressLine2":"test","emailAddress":"dheerendra.prajapati@itcinfotech.com","AddressLine1":"345 wilson road","Department":"","mobilePhone":"","infolineUserName":"dheerendra.prajapati@itcinfotech.com","State":"Karnataka","Country":"India","dashboardPassword":"Qa2Server@123","CustomerName":"Asset Advisor Demo","Fax":""}}
def SetUserProfile():
 return jsonify(data)