from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"success":True,"tree":{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"text":"San Diego","leaf":True},{"text":"Seattle","leaf":True},{"text":"Richardson","leaf":True},{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"text":"A1","leaf":True},{"text":"B1","leaf":True}],"text":"Floor 1"},{"text":"Floor 2","leaf":True}],"text":"Bldg 1"},{"text":"Bldg 2","leaf":True}],"text":"Site D_A"},{"expanded":True,"children":[{"text":"Bldg 1","leaf":True},{"text":"Bldg 2","leaf":True}],"text":"Site D_B"}],"text":"Detroit"},{"text":"Morrisville","leaf":True}],"text":"US"},{"text":"Brazil","leaf":True}],"text":"Americas"},{"expanded":True,"children":[{"text":"UK","leaf":True},{"expanded":True,"children":[{"text":"Stuttgart","leaf":True}],"text":"Germany"},{"text":"France","leaf":True},{"text":"Italy","leaf":True},{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"text":"Pole A1","leaf":True},{"text":"Pole B1","leaf":True}],"text":"Floor 1"},{"text":"Floor 2","leaf":True}],"text":"Bldg 1"},{"text":"Bldg 2","leaf":True}],"text":"Site O_A"},{"text":"Site O_B","leaf":True}],"text":"Oulu"}],"text":"Finland"}],"text":"Europe"},{"expanded":True,"children":[{"expanded":True,"children":[{"text":"Tokyo","leaf":True}],"text":"Japan"},{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"expanded":True,"children":[{"text":"Pole A1","leaf":True},{"text":"Pole B1","leaf":True}],"text":"Bldg 1"},{"text":"Bldg 2","leaf":True}],"text":"Site C_A"},{"text":"Site C_B","leaf":True}],"text":"Chengdu"}],"text":"China"},{"expanded":True,"children":[{"text":"Penang","leaf":True}],"text":"Malaysia"}],"text":"Asia"}],"text":"Asset Advisor Demo"}]}}
def GetLocationTree():
 return jsonify(data)