from .FetchAssetDetailsValues import FetchAssetDetailsValues
from .EditAsset import EditAsset
from flask import request
def getEditAssetRoutes(thingworx):

    @thingworx.route('/Things/Keysight.Generic/Services/fetchAssetDetailsValues', methods=['POST'])
    def fetchAssetDetailsValues():
        return FetchAssetDetailsValues()

    @thingworx.route('/Things/Keysight.Asset/Services/EditAsset', methods=['POST'])
    def editAsset():
        return EditAsset(request)
