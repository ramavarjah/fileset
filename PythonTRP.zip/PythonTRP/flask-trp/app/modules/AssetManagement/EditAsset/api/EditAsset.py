from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)

from app.models import Asset, User
from app import db
from marshmallow import pprint
from sqlalchemy.exc import IntegrityError
from app.models import AssetSchema
import json

def __init__(self, **kwargs):
    super(Asset, self).__init__(**kwargs)

    
def EditAsset(request):
    print("Request is : " , request.json)
    if not request.json:
        return jsonify({'message': 'No input data provided '}), 400
    content = request.json["Input"]
    print("User ID",User.get_current_user().id)
    content["user_id"] = User.get_current_user().id
    schema = AssetSchema()
    assetData = schema.load(content)
    print("Asset Data",assetData)
    newAsset = assetData.data
    newAsset["user"] = User.get_current_user()
    a = Asset(**newAsset)
        
    db.session.add(a)
    try:
        db.session.commit()
        return jsonify({"success":True,"message":"Asset 10000026 has been edited successfully."})
    except:
        return json({"sucess": False})
        db.session.rollback()


# from flask import (
#     Blueprint,
#     flash,
#     redirect,
#     render_template,
#     url_for,
#     request,
#     jsonify,
#     Response
# )
# data = {"success":True,"message":"Asset 10000026 has been edited successfully."}
# def EditAsset():
#  return jsonify(data)