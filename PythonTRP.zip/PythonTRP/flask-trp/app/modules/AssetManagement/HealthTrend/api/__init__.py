from .GetHealthDataGrouped import GetHealthDataGrouped
from .GetWarnings import GetWarnings
from .GetErrors import GetErrors
from .GetHealthTrendData import GetHealthTrendData


def getHealthTrendRoutes(thingworx):
    @thingworx.route('/Things/Keysight.BaseListing/Services/GetHealthDataGrouped', methods=['POST'])
    def getHealthDataGrouped():
        return GetHealthDataGrouped()

    @thingworx.route('/Things/Keysight.AssetManagement/Services/GetWarnings', methods=['POST'])
    def getWarnings():
        return GetWarnings()

    @thingworx.route('/Things/Keysight.AssetManagement/Services/GetErrors', methods=['POST'])
    def getErrors():
        return GetErrors()

    @thingworx.route('/Things/Keysight.AmChart/Services/GetHealthTrendData', methods=['POST'])
    def getHealthTrendData():
        return GetHealthTrendData()