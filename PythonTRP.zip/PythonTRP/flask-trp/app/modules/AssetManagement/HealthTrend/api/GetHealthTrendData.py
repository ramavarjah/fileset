from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"EquipmentNo":"10000000001500","graphs":"PLUM_Voltage","metricName":"","data":[{"date":"2018-12-19T18:30:00Z","PLUM_Voltage":"120.48"},{"date":"2018-12-19T19:30:00Z","PLUM_Voltage":"120.82"},{"date":"2018-12-19T20:30:00Z","PLUM_Voltage":"121.06"},{"date":"2018-12-19T21:30:00Z","PLUM_Voltage":"121.01"},{"date":"2018-12-19T22:30:00Z","PLUM_Voltage":"120.63"},{"date":"2018-12-19T23:30:00Z","PLUM_Voltage":"120.58"},{"date":"2018-12-20T00:30:00Z","PLUM_Voltage":"120.97"},{"date":"2018-12-20T01:30:00Z","PLUM_Voltage":"120.70"},{"date":"2018-12-20T02:30:00Z","PLUM_Voltage":"120.91"},{"date":"2018-12-20T03:30:00Z","PLUM_Voltage":"121.15"},{"date":"2018-12-20T04:30:00Z","PLUM_Voltage":"120.79"},{"date":"2018-12-20T05:30:00Z","PLUM_Voltage":"120.63"},{"date":"2018-12-20T06:30:00Z","PLUM_Voltage":"121.29"},{"date":"2018-12-20T07:30:00Z","PLUM_Voltage":"120.64"},{"date":"2018-12-20T08:30:00Z","PLUM_Voltage":"120.82"},{"date":"2018-12-20T09:30:00Z","PLUM_Voltage":"120.96"},{"date":"2018-12-20T10:30:00Z","PLUM_Voltage":"121.04"},{"date":"2018-12-20T11:30:00Z","PLUM_Voltage":"120.92"},{"date":"2018-12-20T12:30:00Z","PLUM_Voltage":"120.88"},{"date":"2018-12-20T13:30:00Z","PLUM_Voltage":"NULL"},{"date":"2018-12-20T14:30:00Z","PLUM_Voltage":"NULL"},{"date":"2018-12-20T15:30:00Z","PLUM_Voltage":"NULL"},{"date":"2018-12-20T16:30:00Z","PLUM_Voltage":"NULL"},{"date":"2018-12-20T17:30:00Z","PLUM_Voltage":"NULL"}],"success":True,"DateFormat":"YYYY-MM-DD JJ","minPeriod":"hh","message":"Data fetched successfully.","Units":"volts"}
def GetHealthTrendData():
 return jsonify(data)