from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {"Errors":[],"success":True}
def GetErrors():
 return jsonify(data)