from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "data": [
    {
      "CategoryId": "2",
      "StartDate": "2019-01-06T18:30:00.000Z",
      "PropertyName": "Organization",
      "Active": True,
      "ChartId": "7",
      "value": "By Organization",
      "File": "",
      "EndDate": "2019-01-07T18:29:59.999Z"
    },
    {
      "CategoryId": "2",
      "StartDate": "2019-01-06T18:30:00.000Z",
      "PropertyName": "Location",
      "Active": False,
      "ChartId": "5",
      "value": "By Location",
      "File": "",
      "EndDate": "2019-01-07T18:29:59.999Z"
    },
    {
      "CategoryId": "2",
      "StartDate": "2019-01-06T18:30:00.000Z",
      "PropertyName": "ModelNo",
      "Active": False,
      "ChartId": "6",
      "value": "By Model Number",
      "File": "",
      "EndDate": "2019-01-07T18:29:59.999Z"
    },
    {
      "CategoryId": "2",
      "StartDate": "2019-01-06T18:30:00.000Z",
      "PropertyName": "EquipmentNo",
      "Active": False,
      "ChartId": "19",
      "value": "By Equipment Number",
      "File": "",
      "EndDate": "2019-01-07T18:29:59.999Z"
    },
    {
      "CategoryId": "2",
      "StartDate": "2019-01-06T18:30:00.000Z",
      "PropertyName": "AssetNo",
      "Active": False,
      "ChartId": "20",
      "value": "By Asset Number",
      "File": "",
      "EndDate": "2019-01-07T18:29:59.999Z"
    },
    {
      "CategoryId": "2",
      "StartDate": "2019-01-06T18:30:00.000Z",
      "PropertyName": "SerialNo",
      "Active": False,
      "ChartId": "8",
      "value": "By Serial Number",
      "File": "",
      "EndDate": "2019-01-07T18:29:59.999Z"
    }
  ]
}
def GetSubViewOptions(request):
    if request == None:
      return data
    return jsonify(data)