from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "data": [
    {
      "ModelNo": "R1605-80001",
      "Count": 10
    },
    {
      "ModelNo": "PLUM-1",
      "Count": 9
    },
    {
      "ModelNo": "MSOS804A",
      "Count": 6
    },
    {
      "ModelNo": "E7515B",
      "Count": 4
    },
    {
      "ModelNo": "",
      "Count": 3
    },
    {
      "ModelNo": "A3141B",
      "Count": 3
    },
    {
      "ModelNo": "12342",
      "Count": 2
    },
    {
      "ModelNo": "DSOS604A",
      "Count": 2
    },
    {
      "ModelNo": "N5232A",
      "Count": 2
    },
    {
      "ModelNo": "DELL",
      "Count": 1
    },
    {
      "ModelNo": "A98734",
      "Count": 1
    },
    {
      "ModelNo": "N34567A",
      "Count": 1
    },
    {
      "ModelNo": "GS-1000",
      "Count": 1
    },
    {
      "ModelNo": "3458A",
      "Count": 1
    },
    {
      "ModelNo": "Acme1234",
      "Count": 1
    },
    {
      "ModelNo": "U9320B",
      "Count": 1
    },
    {
      "ModelNo": "111111",
      "Count": 1
    },
    {
      "ModelNo": "Monitor",
      "Count": 1
    },
    {
      "ModelNo": "895687",
      "Count": 1
    },
    {
      "ModelNo": "PB1185WX",
      "Count": 1
    },
    {
      "ModelNo": "ALPHASTEP200",
      "Count": 1
    },
    {
      "ModelNo": "SMD-2000",
      "Count": 1
    },
    {
      "ModelNo": "3344444",
      "Count": 1
    },
    {
      "ModelNo": "44443",
      "Count": 1
    },
    {
      "ModelNo": "N9020A",
      "Count": 1
    },
    {
      "ModelNo": "NMN",
      "Count": 1
    },
    {
      "ModelNo": "4090u",
      "Count": 1
    },
    {
      "ModelNo": "4328A",
      "Count": 1
    },
    {
      "ModelNo": "10001977",
      "Count": 1
    },
    {
      "ModelNo": "5567",
      "Count": 1
    },
    {
      "ModelNo": "ZVA40",
      "Count": 1
    },
    {
      "ModelNo": "10001",
      "Count": 1
    },
    {
      "ModelNo": "N9000A",
      "Count": 1
    },
    {
      "ModelNo": "PLUM",
      "Count": 1
    },
    {
      "ModelNo": "WSRX",
      "Count": 1
    },
    {
      "ModelNo": "1234=Test",
      "Count": 1
    },
    {
      "ModelNo": "N5225A",
      "Count": 1
    },
    {
      "ModelNo": "8720ES",
      "Count": 1
    },
    {
      "ModelNo": "4500B",
      "Count": 1
    },
    {
      "ModelNo": "SMB100A",
      "Count": 1
    }
  ],
  "success": True
}
def GetAssetCountByModelNo():
    return jsonify(data)