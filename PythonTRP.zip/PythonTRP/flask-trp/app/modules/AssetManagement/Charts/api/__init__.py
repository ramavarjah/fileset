from .GetUtilizationViewData import GetUtilizationViewData
from .SetCategoryId import SetCategoryId
from .GetSubViewOptions import GetSubViewOptions
from .SetChartId import SetChartId
from .GetServiceDueDateData import GetServiceDueDateData
from .GetAssetHealthViewForOrganization import GetAssetHealthViewForOrganization
from .GetAssetCountByOrganization import GetAssetCountByOrganization
from .GetAssetCountByModelNo import GetAssetCountByModelNo
from .GetAssetCountByManufacturer import GetAssetCountByManufacturer
from .GetAssetCountByLocation import GetAssetCountByLocation
from .SetDates import SetDates
from .GetAssetHealthView import GetAssetHealthView
from .GetAssetHealthViewForLocation import GetAssetHealthViewForLocation
from .SetPreset import SetPreset


def getAssetChartsRoutes(app):
    @app.route('/Things/Keysight.AmChart/Services/GetUtilizationViewData', methods=['POST'])
    def getUtilizationViewData():
        return GetUtilizationViewData()

    @app.route('/Things/Keysight.AmchartListDT/Services/SetCategoryId', methods=['POST'])
    def setCategoryId():
        return SetCategoryId()

    @app.route('/Things/Keysight.AmchartListDT/Services/GetSubViewOptions', methods=['POST'])
    def getSubViewOptions():
        return GetSubViewOptions()

    @app.route('/Things/Keysight.AmChart/Services/GetAssetHealthViewForOrganization', methods=['POST'])
    def getAssetHealthViewForOrganization():
        return GetAssetHealthViewForOrganization()

    @app.route('/Things/Keysight.AmChart/Services/GetAssetCountByOrganization', methods=['POST'])
    def getAssetCountByOrganization():
        return GetAssetCountByOrganization()

    @app.route('/Things/Keysight.AmChart/Services/GetServiceDueDateData', methods=['POST'])
    def getServiceDueDateData():
        return GetServiceDueDateData()

    @app.route('/Things/Keysight.AmchartListDT/Services/SetChartId', methods=['POST'])
    def setChartId():
        return SetChartId()

    @app.route('/Things/Keysight.AmChart/Services/GetAssetCountByModelNo', methods=['POST'])
    def getAssetCountByModelNo():
        return GetAssetCountByModelNo()

    @app.route('/Things/Keysight.AmChart/Services/GetAssetCountByManufacturer', methods=['POST'])
    def getAssetCountByManufacturer():
        return GetAssetCountByManufacturer()

    @app.route('/Things/Keysight.AmChart/Services/GetAssetCountByLocation', methods=['POST'])
    def getAssetCountByLocation():
        return GetAssetCountByLocation()

    @app.route('/Things/Keysight.AmchartListDT/Services/SetDates', methods=['POST'])
    def setDates():
        return SetDates()

    @app.route('/Things/Keysight.AmChart/Services/GetAssetHealthViewForLocation', methods=['POST'])
    def getAssetHealthViewForLocation():
        return GetAssetHealthViewForLocation()

    @app.route('/Things/Keysight.AmChart/Services/GetAssetHealthView', methods=['POST'])
    def getAssetHealthView():
        return GetAssetHealthView()

    @app.route('/Things/Keysight.AmchartListDT/Services/SetPreset', methods=['POST'])
    def setPreset():
        return SetPreset()