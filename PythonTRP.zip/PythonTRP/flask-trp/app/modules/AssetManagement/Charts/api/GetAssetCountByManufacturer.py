from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "data": [
    {
      "Count": 55,
      "Manufacturer": "3CON Electronics AB"
    },
    {
      "Count": 5,
      "Manufacturer": "Keysight Technologies"
    },
    {
      "Count": 2,
      "Manufacturer": "Geico Electrico, S.A."
    },
    {
      "Count": 2,
      "Manufacturer": "3M Co."
    },
    {
      "Count": 1,
      "Manufacturer": "3D INSTRUMENTS INC"
    },
    {
      "Count": 1,
      "Manufacturer": "A Daigger and Co Inc"
    },
    {
      "Count": 1,
      "Manufacturer": "A and D Co., Ltd."
    },
    {
      "Count": 1,
      "Manufacturer": "Dell Computer Corp."
    },
    {
      "Count": 1,
      "Manufacturer": "Keysight Technologies Inc."
    },
    {
      "Count": 1,
      "Manufacturer": "Agilent Technologies Inc"
    },
    {
      "Count": 1,
      "Manufacturer": "Boonton Electronics Corp"
    },
    {
      "Count": 1,
      "Manufacturer": "Rohde & Schwarz, Inc."
    }
  ],
  "success": True
}
def GetAssetCountByManufacturer():
    return jsonify(data)