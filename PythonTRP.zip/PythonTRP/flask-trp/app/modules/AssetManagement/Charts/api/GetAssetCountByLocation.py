from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "data": [
    {
      "breadcrumb": "Asset Advisor Demo",
      "count": 72,
      "location": "Asset Advisor Demo",
      "CustomerId": "2",
      "subnodes": [
        {
          "breadcrumb": "Asset Advisor Demo > Americas",
          "count": 13,
          "location": "Americas",
          "CustomerId": "2",
          "subnodes": [
            {
              "breadcrumb": "Asset Advisor Demo > Americas > US",
              "count": 6,
              "location": "US",
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Americas > US > San Diego",
                  "count": 0,
                  "location": "San Diego",
                  "CustomerId": "2",
                  "subnodes": []
                },
                {
                  "breadcrumb": "Asset Advisor Demo > Americas > US > Seattle",
                  "count": 0,
                  "location": "Seattle",
                  "CustomerId": "2",
                  "subnodes": []
                },
                {
                  "breadcrumb": "Asset Advisor Demo > Americas > US > Richardson",
                  "count": 0,
                  "location": "Richardson",
                  "CustomerId": "2",
                  "subnodes": []
                },
                {
                  "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit",
                  "count": 0,
                  "location": "Detroit",
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_A",
                      "count": 0,
                      "location": "Site D_A",
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1",
                          "count": 0,
                          "location": "Bldg 1",
                          "CustomerId": "2",
                          "subnodes": [
                            {
                              "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 1",
                              "count": 0,
                              "location": "Floor 1",
                              "CustomerId": "2",
                              "subnodes": [
                                {
                                  "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 1 > A1",
                                  "count": 0,
                                  "location": "A1",
                                  "CustomerId": "2",
                                  "subnodes": []
                                },
                                {
                                  "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 1 > B1",
                                  "count": 0,
                                  "location": "B1",
                                  "CustomerId": "2",
                                  "subnodes": []
                                }
                              ]
                            },
                            {
                              "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 2",
                              "count": 0,
                              "location": "Floor 2",
                              "CustomerId": "2",
                              "subnodes": []
                            }
                          ]
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 2",
                          "count": 0,
                          "location": "Bldg 2",
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    },
                    {
                      "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_B",
                      "count": 0,
                      "location": "Site D_B",
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_B > Bldg 1",
                          "count": 0,
                          "location": "Bldg 1",
                          "CustomerId": "2",
                          "subnodes": []
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Americas > US > Detroit > Site D_B > Bldg 2",
                          "count": 0,
                          "location": "Bldg 2",
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    }
                  ]
                },
                {
                  "breadcrumb": "Asset Advisor Demo > Americas > US > Morrisville",
                  "count": 0,
                  "location": "Morrisville",
                  "CustomerId": "2",
                  "subnodes": []
                }
              ]
            },
            {
              "breadcrumb": "Asset Advisor Demo > Americas > Brazil",
              "count": 0,
              "location": "Brazil",
              "CustomerId": "2",
              "subnodes": []
            }
          ]
        },
        {
          "breadcrumb": "Asset Advisor Demo > Europe",
          "count": 3,
          "location": "Europe",
          "CustomerId": "2",
          "subnodes": [
            {
              "breadcrumb": "Asset Advisor Demo > Europe > UK",
              "count": 3,
              "location": "UK",
              "CustomerId": "2",
              "subnodes": []
            },
            {
              "breadcrumb": "Asset Advisor Demo > Europe > Germany",
              "count": 0,
              "location": "Germany",
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Europe > Germany > Stuttgart",
                  "count": 0,
                  "location": "Stuttgart",
                  "CustomerId": "2",
                  "subnodes": []
                }
              ]
            },
            {
              "breadcrumb": "Asset Advisor Demo > Europe > France",
              "count": 0,
              "location": "France",
              "CustomerId": "2",
              "subnodes": []
            },
            {
              "breadcrumb": "Asset Advisor Demo > Europe > Italy",
              "count": 0,
              "location": "Italy",
              "CustomerId": "2",
              "subnodes": []
            },
            {
              "breadcrumb": "Asset Advisor Demo > Europe > Finland",
              "count": 0,
              "location": "Finland",
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu",
                  "count": 0,
                  "location": "Oulu",
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A",
                      "count": 0,
                      "location": "Site O_A",
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1",
                          "count": 0,
                          "location": "Bldg 1",
                          "CustomerId": "2",
                          "subnodes": [
                            {
                              "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 1",
                              "count": 0,
                              "location": "Floor 1",
                              "CustomerId": "2",
                              "subnodes": [
                                {
                                  "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 1 > Pole A1",
                                  "count": 0,
                                  "location": "Pole A1",
                                  "CustomerId": "2",
                                  "subnodes": []
                                },
                                {
                                  "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 1 > Pole B1",
                                  "count": 0,
                                  "location": "Pole B1",
                                  "CustomerId": "2",
                                  "subnodes": []
                                }
                              ]
                            },
                            {
                              "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 2",
                              "count": 0,
                              "location": "Floor 2",
                              "CustomerId": "2",
                              "subnodes": []
                            }
                          ]
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 2",
                          "count": 0,
                          "location": "Bldg 2",
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    },
                    {
                      "breadcrumb": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_B",
                      "count": 0,
                      "location": "Site O_B",
                      "CustomerId": "2",
                      "subnodes": []
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          "breadcrumb": "Asset Advisor Demo > Asia",
          "count": 0,
          "location": "Asia",
          "CustomerId": "2",
          "subnodes": [
            {
              "breadcrumb": "Asset Advisor Demo > Asia > Japan",
              "count": 0,
              "location": "Japan",
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Asia > Japan > Tokyo",
                  "count": 0,
                  "location": "Tokyo",
                  "CustomerId": "2",
                  "subnodes": []
                }
              ]
            },
            {
              "breadcrumb": "Asset Advisor Demo > Asia > China",
              "count": 0,
              "location": "China",
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Asia > China > Chengdu",
                  "count": 0,
                  "location": "Chengdu",
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A",
                      "count": 0,
                      "location": "Site C_A",
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 1",
                          "count": 0,
                          "location": "Bldg 1",
                          "CustomerId": "2",
                          "subnodes": [
                            {
                              "breadcrumb": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 1 > Pole A1",
                              "count": 0,
                              "location": "Pole A1",
                              "CustomerId": "2",
                              "subnodes": []
                            },
                            {
                              "breadcrumb": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 1 > Pole B1",
                              "count": 0,
                              "location": "Pole B1",
                              "CustomerId": "2",
                              "subnodes": []
                            }
                          ]
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 2",
                          "count": 0,
                          "location": "Bldg 2",
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    },
                    {
                      "breadcrumb": "Asset Advisor Demo > Asia > China > Chengdu > Site C_B",
                      "count": 0,
                      "location": "Site C_B",
                      "CustomerId": "2",
                      "subnodes": []
                    }
                  ]
                }
              ]
            },
            {
              "breadcrumb": "Asset Advisor Demo > Asia > Malaysia",
              "count": 0,
              "location": "Malaysia",
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Asia > Malaysia > Penang",
                  "count": 0,
                  "location": "Penang",
                  "CustomerId": "2",
                  "subnodes": []
                }
              ]
            }
          ]
        }
      ]
    }
  ],
  "success": True
}
def GetAssetCountByLocation():
    return jsonify(data)