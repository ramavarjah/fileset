from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "data": [
    {
      "RED": 1,
      "percentageYELLOW": 0,
      "propertyName": "M23456",
      "YELLOW": 0,
      "percentageRED": 14.285714285714285,
      "percentageGREEN": 85.71428571428571,
      "GREEN": 6,
      "AssetName": "2_10000000001500"
    },
    {
      "RED": 0,
      "percentageYELLOW": 0,
      "propertyName": "1234A123",
      "YELLOW": 0,
      "percentageRED": 0,
      "percentageGREEN": 100,
      "GREEN": 4,
      "AssetName": "2_10000023"
    }
  ]
}
def GetAssetHealthView():
 return jsonify(data)