from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "graphName": "Utilization",
  "graphs": [
    "Asset Advisor Demo",
    "Asset Advisor Demo > D",
    "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development"
  ],
  "data": [
    {
      "date": "2019-01-06T18:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-06T19:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-06T20:30:00Z",
      "Asset Advisor Demo": "1.76",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-06T21:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-06T22:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-06T23:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T00:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T01:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T02:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T03:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T04:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T05:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T06:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T07:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T08:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T09:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T10:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T11:30:00Z",
      "Asset Advisor Demo": "1.81",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T12:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T13:30:00Z",
      "Asset Advisor Demo": "1.51",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T14:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T15:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T16:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    },
    {
      "date": "2019-01-07T17:30:00Z",
      "Asset Advisor Demo": "1.82",
      "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development": "0.00",
      "Asset Advisor Demo > D": "0.00"
    }
  ],
  "DateFormat": "YYYY-MM-DD JJ",
  "minPeriod": "hh",
  "message": ""
}
def GetUtilizationViewData():
    return jsonify(data)




