from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "subnodes": [
    {
      "RED": 1,
      "percentageYELLOW": 0,
      "propertyName": "Asset Advisor Demo",
      "YELLOW": 0,
      "percentageRED": 9.090909090909092,
      "percentageGREEN": 90.9090909090909,
      "subnodes": [
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > Americas",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Americas > US",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Americas > US > San Diego",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                },
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Americas > US > Seattle",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                },
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Americas > US > Richardson",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                },
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Americas > US > Detroit",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_A",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [
                            {
                              "RED": 0,
                              "percentageYELLOW": 0,
                              "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 1",
                              "YELLOW": 0,
                              "percentageRED": 0,
                              "percentageGREEN": 0,
                              "subnodes": [
                                {
                                  "RED": 0,
                                  "percentageYELLOW": 0,
                                  "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 1 > A1",
                                  "YELLOW": 0,
                                  "percentageRED": 0,
                                  "percentageGREEN": 0,
                                  "subnodes": [],
                                  "GREEN": 0
                                },
                                {
                                  "RED": 0,
                                  "percentageYELLOW": 0,
                                  "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 1 > B1",
                                  "YELLOW": 0,
                                  "percentageRED": 0,
                                  "percentageGREEN": 0,
                                  "subnodes": [],
                                  "GREEN": 0
                                }
                              ],
                              "GREEN": 0
                            },
                            {
                              "RED": 0,
                              "percentageYELLOW": 0,
                              "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 1 > Floor 2",
                              "YELLOW": 0,
                              "percentageRED": 0,
                              "percentageGREEN": 0,
                              "subnodes": [],
                              "GREEN": 0
                            }
                          ],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_A > Bldg 2",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    },
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_B",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_B > Bldg 1",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Americas > US > Detroit > Site D_B > Bldg 2",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                },
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Americas > US > Morrisville",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Americas > Brazil",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            }
          ],
          "GREEN": 0
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > Europe",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Europe > UK",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Europe > Germany",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Europe > Germany > Stuttgart",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Europe > France",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Europe > Italy",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Europe > Finland",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [
                            {
                              "RED": 0,
                              "percentageYELLOW": 0,
                              "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 1",
                              "YELLOW": 0,
                              "percentageRED": 0,
                              "percentageGREEN": 0,
                              "subnodes": [
                                {
                                  "RED": 0,
                                  "percentageYELLOW": 0,
                                  "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 1 > Pole A1",
                                  "YELLOW": 0,
                                  "percentageRED": 0,
                                  "percentageGREEN": 0,
                                  "subnodes": [],
                                  "GREEN": 0
                                },
                                {
                                  "RED": 0,
                                  "percentageYELLOW": 0,
                                  "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 1 > Pole B1",
                                  "YELLOW": 0,
                                  "percentageRED": 0,
                                  "percentageGREEN": 0,
                                  "subnodes": [],
                                  "GREEN": 0
                                }
                              ],
                              "GREEN": 0
                            },
                            {
                              "RED": 0,
                              "percentageYELLOW": 0,
                              "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 1 > Floor 2",
                              "YELLOW": 0,
                              "percentageRED": 0,
                              "percentageGREEN": 0,
                              "subnodes": [],
                              "GREEN": 0
                            }
                          ],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_A > Bldg 2",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    },
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Europe > Finland > Oulu > Site O_B",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            }
          ],
          "GREEN": 0
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > Asia",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Asia > Japan",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Asia > Japan > Tokyo",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Asia > China",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Asia > China > Chengdu",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 1",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [
                            {
                              "RED": 0,
                              "percentageYELLOW": 0,
                              "propertyName": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 1 > Pole A1",
                              "YELLOW": 0,
                              "percentageRED": 0,
                              "percentageGREEN": 0,
                              "subnodes": [],
                              "GREEN": 0
                            },
                            {
                              "RED": 0,
                              "percentageYELLOW": 0,
                              "propertyName": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 1 > Pole B1",
                              "YELLOW": 0,
                              "percentageRED": 0,
                              "percentageGREEN": 0,
                              "subnodes": [],
                              "GREEN": 0
                            }
                          ],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Asia > China > Chengdu > Site C_A > Bldg 2",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    },
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Asia > China > Chengdu > Site C_B",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Asia > Malaysia",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Asia > Malaysia > Penang",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            }
          ],
          "GREEN": 0
        }
      ],
      "GREEN": 10
    }
  ]
}
def GetAssetHealthViewForLocation():
 return jsonify(data)