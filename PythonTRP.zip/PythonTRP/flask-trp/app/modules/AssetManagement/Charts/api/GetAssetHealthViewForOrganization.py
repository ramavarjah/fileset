from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "subnodes": [
    {
      "RED": 111,
      "percentageYELLOW": 1.5151515151515151,
      "propertyName": "Asset Advisor Demo",
      "YELLOW": 20,
      "percentageRED": 8.409090909090908,
      "percentageGREEN": 90.07575757575758,
      "subnodes": [
        {
          "RED": 4,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > D",
          "YELLOW": 0,
          "percentageRED": 16.666666666666664,
          "percentageGREEN": 83.33333333333334,
          "subnodes": [],
          "GREEN": 20
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > hello",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [],
          "GREEN": 0
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > EMS",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > EMS > EMS1",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > EMS > EMS1 > Program 1",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > EMS > EMS1 > Program 1 > Dept 1",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > EMS > EMS1 > Program 1 > Dept 1 > Team A",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                },
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > EMS > EMS1 > Program 2",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > EMS > EMS1 > Program 2 > Dept 1",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > EMS > EMS2",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            }
          ],
          "GREEN": 0
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > Automotive Group",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 1",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 2",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 1",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                },
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > Design",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > Design > Team A",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > Design > Team B",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    },
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > NPI",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            }
          ],
          "GREEN": 0
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > Manage Group",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [],
          "GREEN": 0
        },
        {
          "RED": 2,
          "percentageYELLOW": 16.666666666666664,
          "propertyName": "Asset Advisor Demo > Wireless Group",
          "YELLOW": 2,
          "percentageRED": 16.666666666666664,
          "percentageGREEN": 66.66666666666666,
          "subnodes": [
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 2",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 3",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            },
            {
              "RED": 2,
              "percentageYELLOW": 16.666666666666664,
              "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 1",
              "YELLOW": 2,
              "percentageRED": 16.666666666666664,
              "percentageGREEN": 66.66666666666666,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 1",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [],
                  "GREEN": 0
                },
                {
                  "RED": 2,
                  "percentageYELLOW": 16.666666666666664,
                  "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2",
                  "YELLOW": 2,
                  "percentageRED": 16.666666666666664,
                  "percentageGREEN": 66.66666666666666,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > MFG",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > MFG > Team A",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > MFG > Team B",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    },
                    {
                      "RED": 2,
                      "percentageYELLOW": 16.666666666666664,
                      "propertyName": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development",
                      "YELLOW": 2,
                      "percentageRED": 16.666666666666664,
                      "percentageGREEN": 66.66666666666666,
                      "subnodes": [],
                      "GREEN": 8
                    }
                  ],
                  "GREEN": 8
                }
              ],
              "GREEN": 8
            }
          ],
          "GREEN": 8
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > Satellite Group",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI > Team A",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI > Team B",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        },
                        {
                          "RED": 0,
                          "percentageYELLOW": 0,
                          "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI > Team C",
                          "YELLOW": 0,
                          "percentageRED": 0,
                          "percentageGREEN": 0,
                          "subnodes": [],
                          "GREEN": 0
                        }
                      ],
                      "GREEN": 0
                    },
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > Support",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                },
                {
                  "RED": 0,
                  "percentageYELLOW": 0,
                  "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 2",
                  "YELLOW": 0,
                  "percentageRED": 0,
                  "percentageGREEN": 0,
                  "subnodes": [
                    {
                      "RED": 0,
                      "percentageYELLOW": 0,
                      "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 2 > NPB",
                      "YELLOW": 0,
                      "percentageRED": 0,
                      "percentageGREEN": 0,
                      "subnodes": [],
                      "GREEN": 0
                    }
                  ],
                  "GREEN": 0
                }
              ],
              "GREEN": 0
            },
            {
              "RED": 0,
              "percentageYELLOW": 0,
              "propertyName": "Asset Advisor Demo > Satellite Group > Satellite 1",
              "YELLOW": 0,
              "percentageRED": 0,
              "percentageGREEN": 0,
              "subnodes": [],
              "GREEN": 0
            }
          ],
          "GREEN": 0
        },
        {
          "RED": 0,
          "percentageYELLOW": 0,
          "propertyName": "Asset Advisor Demo > Robotic Group",
          "YELLOW": 0,
          "percentageRED": 0,
          "percentageGREEN": 0,
          "subnodes": [],
          "GREEN": 0
        }
      ],
      "GREEN": 1189
    }
  ]
}
def GetAssetHealthViewForOrganization():
    return jsonify(data)




