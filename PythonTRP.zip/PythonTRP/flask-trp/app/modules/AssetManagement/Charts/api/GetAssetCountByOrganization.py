from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
data = {
  "data": [
    {
      "breadcrumb": "Asset Advisor Demo",
      "OU": "Asset Advisor Demo",
      "count": 72,
      "CustomerId": "2",
      "subnodes": [
        {
          "breadcrumb": "Asset Advisor Demo > D",
          "OU": "D",
          "count": 7,
          "CustomerId": "2",
          "subnodes": []
        },
        {
          "breadcrumb": "Asset Advisor Demo > Wireless Group",
          "OU": "Wireless Group",
          "count": 3,
          "CustomerId": "2",
          "subnodes": [
            {
              "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 1",
              "OU": "Wireless 1",
              "count": 3,
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2",
                  "OU": "Program 2",
                  "count": 3,
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > Development",
                      "OU": "Development",
                      "count": 3,
                      "CustomerId": "2",
                      "subnodes": []
                    },
                    {
                      "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > MFG",
                      "OU": "MFG",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > MFG > Team A",
                          "OU": "Team A",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 2 > MFG > Team B",
                          "OU": "Team B",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    }
                  ]
                },
                {
                  "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 1 > Program 1",
                  "OU": "Program 1",
                  "count": 0,
                  "CustomerId": "2",
                  "subnodes": []
                }
              ]
            },
            {
              "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 2",
              "OU": "Wireless 2",
              "count": 0,
              "CustomerId": "2",
              "subnodes": []
            },
            {
              "breadcrumb": "Asset Advisor Demo > Wireless Group > Wireless 3",
              "OU": "Wireless 3",
              "count": 0,
              "CustomerId": "2",
              "subnodes": []
            }
          ]
        },
        {
          "breadcrumb": "Asset Advisor Demo > hello",
          "OU": "hello",
          "count": 0,
          "CustomerId": "2",
          "subnodes": []
        },
        {
          "breadcrumb": "Asset Advisor Demo > EMS",
          "OU": "EMS",
          "count": 0,
          "CustomerId": "2",
          "subnodes": [
            {
              "breadcrumb": "Asset Advisor Demo > EMS > EMS1",
              "OU": "EMS1",
              "count": 0,
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > EMS > EMS1 > Program 1",
                  "OU": "Program 1",
                  "count": 0,
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > EMS > EMS1 > Program 1 > Dept 1",
                      "OU": "Dept 1",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > EMS > EMS1 > Program 1 > Dept 1 > Team A",
                          "OU": "Team A",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    }
                  ]
                },
                {
                  "breadcrumb": "Asset Advisor Demo > EMS > EMS1 > Program 2",
                  "OU": "Program 2",
                  "count": 0,
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > EMS > EMS1 > Program 2 > Dept 1",
                      "OU": "Dept 1",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": []
                    }
                  ]
                }
              ]
            },
            {
              "breadcrumb": "Asset Advisor Demo > EMS > EMS2",
              "OU": "EMS2",
              "count": 0,
              "CustomerId": "2",
              "subnodes": []
            }
          ]
        },
        {
          "breadcrumb": "Asset Advisor Demo > Automotive Group",
          "OU": "Automotive Group",
          "count": 0,
          "CustomerId": "2",
          "subnodes": [
            {
              "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 1",
              "OU": "Automotive 1",
              "count": 0,
              "CustomerId": "2",
              "subnodes": []
            },
            {
              "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 2",
              "OU": "Automotive 2",
              "count": 0,
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 1",
                  "OU": "Program 1",
                  "count": 0,
                  "CustomerId": "2",
                  "subnodes": []
                },
                {
                  "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2",
                  "OU": "Program 2",
                  "count": 0,
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > Design",
                      "OU": "Design",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > Design > Team A",
                          "OU": "Team A",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > Design > Team B",
                          "OU": "Team B",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    },
                    {
                      "breadcrumb": "Asset Advisor Demo > Automotive Group > Automotive 2 > Program 2 > NPI",
                      "OU": "NPI",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": []
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          "breadcrumb": "Asset Advisor Demo > Manage Group",
          "OU": "Manage Group",
          "count": 0,
          "CustomerId": "2",
          "subnodes": []
        },
        {
          "breadcrumb": "Asset Advisor Demo > Satellite Group",
          "OU": "Satellite Group",
          "count": 0,
          "CustomerId": "2",
          "subnodes": [
            {
              "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2",
              "OU": "Satellite 2",
              "count": 0,
              "CustomerId": "2",
              "subnodes": [
                {
                  "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1",
                  "OU": "Program 1",
                  "count": 0,
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI",
                      "OU": "NPI",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": [
                        {
                          "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI > Team A",
                          "OU": "Team A",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI > Team B",
                          "OU": "Team B",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        },
                        {
                          "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > NPI > Team C",
                          "OU": "Team C",
                          "count": 0,
                          "CustomerId": "2",
                          "subnodes": []
                        }
                      ]
                    },
                    {
                      "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 1 > Support",
                      "OU": "Support",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": []
                    }
                  ]
                },
                {
                  "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 2",
                  "OU": "Program 2",
                  "count": 0,
                  "CustomerId": "2",
                  "subnodes": [
                    {
                      "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 2 > Program 2 > NPB",
                      "OU": "NPB",
                      "count": 0,
                      "CustomerId": "2",
                      "subnodes": []
                    }
                  ]
                }
              ]
            },
            {
              "breadcrumb": "Asset Advisor Demo > Satellite Group > Satellite 1",
              "OU": "Satellite 1",
              "count": 0,
              "CustomerId": "2",
              "subnodes": []
            }
          ]
        },
        {
          "breadcrumb": "Asset Advisor Demo > Robotic Group",
          "OU": "Robotic Group",
          "count": 0,
          "CustomerId": "2",
          "subnodes": []
        }
      ]
    }
  ],
  "success": True
}
def GetAssetCountByOrganization():
    return jsonify(data)