from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app import db
from app.models import User, Tab
from flask_login import current_user

def ReorderTabs(request):
    
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400
    content=request.json
    if not content['TabList']:
        return jsonify({'message': 'No input data provided'}), 400

    items = content['TabList']
    utabs = Tab.get_user_tabs()
    for utab in utabs:
        for item in items:
            print(item['TabId'])
            if utab.TabId == item['TabId']:       # need to change after changing the PK 
                utab.TabOrder = items.index(item)

    try:
        db.session.commit()
    except:
        return jsonify({"success":False}), 400
    else:
        return jsonify({"success":True})
