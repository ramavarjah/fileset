from .GetDropDownData import getDropDownData
from .GetAllApiResult import getAllApiResult
from .GetNotificationCount import getNotificationCount
from .GetPermissionBasedColumns import getPermissionBasedColumns
from .InitializeApplication import IntializeApplication
from .SetColumnSort import SetColumnSort
from .SetColumnOrder import SetColumnOrder
from .ClearFilters import ClearFilters
from .CreateTemplate import CreateTemplate
from .SetPinnedColumns import SetPinnedColumns
from .SetColumnWidth import SetColumnWidth
from .UnhideColumn import UnhideColumn
from .HideColumn import HideColumn

from flask import request
from .GetUserDetails import GetUserDetails

from .RenameTab import RenameTab
from .DeleteTab import DeleteTab
from .ReorderTabs import ReorderTabs


def getAssetBaseListingRoutes(thingworx):
    @thingworx.route('/Things/Keysight.BaseListing/Services/InitializeApplication', methods=['POST'])
    def Intializeapplication():
        return IntializeApplication()

    @thingworx.route('/Things/Keysight.BaseListing/Services/ClearFilters', methods=['POST'])
    def Clearfilters():
        return ClearFilters(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetDropDownData', methods=['POST'])
    def getdropdowndata():
        return getDropDownData()

    @thingworx.route('/Things/Keysight.AssetManagement/Services/GetPermissionBasedColumns', methods=['POST'])
    def getpermissionBasedColumns():
        return getPermissionBasedColumns()

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetNotificationCount', methods=['POST'])
    def getnotificationcount():
        return getNotificationCount()

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetColumnSort', methods=['POST'])
    def Setcolumnsort():
        return SetColumnSort(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetColumnOrder', methods=['POST'])
    def SetColumnorder():
        return SetColumnOrder(request)

    @thingworx.route('/Things/Keysight.Generic/Services/GetAllApiResult', methods=['POST'])
    def getallapiresult():
        return getAllApiResult()

    @thingworx.route('/Things/Keysight.User/Services/GetUserDetails', methods=['POST'])
    def getUserDetails():
        return GetUserDetails()

    @thingworx.route('/Things/Keysight.BaseListing/Services/GetFilters', methods=['POST'])
    def getFilters():
        return GetFilters(request)

    @thingworx.route('/Things/Keysight.AssetTemplate/Services/CreateTemplate', methods=['POST'])
    def createTemplate():
        return CreateTemplate(request)
    @thingworx.route('/Things/Keysight.BaseListing/Services/SetPinnedColumns', methods=['POST'])
    def SetPinnedcolumns():
        return SetPinnedColumns(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/SetColumnWidth', methods=['POST'])
    def SetColumnwidth():
        return SetColumnWidth(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/UnhideColumn', methods=['POST'])
    def Unhidecolumn():
        return UnhideColumn(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/RenameTab', methods=['POST'])
    def renameTab():
        return RenameTab(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/DeleteTab', methods=['POST'])
    def deleteTab():
        return DeleteTab(request)

    @thingworx.route('/Things/Keysight.BaseListing/Services/ReorderTabs', methods=['POST'])
    def reorderTabs():
        return ReorderTabs(request)

    # @thingworx.route('/Things/Keysight.BaseListing/Services/GetFilters', methods=['POST'])
    # def getFilters():
    #     return GetFilters(request)
    #     /Things/Keysight.BaseListing/Services/ReorderTabs

    @thingworx.route('/Things/Keysight.BaseListing/Services/HideColumn', methods=['POST'])
    def Hidecolumn():
        return HideColumn(request)
