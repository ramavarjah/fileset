from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app import db
from app.models import User, Tab
from flask_login import current_user

def DeleteTab(request):
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400
    content=request.json
    if not content['TabId']:
        return jsonify({'message': 'No TabId data provided'}), 400
    # tabName = content['Name']
    # tabName=content['Name']
    tId=num(content['TabId'])
    print(content['TabId'])
    currUser=User.get_current_user()
    shiftRequired=False
    if num(currUser.CurrentTabId) == tId:
        shiftRequired=True # NEED TO SHIFT ACTIVE TAB

    currentTab = Tab.query.filter_by(TabId = content['TabId'], User_id = currUser.id).first()
    db.session.delete(currentTab)

    if shiftRequired:
        nextTab=Tab.get_user_tabs().first()
        currUser.CurrentTabId=nextTab.TabId
    try:
        db.session.commit()
    except:
        return jsonify({"success":False}), 400
    else:
        return jsonify({"success":True})
def num(s):
    try:
        return int(s)
    except ValueError:
        return float(s)
