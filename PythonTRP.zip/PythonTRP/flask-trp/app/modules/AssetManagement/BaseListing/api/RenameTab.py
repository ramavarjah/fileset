from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app import db
from app.models import User, Tab
from flask_login import current_user

def RenameTab(request):
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400
    content=request.json
    if not content['Name']:
        return jsonify({'message': 'No input data provided'}), 400

    tabName=content['Name']
    # tId=content['TabId']
    # print(content['TabId'])
    
    currentTab = Tab.query.filter_by(TabId = content['TabId'], User_id = User.get_current_user().id).first()
    

    # from app.models import TabSchema
    # tabSchema=TabSchema()
    # tabDetails=tabSchema.dump(currentTab).data
    # print(tabDetails)
    #return jsonify({"success":True})
    currentTab.TabName = tabName
    try:
        db.session.commit()
    except:
        return jsonify({"success":False}), 400
    else:
        return jsonify({"success":True})
