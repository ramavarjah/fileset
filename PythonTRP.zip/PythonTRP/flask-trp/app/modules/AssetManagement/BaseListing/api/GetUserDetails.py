from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify
)

from app.models import  User
from flask_login import current_user
from marshmallow import pprint
from app import FlaskMarshmallow

ma = FlaskMarshmallow()


class UserSchema(ma.ModelSchema):
    class Meta:
        model = User

def GetUserDetails(request):
    print(current_user.get_id())
    userdetails = User.query.filter_by(id=current_user.get_id()).first()
    schema = UserSchema()
    #pprint(schema.dump(userdetails).data)
    user_details= schema.dump(userdetails).data
    user_details['preferences'] =  {"NotificationAssetGroups":["Org : ITC > Division 3","Loc : ITC"],"AssetHealthStatus":"Weekly","ServiceDueAlert":"Weekly","EndOfWarrantyDaysPrior":30,"ProductSafetyFirmwareAlert":"Weekly","ServiceRequestAcknowledge":False,"GroupAlerts":False,"assetHealthCheckbox":"False","OutofTolerance":"Weekly","Name":"1-Admin","ServiceRequestAcknowledgeAlert":"Weekly","ServiceDueAlertDaysPrior":30,"Language":"The Kings Speech","EndofWarrantySupport":"Weekly","CalibrationDueAlertDaysPrior":30,"ServiceOrderAlert":"Weekly","DND":False,"OOTEvents":False}
    if request == None:
        return user_details
    return jsonify(user_details)