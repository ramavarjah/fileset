from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify
)
def getNotificationCount():
    return jsonify(  {
  "success": True,
  "IssueLogNotificationCount": 6,
  "LoanPoolNotificationCount": 27,
  "ServiceRequestNotificationCount": 0,
  "OOTNotificationCount": 2
}  )
