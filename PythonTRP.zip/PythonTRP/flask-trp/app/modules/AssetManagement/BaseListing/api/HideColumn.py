from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify
)
from app.models import Tab
from app import db
import ast
data = {"success": True}


def HideColumn(request):
    """
    Author: Ayush Jain
    Description: checks the columns to be hidden in request payload and set the same.
    :type request: json
    :param request:getting the request payload from client.

    :raises: exception if no i/p recieved from request payload/ the queried object returns None type or data cant be updated in the db.

    :rtype: json
    """
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400
    content = request.json
    if not content:
        return jsonify({'message': 'No input data provided'}), 400

    tab = Tab.get_active_tab()
    if tab == None:
        return jsonify({'message': 'The object is None type,possible reason may be TabId doesn\'t match'}), 400
    tempHiddenColumns = tab.HiddenColumns
    currentHiddenColumns = ast.literal_eval(tempHiddenColumns)
    print(currentHiddenColumns)
    print(type(currentHiddenColumns))
    print(content['HiddenColumn'][0])

    newhiddencol = content['HiddenColumn']
    for content in newhiddencol:
        if content not in currentHiddenColumns:
            currentHiddenColumns.append(content)
    print(str(newhiddencol))

    tab.HiddenColumns = str(currentHiddenColumns)

    
    from sqlalchemy.exc import IntegrityError
    try:
        db.session.commit()
        print("succesfully saved Hidden Columns")
    except IntegrityError:
        print("saving Hidden Columns failed")
        db.session.rollback()

    return jsonify(data)
