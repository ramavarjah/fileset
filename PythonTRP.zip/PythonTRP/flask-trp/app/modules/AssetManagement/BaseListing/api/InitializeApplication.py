from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify
)
from app.models import Asset
from app.modules.AssetManagement.Common.api import GetCompleteGridData

from app.modules.AssetManagement.Common.api import GetGridDataModel
from app.modules.AssetManagement.Charts.api import GetSubViewOptions
from app.modules.AssetManagement.BaseListing.api.GetUserDetails import GetUserDetails
from app.modules.AssetManagement.Common.api import GetUserTabs
# from app.modules.AssetManagement.Common.api import SetActiveTab

def IntializeApplication():
    returnDict = {} 
    returnDict['completeGridData'] = GetCompleteGridData(None)
    returnDict['gridDataModel'] = GetGridDataModel(None)['data']
    returnDict['subViewOptions'] = GetSubViewOptions(None)['data']

    returnDict['success']=True
    returnDict['userDetails']=GetUserDetails(None)
    returnDict['userTabs'] = GetUserTabs(None)


    returnDict['viewNames'] = [{"CategoryId":"3","Active":False,"Textbox":True,"SubCategory":True,"ViewName":"Utilization vs Time","NoOfWorkingHours":8,"Date":True},{"CategoryId":"2","Active":False,"Textbox":False,"SubCategory":True,"ViewName":"Health","Date":True},{"Active":False,"Textbox":False,"SubCategory":True,"Date":True},{"CategoryId":"1","Active":True,"Textbox":False,"SubCategory":True,"ViewName":"Asset Count","Date":False},{"CategoryId":"4","Active":False,"Textbox":False,"SubCategory":False,"ViewName":"Service Due","Date":True}]
    return jsonify(returnDict)