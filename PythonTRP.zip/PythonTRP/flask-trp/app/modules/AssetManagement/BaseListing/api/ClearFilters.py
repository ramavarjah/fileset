from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from app.models import Tab
from app import db
data = {"success":True}

def ClearFilters(request):
    """
    Author: Ayush Jain
    Description: clear the  filter for the current tab.
    :type request: json
    :param request:getting the request payload from client.

    :raises: exception if no i/p recieved from request payload/ the queried object returns None type or data cant be updated in the db.

    :rtype: json
    """
    if not request.json:
        return jsonify({'message': 'No input data provided'}), 400

    content = request.json
    
    if not content:
        return jsonify({'message': 'No input data provided'}), 400

    tab = Tab.get_active_tab()
    if tab== None:
        return jsonify({'message': 'The object is None type,possible reason may be TabId doesn\'t match'}), 400
        
    return jsonify(data)