from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)

from app.models import Template, User
from app import db
from marshmallow import pprint
from sqlalchemy.exc import IntegrityError
from app.models import TemplateSchema
import json

def __init__(self, **kwargs):
    super(Template, self).__init__(**kwargs)

    
def CreateTemplate(request):
    print("Request is : " , request.json)
    if not request.json:
        return jsonify({'message': 'No input data provided '}), 400
    content = request.json["Input"]
    print("User ID",User.get_current_user().id)
    content["user_id"] = User.get_current_user().id
    schema = TemplateSchema()
    templateData = schema.load(content)
    print("Asset Data",templateData)
    newAsset = templateData.data
    newAsset["user"] = User.get_current_user()
    a = Template(**newAsset)
        
    db.session.add(a)
    try:
        db.session.commit()
        return jsonify({"success":True,"message":"Template test1 created successfully."})
    except:
        return json({"sucess": False})
        db.session.rollback()