from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    abort,
    Response
)
from flask_login import (
    current_user,
    login_required,
    login_user,
    logout_user,
)
import base64
from app.models import User

data = {"resetPassword": False, "success": True,
        "isValid": True, "message": ""}
errorData = {"resetPassword": False, "success": False,
             "isValid": True, "message": "Invalid Username/Password"}


def UserLogout(request):
    try:
        logout_user()
        return jsonify({'success': True})
    except:
        return bad_request('some went wrong!')


def bad_request(message):
    response = jsonify({'message': message})
    response.status_code = 401
    return response
