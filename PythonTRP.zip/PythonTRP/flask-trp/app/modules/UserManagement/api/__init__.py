from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    Response
)
from .UserLogin import UserLogin
from .UserLogout import UserLogout
from app.helpers import Solr


def getLoginRoutes(thingworx):
    @thingworx.route('/Things/Keysight.Login.Search/Services/UserLogin', methods=['POST'])
    def userLogin():
        return UserLogin(request)

    @thingworx.route('/Server/%2A/Services/Logout', methods=['POST'])
    def userLogout():
        return UserLogout(request)

    @thingworx.route('/createSolr', methods=['GET'])
    def createSolr():
        return CreateSolr()


def CreateSolr():
    return jsonify(Solr.createCustomer("123"))
