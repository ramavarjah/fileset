from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request,
    jsonify,
    abort,
    Response
)
from flask_login import (
    current_user,
    login_required,
    login_user,
    logout_user,
)
import base64
from app.models import User

data = {"resetPassword": False, "success": True,
        "isValid": True, "message": ""}
errorData = {"resetPassword": False, "success": False,
             "isValid": True, "message": "Invalid Username/Password"}


def UserLogin(request):
    print("Request is : " , request.json)
    """ Description
    :type request: flask-login request object
    :param request: request is the object which we get from the api request
    """
    if not request.json:
        abort(400)
    authHeader = request.headers['Authorization']
    print("authHeader", authHeader)
    creds = authHeader.split(' ')[1]
    decodedCreds = base64.b64decode(
        creds.encode('utf-8')).decode('utf-8').split(':')
    print("decodedCreds", decodedCreds)
    userName = decodedCreds[0]
    password = decodedCreds[1]
    print("creds", creds)
    print("UserName", userName)
    print("password", password)
    if(userName is not None and password is not None):
        user = User.query.filter_by(email=userName).first()
        if user is not None and user.password_hash is not None and \
                user.verify_password(password):
            login_user(user)
            return jsonify(data)
        else:
            return bad_request('invalid Username/ Password')
    return bad_request('invalid Username/ Password')


def bad_request(message):
    response = jsonify({'message': message})
    response.status_code = 401
    return response
