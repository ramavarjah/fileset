from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    url_for,
    request
)
import os
from app.models import User, Role
from flask_security import Security, SQLAlchemyUserDatastore, UserMixin, RoleMixin, login_required
user = Blueprint('user', __name__)
from app import db, FlaskSecurity

app= FlaskSecurity()

# Setup Flask-Security
user_datastore = SQLAlchemyUserDatastore(db, User, Role)
security = Security(app, user_datastore)

# Create a user to test with
# @app.before_first_request
# def create_user():
#     db.create_all()
#     user_datastore.create_user(email='satya.karri@itcinfotech.com', password='password')
#     db.session.commit()


@user.route('/', methods=['GET'])
@login_required
def home():
    #create_user()
    return render_template('user/index.html')