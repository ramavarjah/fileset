from .. import db
from app.models import User


class Tab(db.Model):
    __tablename__ = "Tab"
    TabId = db.Column(db.Integer, primary_key=True)
    baseQuery = db.Column(db.JSON(), unique=False)
    BaseString = db.Column(db.String(), unique=False)
    BucketType = db.Column(db.String(), unique=False)
    ColumnOrder = db.Column(db.JSON(), unique=False)
    ColumnWidth = db.Column(db.JSON(), unique=False)
    DatePreset = db.Column(db.String(), unique=False)
    DisplayDensity = db.Column(db.String(), unique=False)
    FilterQuery = db.Column(db.JSON(), unique=False)
    HiddenColumns = db.Column(db.String(), unique=False)
    NoOfWorkingHours = db.Column(db.Integer, unique=False)
    Pagination = db.Column(db.Integer, unique=False)
    PinColumn = db.Column(db.JSON, default=False)
    SavedSearchId = db.Column(db.String(), unique=False)
    SortedColumns = db.Column(db.JSON(), unique=False)
    # TabId = db.Column(db.String(), unique=False)
    TabName = db.Column(db.String(), unique=False)
    TabOrder = db.Column(db.Integer, unique=False)
    UserName = db.Column(db.String(), unique=False)
    ViewCategoryId = db.Column(db.String(), unique=False)
    ViewEndDate = db.Column(db.DateTime, unique=False)
    ViewStartDate = db.Column(db.DateTime, unique=False)
    ViewTypeId = db.Column(db.String(), unique=False)
    User_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    user = db.relationship("User", back_populates="tabs")

    def get_user_tabs():
        """
            Gettting current user tabs from tabs table
            can be called from anywhere from the application after successful login
        """
        return User.get_current_user().tabs

    def get_active_tab():
        """
            Gettting current user tabs from tabs table
            can be called from anywhere from the application after successful login
        """
        currUser = User.get_current_user()
        activeUserTab = currUser.CurrentTabId
        return Tab.query.get(int(activeUserTab))

    @staticmethod
    def generate_fake(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        from random import seed, choice
        from faker import Faker

        fake = Faker()
        users = User.query.all()

        my_tab_name = ['All Asset', 'conneted asset',
                       ' asset', 'unConnected asset']
        seed()
        for user in users:
            print("generate tabsrs")
            u = Tab(
                baseQuery='{}',
                BaseString='{}',
                BucketType=fake.color_name(),
                ColumnOrder='{}',
                ColumnWidth='{}',
                DatePreset='Today',
                DisplayDensity='default',
                FilterQuery={},
                HiddenColumns='[]',
                NoOfWorkingHours=fake.pyint(),
                Pagination=fake.pyint(),
                PinColumn={"PinnedColumn": {"pinright": [
                    {"colId": "0", "fieldId": 0}], "pinleft": [{}]}},
                SavedSearchId='{}',
                SortedColumns={"array": "[]"},
                # TabId=str(fake.random_number(1, 12)),
                TabName=fake.sentence(ext_word_list=my_tab_name),
                TabOrder=fake.pyint(),
                UserName=fake.email(),
                ViewCategoryId=str(fake.random_number()),
                ViewEndDate=fake.date_between(
                    start_date="-1y", end_date="today"),
                ViewStartDate=fake.date_between(
                    start_date="-30y", end_date="-2y"),
                ViewTypeId=fake.uuid4(),
                user=user,
                **kwargs)
            db.session.add(u)
            try:
                db.session.commit()
                print("generate tabs_Success")
            except IntegrityError:
                print("generate tabs_Failed")
                db.session.rollback()
