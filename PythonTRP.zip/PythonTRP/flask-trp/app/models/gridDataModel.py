from .. import db
from app.static.gridDataModel import gridDataModel
from marshmallow import pprint


class GridDataModel(db.Model):
    __tablename__ = "GridDataModel"
    id = db.Column(db.Integer, primary_key=True)
    dataIndex = db.Column(db.String(), unique=False)
    filter = db.Column(db.String(), unique=False)
    hidden = db.Column(db.Boolean(), unique=False)
    hideable = db.Column(db.Boolean(), unique=False)
    lockable = db.Column(db.Boolean(), unique=False)
    locked = db.Column(db.Boolean(), unique=False)
    renderer = db.Column(db.String(), unique=False)
    sortable = db.Column(db.Boolean(), unique=False)
    text = db.Column(db.String(), unique=False)
    width = db.Column(db.String(), unique=False)
    xtype = db.Column(db.String(), unique=False)

    def __init__(self, **kwargs):
        super(GridDataModel, self).__init__(**kwargs)

    @staticmethod
    def insert_grid_models( **kwargs):
        for datamodel in gridDataModel:
            # pprint(datamodel)
            dm = GridDataModel(
                dataIndex=datamodel['dataIndex'],
                filter=datamodel['filter'],
                hidden=datamodel['hidden'],
                hideable=datamodel['hideable'],
                lockable=datamodel['lockable'],
                locked=datamodel['locked'],
                # renderer=datamodel['renderer'],
                sortable=datamodel['sortable'],
                text=datamodel['text'],
                width=datamodel['width'],
                xtype=datamodel['xtype'],
                **kwargs)
            db.session.add(dm)
            try:
                db.session.commit()
                print("generate assets_Success")
            except IntegrityError:
                print("generate assets_Failed")
                db.session.rollback()
