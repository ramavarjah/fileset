from .. import db


class Organization(db.Model):
    __tablename__ = "Organization"
    id = db.Column(db.Integer, primary_key=True)
    ParentNode = db.Column(db.String(), unique=False)
    DisplayName = db.Column(db.String(), unique=False)
    # ParentBreadcrumb > DisplayName
    Breadcrumb = db.Column(db.String(), unique=False)
    CustomerId = db.Column(db.Integer, db.ForeignKey('Customer.id'))
    customer = db.relationship("Customer", back_populates="organizations")
    #   assets = db.relationship('Asset', backref='location', lazy='dynamic')

    @staticmethod
    def generate_fake(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        from random import seed, choice
        from faker import Faker
        from app.models import Customer

        fake = Faker()
        customers = Customer.query.all()
        for customer in customers:
            u = Organization(
                ParentNode='topNode',
                DisplayName=customer.DisplayName,
                # ParentBreadcrumb > DisplayName
                Breadcrumb=customer.DisplayName,
                customer=customer,
                ** kwargs)
            db.session.add(u)
            try:
                db.session.commit()
                print("generate assets_Success")
            except IntegrityError:
                print("generate assets_Failed")
                db.session.rollback()


        for i in range(count):
            print("generate Top Nodes")
            organizations = Organization.query.all()
            nodeData = choice(organizations)
            dpName = fake.company()
            u1 = Organization(
                ParentNode=nodeData.id,
                DisplayName=dpName,
                # ParentBreadcrumb > DisplayName
                Breadcrumb=nodeData.Breadcrumb+" > "+dpName,
                CustomerId=nodeData.CustomerId,
                ** kwargs)
            db.session.add(u1)
            try:
                db.session.commit()
                print("generate assets_Success")
            except IntegrityError:
                print("generate assets_Failed")
                db.session.rollback()
