from app import FlaskMarshmallow
from app.models import Tab, Asset, IssueLog, User, Organization, Template
ma = FlaskMarshmallow()


class TabSchema(ma.ModelSchema):
    class Meta:
        model = Tab


class AssetSchema(ma.ModelSchema):
    class Meta:
        model = Asset


class IssuelogSchema(ma.ModelSchema):
    class Meta:
        model = IssueLog


class UserSchema(ma.ModelSchema):
    class Meta:
        model = User

class TemplateSchema(ma.ModelSchema):
    class Meta:
        model = Template

class OrganizationSchema(ma.ModelSchema):
    class Meta:
        model = Organization
