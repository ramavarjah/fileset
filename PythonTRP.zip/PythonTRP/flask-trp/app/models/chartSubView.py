from .. import db


class ChartSubView(db.Model):
    __tablename__ = "ChartSubView"
    id = db.Column(db.Integer, primary_key=True)
    Active = db.Column(db.Boolean(), unique=False)
    CategoryId = db.Column(db.String(), unique=False)
    ChartId = db.Column(db.String(), unique=False)
    EndDate = db.Column(db.String(), unique=False)
    File = db.Column(db.String(), unique=False)
    PropertyName = db.Column(db.String(), unique=False)
    StartDate = db.Column(db.String(), unique=False)
    value = db.Column(db.String(), unique=False)
    tab_id = db.Column(db.Integer, db.ForeignKey('Tab.TabId'))
   