from .. import db


class Location(db.Model):
    __tablename__ = "Location"
    id = db.Column(db.Integer, primary_key=True)
    ParentBreadcrumb = db.Column(db.String(), unique=False)
    NodeLevel = db.Column(db.INTEGER, unique=False)
    DisplayName = db.Column(db.String(), unique=False)
    Breadcrumb =  db.Column(db.String(), unique=False)
    CustomerId =  db.Column(db.String(), unique=False)
    name = db.Column(db.String(), unique=False)
    description = db.Column(db.String(), unique=False)
    thingTemplate = db.Column(db.String(), unique=False)
    tags = db.Column(db.String(), unique=False)
    #   assets = db.relationship('Asset', backref='location', lazy='dynamic')