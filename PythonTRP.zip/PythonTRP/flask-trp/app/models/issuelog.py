from .. import db

class IssueLog(db.Model):
    __tablename__ = "IssueLog"
    id = db.Column(db.Integer, primary_key=True)
    Status = db.Column(db.String(), unique=False)
    DateOpened = db.Column(db.DateTime, unique=False)
    Category = db.Column(db.String(), unique=False)
    Description = db.Column(db.String(), unique=False)
    NotificationId = db.Column(db.String(), unique=False)
    Customer = db.Column(db.String(), unique=False)
    SubmittedBy = db.Column(db.String(), unique=False)
    Severity = db.Column(db.String(), unique=False)
    CustomerId = db.Column(db.String(), unique=False)
    History = db.Column(db.String(), unique=False)
    Implication = db.Column(db.String(), unique=False)
    AssignedTo = db.Column(db.String(), unique=False)
    IssueSummary = db.Column(db.String(120), unique=False, nullable = False)
    IssueId = db.Column(db.String(), unique=False)
    description = db.Column(db.String(), unique=False)
    thingTemplate = db.Column(db.String(), unique=False)
    tags = db.Column(db.String(), unique=False)
    #issuelog_id = db.Column(db.Integer, db.ForeignKey('issuelogs.id'))

    def __init__(self, Status, DateOpened, Category, Description, NotificationId, Customer,
                 SubmittedBy, Severity, CustomerId, History,  Implication, AssignedTo,  IssueSummary, IssueId,
                 description, thingTemplate, tags):
        self.Status = Status
        self.DateOpened = DateOpened
        self.Category = Category
        self.Description = Description
        self.NotificationId = NotificationId
        self.Customer = Customer
        self.SubmittedBy = SubmittedBy
        self.Severity = Severity
        self.CustomerId = CustomerId
        self.History = History
        self.Implication = Implication
        self.AssignedTo = AssignedTo
        self.IssueSummary = IssueSummary
        self.IssueId = IssueId
        self.description = description
        self.thingTemplate = thingTemplate
        self.tags = tags

    def __repr__(self):
        return '<Customer Name %r>' %  self.Customer
