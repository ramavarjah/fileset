from .. import db
from sqlalchemy.orm import relationship
from app.models import Tab

class ChartView(db.Model):
    __tablename__ = "ChartView"
    id = db.Column(db.Integer, primary_key=True)
    CategoryId = db.Column(db.String(64), unique=False)
    Active = db.Column(db.Boolean, unique=False)
    Date = db.Column(db.Date(), unique=False)
    SubCategory = db.Column(db.Boolean(), unique=False)
    Textbox = db.Column(db.String(128), unique=False)
    ViewName = db.Column(db.String(64), unique=False)
    tab_id = db.Column(db.Integer, db.ForeignKey('Tab.TabId'))
    

    @staticmethod
    def generate_fake(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        from random import seed, choice
        from faker import Faker
        from random import randint

        fake = Faker()
        tabs = Tab.query.all()

        seed()
        for i in range(count):
            print("generate users")
            catId = randint(1,5)
            if catId == 1 :
                catSubId = randint(1,4)
            elif catId == 2 :
                catSubId = randint(5,8)
            elif catId == 3 :
                catSubId = randint(12,17)
            elif catId == 4 :
                catSubId = 10
            elif catId == 5 :
                catSubId = 11
            
            u = ChartView(
                CategoryId = catId,
                Active = fake.Active(),
                Date = fake.date_this_year(),
                SubCategory = catSubId,
                Textbox = fake.Boolean(),
                ViewName = 'Charview',
                #confirmed=True,
                tab_id=choice(tabs),
                **kwargs)
            db.session.add(u)
            try:
                db.session.commit()
                print("generate chartview_Success")
            except IntegrityError:
                print("generate chartview_Failed")
                db.session.rollback()