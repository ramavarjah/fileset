from app import db
from app.models import User
from app import FlaskMarshmallow

ma = FlaskMarshmallow()


class Asset(db.Model):
    __tablename__ = "Asset"
    id = db.Column(db.Integer, primary_key=True)
    ParentSystemName = db.Column(db.String(), unique=False)
    UniqueID = db.Column(db.String(), unique=False)
    UtilizationCategory = db.Column(db.String(), unique=False)
    CalibrationInterval = db.Column(db.Integer, unique=False)
    LastUpdate = db.Column(db.DateTime, unique=False)
    AssetNo = db.Column(db.String(), unique=False)
    BorrowereReturnDate = db.Column(db.DateTime, unique=False)
    OrderNumber = db.Column(db.String(), unique=False)
    LifeCycleStage = db.Column(db.String(), unique=False)
    UseProviderCalibrationType = db.Column(db.Boolean, unique=False)
    History = db.Column(db.String(), unique=False)
    UseProviderCalibrationSchedule = db.Column(db.Boolean, unique=False)
    EquipmentType = db.Column(db.String(), unique=False)
    RepairProvider = db.Column(db.Boolean, default=False)
    SubscribedUsers = db.Column(db.String(), unique=False)
    ServiceAgreement = db.Column(db.String(), unique=False)
    LastServiceDate = db.Column(db.DateTime, unique=False)
    ReplacedBy = db.Column(db.String(), unique=False)
    CalibrationProvider = db.Column(db.String(), unique=False)
    OOTGroup = db.Column(db.String(), unique=False)
    Currency = db.Column(db.String(), unique=False)
    ServiceInterval = db.Column(db.Integer, unique=False)
    BorrowerStartDate = db.Column(db.DateTime, unique=False)
    Manufacturer = db.Column(db.String(), unique=False, nullable= True)
    InvoiceNumber = db.Column(db.String(), unique=False)
    PlannedDisposalDate = db.Column(db.DateTime, unique=False)
    AltManufacturerName = db.Column(db.String(), unique=False)
    Status = db.Column(db.String(), unique=False)
    InventoryDate = db.Column(db.DateTime, unique=False)
    SerialNo = db.Column(db.String(), unique=False)
    HealthStatus = db.Column(db.String(), unique=False)
    SoftwareRevision = db.Column(db.String(), unique=False)
    WorkFlowState = db.Column(db.String(), unique=False)
    HardwareVersion = db.Column(db.String(), unique=False)
    LastReportedCondition = db.Column(db.String(), unique=False)
    Project = db.Column(db.String(), unique=False)
    Depreciation = db.Column(db.Integer, unique=False)
    ReceivedDate = db.Column(db.DateTime, unique=False)
    Barcode = db.Column(db.String(), unique=False)
    OrganizationUnit = db.Column(db.String(), unique=False)
    ProductCategory = db.Column(db.String(), unique=False, nullable= True)
    LoanAutoCalculate = db.Column(db.Boolean, unique=False)
    OwnershipStatus = db.Column(db.String(), unique=False)
    LoanpoolStatus = db.Column(db.String(), unique=False)
    Options = db.Column(db.DateTime, unique=False)
    Description = db.Column(db.String(), unique=False)
    Organization = db.Column(db.String(), unique=False, nullable= True)
   # User = db.Column(db.String(), unique=False)
    LoanDailyRate = db.Column(db.Integer, unique=False)
    InfolineAssetKey = db.Column(db.String(), unique=False)
    SystemParent = db.Column(db.Boolean, unique=False)
    BookValueDate = db.Column(db.DateTime, unique=False)
    ReplacementDate = db.Column(db.DateTime, unique=False)
    PurchasePrice = db.Column(db.Integer, unique=False)
    Information = db.Column(db.String(), unique=False)
    PartOfSystemCalibration = db.Column(db.Boolean, unique=False)
    CalibrationDate = db.Column(db.DateTime, unique=False)
    Accessories = db.Column(db.String(), unique=False)
    AssetLocation = db.Column(db.String(), unique=False)
    OOTInvestigator = db.Column(db.String(), unique=False)
    SystemChild = db.Column(db.Boolean, unique=False)
    RemoteThing = db.Column(db.String(), unique=False)
    CalibrationDueDate = db.Column(db.DateTime, unique=False)
    SystemComponents = db.Column(db.String(), unique=False)
    SystemName = db.Column(db.String(), unique=False)
    DepreciationRate = db.Column(db.Integer, unique=False)
    OOTStatus = db.Column(db.String(), unique=False)
    EquipmentNo = db.Column(db.String(), unique=False)
    Borrowable = db.Column(db.Boolean, unique=False)
    IsUtilization = db.Column(db.Boolean, unique=False)
    OOTReviewer = db.Column(db.String(), unique=False)
    Borrower = db.Column(db.String(), unique=False)
    OwningCompany = db.Column(db.String(), unique=False)
    ServiceDueDate = db.Column(db.DateTime, unique=False)
    ServiceLogistics = db.Column(db.String(), unique=False)
    Request = db.Column(db.String(), unique=False)
    Coordinator = db.Column(db.String(), unique=False,nullable= True)
    RequestorEmail = db.Column(db.String(), unique=False)
    OrderDate = db.Column(db.DateTime, unique=False)
    IsIndexed = db.Column(db.Boolean, unique=False)
    ModelNo = db.Column(db.String(), unique=False, nullable= True)
    UseDefaultProvider = db.Column(db.Boolean, unique=False)
    BookValue = db.Column(db.Integer, unique=False)
    LoanDailyCost = db.Column(db.Integer, unique=False)
    ServiceCost = db.Column(db.Integer, unique=False)
    CalibrationType = db.Column(db.String(), unique=False)
    FirmwareRevision = db.Column(db.String(), unique=False)
    IsConnected = db.Column(db.Boolean, unique=False)
    Location = db.Column(db.String(), unique=False, nullable= True)
    StickyNotes = db.Column(db.String(), unique=False)
    LastCalibrationDate = db.Column(db.DateTime, unique=False)
    CustomerId = db.Column(db.Integer, unique=False)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    user = db.relationship("User", back_populates="assets")


    def __init__(self, **kwargs):
        super(Asset, self).__init__(**kwargs)

    def get_user_assets():
        """
            Gettting current user from user table
            can be called from anywhere from the application after successful login
        """
        from app.models import AssetSchema
        currUser = User.get_current_user()
        assets = Asset.query.filter_by(user_id=currUser.id).all()
        schema = AssetSchema()
        customerAssets = []
        for asset in assets:
            customerAssets.append(schema.dump(asset).data)
        return customerAssets
    @staticmethod
    def generate_fake(count=100, **kwargs):
        """Generate a number of fake users for testing."""
        from sqlalchemy.exc import IntegrityError
        from random import seed, choice
        from faker import Faker

        fake = Faker()
        users = User.query.all()

        seed()
        x = 0
        for i in range(count):
            print("generate users")
            x = x+1
            u = Asset(
                # ParentSystemName="TEST",
                # UniqueID="TEST",
                # UtilizationCategory="TEST",
                ParentSystemName=fake.company(),
                UniqueID=fake.uuid4(),
                UtilizationCategory='active',
                CalibrationInterval=fake.random_number(),
                LastUpdate=fake.date_between(
                    start_date="-3y", end_date="today"),
                AssetNo=fake.random_number(2),
                BorrowereReturnDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                OrderNumber=fake.uuid4(),
                LifeCycleStage=fake.word(),
                UseProviderCalibrationType=fake.boolean(),
                History=fake.sentence(),
                UseProviderCalibrationSchedule=fake.boolean(),
                EquipmentType=fake.word(["Mechanical", "Electrical", "Smart"]),
                RepairProvider=fake.boolean(),
                SubscribedUsers=fake.first_name(),
                ServiceAgreement=fake.uuid4(),
                LastServiceDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                ReplacedBy=fake.first_name(),
                CalibrationProvider=fake.company(),
                OOTGroup=fake.word(),
                Currency=fake.currency_name(),
                ServiceInterval=fake.random_number(),
                BorrowerStartDate=fake.date_time(
                    tzinfo=None, end_datetime=None),
                Manufacturer=fake.company(),
                InvoiceNumber=fake.uuid4(),
                PlannedDisposalDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                AltManufacturerName=fake.company(),
                Status=fake.word(["active", "inactive"]),
                InventoryDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                SerialNo=fake.uuid4(),
                HealthStatus=fake.word(
                    ["enable", "active", "disable", "inactive"]),
                SoftwareRevision='1.7',
                WorkFlowState='yes',
                HardwareVersion='1.0',
                LastReportedCondition=fake.word(
                    ["working", "non-working", "Suspected"]),
                Project=fake.word(["Keysight", "Flask", "Keysight_off_shore"]),
                Depreciation=2.0,
                ReceivedDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                Barcode=fake.uuid4(),
                OrganizationUnit=fake.company(),
                ProductCategory=fake.word(),
                LoanAutoCalculate=fake.boolean(),
                OwnershipStatus='done',
                LoanpoolStatus='done',
                Options=fake.date_between(start_date="-3y", end_date="today"),
                Description=fake.sentence(),
                Organization=fake.company(),
                # User = db.Column(db.String(), unique=False)
                LoanDailyRate=fake.random_number(),
                InfolineAssetKey=fake.word(),
                SystemParent=fake.boolean(),
                BookValueDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                ReplacementDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                PurchasePrice=fake.random_number(),
                Information='development',
                PartOfSystemCalibration=fake.boolean(),
                CalibrationDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                Accessories=fake.sentence(),
                AssetLocation=fake.city(),
                OOTInvestigator=fake.first_name(),
                SystemChild=fake.boolean(),
                RemoteThing=fake.word(),
                CalibrationDueDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                SystemComponents=fake.word(),
                SystemName=fake.company(),
                DepreciationRate=fake.random_number(),
                OOTStatus="Active",
                EquipmentNo=fake.uuid4(),
                Borrowable=fake.boolean(),
                IsUtilization=fake.boolean(),
                OOTReviewer=fake.first_name(),
                Borrower=fake.last_name(),
                OwningCompany=fake.company(),
                ServiceDueDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                ServiceLogistics=fake.word(),
                Request=fake.uuid4(),
                Coordinator=fake.first_name(),
                RequestorEmail=fake.email(),
                OrderDate=fake.date_between(
                    start_date="-3y", end_date="today"),
                IsIndexed=fake.boolean(),
                ModelNo=fake.uuid4(),
                UseDefaultProvider=fake.boolean(),
                BookValue=fake.random_number(),
                LoanDailyCost=fake.random_number(),
                ServiceCost=fake.random_number(),
                CalibrationType=fake.word(),
                FirmwareRevision="2.03",
                IsConnected=fake.boolean(),
                Location=fake.city(),
                StickyNotes=fake.words(),
                LastCalibrationDate = fake.date_between(
                    start_date="-3y", end_date="today"),
                CustomerId = fake.random_number(),
                user=choice(users),
                **kwargs)

            db.session.add(u)
            try:
                db.session.commit()
                print("generate assets_Success")
            except IntegrityError:
                print("generate assets_Failed")
                db.session.rollback()
