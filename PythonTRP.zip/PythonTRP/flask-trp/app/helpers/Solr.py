import requests

solrIp = "https://192.168.70.181:8983"
instanceDir = "/home/champ/Downloads/solr-6.0.1/server/solr/"


def createCore(coreName):
    r = requests.get(solrIp+"/solr/admin/cores?action=CREATE&name="+coreName +
                     "&instanceDir="+instanceDir+coreName+"&configSet=KeysightConfig", verify=False)
    response = {
        "response": r.text,
        "status": r.status_code,
        "content_type": r.headers['content-type']
    }
    return response


def createCustomer(CustomerId):
    return {
        "Health": createCore(CustomerId+"-Health"),
        "Utilization": createCore(CustomerId+"-Utilization"),
        "CustomerId": createCore(CustomerId)
    }
