#!/usr/bin/env python
import os
import subprocess

from flask_migrate import Migrate, MigrateCommand
from flask_script import Manager

from app import create_app, db
from app.models import Customer, User, Role, Asset, Tab, GridDataModel,Organization
from config import Config
from app.factory import UserFactory, OrganizationFactory, CustomerFactory, LocationFactory,\
    CharsubViewFactory, CharviewFactory, GridDataModelFactory

app = create_app(os.getenv('FLASK_CONFIG') or 'default')
manager = Manager(app)
migrate = Migrate(app, db)


def make_shell_context():
    return dict(app=app, db=db, Customer=Customer, User=User)


manager.add_command('db', MigrateCommand)


@manager.command
def test():
    """Run the unit tests."""
    import unittest

    tests = unittest.TestLoader().discover('tests')
    unittest.TextTestRunner(verbosity=2).run(tests)


@manager.command
def recreate_db():
    """
    Recreates a local database. You probably should not use this on
    production.
    """
    db.drop_all()
    db.create_all()
    db.session.commit()


@manager.option(
    '-n',
    '--number-users',
    default=10,
    type=int,
    help='Number of each model type to create',
    dest='number_users')
def add_fake_data(number_users):
    """
    Adds fake data to the database.
    """
    # users = UserFactory.build_batch(10)
    CustomerFactory.build_batch(10)
    User.generate_fake(count=number_users)
    Asset.generate_fake(count=number_users)
    Organization.generate_fake(count=200)
    Tab.generate_fake(count=number_users)
    # for customer in customers:
    #     print(customer)
    #     UserFactory.create(customer=customer)
    # UserFactory.generate_user(count=number_users)
    # OrganizationFactory.generate_organization(count=number_users)
    # LocationFactory.generate_location(count=number_users)
    # CharsubViewFactory.generate_Charsubview(count=number_users)
    # CharviewFactory.generate_Charview(count=number_users)
    # GridDataModelFactory.generate_Griddatamodel(count=number_users)


@manager.command
def setup_dev():
    """Runs the set-up needed for local development."""
    setup_general()


@manager.command
def recreate_all():
    """Runs the set-up needed for local development."""
    recreate_db()
    setup_dev()
    add_fake_data(number_users=10)


@manager.command
def setup_prod():
    """Runs the set-up needed for production."""
    setup_general()


def setup_general():
    """Runs the set-up needed for both local development and production.
       Also sets up first admin user."""
    Role.insert_roles()
    admin_query = Role.query.filter_by(name='Administrator')
    if admin_query.first() is not None:
        if User.query.filter_by(email=Config.ADMIN_EMAIL).first() is None:
            user = User(
                first_name='Admin',
                last_name='Account',
                password=Config.ADMIN_PASSWORD,
                confirmed=True,
                email=Config.ADMIN_EMAIL)
            db.session.add(user)
            db.session.commit()
            print('Added administrator {}'.format(user.full_name()))
        GridDataModel.insert_grid_models()


if __name__ == '__main__':
    manager.run()
